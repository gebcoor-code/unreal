# mktrd.py IN.trd OUT.trd FILE..: a CP/M (ATM) disk image - the files written into it (the directory: at #2000, 128
# entries, 2048-byte blocks, 16-bit block numbers, 8 a 16K extent); the same names replaced, the others kept
import sys, os
img = bytearray(open(sys.argv[1], 'rb').read()); BASE, BS, NE = 0x2000, 2048, 128
NB = (len(img) - BASE) // BS
def name(f):
    n, _, x = os.path.basename(f).upper().partition('.'); return n.ljust(8)[:8].encode() + x.ljust(3)[:3].encode()
new = {name(f): f for f in sys.argv[3:]}
used = {0, 1}; keep = []
for e in range(NE):
    d = img[BASE + e * 32:BASE + e * 32 + 32]
    if d[0] == 0xE5: continue
    if bytes(d[1:12]) in new: continue
    keep.append(bytes(d)); used |= {int.from_bytes(d[16 + 2 * i:18 + 2 * i], 'little') for i in range(8)} - {0}
ents = list(keep)
free = (b for b in range(2, NB) if b not in used)
for nm, f in new.items():
    data = open(f, 'rb').read()
    pad = 0x1A if nm.endswith(b'TXT') else 0
    if len(data) % 128: data += bytes([pad]) * (128 - len(data) % 128)
    for ex in range(max(1, (len(data) + 16383) // 16384)):
        part = data[ex * 16384:(ex + 1) * 16384]; bl = []
        for k in range(0, len(part), BS):
            b = next(free); bl.append(b); c = part[k:k + BS]
            img[BASE + b * BS:BASE + b * BS + BS] = c + bytes([0xE5]) * (BS - len(c))
        bl += [0] * (8 - len(bl))
        ents.append(bytes([0]) + nm + bytes([ex & 31, 0, ex >> 5, len(part) // 128]) + b''.join(x.to_bytes(2, 'little') for x in bl))
assert len(ents) <= NE
for e in range(NE): img[BASE + e * 32:BASE + e * 32 + 32] = ents[e] if e < len(ents) else bytes([0xE5]) * 32
open(sys.argv[2], 'wb').write(img); print(len(ents), 'entries', sorted(n.decode() for n in new))
