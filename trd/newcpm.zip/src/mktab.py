# tables for DZFX (the scroll's band left out): 64 angles x 64 depths x 4 bytes (the Dizzy 5 intro's polar table, for the ATM's screen)
# mode 640: lo, hi (#C000 + y*40 + col/2, odd columns +#2000), pixel mask, 0;  invalid: hi = 0
# mode 320: lo, hi (#C000 + y*40 + pair/4, pairs 2,3 mod 4 +#2000), side (0 left, 1 right), #FFF7 value (page 1 / 5)
import math, sys
mode = sys.argv[1]
W = 640 if mode == '640' else 320
XS = 2.0 if mode == '640' else 1.0          # 640x200: pixels half as wide
CX, CY = W / 2, 100
RMIN = 14 * 100 / 96                        # Dizzy: 14 of 96 (half height)
BY = 133                                    # the scroll's band: lines BY .. BY + 23 (no points there - behind it)
B = 70.8
t = bytearray()
for a in range(64):
    ang = a * 2 * math.pi / 64
    for c in range(64):
        r = RMIN * B / (B - c)
        x = int(round(CX + r * math.cos(ang) * XS)); y = int(round(CY + r * math.sin(ang)))
        if not (0 <= x < W and 0 <= y < 200) or BY <= y < BY + 24: t += bytes(4); continue
        if mode == '640':
            col = x >> 3; ad = 0xC000 + y * 40 + (col >> 1) + (0x2000 if col & 1 else 0)
            t += bytes([ad & 255, ad >> 8, 0x80 >> (x & 7), 0])
        else:
            p = x >> 1; q = p & 3; ad = 0xC000 + y * 40 + (p >> 2) + (0x2000 if q >= 2 else 0)
            t += bytes([ad & 255, ad >> 8, x & 1, 0x7E if q in (0, 2) else 0x7A])
open('tab%s.bin' % mode, 'wb').write(t)
# colours per point: 64 x [dim, bright] (640: attribute, ink only; 320: [left, right] pixel bits each)
cols = [9, 10, 11, 12, 13, 14, 15]
c = bytearray()
for i in range(64):
    k = cols[i % 7]
    for br in (0, 1):
        v = k if br else (k & 7)
        if mode == '640': c += bytes([(v & 7) | (64 if v & 8 else 0), 0])
        else: c += bytes([(v & 7) | ((v & 8) << 3), ((v & 7) << 3) | ((v & 8) << 4)])
open('col%s.bin' % mode, 'wb').write(c)
