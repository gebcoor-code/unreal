# dizzy5.ctr (the ASC compiled module: player + module, #C000..) from the Dizzy 5 intro snapshot (the font, the
# text: mkfont.py)
import sys
sna = open(sys.argv[1], 'rb').read(); out = sys.argv[2]
p7 = sna[49181]; cur = p7 & 7
mem = bytearray(65536); mem[0x4000:0x8000] = sna[27:27 + 16384]; mem[0x8000:0xC000] = sna[27 + 16384:27 + 32768]
mem[0xC000:] = sna[27 + 32768:27 + 49152]
# the music: the ASC compiled block (player + module) at #C000
ctr = bytes(mem[0xC000:0xD286]); open(out + '/dizzy5.ctr', 'wb').write(ctr)
print('ctr', len(ctr))
