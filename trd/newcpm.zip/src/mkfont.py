# mkfont.py DIZ.FNT OUTDIR [TEXT]: font.fnt (256 x 8, KOI8-R) from DIZ.FNT (128 x 8: #20..#5F ASCII capitals,
# #61..#7D Cyrillic in KOI-7 order, #40 = Ю, #3C = Щ, #3E = Э, #7D = Ш, #7B = Ч, #7C = Ъ), text.txt in KOI8-R
import sys
d = open(sys.argv[1], 'rb').read(); out = sys.argv[2]
F = lambda c: d[c * 8:c * 8 + 8]
def g(rows): return bytes(int(r.replace('.', '0').replace('#', '1'), 2) for r in rows)
OWN = {   # the ASCII ones DIZ.FNT has Cyrillic (or else) in place of
 0x40: ['........', '.#####..', '##...##.', '##.####.', '##.####.', '##......', '.#####..', '........'],   # @
 0x3C: ['........', '....##..', '...##...', '..##....', '...##...', '....##..', '........', '........'],   # <
 0x3E: ['........', '..##....', '...##...', '....##..', '...##...', '..##....', '........', '........'],   # >
 0x5B: ['........', '.####...', '.##.....', '.##.....', '.##.....', '.##.....', '.####...', '........'],   # [
 0x5D: ['........', '.####...', '...##...', '...##...', '...##...', '...##...', '.####...', '........'],   # ]
 0x5E: ['........', '...#....', '..###...', '.##.##..', '........', '........', '........', '........'],   # ^
 0x7C: ['........', '...##...', '...##...', '...##...', '...##...', '...##...', '...##...', '........'],   # |
}
fnt = bytearray(2048)
for c in range(0x20, 0x60): fnt[c * 8:c * 8 + 8] = F(c)
for c in range(0x61, 0x7B): fnt[c * 8:c * 8 + 8] = F(c - 0x20)             # a..z: as A..Z
for c, rows in OWN.items(): fnt[c * 8:c * 8 + 8] = g(rows)
fnt[0x60 * 8:0x61 * 8] = F(0x27)                                             # `
fnt[0x7B * 8:0x7C * 8] = F(0x28); fnt[0x7D * 8:0x7E * 8] = F(0x29)           # { }: ( )
fnt[0x7E * 8:0x7F * 8] = F(0x7E)                                             # ~
cyr = {'ю': 0x40, 'а': 0x61, 'б': 0x62, 'ц': 0x63, 'д': 0x64, 'е': 0x65, 'ф': 0x66, 'г': 0x67, 'х': 0x68, 'и': 0x69,
       'й': 0x6A, 'к': 0x6B, 'л': 0x6C, 'м': 0x6D, 'н': 0x6E, 'о': 0x6F, 'п': 0x70, 'я': 0x71, 'р': 0x72, 'с': 0x73,
       'т': 0x74, 'у': 0x75, 'ж': 0x76, 'в': 0x77, 'ь': 0x78, 'ы': 0x79, 'з': 0x7A, 'ш': 0x7D, 'э': 0x3E, 'щ': 0x3C,
       'ч': 0x7B, 'ъ': 0x7C, 'ё': 0x65}
for ch, k in cyr.items():                                                    # both cases: the capitals
    for c in (ch, ch.upper()):
        b = c.encode('koi8_r'); fnt[b[0] * 8:b[0] * 8 + 8] = F(k)
fnt[0xBF * 8:0xC0 * 8] = F(0x7F)                                             # ©
open(out + '/font.fnt', 'wb').write(fnt)
if len(sys.argv) > 3:
    t = sys.argv[3]
    open(out + '/text.txt', 'wb').write((t + ' ' * 7 + '\r\n').encode('koi8_r'))   # (+ the gap before it again)
