; DZFX: the Dizzy 5 intro (128K) for ATM Turbo 2+ CP/M - the dots flying out of a circle, the scroll, the music
; -DHI: 640x200 (pixels page 5, attributes page 1), else 320x200x16 (pages 1, 5)
; Dots: 64 points, each with its own angle (64 steps) and depth (64 steps); every frame all of them move by the
; same step in depth (+-1 / 0) and angle (+-1 / 0); a new direction (8 kinds) every 256 frames. Depth wraps: out
; of the screen's edge -> back on the circle.
; Scroll (as the intro's): FONT.FNT (256 x 8 bytes, KOI8-R), TEXT.TXT (a line's end: one space; ^Z / the file's
; end: the end, then from the start again) - each letter 2x wide (640x200: 4x, the same look), 3x high, at the
; intro's speed (a font pixel in 2 frames), lines BY..BY+23 (the points not drawn there: behind it). 7 MHz: 50 fps.
; Music: DIZZY5.CTR - the intro's ASC Sound Master compiled module (player + module, made for #C000): in page
; MUSPG, at #C000 (W3) for its calls - init #C09A, each frame #C00E.
; Any file missing: that part off. A key: back to CP/M.
        DEVICE NOSLOT64K
BDOS    equ 5
FCB     equ #5C
P_CPM   equ #7C                 ; #FFF7: page 3 (CP/M) / 5 / 1
P_5     equ #7A
P_1     equ #7E
MUSPG   equ 31                  ; the music's page (free under CP/M)
P_MUS   equ #7F-MUSPG
DIM_D   equ 24                  ; depth below: the dim colour
BY      equ 133                 ; the scroll's first line (mktab.py's BY)

        org #100
start   ld sp,stk
        ; the files (CP/M's file calls: before the screen changes)
        ld hl,wrk : ld de,wrk+1 : ld bc,wrk_e-wrk-1 : ld (hl),0 : ldir
        ld hl,n_fnt : ld de,fnt : ld bc,2048 : call load : ld (f_fnt),a
        ld hl,n_txt : ld de,txt : ld bc,TXTMAX : call load : ld (f_txt),a
        ld hl,n_mus : ld de,txt+TXTMAX : ld bc,#1400 : call load : ld (f_mus),a
        call t_prep
        ld de,m_on : ld c,9 : call BDOS
        di
        ld a,P_5 : call cls
        ld a,P_1 : call cls
        IFDEF HI
        ld bc,#FFF7 : ld a,P_1 : out (c),a              ; the band's attributes: white on black
        ld hl,#C000+BY*40 : ld a,#47 : call 2F : ld hl,#E000+BY*40 : ld a,#47 : call 2F
        ENDIF
        ld a,(f_mus) : or a : jr z,1F                   ; the music into its page, its init
        ld bc,#FFF7 : ld a,P_MUS : out (c),a
        ld hl,txt+TXTMAX : ld de,#C000 : ld bc,#1400 : ldir
        call #C09A
1       ld bc,#FFF7 : ld a,P_CPM : out (c),a
        ei
        ; the points: angle (i + 12) & 63 (as Dizzy), depth random
        ld hl,pts : ld b,64 : ld c,12
1       ld a,r : add a,b : ld e,a : ld a,(seed) : rlca : xor e : ld (seed),a
        and #FC : ld (hl),a : inc hl
        ld a,c : and 63 : add a,high tab : ld (hl),a : inc hl
        inc c : djnz 1B
main    ei : halt
        di
        ld a,(f_mus) : or a : jr z,1F
        ld bc,#FFF7 : ld a,P_MUS : out (c),a : call #C00E
1       call frame
        call scroll
        ld bc,#FFF7 : ld a,P_CPM : out (c),a
        ei
        ld e,#FF : ld c,6 : call BDOS : or a : jr z,main
        call ay_off
        ld de,m_off : ld c,9 : call BDOS
        rst 0
2       ld d,h : ld e,l : inc de : ld (hl),a : ld bc,24*40-1 : ldir : ret

; the AY quiet: the three volumes 0
ay_off  ld a,8
1       ld bc,#FFFD : out (c),a : ld b,#BF : ld e,0 : out (c),e
        inc a : cp 11 : jr c,1B
        ret

; HL = the name (11 bytes), DE = where, BC = the most: the file read (128 at a time) -> A = 1 read (0: not there,
; nothing); the rest of the space zeroed first
load    push hl : push de : push bc
        ld h,d : ld l,e : inc de : dec bc : ld (hl),0 : ldir
        ld hl,FCB : ld (hl),0 : ld de,FCB+1 : ld bc,35 : ldir
        pop bc : pop de : pop hl
        push de : push bc : ld de,FCB+1 : ld bc,11 : ldir : pop bc : pop de
        push de : push bc : ld de,FCB : ld c,15 : call BDOS : pop bc : pop de
        inc a : ret z                                   ; (#FF: not there)
1       ld a,b : or a : jr nz,2F : ld a,c : cp 128 : jr c,9F   ; (no room for 128 more)
2       push de : push bc : ld c,26 : call BDOS
        ld de,FCB : ld c,20 : call BDOS : pop bc : pop de
        or a : jr nz,9F
        ld hl,128 : add hl,de : ex de,hl
        ld hl,-128 : add hl,bc : ld b,h : ld c,l : jr 1B
9       ld a,1 : ret
n_fnt   db "FONT    FNT"
n_txt   db "TEXT    TXT"
n_mus   db "DIZZY5  CTR"
f_fnt   db 0
f_txt   db 0
f_mus   db 0

; the text as read -> as shown: ^Z / 0 the end, CR none, LF / TAB a space; no font or no text: no scroll
t_prep  ld a,(f_fnt) : ld hl,f_txt : and (hl) : ld (hl),a : ret z
        ld hl,txt : ld de,txt
1       ld a,(hl) : inc hl
        cp #1A : jr z,8F : or a : jr z,8F
        cp 13 : jr z,1B
        cp 10 : jr z,2F : cp 9 : jr nz,3F
2       ld a,' '
3       ld (de),a : inc de : jr 1B
8       xor a : ld (de),a
        ld a,(txt) : or a : jr nz,9F : ld (f_txt),a     ; (empty: none)
9       ld hl,txt : ld (t_ptr),hl : ret

; ---- the scroll
        IFDEF HI
; 640x200: the unit is 2 pixels (half a font pixel) - one a frame. The stream: unit n (from the start); a screen
; row shows units pos..pos+319 (pos = n - 319, n the newest): its byte j (0..79) = units pos+4j..+3 = entry k =
; (pos >> 2) + j of array phase pos & 3. Each row: 8 arrays (phase x the entry's parity), entry k at (k >> 1) & 63
; and again at +64 (a ring: 40 bytes read from anywhere - no wrap); the even screen bytes (#C000..) from one
; parity's array, the odd (#E000..) from the other's - straight copies. Each frame one entry a row is new: the row's
; last 4 units (R = R << 2 | the unit).
RL      equ 128                                         ; an array's length (8 x 8 of them: rows 1024 apart)
scroll  ld a,(f_txt) : or a : ret z
        ld a,(s_n) : and 1 : jr nz,2F                   ; a new font column every 2 units
        ld hl,s_col : dec (hl) : jr nz,1F
        ld (hl),8 : call t_glyph : ld de,s_gl : ld bc,8 : ldir   ; the next letter's 8 rows
1       ld hl,s_gl : ld de,s_rc+1 : ld b,8
11      ld a,(hl) : add a,a : ld (hl),a : sbc a,a : and 3 : ld (de),a    ; the column's pixel: unit 3 / 0
        inc hl : inc de : inc de : djnz 11B
2       ; the entry m = n - 3: array (m & 3) * 2 + ((m >> 2) & 1), at (m >> 3) & 63 (+64)
        ld hl,(s_n) : ld bc,-3 : add hl,bc
        call s_ent
        ld de,s_rc : ld b,8
3       ld a,(de) : add a,a : add a,a : inc de : ex de,hl : or (hl) : ex de,hl : dec de
        ld (de),a : inc de : inc de                     ; R (each row's)
        ld (hl),a : set 6,l : ld (hl),a : res 6,l
        ld a,h : add a,4 : ld h,a : djnz 3B
        ld hl,(s_n) : inc hl : ld (s_n),hl
        ; drawn: pos = n - 319 (the new n - 320)
        ld bc,-320 : add hl,bc
        push hl : call s_ent : ld (s_s1),hl : pop hl    ; the even screen bytes: array (phase, (pos >> 2) & 1)
        ld bc,4 : add hl,bc                             ; the odd: entry k + 1 (pos + 4)
        call s_ent : ld (s_s2),hl
        ld bc,#FFF7 : ld a,P_5 : out (c),a
        ld de,#C000+BY*40 : ld b,8
5       push bc : ld b,3
6       push bc
        ld hl,(s_s1) : push de : call ldi40 : pop de
        ld hl,(s_s2) : set 5,d : push de : call ldi40 : pop de : res 5,d
        ex de,hl : ld bc,40 : add hl,bc : ex de,hl
        pop bc : djnz 6B
        ld hl,(s_s1) : ld bc,8*RL : add hl,bc : ld (s_s1),hl
        ld hl,(s_s2) : add hl,bc : ld (s_s2),hl
        pop bc : djnz 5B
        ret
; HL = unit m -> HL = row 0's entry for it: sarr + ((m & 3) * 2 + ((m >> 2) & 1)) * RL + ((m >> 3) & 63)
s_ent   ld a,l : and 3 : add a,a : ld c,a
        ld a,l : rrca : rrca : and 1 : or c : ld c,a
        srl h : rr l : srl h : rr l : srl h : rr l : ld a,l : and 63 : ld l,a
        ld a,c : rrca : and #80 : or l : ld l,a
        ld a,c : srl a : ld h,a
        ld de,sarr : add hl,de : ret
s_n     dw 0
s_col   db 1
s_s1    dw 0
s_s2    dw 0
s_gl    ds 8
s_rc    ds 16                                           ; each row: R, its unit
        ELSE
; 320x200: a pair of pixels (a byte's 2) is the step - every other frame. Each row: 4 arrays, pair P (from the
; start, s_pos) in array P & 3 at (P >> 2); the screen's pair c (0..159) is P = s_pos + c: its plane c & 3 (0, 2:
; page 1 #C000 / #E000, 1, 3: page 5) at byte c >> 2 - from array (s_pos + q) & 3 from (s_pos + q) >> 2. A pair:
; one font pixel (2x wide). Each row on 3 lines.
RL      equ 128                                         ; an array's length (4 x 8 of them)
scroll  ld a,(f_txt) : or a : ret z
        ld hl,s_fr : ld a,(hl) : xor 1 : ld (hl),a : jr z,s_step
        ; the other frame: the arrays near their end - all moved back by 80 (s_pos - 320), the picture unchanged
        ld hl,(s_pos) : ld de,-(4*(RL-48)) : add hl,de : ret nc
        ld (s_pos),hl
        ld hl,sarr+80 : ld de,sarr : ld bc,8*4*RL-80 : ldir : ret
s_step
        ld hl,(s_pos) : inc hl : ld (s_pos),hl
        ; the pair coming: P = s_pos + 159 - the letter's next column (its pixels' bits, each row)
        ld a,l : and 3 : ld c,a : ld a,c : add a,159 & 3 : and 3 : ld c,a          ; C = its array
        ld de,159 : add hl,de : srl h : rr l : srl h : rr l                      ; L = its index
        ld a,c : rrca : and #80 : ld e,a : ld a,c : srl a : ld d,a              ; (array c at sarr + c * RL)
        ld h,0 : add hl,de : ld de,sarr : add hl,de                              ; HL -> row 0's (rows 4 * RL apart)
        push hl
        ld hl,s_col : dec (hl) : jr nz,1F
        ld (hl),8 : call t_glyph : ld de,s_gl : ld bc,8 : ldir                   ; the next letter's 8 rows
1       pop hl : ld de,s_gl : ld b,8
2       ld a,(de) : add a,a : ld (de),a : sbc a,a                                ; the column's pixel: #FF (15, white) / 0
        ld (hl),a : inc de
        push de : ld de,4*RL : add hl,de : pop de : djnz 2B
        ; drawn: page 1 (planes 0, 2), page 5 (1, 3)
        ld a,P_1 : ld (s_pg),a : ld c,0 : call s_two
        ld a,P_5 : ld (s_pg),a : ld c,1
; C = the first plane (0 / 1): it and C + 2 on the band's 24 lines
s_two   ld a,(s_pg) : ld b,#FF : push bc : ld c,#F7 : out (c),a : pop bc
        ld a,c : call s_src : ld (s_s1),hl
        ld a,c : add a,2 : call s_src : ld (s_s2),hl
        ld de,#C000+BY*40 : ld b,8
1       push bc : ld b,3
2       push bc
        ld hl,(s_s1) : push de : call ldi40 : pop de
        ld hl,(s_s2) : set 5,d : push de : call ldi40 : pop de : res 5,d
        ex de,hl : ld bc,40 : add hl,bc : ex de,hl
        pop bc : djnz 2B
        ld hl,(s_s1) : ld bc,4*RL : add hl,bc : ld (s_s1),hl
        ld hl,(s_s2) : add hl,bc : ld (s_s2),hl
        pop bc : djnz 1B
        ret
; A = plane q -> HL = row 0's source (array (s_pos + q) & 3 from (s_pos + q) >> 2)
s_src   push bc : ld hl,(s_pos) : add a,l : ld l,a : jr nc,1F : inc h
1       ld a,l : and 3 : push af
        srl h : rr l : srl h : rr l
        pop af : ld e,a : rrca : and #80 : ld c,a : ld a,e : srl a : ld d,a : ld e,c     ; (array * RL)
        add hl,de : ld de,sarr : add hl,de : pop bc : ret
s_fr    db 0
s_col   db 1
s_pg    db 0
s_pos   dw 0
s_s1    dw 0
s_s2    dw 0
s_gl    ds 8
        ENDIF
; the text's next letter -> HL = its 8 font bytes
t_glyph ld hl,(t_ptr) : ld a,(hl) : or a : jr nz,1F
        ld hl,txt : ld a,(hl)                           ; (the end: from the start)
1       inc hl : ld (t_ptr),hl
        ld l,a : ld h,0 : add hl,hl : add hl,hl : add hl,hl : ld de,fnt : add hl,de : ret
s_cnt   db 1
t_ptr   dw txt
ldi40
        DUP 40
        ldi
        EDUP
        ret

; A = page: its picture part (2 x 8000 bytes) cleared (the rest of the page is the BIOS's)
cls     ld bc,#FFF7 : out (c),a
        ld hl,#C000 : call 1F
        ld hl,#E000
1       ld d,h : ld e,l : inc de : ld bc,8000-1 : ld (hl),0 : ldir : ret

frame   ld hl,dcnt : dec (hl) : jr nz,1F         ; a new direction every 256 frames (the first after 12)
        ld a,r : and #0E : ld e,a : ld d,0 : ld hl,dtab : add hl,de
        ld a,(hl) : ld (dl),a : inc hl : ld a,(hl) : ld (dh),a
1       ld hl,pts : ld b,64
.lp     push bc : push hl
        ld e,(hl) : inc hl : ld d,(hl)          ; DE = the point's table entry
        push hl : push de : call erase : pop de : pop hl
        ld a,(dl) : add a,e : ld e,a            ; depth +-1 (4 bytes an entry; wraps)
        ld a,(dh) : add a,d : sub high tab : and 63 : add a,high tab : ld d,a   ; angle +-1 (wraps)
        ld (hl),d : dec hl : ld (hl),e
        pop hl : pop bc : push bc : push hl
        ld a,64 : sub b : call plot             ; A = the point's number
        pop hl : inc hl : inc hl : pop bc
        djnz .lp
        ret

; DE = entry: its pixel off
erase   ex de,hl
        ld e,(hl) : inc hl : ld d,(hl) : inc hl
        ld a,d : or a : ret z                   ; (off the screen)
        IFDEF HI
        ld a,(hl) : cpl : ld l,a
        ld bc,#FFF7 : ld a,P_5 : out (c),a
        ld a,(de) : and l : ld (de),a
        ELSE
        ld a,(hl) : inc hl : ld l,(hl) : or a : ld h,#B8 : jr z,1F : ld h,#47     ; (left: keep the right's bits)
1       ld bc,#FFF7 : ld a,l : out (c),a
        ld a,(de) : and h : ld (de),a
        ENDIF
        ret

; DE = entry, A = the point's number: its pixel on (its colour: dim near the circle)
plot    add a,a : add a,a : ld c,a              ; colour index: n * 4 (+2 bright) (+1 right)
        ld a,e : cp DIM_D*4 : jr c,1F : inc c : inc c
1       ld b,0 : ld hl,ctab : add hl,bc         ; HL -> the colour bytes
        ex de,hl
        ld c,(hl) : inc hl : ld b,(hl) : inc hl
        ld a,b : or a : ret z
        IFDEF HI
        ld a,(hl) : push af                     ; mask
        ld a,(de) : ld (pl_at),a                ; attribute
        ld h,b : ld l,c
        ld bc,#FFF7 : ld a,P_5 : out (c),a
        pop af : or (hl) : ld (hl),a
        ld a,P_1 : out (c),a
        ld a,(pl_at) : ld (hl),a
        ELSE
        ld a,(hl) : inc hl : or a : jr z,2F : inc de    ; right pixel: the second colour byte
2       ld a,(hl) : push bc : ld bc,#FFF7 : out (c),a : pop hl
        ld a,(de) : or (hl) : ld (hl),a
        ENDIF
        ret

dtab    db 4,0, 4,1, 4,-1, -4,0, -4,1, -4,-1, 0,1, 0,-1        ; depth, angle (Dizzy's 8)
dcnt    db 12
dl      db 4
dh      db 0
seed    db #5A
pl_at   db 0
        IFDEF HI
m_on    db 27,"M2",27,"Z0$"
ctab    incbin "col640.bin"
        ELSE
m_on    db 27,"M0",27,"Z0$"
ctab    incbin "col320.bin"
        ENDIF
m_off   db 27,"Z1",27,"M1",13,10,"DZFX: the Dizzy 5 intro. Gambler (coor@mail.ru), 2026",13,10,"$"
pts     ds 128
        ds 256
stk
        ALIGN 256
tab
        IFDEF HI
        incbin "tab640.bin"
        ELSE
        incbin "tab320.bin"
        ENDIF
tab_end
        IFDEF HI
        savebin "DZFX640.COM",#100,tab_end-#100
        ELSE
        savebin "DZFX320.COM",#100,tab_end-#100
        ENDIF
; (past the file: zeroed at the start)
wrk
fnt     ds 2048
        IFDEF HI
sarr    ds 8*8*RL
        ELSE
sarr    ds 8*4*RL
        ENDIF
wrk_e
TXTMAX  equ #BC00-txt-#1400
txt
        ASSERT txt + 2048 <= #BC00-#1400
