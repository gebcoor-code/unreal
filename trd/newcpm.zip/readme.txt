newcpm.trd: DZFX320.COM (320x200x16), DZFX640.COM (640x200), FONT.FNT, TEXT.TXT, DIZZY5.CTR
 - FONT.FNT  — шрифт 256 x 8 байт, кодировка KOI8-R (из DIZ.FNT; строчные = прописные)
 - TEXT.TXT  — текст бегущей строки (KOI8-R); конец строки = пробел, ^Z или конец файла = конец, затем по кругу
 - DIZZY5.CTR — музыка интро (ASC Sound Master, плеер+модуль с #C000: init #C09A, play #C00E)
Скорость: 50 кадров/с на 7 МГц.

Сборка: sjasmplus dzfx.asm (320), sjasmplus -DHI dzfx.asm (640)
 python3 mkfont.py DIZ.FNT files "текст"  — font.fnt (KOI8-R) и text.txt
 python3 mkdata.py dizzy5.sna files       — dizzy5.ctr из снапшота
 python3 mktrd.py in.trd out.trd файлы    — запись файлов в CP/M-образ
