#UFO2 EGA HDD edition

Interface=ATM
CHS=723/15/38