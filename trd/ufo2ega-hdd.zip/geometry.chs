# ufo2ega hdd edition: CP/M, ATM BIOS 1.07 layout (drive C:)
CHS=149/5/17
Interface=ATM
