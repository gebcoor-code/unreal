#Tasis v5.40 HDD
#Extracted from 11 drives HDD pack for web unreal by ae485 05.10.26

Interface=ATM
CHS=400/16/63
ISDOS=C 1-33
