#Neo8 STM files (MicroART and Max.T disks) hdd vol3 (compilation by ae485, 11.10.26)
#HDD extra size 6MB, 512 entries, works only on WEB Unreal Speccy (from v 0.42.6)

CHS=149/5/17
Interface=ATM
DirEntries=512  # ROM HDD table changed while mounted
