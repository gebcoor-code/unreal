# EVO HDD: FAT16 (ZX-Evolution, NEMO interface)

Interface=NEMO-DIVIDE
CHS=21/16/63
