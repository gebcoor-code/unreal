# EVO HDD: FAT16 (ZX-Evo, NEMO-DIVIDE interface)

Interface=NEMO-DIVIDE
CHS=21/16/63
