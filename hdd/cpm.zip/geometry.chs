#Somehow test HDD for CPM

Interface=ATM
CHS=723/15/38