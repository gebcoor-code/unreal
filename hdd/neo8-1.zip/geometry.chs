#Neo8 S3m files hdd vol1 (by ae485, 10.10.26)
#HDD extra size 6MB, 512 entries, works only on WEB Unreal Speccy (from v 0.42.6)

CHS=149/5/17
Interface=ATM
DirEntries=512
