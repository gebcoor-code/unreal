// UnrealSpeccy web front-end: canvas, Web Audio, keyboard, disk drives
(function () {
  'use strict';
  const { MemFS, WASI } = window.UnrealWasi;
  const SCAN = window.UnrealScan.codeToScan;

  // Files on the server: index.html in the root, scripts in js/, the emulator (wasm, unreal.ini, boot, CMOS) in unreal/,
  // ROM images in rom/. ROM / boot names must match the ones referenced in unreal.ini.
  const WASM_URL = 'unreal/unreal.wasm?v=20261116104818';
  const WASM_ZIP_URL = 'unreal/unreal.zip?v=20261116104818'; // the server keeps the wasm packed (deflate); a bare unreal.wasm is the fallback
  const SJASM_URL = 'unreal/sjasm.zip?v=20261116104818'; // sjasmplus for File Commander (Compile, F9), loaded at the first compile
  const MAIL_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAKMAAAAeCAYAAABAOK4rAAAHfUlEQVR42u2bfZBWVR3HP6vggoiiEWoOKYqOrkVMqIy0FcOLleguUThjcTDRyOBYTDZ5oGUjgTo2kg6eFMdS4cw2jilokA7m5BRiL7gmFtIwJTWuEiDQriQvCvXH831m7ty5z+7D7rPLKvc788yZ5zz3d8+953zP9/dydiFHjhw5cuTIkSNHjhw5cuTIkSPHexRV+RS8P+FDfAYYD9zsrAkd9fcG9DkGF6kPcCUwCRgDnAEMAlqBLcCzQHTW/C2ndM/iuGOMiNcCm4EngJnAR4DB2pQfAC4H5gGbfYgP+hBPyymSK2OlSVgN3Atcr67ngZ8D64GtwD7gdOB8oB64FvgKMMmH+BlnzZ/fa+/srJmQk7H3EfE44BfA1UALcIOz5umMS1/T5zc+xEbgNuAbwNM+xLHOmk25dh0FMvoQa4GbgE8opvov8CqwGvips2Zb6vrjgesAA4wABgI7pTx3OWueb4csnbL1Ib4EfEwq1gzMBcYBZwKvOWuG69JFIuIfgMnOmu1lqEor8E0f4mbgHuAxH+JIZ83+dp7hRWC+nmEwsB14HFjgrNntQ6wCZgA3ADVAX2AjsMhZ82SJdzxZz/554GJgqH76J/AUsMRZ8+8jSWC6uLE7nHMf4l5gAHCps+aFjHucI28E0D85p30yVORuYFbqHv0UU10KjAauSticpBhsXMrmQ8BUYKoPscFZszjjwTptm8AngQeA/ulY2Id4HvBt4A2gzlmzM/GeN2vDDQN2AI8A3wOagHpnTZWzZpkPcajiyFnAj0s8Q23GMwzVGON9iJcBDwFfTNldDqz2IU511qzMuO+PgK9l9F+sz3Qf4rijoNol57ySCcz3E0RsEvEGAKcClwALtbBJ/ERkehdo0CL0A0YCa4rq5EOckjF+V2yLmAW8DkwGBolE5+q3eVKgGUUiCsuAu4ALgWqNewvwW+DE1P0XAW+KuKUwW2o1Sap4BvAt4JBUcIPUbYm+D9DGbtYaLNEGSWMPcD9wBXCeFv8s4AvAJmAIsOIoeNT25rzrbtqHeBbwHX1d7KxpSFz3tiauOaVs58u9AtzqrEkqx0YfYj2wFpggIq+shG0K+4EJzpp/Zbj/yUCzs2Zton8i8FXZ3ap48lCCLANSLnufD/Fx4EYf4tnpcYSdQK2zZnei704f4iXAl4CLgPnOmkWJ31/wIU5Tdn+OSPrX1NhzM8Z6A1jpQ1wPvAJ83Ic4ylnT3INkzJzzSipjPXCCVGBhmfZXUSicb5fKpWOvw8ACfa2R26yEbRIrSkzKKOA0xW1J3Ki2wVmz1FmzzVmzw1lzHzCnxBgb1Q4v8fsDKSIWsV7t4SwXr1pmUbGHHWG2vB14Tl9H97Ayrqg0EdMx4wi165w1B8q0v0jty+3Y/BF4R+6yBvhHBWyTKBUvfbh4/wySAizPsFkuF358qv+g2hNLjFWqQL6jmKk7a95u55oPlrq3D3G8Ep/LFEtnXTekh8nYLTFqUhlPUbv7COxPTriOUjv4XaAtdX1XbbMWPI1iwbot1T8IOOCseTNjvHek1GkMS7jjUm6rI7fWEaoyiHgH8Ixc/fB2NkO/Hibjju4mY1tqEctBWyL7LVUO6JMgUluFbMvBHrWDU/2tQLUPcXCJ8Yak+qooHB/uB17qwfroGCVVxYRrtN7lBCUMVUoyexv+15lyYpqMxbioVicW5aDonka0YzNabhYF65WwLQctqXCgiBfVXpdhMy1jsm5SCNOUrjN2MyaqfdZZ83VnzZ+cNbuk3kVc0AvJuE/t6SV+H14OS58A7lT8Mk81t46wBrhDA89OB+kqVzQWyeSs+XuFbMtBM/CWMupkQvag6n0LfYgHgUdVWrpa718cv0bJzhyVMRp6eFH7JSoZWcr5OZWHehu2ikPjgF9lrOktHZLRWfO6YpR5QKMP8WwgKFitVp2rDjjTWTNTNlt8iE1SlNulcMuVkV9I4UjtCg3RmIrPOm1bZrZ50If4FHCND3Gis+bX6n/Sh7gCmA4s1SdJ4F0ad1MiWJ9S6qSjG1E8vbjSh9igTbRL8euX21vULoQGcxIbcqCzZm8nbvNLJVuzfYhbtdn3ybvcBowtx00XF/3+hBvboJ25R5PTmBHjzQJ+J2L/QCpyQG6/XtcscNY8WqJ42lnbcrBYZZW7fYinJPpnUDiZ2aJMuYVCEXysYsoWeYrpwEhnzZajoDCrKBThq6TsLVrUV4DvUjieXdMLlXGpQrBqCqd524D/aJ0/DfywrGDSWXMImOlDfJjCMdQYBfStkt/VwM9SNm+p/HC9VO6jwElSuPXAUmfNuhLq1WnbMtXxZR/iMpF+lQ+xzlmzV++5RJ80rukNK+qsOexD/CzgKJwFD1MS9SrwmJ79nt7GRK1pLYUacR2Fc+tW4PfA7RKcuWWVE95v8CH2VXnkU9qx0501GzqwqQHuA5Y5a5rI0SM4Jv7twIc4kMIZ7mR1rVUss05u5ACF8+QxUsY6qdA0Z82qnCY5GStNyCqVaebLdbSHdcBsZ81fcorkZOxOUvYHplD4C5tRUsS+imWeAx5O/mFFjhw5jkH8HzsgzyJO/agJAAAAAElFTkSuQmCC';
  const APP_VER = '1.89.1'; // About, System Info (history: changes.txt)
  // a phone in landscape (landUpdate, applyScale): the whole screen, the on-screen keyboards over it
  const HOME_APP = !!(navigator.standalone || (window.matchMedia && matchMedia('(display-mode: standalone)').matches)); // started from the home screen
  const LAND_MQ = window.matchMedia ? window.matchMedia('(orientation: landscape) and (max-height: 540px) and (pointer: coarse)') : null;
  let land = false;
  const BUILD = '20261116104818'; // set by make_dist.sh: the build of these files (index.html carries the same in <meta name="build">)
  // Only what the current machine needs is downloaded; the rest is fetched on a model switch.
  const COMMON_FILES = ['unreal.ini', 'boot6.$b'];
  const GS_ROM = 'bootgs.rom'; // NeoGS ROM: fetched when General Sound is switched on
  // Folders on the server are lower case (rom/, hdd/, trd/ …): Linux hosts are case-sensitive, Windows does not care.
  // ROM images live in rom/; inside the emulator they sit next to unreal.ini (names as in the ini)
  const ROM_DIR = 'rom/';
  const EMU_DIR = 'unreal/', EMU_FILES = /^(unreal\.ini|boot6\.\$b|cmos|sos\.l)$/i;
  const srcUrl = (f) => /\.rom$/i.test(f) ? ROM_DIR + f : EMU_FILES.test(f) ? EMU_DIR + f : f;

  // ------------------------------------------------------------------ machine models
  // unreal.ini is used as is; a model only overrides a few keys through web_model.ini
  // (read by the emulator before unreal.ini). base = t-states per frame at 1x (3.5 MHz).
  const MODELS = {
    ATM710: { name: 'Turbo 2+ (7.10)', base: 69888, speed: 2.5, xt: true, ini: { MISC: { RESET: 'SYS' } }, files: ['bios_1_07_13.rom'],
      note: '1024 KB · BIOS 1.07.13' },
    // eXtra BIOS 1.36XT (NedoPC): 128K ROM, dual TR-DOS (5.04R + vTR-DOS with a WD1793 emulator), setup utility (start macros,
    // CP/M, ROM disk; TASiS / iS-DOS Chic boot on it)
    XBIOS136: { name: 'Turbo 2+ xBIOS 1.36', base: 69888, speed: 2.5, xt: true, files: ['xbios136.rom'], note: '1024 KB · eXtra BIOS 1.36XT (128K ROM: TR-DOS 5.04R + vTR-DOS)',
      ini: { MISC: { HIMEM: 'ATM710', RAMSize: '1024', RESET: 'SYS' }, ROM: { ROMSET: '', ATM2: 'xbios136.rom' } } },
    // ATM-1: the BIOS times the CPU (copy protection, CP/M key), so the clock stays at 3.5 MHz
    // BIOS 1.04.1R: the CP/M part is plain (1.03 is encrypted with a key from CPU timing, so it ran at 3.5 MHz only);
    // CP/M starts "B:XC /R" (X-Commander from the CP/M drive B: = floppy A:) by itself
    ATM450: { name: 'ATM Turbo 1 (4.50)', base: 69888, speed: 2.5, xt: false, files: ['atm1041r.rom'], note: '512 KB · BIOS 1.04.1R',
      ini: { MISC: { HIMEM: 'ATM450', RAMSize: '512', CMOS: 'none', RESET: 'SYS' }, ROM: { ROMSET: '', ATM1: 'atm1041r.rom' }, ULA: { Preset: 'ATM1_2_3.5MHz' } } },
    EVO: { name: 'ZX Evo BaseConf', base: 69888, speed: 2.5, xt: true, files: ['zxevo_fe.rom', 'CMOS'], note: '4096 KB · EVO Reset Service FE · CMOS',
      ini: { MISC: { HIMEM: 'ATM3', RAMSize: '4096', CMOS: 'DALLAS', RESET: 'SYS' }, ROM: { ROMSET: '', ATM3: 'zxevo_fe.rom' } } },
    // ZX-Evolution with the TS configuration (TS-Conf): TS-BIOS, 4 MB, TS video modes; the program sets the CPU clock (3.5 / 7 / 14 MHz)
    TSCONF: { name: 'ZX Evo TS-Conf', base: 71680, speed: 1, fixed: true, xt: true, files: ['zxevo.rom', 'CMOS'], note: '4096 KB · TS-BIOS · CMOS · SD: Wild Commander (sd/wc.zip), boots on Reset',
      ini: { MISC: { HIMEM: 'TSL', RAMSize: '4096', CMOS: 'DALLAS', RESET: 'SYS' }, ROM: { ROMSET: '', TSL: 'zxevo.rom' }, ULA: { Preset: 'PENTAGON' } } },
    // Sprinter Sp2000 (Peters Plus): Z84C15 at 3.5 / 21 MHz (the program sets it), 4 MB, FPGA video (web/web_sp.cpp); the flash
    // has the BIOS 3.06 (Sprinter Team), its FPGA bitstream, setup and a ROM disk (RECOVERY); boots from the IDE HDD (Estex DSS)
    SPRINTER: { name: 'Sprinter Sp2000', base: 71680, speed: 1, fixed: true, xt: true, files: ['sp2k306.rom', 'CMOS'], note: '4096 KB · BIOS 3.06 (Sprinter Team) · CMOS · Estex DSS 1.71 from hdd/dss.zip',
      ini: { MISC: { HIMEM: 'SPRINTER', RAMSize: '4096', CMOS: 'DALLAS', RESET: 'SYS' }, ROM: { ROMSET: '', SPRINTER: 'sp2k306.rom' }, ULA: { Preset: 'PENTAGON' } } },
    // RAM 128 / 512 / 1024 KB (Options / System: RAM, link ram=): 512 pages with #7FFD D6, D7, 1024 also with D5 (no lock bit then)
    PENTAGON: { name: 'Pentagon 128', base: 71680, speed: 2.5, xt: false, files: ['pentagon.rom', 'trd504tm.rom'], note: '128K ROM + TR-DOS',
      ini: { MISC: { HIMEM: 'PENTAGON', RAMSize: '128', CMOS: 'none' }, ROM: { ROMSET: 'pentagon' }, 'ROM.pentagon': { 128: 'pentagon.rom:0', sos: 'pentagon.rom:1', dos: 'trd504tm.rom', sys: 'trd504tm.rom' }, ULA: { Preset: 'PENTAGON' } } },
    // ZX Spectrum 128 with a Beta 128 disk interface (the Sinclair ROMs, TR-DOS 5.04TM): the plain 128K for DivMMC (esxDOS), Gotek
    ZX128: { name: 'ZX Spectrum 128', base: 70908, speed: 1, xt: false, files: ['sinclair.rom', 'trd504tm.rom'], note: '128 KB · Sinclair ROMs · Beta 128 (TR-DOS 5.04TM)',
      ini: { MISC: { HIMEM: 'PENTAGON', RAMSize: '128', CMOS: 'none' }, ROM: { ROMSET: 'zx128b' }, 'ROM.zx128b': { 128: 'sinclair.rom:1', sos: 'sinclair.rom:2', dos: 'trd504tm.rom', sys: 'sinclair.rom:1' }, ULA: { Preset: 'PENTAGON' } } },
    // RZX playback (not in the model list): the Sinclair ROMs (sinclair.rom: 48, 128 ROM 0 / 1, +2 ROM 0 / 1; Amstrad allows
    // their distribution) on the Pentagon's memory and timing: a recording replays the ROM code it ran
    RZX48: { name: 'ZX Spectrum 48', hidden: true, base: 69888, speed: 1, xt: false, files: ['sinclair.rom'], note: 'RZX playback',
      ini: { MISC: { HIMEM: 'PENTAGON', RAMSize: '128', CMOS: 'none' }, ROM: { ROMSET: 'zx48' }, 'ROM.zx48': { 128: 'sinclair.rom:0', sos: 'sinclair.rom:0', dos: 'sinclair.rom:0', sys: 'sinclair.rom:0' }, ULA: { Preset: 'PENTAGON' } } },
    RZX128: { name: 'ZX Spectrum 128', hidden: true, base: 70908, speed: 1, xt: false, files: ['sinclair.rom'], note: 'RZX playback',
      ini: { MISC: { HIMEM: 'PENTAGON', RAMSize: '128', CMOS: 'none' }, ROM: { ROMSET: 'zx128' }, 'ROM.zx128': { 128: 'sinclair.rom:1', sos: 'sinclair.rom:2', dos: 'sinclair.rom:2', sys: 'sinclair.rom:1' }, ULA: { Preset: 'PENTAGON' } } },
    RZXP2: { name: 'ZX Spectrum +2', hidden: true, base: 70908, speed: 1, xt: false, files: ['sinclair.rom'], note: 'RZX playback',
      ini: { MISC: { HIMEM: 'PENTAGON', RAMSize: '128', CMOS: 'none' }, ROM: { ROMSET: 'zxp2' }, 'ROM.zxp2': { 128: 'sinclair.rom:3', sos: 'sinclair.rom:4', dos: 'sinclair.rom:4', sys: 'sinclair.rom:3' }, ULA: { Preset: 'PENTAGON' } } },
    // other Spectrum clones of UnrealSpeccy: one 64K ROM each (KAY: as a ROM set, the core has no single-file KAY ROM)
    SCORPION: { name: 'Scorpion ZS 256', base: 69888, speed: 2.5, xt: false, files: ['scorp295.rom'], note: '256 KB · ROM 2.95 (128 / 48 / service / TR-DOS 5.03)',
      ini: { MISC: { HIMEM: 'SCORPION', RAMSize: '256', CMOS: 'none', RESET: 'SYS' }, ROM: { ROMSET: '', SCORP: 'scorp295.rom' }, ULA: { Preset: 'SCORPION' } } },
    // Scorpion ZS 256 with the GMX board (web/web_gmx.cpp): 2 MB, 640x200, the 512K flash of the GMX (Loader, shadow monitor)
    GMX: { name: 'Scorpion ZS 256 GMX', base: 69888, speed: 2.5, xt: false, files: ['gmx644.rom'], note: '2048 KB · GMX: 640×200, turbo · flash 512K (LW/PLM, 21.08.2025): GMX Loader 2.00 (Delete at start: Set Up), Shadow Service Monitor 6.44 (NMI) · SD: Z-Controller · HDD: SMUC',
      ini: { MISC: { HIMEM: 'PROFSCORP', RAMSize: '2048', CMOS: 'DALLAS', SMUC: '1', RESET: 'MENU', GMX: '1' }, ROM: { ROMSET: '', PROFROM: 'gmx644.rom' }, ULA: { Preset: 'SCORPION' } } },
    PROFI: { name: 'Profi 1024', base: 69888, speed: 2.5, xt: false, files: ['profi.rom'], note: '1024 KB · Profi ROM BIOS (Micco Software)',
      ini: { MISC: { HIMEM: 'PROFI', RAMSize: '1024', CMOS: 'none', RESET: 'SYS' }, ROM: { ROMSET: '', PROFI: 'profi.rom' }, ULA: { Preset: 'PROFI' } } },
    KAY: { name: 'KAY 1024', base: 69888, speed: 2.5, xt: false, files: ['kay1024.rom'], note: '1024 KB · Nemo KAY 1024, JV Kramis 0.3',
      ini: { MISC: { HIMEM: 'KAY', RAMSize: '1024', CMOS: 'none', RESET: 'SYS' }, ROM: { ROMSET: 'kay' }, 'ROM.kay': { 128: 'kay1024.rom:0', sos: 'kay1024.rom:1', dos: 'kay1024.rom:2', sys: 'kay1024.rom:3' }, ULA: { Preset: 'KAY1024' } } },
    PLUS3: { name: 'Spectrum +3', base: 70908, speed: 2.5, xt: false, files: ['plus341.rom'], note: '128 KB · Amstrad +3 ROM 4.1 (+3DOS, µPD765)',
      ini: { MISC: { HIMEM: 'PLUS3', RAMSize: '128', CMOS: 'none', RESET: 'MENU' }, ROM: { ROMSET: '', PLUS3: 'plus341.rom' } } },
    // SAM Coupé (MGT, 1989; web/web_sam.cpp): Z80B 6 MHz, 512K, ASIC video (modes 1..4, 128 colors), SAA1099; ROM 3.0
    SAM: { name: 'SAM Coupé', base: 119808, speed: 1, xt: false, files: ['samcoupe.rom'], note: '512 KB · ROM 3.0 · 6 MHz · SAA1099',
      ini: { MISC: { HIMEM: 'SAM', RAMSize: '512', CMOS: 'none', RESET: 'SYS' }, ROM: { ROMSET: '', SAM: 'samcoupe.rom' }, INPUT: { ZXKeyMap: 'sam', KeybLayout: 'sam' } } },
    // ZX Spectrum Next (web/web_nx.cpp): Z80N at 3.5..28 MHz (the program sets it), 1792K, Layer 2, sprites, tilemap, copper,
    // zxnDMA; the Sinclair 128 ROMs (no NextZXOS yet): programs start from NEX and DOT files
    NEXT: { name: 'ZX Spectrum Next', base: 70908, speed: 1, fixed: true, xt: false, files: ['enNextZX.rom', 'enNxtmmc.rom', 'enNextMf.rom', 'sinclair.rom'], note: '2048 KB · Z80N · 3.5–28 MHz · System/Next 26.11 · NextZXOS 2.10', link: 'https://www.specnext.com/latestdistro/', linkParen: true,
      ini: { MISC: { HIMEM: 'NEXT', RAMSize: '2048', CMOS: 'none' }, ROM: { ROMSET: 'next' }, 'ROM.next': { 128: 'enNextZX.rom:0', sos: 'enNextZX.rom:1', sys: 'enNextZX.rom:2', dos: 'enNextZX.rom:3' }, ULA: { Preset: 'PENTAGON' } } },
    QUORUM: { name: 'Quorum 1024', base: 69888, speed: 2.5, xt: false, files: ['qu7v42.rom'], note: '1024 KB · ROM-MENU Quorum 4.2',
      ini: { MISC: { HIMEM: 'QUORUM', RAMSize: '1024', CMOS: 'none', RESET: 'SYS' }, ROM: { ROMSET: '', QUORUM: 'qu7v42.rom' } } },
  };
  // the groups of Options / System / Model (in this order; a model of none: Other)
  const MODEL_GROUPS = [
    ['ATM / ZX Evolution', ['ATM710', 'XBIOS136', 'ATM450', 'EVO', 'TSCONF']],
    ['128K clones', ['KAY', 'PENTAGON', 'PROFI', 'QUORUM', 'SCORPION', 'GMX']],
    ['Sinclair and others', ['ZX128', 'PLUS3', 'NEXT', 'SAM', 'SPRINTER']],
    ['Operating systems', ['CHIC', 'NEDOOS', 'OSZ', 'TASIS']],
    ['Custom', ['CUSTOM']],
  ];
  // operating systems on HDD: an xBIOS XT machine that boots HDD 0 (setup → Boot → IDE hard drive master) in ATM mode
  const OS_MODELS = {
    TASIS: { name: 'TaSiS v5.40 (BIOS 1.36XT)', hdd: 'hdd/tasis540.zip', note: 'iS-DOS TASiS v5.40 · starts on Turbo 2+ xBIOS 1.36' },
    CHIC: { name: 'iS-DOS Chic v5.01 (BIOS 1.36XT)', hdd: 'hdd/isdos501.zip', note: 'iS-DOS Chic v5.01 · starts on Turbo 2+ xBIOS 1.36' },
    // NedoOS on the SD card of ZX-Evolution: EVO Reset Service, 5 = SDcard boot (sd_boot.$C)
    NEDOOS: { name: 'NedoOS (BaseConf)', machine: 'EVO', sd: 'sd/nedoos.zip', note: 'NedoOS v0.2188.1 · starts on ZX Evo BaseConf from SD (~30 MB, browser caches once)',
      link: 'https://github.com/alfishe/NedoOS' },
    // OSZ (izzx) on the SD card of Scorpion GMX: the card's .json puts OS.TRD into A:, it boots the kernel from the card
    OSZ: { name: 'OSZ (Scorpion GMX)', machine: 'GMX', sd: 'sd/osz.zip', note: 'OSZ 2025.10.08 (izzx), multitasking OS · starts on Scorpion ZS 256 GMX from SD + OS.TRD',
      link: 'https://github.com/izzx-git/OSZ' },
  };
  for (const [k, v] of Object.entries(OS_MODELS)) MODELS[k] = Object.assign({}, MODELS[v.machine || 'XBIOS136'], v, { machine: v.machine || 'XBIOS136' });
  // ------------------------------------------------------------------ Custom ROM (Options / System)
  // The user picks the machine and what goes where; the page only turns that into web_model.ini.
  // Machine profiles: memory model (HIMEM), RAM, timings, CMOS; the ROM is either one file taken whole ([ROM] key,
  // sizes as the core accepts them) or a ROM set of four 16K slots ([ROM.custom]: 128, sos = 48 BASIC, dos = TR-DOS, sys = service).
  const MACHINES = {
    PENT128: { name: 'Pentagon 128', himem: 'PENTAGON', ram: 128, base: 71680, ula: 'PENTAGON', set: true },
    PENT1024: { name: 'Pentagon 1024', himem: 'PENTAGON', ram: 1024, base: 71680, ula: 'PENTAGON', set: true },
    KAY: { name: 'KAY 1024', himem: 'KAY', ram: 1024, base: 69888, ula: 'KAY1024', set: true },
    SCORPION: { name: 'Scorpion ZS 256', himem: 'SCORPION', ram: 256, base: 69888, ula: 'SCORPION', key: 'SCORP', sizes: [64] },
    PROFSCORP: { name: 'Scorpion + ProfROM', himem: 'PROFSCORP', ram: 256, base: 69888, ula: 'SCORPION', key: 'PROFROM', sizes: [64, 128, 256, 512], page: ':0' },
    PROFI: { name: 'Profi 1024', himem: 'PROFI', ram: 1024, base: 69888, ula: 'PROFI', key: 'PROFI', sizes: [64] },
    PLUS3: { name: 'Spectrum +3', himem: 'PLUS3', ram: 128, base: 70908, key: 'PLUS3', sizes: [64] },
    QUORUM: { name: 'Quorum 1024', himem: 'QUORUM', ram: 1024, base: 69888, key: 'QUORUM', sizes: [64] },
    ATM450: { name: 'ATM Turbo 1 (4.50)', himem: 'ATM450', ram: 512, base: 69888, ula: 'ATM1_2_3.5MHz', key: 'ATM1', sizes: [64] },
    ATM710: { name: 'ATM Turbo 2+ (7.10)', himem: 'ATM710', ram: 1024, base: 69888, key: 'ATM2', sizes: [64, 128, 512, 1024], xt: true },
    EVO: { name: 'ZX Evo BaseConf', himem: 'ATM3', ram: 4096, base: 69888, key: 'ATM3', sizes: [64, 128, 512, 1024], xt: true, cmos: 'DALLAS' },
    TSCONF: { name: 'ZX Evo TS-Conf', himem: 'TSL', ram: 4096, base: 71680, ula: 'PENTAGON', key: 'TSL', sizes: [64, 512], cmos: 'DALLAS' },
  };
  const SLOTS = [['128', '128'], ['sos', '48 BASIC'], ['dos', 'TR-DOS'], ['sys', 'Service']]; // ROM set: ini name, label
  // parts on the server to build a ROM set from (rom/roms.json replaces this list): file in rom/ (or rom/<name>.zip), slot, title
  let romParts = [
    { file: '48.rom', slot: 'sos', name: '48 BASIC (1982, original)' },
    { file: '48for128.rom', slot: 'sos', name: '48 BASIC for 128' },
    { file: '2006.rom', slot: 'sos', name: '48 BASIC 2006 (bugfixed, not with 128 BASIC)' },
    { file: 'pentagon.rom', page: 1, slot: 'sos', name: '48 BASIC (Pentagon)' },
    { file: 'pentagon.rom', page: 0, slot: '128', name: '128 BASIC + menu (Pentagon)' },
    { file: 'sinclair.rom', page: 1, slot: '128', name: '128 BASIC + menu (Sinclair 128)' },
    { file: 'sinclair.rom', page: 2, slot: 'sos', name: '48 BASIC (Sinclair 128)' },
    { file: 'sinclair.rom', page: 3, slot: '128', name: '128 BASIC + menu (Spectrum +2)' },
    { file: 'qc_3_05.rom', slot: '128', name: 'Quick Commander 3.05' },
    { file: 'rrom_200.rom', slot: '128', name: 'RRom 2.00 (STS 6.2)' },
    { file: 'trd503.rom', slot: 'dos', name: 'TR-DOS 5.03' },
    { file: 'trd504tm.rom', slot: 'dos', name: 'TR-DOS 5.04TM' },
    { file: 'trdos.rom', slot: 'dos', name: 'TR-DOS 5.05D' },
    { file: 'dos6_10e.rom', slot: 'dos', name: 'TR-DOS 6.10E' },
    { file: 'dos_607+.rom', slot: 'dos', name: 'PereDOS 6.07+' },
    { file: 'glukpen.rom', slot: 'sys', name: 'Gluk Reset Service 6.5R' },
    { file: 'gluk61r.rom', slot: 'sys', name: 'Gluk Reset Service 6.1R' },
  ];
  // the selected ROM file of this session (FS name, file name, KB, its pages); a slot is 'f:<fs>:<page>' (local) or 's:<file>' (server part)
  let crCur = null;
  // extra: machine settings from the json of a Custom ROM ZIP (speed, fdd, hdd, ini) — they win over the visitor's own
  // settings while this Custom ROM runs and are never stored
  const customCfg = { mach: 'PENT128', reset: '', name: '', whole: '', slots: { 128: '', sos: '', dos: '', sys: '' }, extra: null };
  const crX = () => (model === 'CUSTOM' && customCfg.extra) || {};
  function iniMerge(dst, src) { // ini sections / keys of src over dst, names compared without case
    for (const [sec, kv] of Object.entries(src || {})) {
      if (!kv || typeof kv !== 'object') continue;
      const ds = Object.keys(dst).find((k) => k.toLowerCase() === sec.toLowerCase()) || sec; dst[ds] = dst[ds] || {};
      for (const [k, v] of Object.entries(kv)) { const dk = Object.keys(dst[ds]).find((x) => x.toLowerCase() === k.toLowerCase()) || k; dst[ds][dk] = String(v); }
    }
    return dst;
  }
  const crFile = (fsn) => (crCur && crCur.fs === fsn ? crCur : null);
  // → { ini, files } or { why }
  function customPlan() {
    const c = MACHINES[customCfg.mach], ini = { MISC: { HIMEM: c.himem, RAMSize: String(c.ram), CMOS: c.cmos || 'none' }, ROM: {} };
    if (c.ula) ini.ULA = { Preset: c.ula };
    const files = c.cmos ? ['CMOS'] : [];
    if (!c.set) {
      const p = crFile(customCfg.whole);
      if (!p) return { why: 'Select ROM (' + c.sizes.join(' / ') + ' KB).' };
      if (!c.sizes.includes(p.kb)) return { why: c.name + ' takes ' + c.sizes.join(' / ') + ' KB, ' + p.name + ' is ' + p.kb + ' KB.' };
      ini.ROM.ROMSET = ''; ini.ROM[c.key] = p.fs + (c.page || ''); ini.MISC.RESET = 'SYS'; files.push(p.fs);
      if (customCfg.extra && customCfg.extra.ini) iniMerge(ini, customCfg.extra.ini);
      return { ini, files };
    }
    const set = {};
    for (const [s] of SLOTS) {
      const v = customCfg.slots[s];
      if (v.startsWith('f:')) { const [, fsn, pg] = v.split(':'); if (crFile(fsn)) { set[s] = fsn + ':' + pg; if (!files.includes(fsn)) files.push(fsn); } }
      else if (v.startsWith('s:')) { const [, f, pg] = v.split(':'); set[s] = f + (pg ? ':' + pg : ''); if (!files.includes(f)) files.push(f); }
    }
    if (!set.sos) return { why: 'Choose 48 BASIC ROM (model cannot start without it).' };
    ini.ROM.ROMSET = 'custom'; ini['ROM.custom'] = set;
    const auto = set.sys ? 'SYS' : set['128'] ? 'MENU' : 'BASIC';
    const r = customCfg.reset, ok = r && (r !== 'SYS' || set.sys) && (r !== 'MENU' || set['128']) && (r !== 'DOS' || set.dos);
    ini.MISC.RESET = ok ? r : auto;
    if (customCfg.extra && customCfg.extra.ini) iniMerge(ini, customCfg.extra.ini);
    return { ini, files };
  }
  MODELS.CUSTOM = { name: 'Custom ROM', machine: 'CUSTOM', base: 71680, speed: 2.5, xt: false, files: [], ini: {}, note: '', custom: true };
  function customApply() { // MODELS.CUSTOM from the settings
    const p = customPlan(), m = MODELS.CUSTOM, c = MACHINES[customCfg.mach];
    if (p.ini) { m.ini = p.ini; m.files = p.files; }
    m.base = c.base; m.xt = !!c.xt;
    const x = customCfg.extra || {}, sp = +x.speed;
    m.speed = isFinite(sp) && sp > 0 ? SPEEDS.reduce((a, b) => (Math.abs(b - sp) < Math.abs(a - sp) ? b : a)) : 2.5;
    const xs = [isFinite(sp) && sp > 0 ? 'clock ' + m.speed + 'x' : '', x.fdd ? 'FDD ' + x.fdd : '', x.hdd ? 'HDD ' + x.hdd : '', x.ini && Object.keys(x.ini).length ? 'ini: ' + Object.keys(x.ini).join(', ') : ''].filter(Boolean);
    m.note = (p.ini ? (customCfg.name ? customCfg.name + ' · ' : '') + c.name + (c.set ? ' · ROM set' : ' · whole ROM') : p.why)
      + (xs.length ? '\nFrom its json: ' + xs.join(' · ') : '')
      + '\nMenu SAVE can store this combined ROM to load later.';
    return p;
  }
  customApply();
  let model = 'ATM710';
  // RZX playback machines: only for the recording; another file brings back the machine before it (rzxBack), and the
  // browser storage never keeps them as the machine of a disk, tape or snapshot
  const RZX_MODELS = new Set(['RZX48', 'RZX128', 'RZXP2']); let rzxBack = null;
  const keepModel = (name) => RZX_MODELS.has(model) && !/\.rzx$/i.test(name) ? (rzxBack || 'ATM710') : model;
  const M = () => MODELS[model].machine || model; // the machine under an OS model
  const isTS = () => M() === 'TSCONF' || (model === 'CUSTOM' && customCfg.mach === 'TSCONF'); // ZX Evo TS-Conf (also an OS on it, a Custom ROM)
  const xbiosOf = () => 'XBIOS136'; // the xBIOS model a ROM disk is built on
  // ROM disk (xBIOS XT manual, appendix 4): IMAGE.TRD (40 pages) + empty 256K + XBIOS.ROM = 1 MB ROM; vTR-DOS mounts it read-only
  const ROMDISK_FILE = 'romdisk.rom', ROMDISK_TRD = 40 * 16384, ROM_TARGET = 9;
  let romDisk = null; // { name } for this session
  // PC keys → ZX keyboard as in Fuse / USP: Esc = EDIT (Caps Shift+1, "back / exit" in most programs: QC, TView, iS-DOS…),
  // Tab = EXTEND MODE (Caps Shift+Symbol Shift; BREAK is Shift+Space). Only the ZX matrix: with the ATM XT keyboard on, the
  // ATM keyboard controller has its own table. Not for Quorum (own keys). The model's own ini (a Custom ROM json) is put
  // over it, so it may set its own ESC / TAB.
  const ZX_KEYS_WEB = { 'ZX.KEYS.default': { ESC: 'CAP 1', TAB: 'SYM CAP' } };
  const PENT_RAMS = [128, 512, 1024];
  function pentRam() { // Pentagon RAM: the link's ram= (for that start), else the one chosen in Options
    let l = 0; try { l = +(LINK && LINK.ram); } catch (e) {}
    if (PENT_RAMS.includes(l)) return l;
    const v = +load('pentram'); return PENT_RAMS.includes(v) ? v : 128;
  }
  let pentRun = 0; // RAM of the Pentagon started last
  function pentName() { MODELS.PENTAGON.name = 'Pentagon ' + pentRam(); MODELS.PENTAGON.note = pentRam() + ' KB · 128K ROM + TR-DOS'; const o = $('modelsel') && [...$('modelsel').options].find((x) => x.value === 'PENTAGON'); if (o) o.textContent = MODELS.PENTAGON.name; }
  function modelIniObj(m) { // the ini overrides of model m, as they go to the emulator
    const quorum = (MODELS[m].machine || m) === 'QUORUM' || (m === 'CUSTOM' && customCfg.mach === 'QUORUM');
    const ini = iniMerge(quorum ? {} : JSON.parse(JSON.stringify(ZX_KEYS_WEB)), JSON.parse(JSON.stringify(MODELS[m].ini)));
    if (m === 'PENTAGON') ini.MISC.RAMSize = String(pentRun = pentRam());
    if ((MODELS[m].machine || m) === 'XBIOS136' && romDisk && romDisk.model === xbiosOf(m) && fs.exists(ROMDISK_FILE)) ini.ROM.ATM2 = ROMDISK_FILE; // 1 MB: disk + empty + xBIOS
    // no TR-DOS ROM on the server: take TR-DOS 5.03 from the ATM BIOS (page 1)
    for (const set of Object.keys(ini).filter((k) => /^ROM\./.test(k))) for (const r of ['dos', 'sys']) if (ini[set][r] === 'trd504tm.rom' && !fs.exists('trd504tm.rom')) ini[set][r] = 'bios_1_07_13.rom:1';
    return ini;
  }
  function modelIni(m) {
    const ini = modelIniObj(m);
    // HDD images (Image0= / Image1= empty in unreal.ini) are mounted by the page; sound volumes: unreal.ini (8192 = 100%)
    let t = '; web page: overrides for ' + MODELS[m].name + '\r\n';
    for (const [sec, kv] of Object.entries(ini)) {
      t += '[' + sec + ']\r\n';
      for (const [k, v] of Object.entries(kv)) t += k + '=' + v + '\r\n';
    }
    return new TextEncoder().encode(t);
  }
  const NDRIVES = 2; // drives shown in Options (A, B)

  const $ = (id) => document.getElementById(id);
  const canvas = $('screen');
  // a GPU canvas: willReadFrequently (a canvas in memory) made putImageData cheaper on desktops, but phones and tablets took more
  const ctx2d = canvas.getContext('2d', { alpha: false });
  function log(s) { console.log('[emu] ' + s); }
  let toastTimer = 0;
  function toast(s, err) {
    log(s);
    const t = $('toast'); t.textContent = s; t.classList.toggle('err', !!err); t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), err ? 4000 : 2500);
  }

  // the emulator: unreal/unreal.zip (its .wasm inside), or unreal/unreal.wasm when there is no zip
  async function fetchWasm() {
    let zip = null;
    try { zip = await fetchBytes(WASM_ZIP_URL); } catch (e) {}
    if (zip && UnrealZip.isZip(zip)) {
      const e = UnrealZip.list(zip).find((x) => /\.wasm$/i.test(x.name));
      if (e) return UnrealZip.extract(zip, e);
    }
    return fetchBytes(WASM_URL);
  }
  // sjasmplus (z00m128, BSD-3-Clause) in its own WASI with its own file system: files [{ path, data }] of the project,
  // main: its main file. → { files: [{ path, data }] (output, listing, labels, log), errors, warnings, log, ms }
  let sjasmMod = null;
  async function sjasmRun(files, main, proj) {
    if (!sjasmMod) {
      let b = null;
      try { const z = await fetchBytes(SJASM_URL); const e = UnrealZip.list(z).find((x) => /\.wasm$/i.test(x.name)); if (e) b = await UnrealZip.extract(z, e); } catch (e) {}
      if (!b) b = await fetchBytes(SJASM_URL.replace(/\.zip(\?|$)/, '.wasm$1').replace('sjasm.wasm', 'sjasmplus.wasm'));
      sjasmMod = await WebAssembly.compile(b);
    }
    const mfs = new MemFS();
    for (const f of files) mfs.write('src/' + f.path, f.data);
    const lines = [], t0 = performance.now();
    const w = new WASI(mfs, { args: ['sjasmplus', '--nologo', '--msg=war', '--outprefix=/out/', '--lst=/out/' + proj + '.lst', '--sym=/out/' + proj + '.sym', '/src/' + main], stdout: (l) => lines.push(l) });
    const inst = await WebAssembly.instantiate(sjasmMod, { wasi_snapshot_preview1: w.imports });
    w.setMemory(inst.exports.memory);
    let code = 0;
    try { inst.exports._start(); } catch (e) { if (e.exitCode === undefined) { lines.push('sjasmplus: ' + e.message); code = 1; } else code = e.exitCode; }
    for (const s of w.outbuf) if (s) lines.push(s);
    const ms = Math.round(performance.now() - t0);
    let errors = lines.filter((l) => /\berror\b/i.test(l) && !/^Errors:/i.test(l)).length; const warnings = lines.filter((l) => /\bwarning\b/i.test(l)).length;
    if (code && !errors) errors = 1;
    const text = lines.map((l) => l.replace(/\/src\//g, '')).join('\n') + '\n' + (errors ? 'Errors: ' + errors : 'OK') + ', warnings: ' + warnings + ', ' + ms + ' ms\n';
    const log = new TextEncoder().encode(text), out = [];
    for (const [k, f] of mfs.files) if (k.startsWith('out/')) out.push({ path: f.name.replace(/^out\//i, ''), data: f.data.slice(0, f.size) });
    out.push({ path: proj + '.log', data: log });
    return { files: out, errors, warnings, log, ms };
  }
  async function fetchBytes(url) {
    // revalidate with the server ('no-cache'). Options / System "Force update from server": download again ('reload') —
    // a file replaced by one with an older date (e.g. renamed) gets a 304 on revalidation and the cached copy stays.
    // The wasm has the build in its URL (?v=), so for it a revalidation is always enough.
    const force = load('fetch.reload') === '1' && !/\.wasm(\?|$)|unreal\.zip(\?|$)/i.test(url);
    const r = await fetch(encodeURI(url).replace(/\$/g, '%24'), { cache: force ? 'reload' : 'no-cache' });
    if (!r.ok) throw new Error(url + (r.status === 404 ? ' not found (404)' : ' HTTP ' + r.status));
    // some hosts answer a missing file with their own HTML page (status 200)
    if (/text\/html/i.test(r.headers.get('content-type') || '') && !/\.html?$/i.test(url)) throw new Error(url + ' not found (web page instead of the file)');
    return new Uint8Array(await r.arrayBuffer());
  }

  // ------------------------------------------------------------------ file system
  const fs = new MemFS();
  const drives = [null, null, null, null]; // {name, ext}

  // ------------------------------------------------------------------ wasm
  let module = null, E = null, AS = null;
  const cstr = (p) => { const m = new Uint8Array(E.memory.buffer); let s = ''; while (m[p]) s += String.fromCharCode(m[p++]); return s; };
  function setName(name) {
    const nb = E.web_namebuf(); const m = new Uint8Array(E.memory.buffer);
    for (let i = 0; i < name.length; i++) m[nb + i] = name.charCodeAt(i) & 0xFF;
    m[nb + name.length] = 0;
  }

  // fetch the files that are not in the in-memory FS yet (once per page session)
  const missing = new Set(), whyMissing = {}; // why: "rom/x.rom not found (404)" or a network error
  // a ROM is looked for as rom/<name>.zip first (the image inside: the same name, or the only / largest ROM there), then rom/<name>
  async function fetchSrv(f) {
    if (/\.rom$/i.test(f)) {
      let zip = null;
      try { zip = await fetchBytes(ROM_DIR + f.replace(/\.rom$/i, '.zip')); } catch (e) {}
      if (zip && UnrealZip.isZip(zip)) {
        const ents = UnrealZip.list(zip).filter((x) => x.size && !/\/$/.test(x.name));
        const e = ents.find((x) => x.name.replace(/^.*\//, '').toLowerCase() === f.toLowerCase())
          || ents.filter((x) => /\.(rom|bin)$/i.test(x.name)).sort((x, y) => y.size - x.size)[0];
        if (e) return UnrealZip.extract(zip, e);
      }
    }
    return fetchBytes(srcUrl(f));
  }
  async function ensureFiles(list) {
    const need = list.filter((f) => !fs.exists(f) && !missing.has(f));
    const got = await Promise.all(need.map((f) => fetchSrv(f).catch((e) => { whyMissing[f] = /not found|HTTP/.test(e.message) ? e.message.replace(/\.rom /i, '.rom (or .zip) ') : srcUrl(f) + ' (' + e.message + ')'; return null; })));
    // not asked again: a file the server does not have (404); a network error: asked again next time (a retry works)
    need.forEach((f, i) => { if (got[i]) fs.write(f, got[i]); else if (/not found|404/i.test(whyMissing[f] || '')) missing.add(f); });
    return list.every((f) => fs.exists(f));
  }
  async function modelFiles(m) {
    const list = MODELS[m].files;
    await ensureFiles(list);
    // Pentagon without trd504tm.rom: TR-DOS is taken from the ATM BIOS (see modelIni)
    if ((m === 'PENTAGON' || m === 'CUSTOM') && list.includes('trd504tm.rom') && !fs.exists('trd504tm.rom')) await ensureFiles(['bios_1_07_13.rom']);
    const lost = list.filter((f) => !fs.exists(f) && !((m === 'PENTAGON' || m === 'CUSTOM') && f === 'trd504tm.rom'));
    if (lost.length) toast('Cannot load: ' + lost.map((f) => whyMissing[f] || srcUrl(f) + ' not found').join(', '), true);
  }

  // ------------------------------------------------------------------ CMOS / NVRAM of each machine, kept in the browser
  // A machine with a CMOS (EVO, TS-Conf, Sprinter, GMX, a Custom ROM on one of them) starts with its own copy from the last
  // visit; none yet: the typical one (unreal/CMOS of the server; the Sprinter: the defaults of its Setup). The emulator's
  // CMOS / NVRAM files are written back to the browser (localStorage) on a switch, on hiding the page and every few seconds
  let nvBase = null; // unreal/CMOS as the server has it
  // the key of a machine's CMOS / NVRAM in the browser; a Custom ROM: CUSTOM.<HIMEM>, shared by all of that machine, unless
  // the json of its ZIP says "cmos": "own" (CUSTOM.<HIMEM>.<ZIP name>: its own) or "fresh" (the same, kept for the visit only)
  const nvOwn = () => model === 'CUSTOM' && crCur && /^(own|fresh)$/.test(crCur.cmos || '');
  const nvFresh = () => model === 'CUSTOM' && crCur && crCur.cmos === 'fresh';
  const nvMach = (m) => (m === 'CUSTOM' ? 'CUSTOM.' + ((MODELS.CUSTOM.ini && MODELS.CUSTOM.ini.MISC && MODELS.CUSTOM.ini.MISC.HIMEM) || '') + (nvOwn() ? '.' + crCur.key : '') : MODELS[m].machine || m);
  const nvVisit = {}; // "cmos": "fresh": the CMOS of this visit (a switch away and back keeps it); a new visit: the typical one
  const nvMisc = (m) => (MODELS[m] && MODELS[m].ini && MODELS[m].ini.MISC) || {};
  const nvHas = (m) => { const mi = nvMisc(m); return (!!mi.CMOS && !/^none$/i.test(mi.CMOS)) || mi.SMUC === '1'; };
  const nvFiles = (m) => (nvMisc(m).SMUC === '1' ? ['CMOS', 'NVRAM'] : ['CMOS']); // NVRAM: SMUC only
  const b64e = (u) => { let t = ''; for (let i = 0; i < u.length; i += 0x8000) t += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(t); };
  const b64d = (t) => { const b = atob(t), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  let nvLast = {}; // what was stored last (no write when nothing changed)
  function nvPut() { // before the machine starts: its own CMOS / NVRAM into the emulator's files
    if (nvBase === null && fs.exists('CMOS')) nvBase = fs.read('CMOS').slice();
    nvLast = {};
    if (!nvHas(model)) return;
    const k = nvMach(model);
    for (const f of ['CMOS', 'NVRAM']) {
      const v = nvFiles(model).includes(f) && (nvFresh() ? nvVisit[f + '.' + k] : load('nv.' + f + '.' + k));
      let d = null; try { if (v) d = b64d(v); } catch (e) {}
      if (d) { fs.write(f, d); nvLast[f] = v; }
      else if (f === 'CMOS' && nvBase) fs.write(f, nvBase.slice());
      else fs.remove(f);
    }
  }
  function nvKeep() { // the machine's CMOS / NVRAM (as the emulator wrote them) into the browser
    if (!E || nvKeep.skip || !nvHas(model) || (switching && !nvKeep.force)) return;
    try { E.web_save_nv(); } catch (e) { return; }
    const k = nvMach(model);
    for (const f of nvFiles(model)) {
      const d = fs.read(f); if (!d) continue;
      const v = b64e(d); if (v !== nvLast[f]) { if (nvFresh()) nvVisit[f + '.' + k] = v; else store('nv.' + f + '.' + k, v); nvLast[f] = v; }
    }
  }
  function nvReset(m) { // Options / System: Reset CMOS — the typical one from the next start
    for (const f of ['CMOS', 'NVRAM']) try { localStorage.removeItem('unreal.nv.' + f + '.' + nvMach(m)); } catch (e) {}
    for (const f of ['CMOS', 'NVRAM']) delete nvVisit[f + '.' + nvMach(m)];
  }
  setInterval(() => { if (E && !document.hidden) nvKeep(); }, 5000);
  document.addEventListener('visibilitychange', () => { if (document.hidden) nvKeep(); });
  window.addEventListener('pagehide', () => nvKeep());

  let startedAt = 0; // when the machine was (re)started: TS-BIOS needs its power-up run first
  // jobs counted in frames the machine has run (not in time: a download at start, a hidden tab, turbo): a key let go after
  // TS-BIOS went through its power-up. A job belongs to its machine: a model switch drops it
  let frameJobs = [], framesRun = 0;
  function afterFrames(n, fn) { frameJobs.push({ n: Math.max(1, Math.ceil(n)), fn, e: E }); }
  function frameJobsRun() {
    framesRun++;
    if (frameJobs.length) frameJobs = frameJobs.filter((j) => { if (j.e !== E) return false; if (--j.n > 0) return true; j.fn(); return false; });
  }
  let pageStarts = 0; // machine starts on this page (0: the first one, where a link may load something)
  async function start() {
    startedAt = performance.now(); framesRun = 0; frameJobs = [];
    if (!module) {
      const [wasm] = await Promise.all([fetchWasm(), ensureFiles(COMMON_FILES), ensureFiles(['sos.l'])]); // sos.l: labels of 48 BASIC for the debugger (optional)
      for (const f of COMMON_FILES) if (!fs.exists(f)) toast('File not found: ' + f, true);
      module = await WebAssembly.compile(wasm);
    }
    await modelFiles(model);
    if (nvHas(model)) await ensureFiles(['CMOS']); // the typical CMOS (GMX: its files do not list it)
    nvPut();
    macro = null;
    if (gsPref() !== '0') await ensureFiles([GS_ROM]); // on, or auto: the ROM is at hand when a program asks
    fs.write('web_model.ini', modelIni(model));
    const wasi = new WASI(fs, { stdout: (s) => log(s) });
    const env = {
      web_fatal: (p) => { const m = cstr(p); log('FATAL: ' + m); throw new Error(m); },
      web_message: (t, c, type) => {
        const text = cstr(t), cap = cstr(c);
        const q = (type & 0xF) === 4 || (type & 0xF) === 3; // a question (yes / no); else an error or a note: shown
        if (q && coreAnswer !== null) { const a = coreAnswer; coreAnswer = null; return a; } // asked by the page before the core asks (askBox)
        toast(cap + ': ' + text.replace(/\r?\n/g, ' '), true);
        if (q) return window.confirm(cap + '\n\n' + text) ? 6 : 7; // a question the page did not ask first (none known)
        return 1;
      },
      web_tz_offset: () => -new Date().getTimezoneOffset(),
      web_sleep: (ms) => as.web_sleep(ms),
      web_debug_notify: (on) => setTimeout(() => debugShown(!!on), 0),
      web_ui: (ptr) => webUi(ptr),
    };
    const as = window.UnrealAsyncify.create();
    const inst = await WebAssembly.instantiate(module, { wasi_snapshot_preview1: wasi.imports, env });
    AS = as;
    E = inst.exports;
    wasi.setMemory(E.memory);
    E._initialize();
    AS.init(E);
    E.web_init();
    bpRestore(); // breakpoints of the last session (debugger, Alt+C)
    statSeq = 0; statBoot = true;
    drives.forEach((d, i) => { if (d) insertFromFs(d.name, i, true); }); // re-insert after restart
    ulaApply(); ulaxApply();
    loadSpeed();
    eff7Apply();
    applySoundPrefs();
    applyPal();
    applyFdd(); applyMouseSwap(); applyNxKeys(); applyBorder(); applyText64();
    if (model === 'TSCONF') { // TS-BIOS starts in its Setup (Symbol Shift held over the power-up), its NVRAM already set:
      // Reset to: BD boot.$c — F12 boots the SD card. A link that loads something (a=, snap=, cpm=...): TS-BIOS as before (TR-DOS)
      const linkLoad = !pageStarts && ['a', 'b', 'snap', 'tape', 'hdd', 'hdd1', 'sd', 'mmc', 'sd2', 'cpm', 'autorun', 'run'].some((k) => LINK[k] !== undefined);
      // speed= of a link: the CPU clock TS-BIOS sets (NVRAM "CPU Speed"): 3.5 / 7 / 14 (MHz)
      if (!pageStarts && LINK.speed) { const mhz = parseFloat(LINK.speed); if (isFinite(mhz) && mhz > 0) tsNvSet(0xB1, mhz >= 10 ? 2 : mhz >= 5 ? 1 : 0); }
      if (linkLoad) tsNvSet(0xB4, 0);
      else { tsNvSet(0xB4, 3); E.web_zxkey(57, 1); afterFrames(60, () => E.web_zxkey(57, 0)); }
    }
    if (touchMouse) setTouchMouse(true); // touch mouse on: the new machine gets it too (its lock, nothing queued from before)
    pageStarts++;
    await applyHdd();
    sdMount(); sdUI();
    await dmApply();
    gkApply(true);
    updateUI();
  }

  // accurate FDD (Options / Disk): off by default — TR-DOS traps and no WD1793 delays, as before
  // Options / Video / Border: the visitor's choice (kept); not chosen yet: unreal.ini (or a Custom ROM ini) decides
  function applyBorder() {
    if (!E.web_border) return; const v = load('border'); if (v !== null) E.web_border(+v);
    const atm = /^(ATM710|ATM3|ATM450|PROFI)$/.test(himem()); // their video modes need the border area: no "None"
    $('bordersel').querySelector('[value="0"]').hidden = atm; $('bordersel').value = String(E.web_border(-1));
    const ts = himem() === 'TSL' || himem() === 'SPRINTER' || himem() === 'NEXT'; $('bordersel').disabled = ts; // TS-Conf: the picture is the program's raster (320x240 / 360x288)
    $('bordersel').title = ts ? 'ZX Evo TS-Conf: the picture follows the raster of the program (320×240, 360×288 whole)' : 'Border around the picture: none 256×192, small 320×240, wide 384×288 (full screens, .bsc)';
  }
  // Swap Mouse Buttons (Options / Input; swapmouse=1 in a link: this visit only). Off: unreal.ini / a Custom ROM ini decides
  let mswapLink = false;
  function applyNxKeys() { const v = +(load('nxkeys') || 0); if (E && E.web_nx_keys) E.web_nx_keys(v); const c = $('nxkeys'); if (c) c.value = String(v); }
  function applyMouseSwap() { if (E.web_mouse_swap && (mswapLink || load('mswap') === '1')) E.web_mouse_swap(1); const c = $('mswap'); if (c) c.checked = load('mswap') === '1'; }
  // a Custom ROM ZIP may set it ("fdd", or Traps / Fast in its ini [BETA128]): then the visitor's setting is not applied at start
  function applyFdd(user) {
    if (!E.web_fdd_accurate) return;
    const x = crX(), b = x.ini ? Object.entries(x.ini).find(([k]) => k.toLowerCase() === 'beta128') : null;
    const iniSets = !!b && Object.keys(b[1] || {}).some((k) => /^(traps|fast)$/i.test(k));
    if (!user && x.fdd) E.web_fdd_accurate(/^acc/i.test(x.fdd) ? 1 : 0);
    else if (!user && iniSets) { /* the ini of the ZIP decides */ }
    else E.web_fdd_accurate(load('fdd.acc') === '1' ? 1 : 0);
    const c = $('fddacc'); if (c) c.checked = !!E.web_fdd_accurate(-1);
  }
  // ------------------------------------------------------------------ Options: sound (defaults come from unreal.ini)
  // volumes are stored as % of the unreal.ini value (100% = ini)
  const SND_VOL = [0, 1, 2, 3, 4, 11], SND_OPT = { aychip: 5, aystereo: 6, ayvoltab: 7, sndfilter: 8, sdon: 9 };
  const SND_DEF = { 0: '5', 8: '1' }; // until changed in Options / Sound: beeper 5%, low-pass filter on
  const sndPref = (id) => { const v = load('snd.' + id); return v !== null ? v : SND_DEF[id] !== undefined ? SND_DEF[id] : null; };
  const volOf = (id, pct) => { const d = E.web_snd_get(100 + id) || 4000; return Math.round(d * pct / 100); };
  const pctOf = (id) => { const d = E.web_snd_get(100 + id) || 4000; return Math.round(E.web_snd_get(id) * 100 / d); };
  function fillSndList(sel, list) {
    if (sel.options.length) return;
    for (let i = 0, n = E.web_snd_count(list); i < n; i++) { const o = document.createElement('option'); o.value = i; o.textContent = cstr(E.web_snd_name(list, i)); sel.appendChild(o); }
  }
  function syncSoundUI() {
    fillSndList($('aystereo'), 6); fillSndList($('ayvoltab'), 7);
    for (const id of SND_VOL) { const r = $('vol' + id); r.value = pctOf(id); r.nextElementSibling.textContent = r.value + '%'; }
    for (const [el, id] of Object.entries(SND_OPT)) {
      const v = E.web_snd_get(id);
      if ($(el).type === 'checkbox') $(el).checked = !!v; else $(el).value = String(v);
    }
    $('vol3').disabled = !$('sdon').checked;
  }
  function applySoundPrefs() {
    for (const id of SND_VOL) { const v = sndPref(id); if (v !== null) E.web_snd_set(id, volOf(id, +v)); }
    for (const id of Object.values(SND_OPT)) { const v = sndPref(id); if (v !== null) E.web_snd_set(id, +v); }
    syncSoundUI();
    const gs = gsPref(), ay = load('ay');
    if (E.web_gs_kind_set) E.web_gs_kind_set(gs === '3' ? 1 : 0);
    if (!E.web_set_gs(gs === '1' || gs === '3' ? 1 : 0) && (gs === '1' || gs === '3')) toast('General Sound: rom/bootgs.rom (512 KB) not found', true);
    if (E.web_gs_auto_set) E.web_gs_auto_set(gs === '2' && fs.exists(GS_ROM) ? 1 : 0);
    if (ay !== null) E.web_set_ay_scheme(+ay);
    zxbusApply(false);
    $('gssel').value = gs === '2' ? '2' : String(E.web_get_gs());
    const sc = String(E.web_get_ay_scheme());
    if ([...$('aysel').options].some((o) => o.value === sc)) $('aysel').value = sc;
  }
  // General Sound: '0' off, '1' on, '2' auto (default): off until a program touches the GS ports
  // ZX-MultiSound '' off / 'auto' (default) / 'a2' / 'max'; MoonSound '0' / 'auto' (default) / '1'
  const zxmsPref = () => { const v = load('zxms'); return v === null ? 'auto' : ['', 'auto', 'a2', 'max'].includes(v) ? v : 'auto'; };
  const moonPref = () => { const v = load('moon'); return ['0', 'auto', '1'].includes(v) ? v : 'auto'; };
  const gsPref = () => { const v = load('gs'); return v === '0' || v === '1' || v === '3' ? v : '2'; }; // 0 off, 1 NeoGS, 2 auto (NeoGS), 3 classic GS
  // ZXBUS cards: ZX-MultiSound (Rev.A2 / Max) = TurboSound FM + SAA1099 + GS + SounDrive (+ OPL3 on Max), ZXM-MoonSound = OPL4
  let zxbusWas = false;
  const MOON_ROM = 'yrw801-m.rom'; // rom/yrw801-m.zip (yrw801-m.rom in it)
  async function zxbusApply(user) {
    if (!E || !E.web_opl) return;
    const ms = zxmsPref(), moonv = moonPref(), moon = moonv === '1' || moonv === 'auto';
    if (user && ms && ms !== 'auto') { // the board's chips on: AY = TurboSound with YM2203, SAA, SounDrive, GS (auto when it was off)
      E.web_set_ay_scheme(6); store('ay', '6'); E.web_snd_set(5, 2); store('snd.5', '2'); E.web_snd_set(9, 1); store('snd.9', '1');
      if (gsPref() === '0') { store('gs', '2'); await ensureFiles([GS_ROM]); if (E.web_gs_auto_set) E.web_gs_auto_set(fs.exists(GS_ROM) ? 1 : 0); }
    }
    if (user && (!ms || ms === 'auto') && zxbusWas) { // MultiSound off: the AY block (scheme, chip, stereo, volume table, volume) and Covox / SD as in unreal.ini
      E.web_set_ay_scheme(E.web_snd_get(112)); for (const id of [5, 6, 7]) E.web_snd_set(id, E.web_snd_get(100 + id));
      E.web_snd_set(1, E.web_snd_get(101)); E.web_snd_set(9, E.web_snd_get(109) ? 1 : 0);
      for (const k of ['ay', 'snd.1', 'snd.5', 'snd.6', 'snd.7', 'snd.9']) try { localStorage.removeItem('unreal.' + k); } catch (e) {}
    }
    zxbusWas = !!ms && ms !== 'auto';
    E.web_snd_set(10, ms && ms !== 'auto' ? 1 : 0);
    if (E.web_zxms_auto_set) E.web_zxms_auto_set(ms === 'auto' ? 3 : 0); // SAA, TurboSound FM: on when a program uses them
    if (user && ms === 'auto' && gsPref() === '0') { store('gs', '2'); await ensureFiles([GS_ROM]); if (E.web_gs_auto_set) E.web_gs_auto_set(fs.exists(GS_ROM) ? 1 : 0); }
    if (moon && !fs.exists(MOON_ROM)) { try { await ensureFiles([MOON_ROM]); } catch (e) {} }
    const r = E.web_opl(moonv === '1' ? 2 : moonv === 'auto' ? 3 : ms === 'max' ? 1 : 0);
    moonIntApply(moon);
    zxbusUI();
    $('moonrom').textContent = moon && !(r & 0x100) ? 'no rom/yrw801-m.zip: FM only, wavetable silent' : '';
    $('moonrom').classList.toggle('err', moon && !(r & 0x100));
    if (user) { syncSoundUI(); $('gssel').value = gsPref() === '2' ? '2' : String(E.web_get_gs()); const sc = String(E.web_get_ay_scheme()); if ([...$('aysel').options].some((o) => o.value === sc)) $('aysel').value = sc; }
  }
  // the ZXBUS cards' controls: in Options / Sound and again in Options / ULA (prefix u_), both show the same settings
  // MoonSound INT (Help: MoonSound INT): 'off', 'card' (default: the INT jumper, the IRQ of the OPL4 timers), 'hz' (the
  // machine's INT at moonhz instead of the frame's while a timer runs); before 1.49.0: the checkboxes moonint ('0' = off)
  // and moon60 ('1' = the frame INT at moonhz)
  const moonHz = () => { const v = Math.round(+load('moonhz')); return v >= 10 && v <= 1000 ? v : 60; };
  const moonInt = () => { const v = load('moonintm'); if (['off', 'card', 'hz'].includes(v)) return v; return load('moon60') === '1' ? 'hz' : load('moonint') === '0' ? 'off' : 'card'; };
  function moonIntApply(moon) {
    if (!E) return;
    const m = moon ? moonInt() : 'off';
    if (E.web_opl_int_set) E.web_opl_int_set(m === 'card' ? 1 : 0);
    if (E.web_opl_int60_set) E.web_opl_int60_set(m === 'hz' ? 1 : 0);
    if (E.web_opl_int60_hz) E.web_opl_int60_hz(moonHz());
  }
  function zxbusUI() {
    const moon = moonPref() !== '0', m = moonInt();
    $('zxms').value = zxmsPref(); $('moon').value = moonPref();
    for (const p of ['', 'u_']) {
      if (document.activeElement !== $(p + 'moonhz')) $(p + 'moonhz').value = moonHz();
      $(p + 'moonhzrow').hidden = m !== 'hz';
      $(p + 'moonint').value = m; $(p + 'moonint').disabled = $(p + 'moonhz').disabled = !moon;
    }
  }
  function bindSoundOpts() {
    $('zxms').onchange = () => { store('zxms', $('zxms').value); zxbusApply(true); };
    $('moon').onchange = () => { store('moon', $('moon').value); zxbusApply(true); };
    for (const p of ['', 'u_']) $(p + 'moonint').onchange = () => { store('moonintm', $(p + 'moonint').value); moonIntApply(moonPref() !== '0'); zxbusUI(); };
    for (const p of ['', 'u_']) {
      const hz = $(p + 'moonhz');
      hz.onchange = () => { const v = Math.round(+hz.value); if (v >= 10 && v <= 1000) store('moonhz', String(v)); if (E && E.web_opl_int60_hz) E.web_opl_int60_hz(moonHz()); hz.blur(); zxbusUI(); };
      hz.onkeydown = (e) => { if (e.key === 'Enter') hz.onchange(); };
    }
    $('ulaz_def').onclick = () => { for (const k of ['moonintm', 'moonint', 'moon60']) try { localStorage.removeItem('unreal.' + k); } catch (e) {} moonIntApply(moonPref() !== '0'); zxbusUI(); };
    zxbusUI();
    $('gssel').onchange = async () => {
      const v = $('gssel').value, on = v === '1' || v === '3' ? 1 : 0;
      if (v !== '0') await ensureFiles([GS_ROM]);
      if (E && E.web_gs_kind_set) E.web_gs_kind_set(v === '3' ? 1 : 0); // classic GS (12 MHz, no #0F) or NeoGS: the GS restarts
      if (E && E.web_set_gs(on) !== on) { toast('General Sound: rom/bootgs.rom (512 KB) not found', true); $('gssel').value = '0'; }
      if (E && E.web_gs_auto_set) E.web_gs_auto_set(v === '2' && fs.exists(GS_ROM) ? 1 : 0);
      store('gs', $('gssel').value);
    };
    $('aysel').onchange = () => { if (E) E.web_set_ay_scheme(+$('aysel').value); store('ay', $('aysel').value); };
    for (const id of SND_VOL) {
      const r = $('vol' + id);
      r.oninput = () => { r.nextElementSibling.textContent = r.value + '%'; if (E) E.web_snd_set(id, volOf(id, +r.value)); store('snd.' + id, r.value); };
      r.ondblclick = () => { r.value = SND_DEF[id] !== undefined ? +SND_DEF[id] : 100; r.oninput(); }; // double click: back to the default
    }
    for (const [el, id] of Object.entries(SND_OPT)) {
      $(el).onchange = () => {
        const v = $(el).type === 'checkbox' ? ($(el).checked ? 1 : 0) : +$(el).value;
        if (E) E.web_snd_set(id, v); store('snd.' + id, String(v));
        $('vol3').disabled = !$('sdon').checked;
      };
    }
  }

  // ------------------------------------------------------------------ Options: palette ([COLORS] of unreal.ini, default from color=)
  function applyPal() {
    const sel = $('palsel');
    if (!sel.options.length) {
      for (let i = 0, n = E.web_pal_count(); i < n; i++) { const nm = cstr(E.web_pal_name(i)); if (/^atari\./i.test(nm)) continue; const o = document.createElement('option'); o.value = nm; o.textContent = nm; sel.appendChild(o); } // atari.* are AtariPreset color tables, not palettes
      sel.onchange = () => { setPal(sel.value); store('pal', sel.value); };
    }
    setPal(load('pal'));
  }
  function setPal(name) {
    for (let i = 0, n = E.web_pal_count(); i < n; i++) if (name && cstr(E.web_pal_name(i)) === name) { E.web_set_pal(i); break; }
    $('palsel').value = cstr(E.web_pal_name(E.web_get_pal()));
    if (gfx && gfx.open) gfx.refresh();
  }

  // ------------------------------------------------------------------ Options: video filter (drawn over the canvas)
  let fxMode = load('fx') || 'sharp';
  const FX_LINK = { off: 'sharp', none: 'sharp', scanlines: 'scan', 'anti-text64': 'text64', 'anti-text42': 'text42', antitext64: 'text64', antitext42: 'text42' }; // fx= names
  function setFx(v) {
    v = { text64ext: 'text64', advmame: 'scale2x' }[v] || v; // the names before 1.68
    fxMode = ['sharp', 'smooth', 'scan', 'crt', 'xbr', 'pal', 'scale2x', 'scale3x', 'text64', 'text42'].includes(v) ? v : 'sharp';
    if (GL_FX.includes(fxMode) && !glInit()) { toast('Filter ' + fxMode.toUpperCase() + ': no WebGL 2 in this browser', true); fxMode = 'sharp'; }
    const w = $('screenwrap');
    ['smooth', 'scan'].forEach((m) => w.classList.toggle('fx-' + m, m === fxMode));
    w.classList.toggle('fx-gl', GL_FX.includes(fxMode));
    $('fxsel').value = fxMode;
    placeFx(); applyText64();
  }
  // Anti-Text64 (from UnrealSpeccy): the core finds 4×8 letters (64 a line, the press) on the ZX screen and draws them 8×16
  // AdvMAME (Scale2x): a double-size frame drawn again from its own pixels with the slopes smoothed (the core, after each frame)
  function applyText64() { if (E && E.web_text64) { E.web_text64(fxMode === 'text64' ? 1 : fxMode === 'text42' ? 2 : 0); if (E.web_advmame) E.web_advmame(fxMode === 'scale2x' ? 1 : 0); render(); } }
  // xBR, CRT, PAL: shaders (glfx.js) on a canvas over the screen; the screen canvas stays under it (pointer, screenshots)
  const GL_FX = ['xbr', 'scale3x', 'crt', 'pal'];
  let glfx = null, glTried = false;
  function glInit() {
    if (!glTried) { glTried = true; try { glfx = window.UnrealGL && UnrealGL.create($('glscreen')); } catch (e) { log('WebGL: ' + e.message); glfx = null; } }
    return !!glfx;
  }
  function glDraw(img, w, h) {
    if (!glfx || !GL_FX.includes(fxMode)) return;
    try { glfx.draw(img, w, h, E.web_fb_dbl ? E.web_fb_dbl() : 0, fxMode); } catch (e) { log('WebGL: ' + e.message); glfx = null; setFx('sharp'); }
  }
  function placeFx() {
    const fx = $('fx'), gc = $('glscreen');
    fx.style.width = canvas.style.width; fx.style.height = canvas.style.height;
    gc.style.width = canvas.style.width; gc.style.height = canvas.style.height;
    if (glfx) { glfx.size(parseFloat(canvas.style.width) || 1, parseFloat(canvas.style.height) || 1); if (E && imageData && GL_FX.includes(fxMode)) glDraw(imageData, canvas.width, canvas.height); }
    const ch = parseFloat(canvas.style.height) || 0;
    const lines = canvas.height >= 384 ? canvas.height / 2 : canvas.height; // one ZX line = 2 rows in double size
    const period = lines ? ch / lines : 3;
    fx.style.setProperty('--sl', period + 'px');
    // thin lines on small screens turn into moire: make them lighter
    const strong = 0.38;
    fx.style.setProperty('--so', String(period >= 2.5 ? strong : period >= 1.8 ? strong * 0.5 : 0));
  }

  // ------------------------------------------------------------------ Kempston mouse
  // mouse / trackpad: the toolbar button captures the pointer (Esc releases it);
  // touch: the button turns on taps on the screen — 1 tap moves the pointer there, 2 taps = left button, 3 taps = right button
  let mouseLocked = false, mouseUnlockAt = 0, mfx = 0, mfy = 0, mbtn = 0, touchMouse = false;
  const msum = { x: 0, y: 0 }; // what the core has accumulated (wm_x, wm_y): Kempston X = x, Y = -y (8 bits)
  function mouseSend(dx, dy, dz, b) { msum.x += dx; msum.y += dy; E.web_mouse(dx, dy, dz, b); }
  function canLockMouse() {
    return E && E.web_mouse_type() === 1 && !dbgOn && !isPaused() && !rz && !!canvas.requestPointerLock;
  }
  function releaseMouse() { if (mouseLocked && document.exitPointerLock) document.exitPointerLock(); }
  function mouseUI() {
    $('mousebtn').classList.toggle('on', mouseLocked || touchMouse); canvas.classList.toggle('tmouse', touchMouse);
    $('mbar').classList.toggle('on', touchMouse);
    $('mbar').querySelectorAll('[data-b]').forEach((b) => b.classList.toggle('on', !!(mbtn & +b.dataset.b)));
    $('mpps').textContent = $('tmscale').value + 'pps';
  }
  let tmQ = []; // one action per emulated frame: the program has to see each step
  function setTouchMouse(v) {
    touchMouse = v; mbtn = 0; tmSticky = tmFinger = 0; tmQ = []; tmPend.x = tmPend.y = 0;
    if (E) { mouseSend(0, 0, 0, 0); E.web_mouse_lock(v ? 1 : 0); }
    mouseUI();
  }
  function tmFrame() { if (!touchMouse) return; if (tmQ.length) tmQ.shift()(); else tmFrameMove(); }
  // touch: dragging moves the program's pointer by the same distance (start on the pointer and it stays under the finger),
  // releasing stops it; a double tap = a left button click (MB / RB of the bar: middle and right buttons; a second finger holds the left one). The program reads the Kempston ports as 8-bit
  // counters, so the movement goes out in steps of at most 40 units a frame.
  const tmPend = { x: 0, y: 0 };
  function tmFrameMove() {
    const step = (v) => Math.max(-40, Math.min(40, Math.trunc(v)));
    const x = step(tmPend.x), y = step(tmPend.y);
    if (x || y) { tmPend.x -= x; tmPend.y -= y; mouseSend(x, y, 0, mbtn); }
  }
  // buttons: tmSticky = MB / RB of the bar (bits 4 / 2), tmFinger = the left one held by a second finger
  let tmSticky = 0, tmFinger = 0;
  function tmButtons() { mbtn = tmSticky | tmFinger; if (E) mouseSend(0, 0, 0, mbtn); mouseUI(); }
  function tmClick(bit) { tmQ.push(() => mouseSend(0, 0, 0, mbtn | bit), () => {}, () => {}, () => mouseSend(0, 0, 0, mbtn)); }
  function bindTouchMouse() {
    let drag = null, second = null;
    canvas.addEventListener('pointerdown', (e) => {
      if (!touchMouse || e.pointerType === 'mouse') return;
      e.preventDefault(); canvas.setPointerCapture(e.pointerId);
      if (drag && second === null) { // a second finger holds the left button while it stays down
        second = e.pointerId; drag.moved = true; tmFinger = 1; tmButtons(); return;
      }
      if (drag && second !== null) return; // a third finger: ignored (it took the drag over, then the first finger's lift no longer matched)
      drag = { id: e.pointerId, x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY, moved: false };
    });
    const secondUp = (e) => { if (e.pointerId !== second) return false; second = null; tmFinger = 0; tmButtons(); return true; };
    canvas.addEventListener('pointerup', secondUp); canvas.addEventListener('pointercancel', secondUp);
    canvas.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      e.preventDefault();
      if (!drag.moved && Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) < 8) return; // still a tap
      drag.moved = true;
      const r = canvas.getBoundingClientRect(), k = +($('tmscale').value || 1); // the program moves k pixels per Kempston unit
      tmPend.x += (e.clientX - drag.x) * 320 / r.width / k;
      tmPend.y += (e.clientY - drag.y) * 240 / r.height / k;
      drag.x = e.clientX; drag.y = e.clientY;
    });
    let lastTap = null; // a tap (no move): a second one within 350 ms near it clicks the left button
    const end = (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      if (!drag.moved) {
        const now = performance.now();
        if (lastTap && now - lastTap.t < 350 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 40) { tmClick(1); lastTap = null; }
        else lastTap = { t: now, x: e.clientX, y: e.clientY };
      } else lastTap = null;
      drag = null;
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', (e) => { if (drag && e.pointerId === drag.id) drag = null; });
  }
  function bindMouse() {
    let btnPtr = 'mouse';
    $('tmscale').value = load('tmscale') || '1';
    $('tmscale').onchange = () => { store('tmscale', $('tmscale').value); $('tmscale').blur(); mouseUI(); };
    // the bar under the screen: MB / RB tap = click, long tap = held until the next tap; pps = pointer speed 1 / 2
    $('mbar').querySelectorAll('[data-b]').forEach((b) => {
      const bit = +b.dataset.b; let t = null, long = false;
      b.addEventListener('pointerdown', (e) => {
        e.preventDefault(); e.stopPropagation(); long = false;
        t = setTimeout(() => { long = true; tmSticky |= bit; tmButtons(); }, 450);
      });
      const up = (e) => {
        e.stopPropagation(); clearTimeout(t);
        if (long) return;
        if (tmSticky & bit) { tmSticky &= ~bit; tmButtons(); } else tmClick(bit);
      };
      b.addEventListener('pointerup', up);
      b.addEventListener('pointercancel', () => clearTimeout(t));
      b.addEventListener('contextmenu', (e) => e.preventDefault());
    });
    $('mpps').addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); });
    $('mpps').addEventListener('pointerup', (e) => {
      e.stopPropagation();
      $('tmscale').value = $('tmscale').value === '1' ? '2' : '1'; store('tmscale', $('tmscale').value); mouseUI();
    });
    bindTouchMouse();
    $('mousebtn').addEventListener('pointerdown', (e) => { btnPtr = e.pointerType; });
    $('mousebtn').onclick = () => {
      if (!E || E.web_mouse_type() !== 1) { toast('Kempston mouse is off in unreal.ini', true); return; }
      if (touchMouse) { setTouchMouse(false); toast('Mouse off'); return; }
      if (btnPtr === 'mouse') {
        if (!canLockMouse()) { toast('Mouse: run the machine first', true); return; }
        const p = canvas.requestPointerLock(); if (p && p.catch) p.catch(() => {});
      } else { setTouchMouse(true); toast('Mouse on'); }
    };
    canvas.addEventListener('mousedown', (e) => {
      if (mouseLocked) { mbtn = e.buttons & 7; mouseSend(0, 0, 0, mbtn); e.preventDefault(); return; }
      // Options / Input: a click on the screen captures the mouse (Esc releases it); that click is not a button press
      if (load('mclick') === '1' && e.button === 0 && !matchMedia('(hover: none)').matches && !touchMouse && canLockMouse()) { e.preventDefault(); const p = canvas.requestPointerLock(); if (p && p.catch) p.catch(() => {}); }
    });
    document.addEventListener('mouseup', (e) => { if (mouseLocked) { mbtn = e.buttons & 7; mouseSend(0, 0, 0, mbtn); } });
    document.addEventListener('mousemove', (e) => {
      if (!mouseLocked) return;
      const k = (canvas.width / 2) / (canvas.getBoundingClientRect().width || 1); // ZX pixels per CSS pixel
      mfx += e.movementX * k; mfy += e.movementY * k;
      const dx = Math.trunc(mfx), dy = Math.trunc(mfy);
      mfx -= dx; mfy -= dy;
      if (dx || dy) mouseSend(dx, dy, 0, mbtn);
    });
    canvas.addEventListener('wheel', (e) => { if (!mouseLocked) return; e.preventDefault(); if (e.deltaY) mouseSend(0, 0, e.deltaY < 0 ? 120 : -120, mbtn); }, { passive: false });
    canvas.addEventListener('contextmenu', (e) => { if (mouseLocked) e.preventDefault(); });
    document.addEventListener('pointerlockchange', () => {
      const on = document.pointerLockElement === canvas;
      if (on === mouseLocked) return;
      mouseLocked = on; mbtn = 0; mfx = mfy = 0;
      if (on && touchMouse) { touchMouse = false; }
      if (E) { mouseSend(0, 0, 0, 0); E.web_mouse_lock(on ? 1 : 0); }
      mouseUI();
      if (on) toast('Mouse captured (Kempston). Esc to release');
      else mouseUnlockAt = performance.now();
    });
  }

  // ------------------------------------------------------------------ video
  let imageData = null;
  function render() {
    E.web_render();
    blit();
  }
  // Mix Frames (Options / Video): the picture = the mean of the last two emulated frames (gigascreen, objects every other
  // frame). The frames are rendered as they run (the last two of a refresh), the mix is drawn once
  let mixOn = false, mixA = null, mixB = null, mixN = 0, mixScr = 0;
  function mixUI() { // a machine started: GMX = on, others = off (the box is off there)
    const g = M() === 'GMX'; mixOn = g; mixN = 0;
    $('vidmix').checked = g; $('vidmix').disabled = !g;
  }
  // each emulated frame: which screen it shows; the picture is grabbed (rendered and copied) only while the screens go
  // 1 2 1 2 (gigascreen), the only case blitMix mixes: a GMX game or OS (Mix Frames is on there by default) costs nothing
  function mixStep() {
    mixScr = ((mixScr << 1) | ((E.web_p7ffd() >> 3) & 1)) & 15; // the shown screen (#7FFD D3) of the last 4 frames
    if (mixScr === 5 || mixScr === 10) mixGrab(); else mixN = 0;
  }
  function mixGrab() {
    E.web_render();
    const w = E.web_fb_w(), h = E.web_fb_h(), n = w * h;
    if (!mixA || mixA.length !== n) { mixA = new Uint32Array(n); mixB = new Uint32Array(n); mixN = 0; }
    const t = mixA; mixA = mixB; mixB = t; // mixB: the frame before, mixA: this one
    mixA.set(new Uint32Array(E.memory.buffer, E.web_fb(), n)); mixN++;
  }
  function blitMix() {
    const w = E.web_fb_w(), h = E.web_fb_h();
    // mixed only while the screen changes every frame (gigascreen: 1 2 1 2); a game with two screens in turn every other frame
    // (Edge Grinder: 1 1 2 2) is shown as it is, not with its moving things doubled
    if (!mixA || mixN < 2 || mixA.length !== w * h || (mixScr !== 5 && mixScr !== 10)) { render(); return; }
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; imageData = null; applyScale(); }
    if (!imageData) imageData = new ImageData(w, h);
    const o = new Uint32Array(imageData.data.buffer), a = mixA, b = mixB;
    for (let i = 0; i < o.length; i++) { const x = a[i], y = b[i]; o[i] = x === y ? x : (((x & 0xFEFEFEFE) >>> 1) + ((y & 0xFEFEFEFE) >>> 1)) | 0xFF000000; }
    ctx2d.putImageData(imageData, 0, 0); glDraw(imageData, w, h);
  }
  function blit() { // copy the wasm frame buffer to the canvas
    const w = E.web_fb_w(), h = E.web_fb_h();
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; imageData = null; applyScale(); }
    if (!imageData) imageData = new ImageData(w, h);
    imageData.data.set(new Uint8ClampedArray(E.memory.buffer, E.web_fb(), w * h * 4));
    ctx2d.putImageData(imageData, 0, 0); glDraw(imageData, w, h);
  }

  // ------------------------------------------------------------------ audio
  const RATE = 44100; // the core's sound rate
  const IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  let audio = null;
  const workletSrc = `
    class Ring extends AudioWorkletProcessor {
      constructor() {
        super();
        this.buf = new Float32Array(${RATE} * 2); this.rd = 0; this.wr = 0; this.fill = 0; this.n = 0; this.got = 0;
        this.port.onmessage = (e) => {
          const d = e.data;
          if (d === 'flush') { this.rd = this.wr = this.fill = 0; return; }
          const cap = this.buf.length / 2; this.got += d.length / 2; // all samples ever received: the page knows what is still on the way
          for (let i = 0; i < d.length; i += 2) {
            if (this.fill >= cap) { this.rd = (this.rd + 2) % this.buf.length; this.fill--; }
            this.buf[this.wr] = d[i]; this.buf[this.wr + 1] = d[i + 1];
            this.wr = (this.wr + 2) % this.buf.length; this.fill++;
          }
        };
      }
      process(inputs, outputs) {
        const out = outputs[0]; const L = out[0], R = out[1] || out[0];
        for (let i = 0; i < L.length; i++) {
          if (this.fill > 0) { L[i] = this.buf[this.rd]; R[i] = this.buf[this.rd + 1]; this.rd = (this.rd + 2) % this.buf.length; this.fill--; }
          else { L[i] = 0; R[i] = 0; }
        }
        if ((++this.n & 3) === 0) this.port.postMessage({ fill: this.fill, got: this.got, t: currentTime }); // t: the audio clock of this report
        return true;
      }
    }
    registerProcessor('unreal-ring', Ring);`;

  let audioStarting = false, pendingCtx = null;
  // iOS audio session: 'playback' = the emulator is the main sound (plays with the silent switch on, other apps' sound
  // stops when it starts); 'ambient' = mixes with other apps (music keeps playing), the silent switch mutes it
  const iosMix = () => load('iosmix') !== '0'; // on by default
  function setAudioSession() { try { if (navigator.audioSession) navigator.audioSession.type = iosMix() ? 'ambient' : 'playback'; } catch (e) {} }
  function bindIosMix() {
    if (!IOS) return;
    $('iosmixcard').hidden = false;
    $('iosmix').checked = iosMix();
    $('iosmix').onchange = () => {
      store('iosmix', $('iosmix').checked ? '1' : '0');
      setAudioSession();
      // the session type is taken when the sound starts: restart it (this tap is a user gesture, so it may start again)
      if (audio) { killAudio(); if (!muted) startAudio(); }
    };
  }
  async function startAudio() {
    if (audio || audioStarting || !(window.AudioContext || window.webkitAudioContext)) return;
    audioStarting = true;
    let ctx;
    try { ctx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: RATE, latencyHint: 'interactive' }); }
    catch (err) { log('audio: ' + err); audioStarting = false; return; }
    pendingCtx = ctx;
    // iOS Safari: the context starts only if resume() is called inside the user gesture, i.e. before the first await
    try { if (!isPaused() && !dbgOn) ctx.resume().catch(() => {}); } catch (e) {}
    setAudioSession(); // iOS 17+: playback (plays in silent mode, stops other apps) or ambient (mixes with other apps)
    const gain = ctx.createGain(); gain.gain.value = muted ? 0 : volume();
    gain.connect(ctx.destination);
    // analyser before the volume: the meter and the spectrum also work with the sound muted
    // analysers sit before the volume (the visualizer also works with the sound muted):
    // input → split → L / R analysers → merge → mono-summing analyser (spectrum) → volume
    const an = ctx.createAnalyser(); an.fftSize = 2048; an.smoothingTimeConstant = 0.5; an.minDecibels = -90; an.maxDecibels = -20;
    const split = ctx.createChannelSplitter(2), merge = ctx.createChannelMerger(2);
    const anL = ctx.createAnalyser(), anR = ctx.createAnalyser(); anL.fftSize = anR.fftSize = 1024;
    split.connect(anL, 0); split.connect(anR, 1); anL.connect(merge, 0, 0); anR.connect(merge, 0, 1);
    merge.connect(an); an.connect(gain);
    const a = { ctx, gain, an, anL, anR, node: null, fill: 0, got: 0, sent: 0, reportAt: performance.now(), push: null, flush: null };
    if (ctx.audioWorklet) {
      const urls = [];
      try { urls.push(URL.createObjectURL(new Blob([workletSrc], { type: 'application/javascript' }))); } catch (e) {}
      urls.push('data:application/javascript;base64,' + btoa(workletSrc));
      for (const url of urls) {
        try {
          try { await ctx.audioWorklet.addModule(url); } finally { if (url.startsWith('blob:')) URL.revokeObjectURL(url); }
          const node = new AudioWorkletNode(ctx, 'unreal-ring', { outputChannelCount: [2] });
          node.connect(split);
          node.port.onmessage = (e) => { a.fill = e.data.fill; a.got = e.data.got || 0; a.repT = e.data.t; a.reportAt = performance.now(); };
          a.node = node;
          a.push = (f) => { a.sent += f.length / 2; node.port.postMessage(f, [f.buffer]); };
          a.flush = () => { node.port.postMessage('flush'); a.fill = 0; };
          break;
        } catch (e) { /* try next */ }
      }
    }
    if (!a.node) { // ScriptProcessorNode fallback
      const cap = RATE; const ring = new Float32Array(cap * 2); let rd = 0, wr = 0;
      const sp = ctx.createScriptProcessor(1024, 0, 2);
      sp.onaudioprocess = (e) => {
        const L = e.outputBuffer.getChannelData(0), R = e.outputBuffer.getChannelData(1);
        for (let i = 0; i < L.length; i++) {
          if (a.fill > 0) { L[i] = ring[rd]; R[i] = ring[rd + 1]; rd = (rd + 2) % ring.length; a.fill--; }
          else { L[i] = R[i] = 0; }
        }
        a.reportAt = performance.now();
      };
      a.push = (f) => {
        for (let i = 0; i < f.length; i += 2) {
          if (a.fill >= cap) { rd = (rd + 2) % ring.length; a.fill--; }
          ring[wr] = f[i]; ring[wr + 1] = f[i + 1]; wr = (wr + 2) % ring.length; a.fill++;
        }
        a.reportAt = performance.now();
      };
      a.flush = () => { rd = wr = 0; a.fill = 0; };
      a.sp = true;
      sp.connect(split);
      a.node = sp;
    }
    if (pendingCtx !== ctx) { try { ctx.close().catch(() => {}); } catch (e) {} return; } // dropped while it was setting up
    audio = a;
    try { if (ctx.state !== 'running' && !isPaused()) await ctx.resume(); } catch (e) {}
    updateSoundBtn();
  }
  // iOS: a context that went through an app switch comes back broken (no sound, the audio-clocked loop slows down),
  // so on iOS it is closed when the page is hidden; the next touch makes a new one ("Tap for sound" until then)
  let audioLost = false;
  function killAudio() {
    const a = audio, c = pendingCtx;
    audio = null; pendingCtx = null; audioStarting = false;
    if (a && a.node) try { a.node.disconnect(); } catch (e) {}
    for (const x of new Set([a && a.ctx, c])) if (x) try { x.close().catch(() => {}); } catch (e) {}
    if (a || c) audioLost = true;
    sentSinceReport = 0; lastReportSeen = 0;
  }
  let muted = false;
  const VOLUME = 0.6;
  function volume() { return VOLUME; }
  function setIcon(btn, id) { $(btn).querySelector('use').setAttribute('href', '#' + id); }
  // a suspended context (iOS, autoplay rules) is resumed by the next touch / click / key
  function unlockAudio() {
    if (!E) return;
    const c = audio ? audio.ctx : pendingCtx; // the context may still be setting up its worklet
    if (!c) { startAudio(); return; }
    if (c.state !== 'running' && !isPaused() && !dbgOn) c.resume().catch(() => {});
  }
  function toggleSound() {
    if (!audio) { muted = false; startAudio(); updateSoundBtn(); return; }
    muted = !muted; audio.gain.gain.value = muted ? 0 : volume(); updateSoundBtn();
    if (!muted) unlockAudio();
  }
  function updateSoundBtn() {
    const on = !muted; // the sound is on by default; the context itself starts with the first touch / click / key
    setIcon('snd', on ? 'i-snd' : 'i-mute');
    $('snd').title = on ? 'Sound off' : 'Sound on';
  }
  // is the machine making a sound right now (the output is not running)? Then "Tap for sound" is worth showing
  let soundAt = 0;
  function soundCheck(n) {
    const s16 = new Int16Array(E.memory.buffer, E.web_snd(), n * 2);
    let lo = 32767, hi = -32768;
    for (let i = 0; i < s16.length; i += 6) { const v = s16[i]; if (v < lo) lo = v; if (v > hi) hi = v; }
    if (hi - lo > 300) soundAt = performance.now();
  }
  function pushAudio(n) {
    if (!audio || !n) return;
    const s16 = new Int16Array(E.memory.buffer, E.web_snd(), n * 2);
    const f = new Float32Array(n * 2);
    for (let i = 0; i < f.length; i++) f[i] = s16[i] / 32768;
    audio.push(f);
  }



  // ------------------------------------------------------------------ sound visualizer (top left of the screen)
  // one effect at a time; "smooth decay": bars fall slowly with peak caps, traces leave a fading trail
  const VZ_MODES = { spectrum: 64, mirror: 64, scope: 64, chan: 0, water: 64, xy: 88 }; // width in CSS px (chan: by channel count)
  const VZ_TALL = { xy: 32 }; // the stereo picture is drawn twice as large
  const VZ_NB = { spectrum: 30, mirror: 30, water: 16 }; // frequency bands
  const VZ_H = 16, VZ_BARS = 30;
  let vzMode = load('viz') || 'chan', vzDecay = load('vizdecay') !== '0';
  if (vzMode !== 'off' && !(vzMode in VZ_MODES)) vzMode = 'chan';
  let vzAlpha = 0, vzQuietT = 0, vzLast = 0, vzBins = new Float32Array(VZ_BARS), vzPeak = new Float32Array(VZ_BARS);
  let vzTD = null, vzL = null, vzR = null, vzFD = null, vzCh = new Float32Array(256), vzChP = new Float32Array(256), vzFl = new Float32Array(256), vzChN = '';
  const vzW = () => vzMode === 'chan' ? vzChW : (VZ_MODES[vzMode] || 1);
  let vzChW = 12;
  function vzSetup() {
    const c = $('viz'), dpr = Math.max(1, window.devicePixelRatio || 1), w = vzW();
    const h = VZ_TALL[vzMode] || VZ_H;
    c.style.width = w + 'px'; c.style.height = h + 'px';
    c.width = Math.round(w * dpr); c.height = Math.round(h * dpr);
    c.getContext('2d').setTransform(dpr, 0, 0, dpr, 0, 0);
    vzBins.fill(0); vzPeak.fill(0); vzCh.fill(0); vzChP.fill(0);
  }
  // colors: quiet → loud (Options / Sound), one pair for all sources (AY and General Sound)
  const VZ_COL = { ay: ['#f0783c', '#ffecaa'] };
  const vzCol = { ay: (load('vizcol.ay') || '').split(',') };
  for (const k in VZ_COL) if (!vzCol[k].every((c) => /^#[0-9a-f]{6}$/i.test(c)) || vzCol[k].length !== 2) vzCol[k] = VZ_COL[k].slice();
  const rgbOf = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
  const mixc = (k, t, a) => { const [p, q] = vzCol[k].map(rgbOf); return 'rgba(' + p.map((v, i) => Math.round(v + (q[i] - v) * t)).join(',') + ',' + (a === undefined ? 1 : a) + ')'; };
  const vzGrad = (k, g, x0, y0, x1, y1) => { const gr = g.createLinearGradient(x0, y0, x1, y1);
    gr.addColorStop(0, mixc(k, 0, .9)); gr.addColorStop(.6, mixc(k, .55, .95)); gr.addColorStop(1, mixc(k, 1, 1)); return gr; };
  const warm = (g, x0, y0, x1, y1) => vzGrad('ay', g, x0, y0, x1, y1);
  function vzClear(g, W, H) {
    if (vzDecay) { g.save(); g.globalCompositeOperation = 'destination-out'; g.fillStyle = 'rgba(0,0,0,.45)'; g.fillRect(0, 0, W, H); g.restore(); }
    else g.clearRect(0, 0, W, H);
  }
  function vzBands(an, nb) { // nb log-spaced bands 50 Hz … 16 kHz, 0..1
    an.getByteFrequencyData(vzFD);
    const ny = audio.ctx.sampleRate / 2, n = vzFD.length;
    for (let b = 0; b < nb; b++) {
      const f0 = 50 * Math.pow(320, b / nb), f1 = 50 * Math.pow(320, (b + 1) / nb);
      const i0 = Math.floor(f0 / ny * n), i1 = Math.max(i0 + 1, Math.ceil(f1 / ny * n));
      let m = 0; for (let i = i0; i < i1 && i < n; i++) m = Math.max(m, vzFD[i]);
      const v = m / 255;
      vzBins[b] = vzDecay ? (v > vzBins[b] ? v : vzBins[b] * 0.86) : v;
      vzPeak[b] = v > vzPeak[b] ? v : Math.max(0, vzPeak[b] - 0.012);
    }
  }
  // channel levels: the core gives groups (AY chips, General Sound, SAA1099, DAC, OPL FM, OPL4 wavetable: web_chan_levels);
  // a channel is shown once it has sounded, and stays while its source plays; a source silent for VZ_HOLD ms goes with
  // its channels (the next time it plays, its channels come back as they sound). Returns [{ k: index of the channel's
  // smoothing (group id × 32 + channel), v: level 0..15, hit: a note started since the last look (D7 of the level: OPL FM /
  // OPL4 wavetable key on, AY envelope restarted; drawn as a short flash over the bar), gap: first of its group }]
  const VZ_HOLD = 4000, vzGrp = new Map(); // id → { last: time a channel sounded, used: [channels that sounded] }
  function vzChans(now) {
    const b = new Uint8Array(E.memory.buffer, E.web_chan_levels(), 80), out = [];
    for (let gi = 0, p = 1, n = b[0]; gi < n; gi++) {
      const id = b[p], cnt = b[p + 1], lv = b.subarray(p + 2, p + 2 + cnt); p += 2 + cnt;
      let st = vzGrp.get(id); if (!st) vzGrp.set(id, st = { last: -1e9, used: [] });
      let any = false;
      for (let i = 0; i < cnt; i++) if (lv[i] & 0x8F) { st.used[i] = true; any = true; }
      if (any) st.last = now;
      else if (now - st.last > VZ_HOLD) { st.used = []; continue; } // silent a while: the source goes
      let first = out.length > 0;
      for (let i = 0; i < cnt; i++) if (st.used[i]) { out.push({ k: id * 32 + i, v: lv[i] & 15, hit: lv[i] >> 7, gap: first }); first = false; }
    }
    return out;
  }
  function drawViz(now) {
    const c = $('viz');
    if (vzMode === 'off' || !audio || !audio.an || muted || isPaused() || turbo) { // muted: no sound, no indicator
      if (vzAlpha > 0) { vzAlpha = 0; c.style.opacity = 0; } return; }
    if (now - vzLast < 30) return; // ~33 fps
    vzLast = now;
    const an = audio.an, g = c.getContext('2d'), H = VZ_TALL[vzMode] || VZ_H;
    let chs = null;
    if (vzMode === 'chan') { // canvas width follows the channels shown
      chs = vzChans(now);
      const key = chs.map((c) => c.k + (c.gap ? 'g' : '')).join(',');
      if (key !== vzChN) { vzChN = key; vzChW = Math.max(0, chs.length * 4 + chs.filter((c) => c.gap).length * 4 - 1); vzSetup(); }
    }
    const W = vzW();
    if (!vzTD) { vzTD = new Float32Array(an.fftSize); vzFD = new Uint8Array(an.frequencyBinCount); vzL = new Float32Array(audio.anL.fftSize); vzR = new Float32Array(audio.anR.fftSize); vzSetup(); }
    an.getFloatTimeDomainData(vzTD);
    let mean = 0; for (let i = 0; i < vzTD.length; i++) mean += vzTD[i];
    mean /= vzTD.length;
    let rms = 0, pk = 0;
    for (let i = 0; i < vzTD.length; i++) { const d = vzTD[i] - mean; rms += d * d; pk = Math.max(pk, Math.abs(d)); }
    rms = Math.sqrt(rms / vzTD.length);
    if (rms > 0.002) vzQuietT = now; // ⅙ s of silence: fade out
    const target = now - vzQuietT < 167 ? 1 : 0;
    vzAlpha += (target - vzAlpha) * (target ? 1 : 0.48);
    c.style.opacity = vzAlpha.toFixed(3);
    if (vzAlpha < 0.01) return;

    if (vzMode === 'spectrum' || vzMode === 'mirror') {
      const nb = VZ_NB[vzMode];
      vzBands(an, nb);
      g.clearRect(0, 0, W, H);
      const bw = W / nb;
      if (vzMode === 'spectrum') {
        g.fillStyle = warm(g, 0, H, 0, 0);
        const w1 = Math.max(0.5, bw - 1);
        for (let b = 0; b < nb; b++) { const bh = Math.max(1, vzBins[b] * (H - 2)); g.fillRect(b * bw, H - bh, w1, bh); }
        if (vzDecay) { g.fillStyle = mixc('ay', 1, .75); for (let b = 0; b < nb; b++) if (vzPeak[b] > 0.04) g.fillRect(b * bw, H - 1 - vzPeak[b] * (H - 2), w1, 1); }
      } else { // mirror: bass in the middle, bars grow up and down from the centre line
        const mid = H / 2, half = W / 2, sw = half / nb;
        g.fillStyle = warm(g, 0, mid, 0, 0);
        for (let b = 0; b < nb; b++) {
          const bh = Math.max(0.5, vzBins[b] * (mid - 1));
          for (const x of [half + b * sw, half - (b + 1) * sw]) g.fillRect(x, mid - bh, Math.max(0.5, sw * 0.5), bh * 2);
        }
      }
    } else if (vzMode === 'scope') {
      vzClear(g, W, H);
      let start = 0; for (let i = 1; i < vzTD.length / 2; i++) if (vzTD[i - 1] < mean && vzTD[i] >= mean) { start = i; break; }
      const k = 0.85 / Math.max(pk, 0.05), mid = H / 2, gr = g.createLinearGradient(0, 0, W, 0);
      gr.addColorStop(0, mixc('ay', .3, .15)); gr.addColorStop(.25, mixc('ay', .3, .95)); gr.addColorStop(.75, mixc('ay', .75, .95)); gr.addColorStop(1, mixc('ay', .75, .15));
      g.lineWidth = 1.2; g.lineJoin = 'round'; g.strokeStyle = gr; g.shadowColor = mixc('ay', .3, .6); g.shadowBlur = 3;
      g.beginPath();
      for (let x = 0; x <= W; x++) {
        const v = (vzTD[(start + Math.floor(x * 512 / W)) % vzTD.length] - mean) * k;
        const y = mid - Math.max(-1, Math.min(1, v)) * (mid - 1.5);
        x ? g.lineTo(x, y) : g.moveTo(x, y);
      }
      g.stroke(); g.shadowBlur = 0;
    } else if (vzMode === 'chan') { // channel amplitudes, a gap between sources (vzChans)
      g.clearRect(0, 0, W, H);
      const gr = vzGrad('ay', g, 0, H, 0, 0);
      let x = 0;
      for (const { k, v: l, hit, gap } of chs) {
        if (gap) x += 4;
        const v = l / 15;
        vzCh[k] = vzDecay ? (v > vzCh[k] ? v : vzCh[k] * 0.8) : v;
        vzChP[k] = v > vzChP[k] ? v : Math.max(0, vzChP[k] - 0.02);
        const bh = Math.max(1, vzCh[k] * (H - 2));
        g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(x, 1, 3, H - 2); // dark track: the bars stay visible on a light border
        g.fillStyle = gr; g.fillRect(x, H - 1 - bh, 3, bh);
        if (vzDecay && vzChP[k] > 0.05) { g.fillStyle = mixc('ay', 1, .85); g.fillRect(x, H - 2 - vzChP[k] * (H - 2), 3, 1); }
        vzFl[k] = hit ? 1 : vzFl[k] * 0.72; // a note started: a flash over the bar, gone in ~⅓ s
        if (vzFl[k] > 0.06) { const f = vzFl[k], top = Math.min(H - 2, bh + f * (H - 2) * 0.35); g.fillStyle = mixc('ay', 1, (0.95 * f).toFixed(2)); g.fillRect(x, H - 1 - top, 3, top - bh + 1); }
        x += 4;
      }
    } else if (vzMode === 'water') { // spectrogram: time runs to the left, low notes at the bottom, loudness as heat color
      const nb = VZ_NB.water, dpr = c.width / W;
      vzBands(an, nb);
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'copy';
      g.drawImage(c, -Math.max(1, Math.round(dpr)), 0); g.restore(); // scroll one column
      g.clearRect(W - 1, 0, 1, H);
      const bh = H / nb;
      for (let b = 0; b < nb; b++) {
        const v = Math.min(1, Math.pow(vzBins[b], 1.4) * 1.15);
        if (v < 0.04) continue;
        g.fillStyle = mixc('ay', Math.min(1, v * 1.2), (0.25 + 0.75 * v).toFixed(2));
        g.fillRect(W - 1, H - (b + 1) * bh, 1, bh);
      }
    } else if (vzMode === 'xy') { // goniometer: mid (L+R) up, side (L−R) across — glowing dots with a fading trail
      audio.anL.getFloatTimeDomainData(vzL); audio.anR.getFloatTimeDomainData(vzR);
      vzClear(g, W, H);
      let mL = 0, mR = 0; for (let i = 0; i < vzL.length; i++) { mL += vzL[i]; mR += vzR[i]; }
      mL /= vzL.length; mR /= vzR.length;
      let p = 0.04; for (let i = 0; i < vzL.length; i++) p = Math.max(p, Math.abs(vzL[i] - mL) + Math.abs(vzR[i] - mR));
      const cx = W / 2, cy = H / 2, kx = (W / 2 - 1.5) / p * 1.4, ky = (H / 2 - 1) / p;
      g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(cx - 0.5, 1, 1, H - 2); g.fillRect(2, cy - 0.5, W - 4, 1);
      g.save(); g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < vzL.length; i += 3) {
        const l = vzL[i] - mL, r = vzR[i] - mR, side = (l - r), mid = (l + r);
        const x = cx + side * kx, y = cy - mid * ky, d = Math.min(1, Math.abs(mid) / p + Math.abs(side) / p);
        g.fillStyle = mixc('ay', d, .09);
        g.fillRect(x - 0.9, y - 0.9, 1.8, 1.8);
      }
      g.restore();
    }
  }
  function bindViz() {
    $('vizsel').value = vzMode; $('vizdecay').checked = vzDecay;
    for (const k of ['ay']) {
      const show = () => { $('vz' + k + '0').value = vzCol[k][0]; $('vz' + k + '1').value = vzCol[k][1]; };
      const set = () => { vzCol[k] = [$('vz' + k + '0').value, $('vz' + k + '1').value]; store('vizcol.' + k, vzCol[k].join(',')); };
      show();
      $('vz' + k + '0').oninput = $('vz' + k + '1').oninput = set;
      $('vz' + k + '_r').onclick = () => { vzCol[k] = VZ_COL[k].slice(); store('vizcol.' + k, ''); show(); };
    }
    $('vizsel').onchange = () => { vzMode = $('vizsel').value; store('viz', vzMode); vzSetup(); };
    $('vizdecay').onchange = () => { vzDecay = $('vizdecay').checked; store('vizdecay', vzDecay ? '1' : '0'); vzSetup(); };
    vzSetup();
    window.addEventListener('resize', () => vzSetup());
  }

  // ------------------------------------------------------------------ run state
  let userPaused = false;   // STOP button / Pause key
  let hiddenPaused = false; // tab is not visible
  let turbo = false;
  const isPaused = () => userPaused || hiddenPaused;

  function applyRunState() {
    const p = isPaused();
    $('pausemark').classList.toggle('show', p);
    setIcon('pause', userPaused ? 'i-play' : 'i-pause');
    $('pause').title = userPaused ? 'Start' : 'Stop';
    $('pause').classList.toggle('on', userPaused);
    if (audio) {
      if (p) { audio.ctx.suspend().catch(() => {}); }
      else if (!dbgOn) { audio.flush(); audio.ctx.resume().catch(() => {}); }
    }
    lastT = performance.now(); frameAcc = 0;
    if (p && !dbgOn) releaseAll();
    if (p) releaseMouse();
  }
  function setUserPaused(v) { userPaused = v; applyRunState(); if (rz) rzxUI(); }
  document.addEventListener('visibilitychange', () => { hiddenPaused = document.hidden; applyRunState(); if (document.hidden && IOS) killAudio(); });
  // Safari: pagehide / pageshow (back-forward cache, app switch) and freeze / resume (Chrome) also mean "not visible"
  window.addEventListener('pagehide', () => { hiddenPaused = true; applyRunState(); if (IOS) killAudio(); });
  window.addEventListener('pageshow', () => { hiddenPaused = document.hidden; applyRunState(); resync(performance.now()); });
  document.addEventListener('freeze', () => { hiddenPaused = true; applyRunState(); });
  document.addEventListener('resume', () => { hiddenPaused = document.hidden; applyRunState(); resync(performance.now()); });

  // ------------------------------------------------------------------ main loop
  let refreshMs = 16.7, renderMs = 2, turboBudget = 12; // max speed: the emulation time per refresh = refresh − picture − margin
  let tickEnd = performance.now(), lastT = performance.now(), frameAcc = 0, fpsCount = 0, fpsT = performance.now();
  let sentSinceReport = 0, lastReportSeen = 0, sampAcc = 0, frameN = 882; // frameN: sound samples of the last frame

  // The page was frozen (iOS app switch, locked screen, background tab) without a visibilitychange:
  // nothing is caught up — the machine continues as if it had been paused.
  let resyncUntil = 0;
  function resync(now) {
    lastT = now; frameAcc = 0; sampAcc = 0; resyncUntil = now + 300; fpsCount = 0; fpsT = now;
    if (audio) { audio.flush(); sentSinceReport = 0; lastReportSeen = audio.reportAt; }
  }
  function tick(now) {
    requestAnimationFrame(tick);
    if (!E || switching) { lastT = tickEnd = now; return; }
    // the page was not run for a while (frozen, app switch): only a gap between ticks counts, not a long tick of our own
    if (now - tickEnd > 400) { resync(now); tickEnd = now; return; }
    let dt = now - lastT; lastT = now;
    if (!turbo && dt > 4 && dt < 50) refreshMs += (dt - refreshMs) * 0.05; // the screen refresh interval (smoothed; not while max speed stretches it)
    // max speed: a tick takes whole refreshes (~33 ms: 2 at 60 Hz, 4 at 120 Hz): emulation, then one picture — about 90% of the time
    // emulates and nothing is lost to a refresh missed by a little
    { const k = Math.max(1, Math.round(33 / refreshMs)); turboBudget = Math.max(6, k * refreshMs - renderMs - 1.5); }
    if (dt > 100) dt = 100;
    if (AS.suspended) { // inside the debugger: wake it up when its Sleep() is over
      if (now >= AS.state.wakeAt) debugResume(true);
      tickEnd = performance.now();
      return;
    }
    let run = 0;
    if (!isPaused() && !linkHold) {
      if (turbo) run = 200; // max speed: as many frames as fit in ~12 ms of this screen refresh (below)
      // audio-clocked only while the worklet reports in time (stale reports after a freeze would ask for a burst of frames)
      else if (audio && audio.ctx.state === 'running' && now >= resyncUntil && now - audio.reportAt < 250) {
        // the machine runs by the clock in sound samples (a Pentagon frame is 903 samples: 48.8 frames a second), and the
        // queue of sound is only a correction: under 60 ms one more frame, over 180 ms one less. The queue = what the worklet
        // holds + what is on its way to it (sent − received, exact) − what it has played since its report, measured by the
        // audio clock itself (the report's currentTime against the context's now: late reports in Safari do not matter)
        if (audio.reportAt !== lastReportSeen) { lastReportSeen = audio.reportAt; sentSinceReport = 0; }
        const played = audio.repT !== undefined ? Math.max(0, audio.ctx.currentTime - audio.repT) * audio.ctx.sampleRate : (now - audio.reportAt) * audio.ctx.sampleRate / 1000;
        const queued = (audio.sp ? audio.fill : audio.fill + (audio.sent - audio.got) - played) * 1000 / RATE;
        sampAcc += dt * RATE / 1000;
        if (queued < 60) sampAcc += frameN * Math.min(2, Math.ceil((60 - queued) / 20)); // behind: make up (at most 2 frames a refresh)
        else if (queued > 180) sampAcc = Math.min(sampAcc, 0);
        sampAcc = Math.min(sampAcc, 6 * frameN);
        run = Math.max(0, Math.floor(sampAcc / frameN)); sampAcc -= run * frameN;
      } else {
        frameAcc += dt * ulaHz / 1000;
        run = Math.min(Math.floor(frameAcc), 6); frameAcc -= Math.floor(frameAcc);
      }
    }
    if (rz && rz.seeking) run = 0; // the player is running the frames itself
    const t0 = performance.now();
    let tCore = 0;
    for (let i = 0; i < run; i++) {
      // a slow device (or a throttled page) must not dig itself in: at most ~30 ms of emulation per screen refresh
      // (measured from the start of this loop: Safari's requestAnimationFrame time can be well before the call, which let only one
      // frame run per refresh — 30 frames a second at a 30 Hz refresh)
      if (i && !turbo && performance.now() - t0 > 30) { if (audio) sampAcc += (run - i) * frameN; break; } // not done: kept for the next refresh
      if (i && turbo && performance.now() - t0 > turboBudget) break; // max speed: the refresh keeps its time for the picture (a fixed count of frames halved the speed when it did not fit)
      const r = AS.call('web_frame');
      if (!r.done) { debugDraw(); tickEnd = performance.now(); return; } // stopped in the debugger
      if (r.value > 100) frameN = r.value;
      frameDone(r.value);
      if (mixOn && !turbo) mixStep(); // max speed: no mix (a frame here and there)
    }
    tCore = performance.now() - t0; // Host: the emulation (the frames with their sound, macros…); the rest below is the picture
    if (rz && run && rz.speed > 1 && (E.web_rzx_status() & 1)) E.web_rzx_ff(run * (rz.speed - 1)); // RZX faster: the frames between without sound
    if (rz) rzxPoll();
    if (run) recPoll();
    if (run) { const r0 = performance.now(); if (mixOn && !turbo) blitMix(); else render(); renderMs += (performance.now() - r0 - renderMs) * 0.1; coreStatus(now); updLed(); if (pf.timer) pfFrame(performance.now() - t0, tCore); }
    else if (isPaused() && ledKey) { ledKey = ''; $('dled').hidden = true; if (hud.trk) { hud.trk = ''; hudDraw(); } }
    drawViz(now);
    if (now - fpsT >= 1000) {
      // started from a link (no click yet): browsers keep the sound off until the first click / key
      // only while the machine is actually making a sound that cannot be heard
      const sh = muted || isPaused() || !!(audio && audio.ctx.state === 'running') || now - soundAt > 1500;
      if ($('sndhint').hidden !== sh) $('sndhint').hidden = sh; // the page is changed only when something did change
      hudSet('fps', Math.round(fpsCount * 1000 / (now - fpsT)) + ' fps');
      { const k = !$('recmark').hidden + ':' + $('barcorner').classList.contains('peek') + ':' + document.body.classList.contains('bare') + ':' + document.body.classList.contains('calm') + ':' + vzMode + ':' + vzW(); if (k !== hudLay) { hudLay = k; hudDraw(); } }
      ulaxCheck();
      hwClock();
      if (E && E.web_gs_auto_fired && E.web_gs_auto_fired()) toast('General Sound on');
      { const z = E && E.web_zxms_auto_fired ? E.web_zxms_auto_fired() : 0, o = E && E.web_opl_auto_fired ? E.web_opl_auto_fired() : 0;
        if (z || o) toast([z & 1 ? 'SAA1099' : '', z & 2 ? 'TurboSound FM' : z & 4 ? 'TurboSound' : '', o ? 'MoonSound (OPL4)' : ''].filter(Boolean).join(', ') + ' on'); }
      fpsCount = 0; fpsT = now;
      if (optOpen() || !$('loadwin').hidden) updateUI(); // drives, HDD, SD rows: only while a window shows them (they are refreshed when it opens)
    }
    tickEnd = performance.now();
  }

  // messages of the core (reset, quick save, CPU halted …): shown as toasts instead of text in the picture
  let statSeq = 0, statLast = '', statT = 0, statBoot = true; // statBoot: the power-on "Reset to …" is not shown
  function coreStatus(now) {
    const seq = E.web_status_seq();
    if (seq === statSeq) return;
    statSeq = seq;
    const t = cstr(E.web_statusline());
    if (statBoot) { statBoot = false; if (/^Reset to/.test(t)) return; }
    if (!t || /^(ATM|XT) mode/.test(t)) return; // shown next to the XT icon
    const again = t === statLast && now - statT < 1500; // repeated every frame (CPU HALTED): once
    statLast = t; statT = now;
    if (!again) toast(t);
  }
  // disk / tape activity at the top centre: floppy blue = read, red = write; tape: cassette
  let ledKey = '';
  function updLed() {
    const b = new Uint8Array(E.memory.buffer, E.web_led(), 8), kind = b[0];
    // the track (cylinder × 2 + side, hex, as Unreal's LED: TR-DOS logical track) right of the floppy (Options / Disk)
    const trk = kind >= 1 && kind <= 4 && b[1] !== 0xFF && load('fdd.trk') !== '0' ? b[1].toString(16).toUpperCase().padStart(2, '0') : '';
    const key = kind + ':' + trk;
    if (key === ledKey) return;
    ledKey = key;
    const el = $('dled');
    el.hidden = !kind;
    if (hud.trk !== trk || hud.trkKind !== kind) { hud.trk = trk; hud.trkKind = kind; hudDraw(); }
    if (!kind) return;
    el.className = ['', 'r', 'w', 'w', 's', 't'][kind];
    const ic = $('dledi');
    ic.setAttribute('viewBox', kind === 5 ? '0 0 16 12' : '0 0 12 12');
    ic.querySelector('use').setAttribute('href', kind === 5 ? '#i-tape' : '#i-floppy');
  }
  function frameDone(n) {
    macroFrame(); tmFrame(); runRestoreFrame(); frameJobsRun(); if (pf.timer) pfDisk(); if (gkOn) gkFrame();
    if (n && (!audio || audio.ctx.state !== 'running') && !muted) soundCheck(n);
    // only into a running context: a suspended / interrupted one (iOS after sleep, before the next touch) does not
    // take the messages off its port — they would pile up (~350 KB/s) until the page is reloaded
    if (!turbo && audio && audio.ctx.state === 'running') { pushAudio(n); if (!audio.sp) sentSinceReport += n; else lastReportSeen = audio.reportAt; }
    fpsCount++;
  }

  // ------------------------------------------------------------------ debugger
  // The C debugger loop runs inside web_frame(); while it waits for input it "sleeps" and
  // Asyncify returns control here. Keys/clicks are queued and the frame is resumed.
  let dbgOn = false, dbgIgnore = null, dbgDown = new Set(), afterDbg = new Set(), dbgCtx = null, dbgImg = null;
  function debugResume(idle) {
    if (!AS.suspended) return;
    const r = AS.resume();
    if (r.done) { frameDone(r.value); render(); lastT = performance.now(); frameAcc = 0; }
    else debugDraw(idle);
  }
  let gfx = null, fc = null, fcVk = false, dga = null, dgaVk = false; // fcVk / dgaVk: the on-screen keyboard types into File Commander / deBUGa
  // one debugger at a time: the Unreal debugger (Shift+F1) or deBUGa — the other one's menu item is off meanwhile
  function dbgMenuUI() {
    const g = !!(dga && dga.open);
    $('dbgbtn').disabled = g; $('dgabtn').disabled = dbgOn && !g;
    if (!g && !$('dgahelp').hidden) showDgaHelp(false);
    $('dgabtn').classList.toggle('on', g);
  }
  function debugDraw(idle) {
    if (!E.web_debug_active()) return;
    if (!idle && gfx && gfx.open) gfx.refresh(); // memory may have changed (step, edit, load)
    blit(); // the debugger repaints the ZX screen itself (dbgpaint.cpp / mon_scr)
    if (dga && dga.open) { dga.refresh(); return; } // deBUGa shows the stop instead of the Unreal screen
    const c = $('dbgcanvas');
    if (!dbgCtx) { dbgCtx = c.getContext('2d', { alpha: false }); dbgImg = new ImageData(640, 480); }
    dbgImg.data.set(new Uint8ClampedArray(E.memory.buffer, E.web_debug_fb(), 640 * 480 * 4));
    dbgCtx.putImageData(dbgImg, 0, 0);
  }
  function debugEnter() {
    if (!E || AS.suspended || E.web_debug_active()) return;
    releaseMouse();
    releaseAll();
    E.web_debug_enter();
    const r = AS.call('web_frame'); // stops at the first instruction
    if (r.done) { frameDone(r.value); render(); } else debugDraw();
  }
  function debugShown(on) {
    if (on === dbgOn) return;
    dbgOn = on;
    const g = !!(dga && dga.open), w = $('dbgwin');
    w.hidden = !on || g;
    $('dbgbtn').classList.toggle('on', on && !g); toolsUI(); dbgMenuUI();
    if (g) { dga.state(on); if (on) { blit(); $('dgawin').focus(); } }
    else if (on) { placeDebugWin(); debugDraw(); $('dbgcanvas').focus(); }
    if (!on) {
      showDbgHelp(false); if (vkbd) vkbd.releaseAll(); E.web_keys_clear(); held.clear(); afterDbg = new Set(dbgDown); dbgDown.clear(); canvas.focus(); }
    if (audio && !isPaused()) {
      if (on) audio.ctx.suspend().catch(() => {});
      else { audio.flush(); audio.ctx.resume().catch(() => {}); }
    }
    lastT = performance.now(); frameAcc = 0;
  }
  function debugKey(e, down) {
    const sc = SCAN[e.code];
    if (down) dbgDown.add(e.code); else dbgDown.delete(e.code);
    if (!down) {
      if (dbgIgnore === e.code) dbgIgnore = null;
      if (sc !== undefined && E.web_debug_active()) E.web_key(sc, 0, locks(e)); // no key-up for the machine after exit
      return;
    }
    if (dbgIgnore === e.code) return; // the key that opened the debugger is still held
    if (e.code === 'F1' && e.shiftKey) { if (!e.repeat) { dbgDown.delete('F1'); debugClose(); } return; } // Shift+F1 toggles the debugger
    if (dbgAltKey(e)) { debugResume(); return; }
    if (sc !== undefined && !e.repeat) E.web_key(sc, 1, locks(e));
    const ch = e.key.length === 1 ? e.key.charCodeAt(0) : (e.key === 'Enter' ? 13 : e.key === 'Escape' ? 27 : e.key === 'Backspace' ? 8 : e.key === 'Tab' ? 9 : 0);
    E.web_debug_key(e.keyCode, ch < 256 ? ch : 0);
    debugResume();
  }
  // keys the browser takes for itself (tabs, address bar, full screen) have stand-ins in the debugger:
  // Alt+Shift+1…8 = Ctrl+1…8, Alt+Shift+D / F = Alt+D / F, Alt+Shift+H = Ctrl+Tab, Alt+Shift+T = Ctrl+T, Shift+F8 = F11
  function dbgAltKey(e) {
    let mods = null, code = e.code, vk = e.keyCode, ch = 0;
    if (e.altKey && e.shiftKey && !e.ctrlKey && /^Digit[1-8]$/.test(e.code)) { mods = ['ControlLeft']; ch = 0; }
    else if (e.altKey && e.shiftKey && !e.ctrlKey && (e.code === 'KeyD' || e.code === 'KeyF')) mods = ['AltLeft'];
    else if (e.altKey && e.shiftKey && !e.ctrlKey && e.code === 'KeyH') { mods = ['ControlLeft']; code = 'Tab'; vk = 9; }
    else if (e.altKey && e.shiftKey && !e.ctrlKey && e.code === 'KeyT') mods = ['ControlLeft'];
    else if (e.shiftKey && !e.altKey && !e.ctrlKey && e.code === 'F8') { mods = []; code = 'F11'; vk = 122; }
    if (!mods) return false;
    const real = ['ShiftLeft', 'ShiftRight', 'AltLeft', 'AltRight', 'ControlLeft', 'ControlRight'].filter((c) => dbgDown.has(c));
    for (const c of real) E.web_key(SCAN[c], 0, locks(e));
    for (const c of mods) E.web_key(SCAN[c], 1, locks(e));
    E.web_key(SCAN[code], 1, locks(e));
    E.web_debug_key(vk, ch); // the key state is taken now
    E.web_key(SCAN[code], 0, locks(e));
    for (const c of mods) E.web_key(SCAN[c], 0, locks(e));
    for (const c of real) E.web_key(SCAN[c], 1, locks(e));
    return true;
  }
  function debugClose() { // same as pressing Esc in the debugger
    if (!dbgOn) return;
    E.web_key(1, 1, 0); E.web_debug_key(27, 27);
    for (let i = 0; i < 20 && AS.suspended && E.web_debug_active(); i++) debugResume();
    E.web_key(1, 0, 0);
  }
  // floating windows (debugger, its help): drag by the title bar (mouse or finger), position remembered
  // window focus: the last clicked / opened window is on top and has a lighter title bar
  const WINS = []; let actWin = null;
  // the main window (toolbar + screen) is not a floating one: it only shows the focus, the others keep their order
  const setMainAct = (on) => $('mainwin').classList.toggle('wact', !!on);
  function activateWin(w) {
    if (w) setMainAct(false);
    if (actWin === w) return;
    if (actWin) actWin.classList.remove('wact');
    actWin = w || null; if (!w) return;
    w.classList.add('wact');
    WINS.splice(WINS.indexOf(w), 1); WINS.push(w);
    helpZ();
  }
  // a help window always stays just above the window it belongs to (it may lie over it on a narrow screen)
  const HELP_OF = [['dbghelp', 'dbgwin'], ['dgahelp', 'dgawin'], ['gfxhelp', 'gfxwin'], ['pfhelp', 'perfwin'], ['rahelp', 'restwin'], ['ldhelp', 'loadwin'], ['svhelp', 'savedlg'], ['fchelp', 'fcwin'], ['mainhelp', 'options']];
  function helpZ() {
    WINS.forEach((x, k) => { x.style.zIndex = String(8 + 2 * k); });
    for (const [h, p] of HELP_OF) { const he = $(h), pe = $(p); if (he && pe && pe.style.zIndex) he.style.zIndex = String(+pe.style.zIndex + 1); }
  }
  const topVisibleWin = () => { for (let k = WINS.length - 1; k >= 0; k--) if (!WINS[k].hidden) return WINS[k]; return null; };
  const winOf = (t) => (t && t.nodeType === 1 ? WINS.find((w) => w.contains(t)) : null) || null;
  const inMain = (t) => t && t.nodeType === 1 && $('mainwin').contains(t);
  document.addEventListener('pointerdown', (e) => { const w = winOf(e.target); activateWin(w); if (!w) setMainAct(inMain(e.target)); }, true);
  document.addEventListener('focusin', (e) => { const w = winOf(e.target); if (w) activateWin(w); else if (inMain(e.target)) { activateWin(null); setMainAct(true); } }, true);
  const winObs = new MutationObserver((ms) => {
    for (const m of ms) {
      const w = m.target;
      if (!w.hidden) activateWin(w);
      else if (actWin === w) { w.classList.remove('wact'); actWin = null; activateWin(topVisibleWin()); }
    }
  });
  function registerWin(w) {
    if (WINS.includes(w)) return;
    WINS.push(w); winObs.observe(w, { attributes: true, attributeFilter: ['hidden'] });
    if (!w.hidden) activateWin(w);
  }
  function floatWin(win, key, defPos) {
    registerWin(win);
    const head = win.querySelector('.fhead');
    let pos = null;
    try { const p = JSON.parse(load(key)); if (p && isFinite(p.x) && isFinite(p.y)) pos = p; } catch (e) {}
    function place(free) { // free: dragged by hand — may go past the left edge (60 px stay visible); else fully in view
      const vw = document.documentElement.clientWidth, vh = window.innerHeight, w = win.offsetWidth;
      let { x, y } = pos || defPos();
      x = free ? Math.max(-(w - 60), Math.min(x, vw - 60)) : Math.max(0, Math.min(x, vw - Math.min(w, vw)));
      y = Math.max(0, Math.min(y, vh - 32));
      win.style.left = x + 'px'; win.style.top = y + 'px';
    }
    let drag = null;
    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button, select, input, label')) return;
      const r = win.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top, id: e.pointerId };
      head.setPointerCapture(e.pointerId); e.preventDefault();
    });
    head.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      pos = { x: e.clientX - drag.dx, y: e.clientY - drag.dy }; place(true);
    });
    const end = () => { if (!drag) return; drag = null; store(key, JSON.stringify(pos)); };
    head.addEventListener('pointerup', end); head.addEventListener('pointercancel', end);
    head.addEventListener('dblclick', (e) => { if (e.target.closest('button, select, input, label')) return; pos = null; store(key, ''); place(); });
    window.addEventListener('resize', () => { if (!win.hidden) place(); });
    return { place, setPos(p) { pos = p; store(key, JSON.stringify(pos)); place(); } };
  }
  let dbgFW = null, helpFW = null, dgaHelpFW = null;
  function showDgaHelp(v) { // deBUGa help: at the right side of its window, same height
    const h = $('dgahelp');
    if (v && !h.dataset.built) { h.querySelector('.hbody').innerHTML = helpHtml(DGA_HELP, '<p>Xpeccy based. Uses Unreal engine loop core.</p><p>deBUGa: a debugger after Xpeccy (SAM style) on the debugger loop of the Unreal core. One debugger at a time.</p>'); h.dataset.built = '1'; }
    h.hidden = !v; $('dgahelpbtn').classList.toggle('on', v);
    if (v) { const r = $('dgawin').getBoundingClientRect(); h.style.height = r.height + 'px'; dgaHelpFW.setPos(snapRight(r, h)); }
  }
  // the debugger of Shift+F1 (Options / System): 'u' Unreal, 'x' deBUGa; the Tools menu shows the key at it
  let dbgDef = load('dbgdef') === 'x' ? 'x' : 'u';
  function dbgDefUI() {
    $('dbgbtn').querySelector('kbd').hidden = dbgDef !== 'u'; $('dgabtn').querySelector('kbd').hidden = dbgDef !== 'x';
    $('dgaclose').title = 'Close (' + (dbgDef === 'x' ? 'Shift+F1 / ' : '') + 'Esc): the machine runs on';
  }
  function dbgShiftF1() { // Shift+F1 outside the Unreal debugger window
    if (dbgDef === 'x') { if (dga.open) dga.show(false); else if (!dbgOn) { releaseMouse(); dga.show(true); } }
    else { dbgIgnore = 'F1'; debugEnter(); } // (deBUGa open: the stop is shown there)
  }
  function placeDebugWin() { dbgFW.place(); }
  function showDbgHelp(v) {
    const h = $('dbghelp');
    if (v && !h.dataset.built) { h.querySelector('.hbody').innerHTML = dbgHelpHtml(); h.dataset.built = '1'; }
    h.hidden = !v; $('dbghelpbtn').classList.toggle('on', v);
    if (v) { // stick to the right side of the debugger, same height
      const r = $('dbgwin').getBoundingClientRect();
      h.style.height = r.height + 'px';
      helpFW.setPos(snapRight(r, h));
    }
  }
  // position for a helper window next to the right edge of its parent (left edge if no room)
  // (no room on either side, e.g. a phone: over the parent, at its right edge)
  // one window resizer for every window with edges (File Commander, its viewer, Graf Search): grips on the 4 edges and
  // 4 corners (CSS .rz), mouse and touch alike. o.minW() / o.minH: the least size; o.fixedW(): width not changed
  // (phone); o.size(w, h): the window applies the size itself (default: style width / height); o.end(rect): saved
  function edgeResize(win, o) {
    o = o || {};
    for (const d of ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']) {
      const h = document.createElement('div'); h.className = 'rz ' + d; win.appendChild(h);
      let rs = null;
      h.addEventListener('pointerdown', (e) => {
        const r = win.getBoundingClientRect();
        rs = { id: e.pointerId, x: e.clientX, y: e.clientY, l: r.left, t: r.top, w: r.width, h: r.height };
        try { h.setPointerCapture(e.pointerId); } catch (err) {}
        e.preventDefault(); e.stopPropagation();
      });
      h.addEventListener('pointermove', (e) => {
        if (!rs || e.pointerId !== rs.id) return;
        e.preventDefault();
        const dx = e.clientX - rs.x, dy = e.clientY - rs.y, vw = document.documentElement.clientWidth, vh = window.innerHeight;
        const fixW = o.fixedW && o.fixedW(), minW = Math.min(vw - 4, o.minW ? o.minW() : 300), minH = Math.min(vh - 8, o.minH || 180);
        let l = rs.l, t = rs.t, w = rs.w, hh = rs.h;
        if (!fixW && d.includes('e')) w = rs.w + dx;
        if (!fixW && d.includes('w')) w = rs.w - dx;
        if (d.includes('s')) hh = rs.h + dy;
        if (d.includes('n')) hh = rs.h - dy;
        w = Math.max(minW, Math.min(w, vw - 4)); hh = Math.max(minH, Math.min(hh, vh - 8));
        if (!fixW && d.includes('w')) l = rs.l + rs.w - w;
        if (d.includes('n')) t = rs.t + rs.h - hh;
        if (o.size) o.size(w, hh); else { if (!fixW) win.style.width = w + 'px'; win.style.height = hh + 'px'; }
        if ((!fixW && d.includes('w')) || d.includes('n')) { win.style.left = l + 'px'; win.style.top = t + 'px'; }
      });
      const end = () => { if (!rs) return; rs = null; if (o.end) o.end(win.getBoundingClientRect()); };
      h.addEventListener('pointerup', end); h.addEventListener('pointercancel', end); h.addEventListener('lostpointercapture', end);
    }
  }
  function snapRight(r, w) {
    const vw = document.documentElement.clientWidth, ww = w.offsetWidth;
    let x = r.right - 1;
    if (x + ww > vw) x = r.left - ww + 1 >= 0 ? r.left - ww + 1 : Math.max(0, Math.min(r.right - ww, vw - ww));
    return { x, y: r.top };
  }
  function toolsMenu(v) { $('toolspop').classList.toggle('open', v); $('toolsbtn').classList.toggle('open', v); }
  function toolsUI() {} // the Tools button keeps one color; the menu items show what is open
  // Graf Search: the floppy images in the drives (TRD; iS-DOS disks as ISD)
  function gfxDisks() {
    const out = [];
    for (let d = 0; d < NDRIVES; d++) if (E && E.web_disk_present(d)) out.push({ drive: d, label: DRV[d] + ': ' + (drives[d] ? drives[d].name : cstr(E.web_disk_name(d)).replace(/^.*[\\/]/, '')) });
    return out;
  }
  function gfxDiskBytes(d) {
    if (!E || !E.web_disk_present(d)) return null;
    const T = UnrealFC._test;
    if (E.web_disk_peek_isd) {
      setName('__gfx.isd');
      if (E.web_disk_peek_isd(d)) { const img = new Uint8Array(fs.read('__gfx.isd')); try { fs.remove('__gfx.isd'); } catch (e) {} if (T.looksIsdos(img)) return img; }
    }
    setName('__gfx.trd');
    if (!E.web_disk_peek_trd(d)) return null;
    const img = new Uint8Array(fs.read('__gfx.trd')); try { fs.remove('__gfx.trd'); } catch (e) {}
    return img;
  }
  function bindDebugger() {
    const w = $('dbgwin'), c = $('dbgcanvas');
    dbgFW = floatWin(w, 'dbgpos', () => {
      const r = $('screenwrap').getBoundingClientRect(), vw = document.documentElement.clientWidth;
      let x = r.right + 12; if (x + w.offsetWidth > vw) x = vw - w.offsetWidth - 8;
      return { x, y: Math.max(8, r.top) };
    });
    const h = $('dbghelp');
    helpFW = floatWin(h, 'dbghelppos', () => {
      const r = w.getBoundingClientRect();
      const vw = document.documentElement.clientWidth;
      let x = r.left - h.offsetWidth - 8, y = r.top;
      if (x < 0) { x = Math.max(0, Math.min(r.left + 24, vw - h.offsetWidth)); y = r.top + 32; }
      return { x, y };
    });
    $('dbgbtn').onclick = () => { toolsMenu(false); if (dga && dga.open) return; if (dbgOn) debugClose(); else debugEnter(); };
    $('dbgclose').onclick = (e) => { e.stopPropagation(); debugClose(); };
    $('dbghelpbtn').onclick = (e) => { e.stopPropagation(); showDbgHelp(h.hidden); c.focus(); };
    $('dbghelpclose').onclick = () => { showDbgHelp(false); c.focus(); };
    gfx = UnrealGfx.create({ E: () => E, tsOn: isTS, floatWin, edgeResize, load, store, snapRight, live: () => !AS.suspended, disks: gfxDisks, diskBytes: gfxDiskBytes, view: (f, t, m, go) => fc && fc.view(f, t, m, go), onToggle: () => toolsUI(), onClose: () => (dbgOn ? c : canvas).focus() });
    $('gfxbtn').onclick = () => { toolsMenu(false); releaseMouse(); gfx.show(!gfx.open); toolsUI(); };
    fc = UnrealFC.create({ extraSrc: () => [['BRW', 'Browser'], ...(brBase ? [['LS', 'Local server']] : [])], extraVol: (k) => (k === 'BRW' ? brwVolume() : k === 'LS' && brBase ? lsVolume() : null),
      E: () => E, fs, setName, floatWin, edgeResize, snapRight, load, store, download: downloadBytes, askBox,
      insert: (name, d) => { if (d >= 0) E.web_disk_mark(d, 0); return insertFromFs(name, d, true); }, // FC writes the disk back: no "save the changed disk?" question
      diskName: (d) => drives[d] ? drives[d].name : cstr(E.web_disk_name(d)),
      hddName: (d) => hdds[d], hddParts: (d) => hddGeom(d).parts || null, hddGeo: (d) => hddGeom(d), sdName: () => sdName, sdTouch: () => { sdDirty = true; sdWcOwn = false; sdUI(); }, cardName: (id) => (id === 'MMC' ? sd2Name : id === 'USB' ? usbName : null), cardTouch: (id) => { if (id === 'MMC') { sd2Dirty = true; dmUI(); } else { usbDirty = true; gkStale = true; gkStaleAt = 0; gkUI(); } }, sdNew: async (name, bytes) => { await sdFromBytes(name, bytes); sdDirty = true; sdUI(); }, hddTouch: (d) => { hddDirty[d] = true; hddUI(); }, hddNew: async (d, name, bytes) => { await hddFromBytes(d, name, bytes); hddDirty[d] = true; hddUI(); }, zip: (files) => UnrealZip.create(files), vhd: (a) => vhdFixed(a),
      // FC: a hard disk / SD card image mounted from a panel (its .chs beside it: in a ZIP with it, as Load takes it)
      mountHdd: async (d, name, bytes, chs) => { const b = chs ? new Uint8Array(await (await UnrealZip.create([{ name, data: bytes }, { name: 'geometry.chs', data: chs }])).arrayBuffer()) : bytes; cpmDirNoReset = true; let ok; try { ok = await hddFromBytes(d, chs ? name.replace(/\.[^.]*$/, '') + '.zip' : name, b); } finally { cpmDirNoReset = false; } if (ok) { hddSrc[d] = null; hddUI(); } return ok; }, // not reset (a .chs with DirEntries=: from the next CP/M start)
      mmcHere: () => dmHere(), mountMmc: async (name, bytes) => (await mmcPut(name, bytes, false)) !== false,
      mountSd: async (name, bytes) => { const ok = await sdFromBytes(name, bytes); if (ok !== false) { sdSrc = null; sdUI(); } return ok !== false; },
      sdOn: () => sdOn(), slotDefault: () => (sdBuiltIn() || OS_MODELS[model] && OS_MODELS[model].sd ? 'sd' : '0'), hddRemount: (d) => { hddDirty[d] = true; hddMount(d); hddUI(); },
      onClose: () => canvas.focus(), run: fcRun, sjasm: sjasmRun, mountDisk: (name, data, d, src, run) => loadLocked(async () => { const before = drives[d]; autorunNext = runMode(run); await putAndInsert(name, data, d, src); return drives[d] !== before; }), graf: (name, data) => { gfx.showFile(name, data); toolsUI(); } });
    $('fcbtn').onclick = () => { toolsMenu(false); releaseMouse(); fc.show(!fc.open); fcVk = fc.open; };
    // deBUGa: the second debugger window on the same debugger loop of the core; one of the two debuggers at a time
    dga = UnrealDbga.create({ E: () => E, tsOn: isTS, spOn: () => M() === 'SPRINTER', samOn: () => M() === 'SAM', nxOn: () => M() === 'NEXT', cstr, floatWin, edgeResize, load, store, activate: activateWin,
      stoppedNow: () => !!(E && E.web_debug_active() && AS.suspended), stop: () => { releaseMouse(); debugEnter(); },
      // F24 (no action) wakes the loop of the core: it leaves when the action ended the stop
      cmd: (n, a) => { E.web_dga_cmd(n, a); E.web_debug_key(0x87, 0); debugResume(); },
      repaint: () => dbgRefresh(), changed: () => dbgMenuUI(), focusScreen: () => canvas.focus(), toast, download: downloadBytes, pickFile, askBox, model: () => model, diskName: () => (drives[0] ? drives[0].name : ''), txt: (t) => txtPut(t), help: () => showDgaHelp($('dgahelp').hidden), sysinfo: () => siData(), wdRows: (t) => wdRows(t) });
    $('dgabtn').onclick = () => { toolsMenu(false); if (dbgOn && !dga.open) return; dga.show(!dga.open); };
    const dh = $('dgahelp');
    dgaHelpFW = floatWin(dh, 'dgahelppos', () => { const r = $('dgawin').getBoundingClientRect(); return { x: Math.max(0, r.left - dh.offsetWidth - 8), y: r.top }; });
    $('dgahelpbtn').onclick = (e) => { e.stopPropagation(); showDgaHelp(dh.hidden); $('dgawin').focus({ preventScroll: true }); };
    $('dgahelpclose').onclick = () => { showDgaHelp(false); if (dga.open) $('dgawin').focus({ preventScroll: true }); };
    // which window the on-screen keyboard types into: File Commander after a touch inside it, the machine after a touch on the screen
    document.addEventListener('pointerdown', (e) => {
      if (e.target.closest('#fcwin, #fvwin, #fewin')) { fcVk = true; dgaVk = false; }
      else if (e.target.closest('#dgawin')) { dgaVk = true; fcVk = false; }
      else if (e.target.closest('#screenwrap, #toolbar')) fcVk = dgaVk = false;
    }, true);
    // Tools: one toolbar button with a small drop-down (Debugger, Graf Search, File Commander)
    $('toolsbtn').onclick = (e) => { e.stopPropagation(); toolsMenu(!$('toolspop').classList.contains('open')); };
    $('toolspop').addEventListener('click', (e) => e.stopPropagation());
    document.addEventListener('click', () => { if ($('toolspop').classList.contains('open')) { toolsMenu(false); canvas.focus(); } });
    const click = (e, right) => {
      e.preventDefault(); c.focus();
      if (!dbgOn) return;
      const r = c.getBoundingClientRect();
      const x = Math.floor((e.clientX - r.left) * 640 / r.width), y = Math.floor((e.clientY - r.top) * 480 / r.height);
      E.web_debug_click(Math.max(0, Math.min(639, x)), Math.max(0, Math.min(479, y)), right ? 1 : 0);
      debugResume();
    };
    c.addEventListener('mousedown', (e) => { if (e.button === 0) click(e, false); });
    c.addEventListener('contextmenu', (e) => click(e, true));
  }

  // ------------------------------------------------------------------ debugger dialogs (HTML windows instead of the Win32 ones)
  // The C side calls env.web_ui(what) (dbgbpx.cpp, dbglabls.cpp, dbgrwdlg.cpp, web_emulkeys.cpp); data goes through web_txt().
  const txtPut = (s) => { const b = new TextEncoder().encode(s), p = E.web_txt(); const m = new Uint8Array(E.memory.buffer, p, 65536); const n = Math.min(b.length, 65535); m.set(b.subarray(0, n)); m[n] = 0; };
  const txtGet = (p) => { const m = new Uint8Array(E.memory.buffer, p, 65536); let n = 0; while (n < 65536 && m[n]) n++; return new TextDecoder().decode(m.subarray(0, n)); }; // UTF-8, as txtPut writes
  const hex4 = (v) => (v & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
  const parseNum = (s) => { s = String(s).trim(); let m;
    if ((m = s.match(/^(?:#|\$|0x)([0-9a-f]+)$/i)) || (m = s.match(/^([0-9a-f]+)h$/i))) return parseInt(m[1], 16);
    if (/^\d+$/.test(s)) return parseInt(s, 10); return NaN; };
  const parseHex = (s) => { s = String(s).trim().replace(/^(#|\$|0x)/i, '').replace(/h$/i, ''); return /^[0-9a-f]{1,4}$/i.test(s) ? parseInt(s, 16) : NaN; };
  const escH = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  // Unreal expressions take bare hex numbers (a leading 0 when it starts with a letter): #C000, $C000, 0xC000, C000h → 0C000
  const exprFix = (s) => s.replace(/(?:#|\$|0x)([0-9a-f]+)\b/gi, '0$1').replace(/\b([0-9][0-9a-f]*|[a-f][0-9a-f]*)h\b/gi, '0$1');
  function dbgRefresh() { if (E && E.web_debug_active() && AS.suspended) { E.web_debug_key(0x87, 0); debugResume(); } } // F24: no action, the debugger repaints
  let ddKind = '';
  function dlgOpen(kind, title, html, wide) {
    ddKind = kind;
    const w = $('dbgdlg');
    $('ddtitle').textContent = title; $('ddbody').innerHTML = html;
    w.classList.toggle('wide', wide === true); w.classList.toggle('narrow', wide === 'narrow');
    fwinShow('dbgdlg', true);
  }
  function dlgClose() { $('dbgdlg').hidden = true; ddKind = ''; if (dbgOn) $('dbgcanvas').focus(); else canvas.focus(); }
  function dlgMsg(t, err) { const m = $('ddmsg'); if (m) { m.textContent = t || ''; m.classList.toggle('err', !!err); } }
  function webUi(p) {
    const what = txtGet(p);
    setTimeout(() => { try { dbgUi(what); } catch (e) { console.log(e.stack); toast(e.message, true); } }, 0);
  }
  function dbgUi(what) {
    if (what.startsWith('download:')) { const n = what.slice(9).replace(/^.*[\\/]/, ''); const d = fs.exists(n) ? fs.read(n) : null; if (d) { downloadBytes(n, d.slice()); toast('Downloaded: ' + n); } else toast('No file ' + n, true); return; }
    switch (what) {
      case 'bp': return bpDialog();
      case 'watch': return watchDialog();
      case 'labels': return labelsDialog();
      case 'search': return searchDialog();
      case 'poke': return pokeDialog();
      case 'tape': return tapeDialog();
      case 'loadblock': return loadBlockDialog();
      case 'help': return showDbgHelp(true);
      case 'load': return showLoad();
      case 'save': return openSave();
      case 'options': return showOptions(true);
    }
  }
  // ---- breakpoints (Alt+C): conditions, execution ranges, memory access ranges; kept in the browser
  function bpStore() { try { store('dbg.bp', txtGet(E.web_bp_get())); } catch (e) {} }
  function bpRestore() { // after a start: the breakpoints of the last session
    const t = load('dbg.bp'); if (!t || !E || !E.web_bp_get) return;
    for (const ln of t.split('\n')) {
      const f = ln.split('\t');
      if (f[0] === 'c' && f[1]) { txtPut(f[1]); E.web_bp_add_cond(); }
      else if (f[0] === 'x') E.web_bp_range(parseInt(f[1], 16), parseInt(f[2], 16), 1, 1);
      else if (f[0] === 'm') E.web_bp_range(parseInt(f[1], 16), parseInt(f[2], 16), (/R/.test(f[3]) ? 2 : 0) | (/W/.test(f[3]) ? 4 : 0), 1);
    }
  }
  function bpLists() {
    const c = [], x = [], m = [];
    for (const ln of txtGet(E.web_bp_get()).split('\n')) { const f = ln.split('\t'); if (f[0] === 'c') c.push(f[1]); else if (f[0] === 'x') x.push(f); else if (f[0] === 'm') m.push(f); }
    const opt = (v, t) => `<option value="${escH(v)}">${escH(t)}</option>`;
    $('bpc').innerHTML = c.map((e, i) => opt(i, e)).join('');
    $('bpx').innerHTML = x.map((f) => opt(f[1] + '-' + f[2], f[1] === f[2] ? f[1] : f[1] + '-' + f[2])).join('');
    $('bpm').innerHTML = m.map((f) => opt(f[1] + '-' + f[2] + '-' + f[3], (f[1] === f[2] ? f[1] : f[1] + '-' + f[2]) + '  ' + f[3])).join('');
  }
  const rangeOf = (s) => { const m = String(s).trim().match(/^([#$]?[0-9a-f]{1,4}h?)(?:\s*-\s*([#$]?[0-9a-f]{1,4}h?))?$/i); if (!m) return null; const a = parseHex(m[1]), b = m[2] ? parseHex(m[2]) : a; return isNaN(a) || isNaN(b) || a > b ? null : [a, b]; };
  function bpDialog() {
    dlgOpen('bp', 'Breakpoints', `
      <section><h3>Conditions</h3>
        <select id="bpc" size="4" class="ddlist"></select>
        <div class="ldrow"><input id="bpce" placeholder="PC==#8000 &amp;&amp; A==3" spellcheck="false" autocomplete="off"><button id="bpcadd">Add</button><button id="bpcdel">Delete</button></div>
        <p class="note">Registers A…IY, AF'…L', I, R; numbers are hex (#C000 = $C000 = 0C000); M addr = byte at addr, a-&gt;b = byte at a+b; OUT / IN = port of last out / in, VAL = its value, DOS = TR-DOS on, FD = #7FFD; == != &lt; &gt; &lt;= &gt;= &amp;&amp; || + - * / % &amp; | ^ ~ ! ( )</p></section>
      <section><h3>Execution</h3>
        <select id="bpx" size="4" class="ddlist"></select>
        <div class="ldrow"><input id="bpxe" data-hex="- " placeholder="8000 or 8000-80FF" spellcheck="false" autocomplete="off"><button id="bpxadd">Add</button><button id="bpxdel">Delete</button></div></section>
      <section><h3>Memory access</h3>
        <select id="bpm" size="4" class="ddlist"></select>
        <div class="ldrow"><input id="bpme" data-hex="- " placeholder="5B00-5BFF" spellcheck="false" autocomplete="off"><label class="lddrv"><input type="checkbox" id="bpmr">R</label><label class="lddrv"><input type="checkbox" id="bpmw" checked>W</label><button id="bpmadd">Add</button><button id="bpmdel">Delete</button></div></section>
      <p class="note" id="ddmsg"></p>`);
    bpLists();
    const done = (msg) => { bpLists(); bpStore(); dbgRefresh(); dlgMsg(msg || ''); };
    $('bpcadd').onclick = () => { const v = $('bpce').value.trim(); if (!v) return; txtPut(exprFix(v)); const r = E.web_bp_add_cond(); if (r === 1) { $('bpce').value = ''; done(); } else dlgMsg(r < 0 ? 'No room: 16 conditions at most' : 'Error in the expression', true); };
    $('bpcdel').onclick = () => { const s = $('bpc'); if (s.selectedIndex < 0) return; $('bpce').value = s.options[s.selectedIndex].textContent; E.web_bp_del_cond(+s.value); done(); };
    $('bpxadd').onclick = () => { const r = rangeOf($('bpxe').value); if (!r) { dlgMsg('Address or range: 8000 or 8000-80FF (hex)', true); return; } E.web_bp_range(r[0], r[1], 1, 1); $('bpxe').value = ''; done(); };
    $('bpxdel').onclick = () => { const s = $('bpx'); if (s.selectedIndex < 0) return; const [a, b] = s.value.split('-'); $('bpxe').value = s.options[s.selectedIndex].textContent; E.web_bp_range(parseInt(a, 16), parseInt(b, 16), 1, 0); done(); };
    $('bpmadd').onclick = () => { const r = rangeOf($('bpme').value), k = ($('bpmr').checked ? 2 : 0) | ($('bpmw').checked ? 4 : 0); if (!r || !k) { dlgMsg(!r ? 'Address or range: 5B00 or 5B00-5BFF (hex)' : 'Choose R and / or W', true); return; } E.web_bp_range(r[0], r[1], k, 1); $('bpme').value = ''; done(); };
    $('bpmdel').onclick = () => { const s = $('bpm'); if (s.selectedIndex < 0) return; const [a, b, f] = s.value.split('-'); $('bpme').value = a === b ? a : a + '-' + b; $('bpmr').checked = /R/.test(f); $('bpmw').checked = /W/.test(f); E.web_bp_range(parseInt(a, 16), parseInt(b, 16), 6, 0); done(); };
    for (const [l, b] of [['bpc', 'bpcdel'], ['bpx', 'bpxdel'], ['bpm', 'bpmdel']]) $(l).ondblclick = () => $(b).click(); // as in Unreal: double click takes it back for editing
    for (const [i, b] of [['bpce', 'bpcadd'], ['bpxe', 'bpxadd'], ['bpme', 'bpmadd']]) $(i).onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); $(b).click(); } };
  }
  // ---- watches (Alt+O)
  function watchDialog() {
    const ls = txtGet(E.web_watch_get()).split('\n');
    let h = '<section><h3>On-screen watches (Alt+S)</h3>';
    for (let i = 0; i < 4; i++) { const f = (ls[i] || '0\t').split('\t'); h += `<div class="ldrow"><label class="lddrv"><input type="checkbox" id="ww${i}" ${f[0] === '1' ? 'checked' : ''}>${i + 1}</label><input id="we${i}" value="${escH(f[1] || '')}" placeholder="expression, e.g. M HL or IX->5" spellcheck="false" autocomplete="off"></div>`; }
    const t = (ls[4] || 't\t0\t0').split('\t');
    h += `</section><section><h3>Trace</h3><div class="ldrow"><label class="lddrv"><input type="checkbox" id="wtram" ${t[1] === '1' ? 'checked' : ''}>RAM</label><label class="lddrv"><input type="checkbox" id="wtrom" ${t[2] === '1' ? 'checked' : ''}>ROM</label></div></section>
      <div class="ldrow"><span class="note" id="ddmsg" style="flex:1"></span><button id="wapply" class="primary">Apply</button></div>`;
    dlgOpen('watch', 'Watches', h);
    $('wapply').onclick = () => {
      const bad = [];
      for (let i = 0; i < 4; i++) { const on = $('ww' + i).checked; txtPut(exprFix($('we' + i).value)); if (!E.web_watch_set(i, on ? 1 : 0)) { bad.push(i + 1); $('ww' + i).checked = false; } }
      E.web_trace_set($('wtram').checked ? 1 : 0, $('wtrom').checked ? 1 : 0);
      dbgRefresh();
      if (bad.length) dlgMsg('Error in the expression of watch ' + bad.join(', '), true); else dlgClose();
    };
  }
  // ---- labels (Ctrl+J): list, go to, load a labels file from the computer
  let lblAll = [];
  function labelsDialog() {
    dlgOpen('labels', 'Labels', `
      <div class="ldrow"><input id="lblf" placeholder="filter" spellcheck="false" autocomplete="off"></div>
      <select id="lbll" size="14" class="ddlist mono"></select>
      <div class="ldrow"><button id="lblgo" class="primary" title="Disassembler at the label (Enter, double click)">Go</button><button id="lblmem" title="Memory dump at the label">Dump</button><span style="flex:1"></span><button id="lblload" title="Unreal .l (xxxx name / bb:xxxx name), sjasmplus .sym / .lab, name EQU addr">Load file…</button><button id="lblclr" title="Remove the labels of RAM">Clear</button></div>
      <p class="note" id="ddmsg"></p>`, 'narrow');
    const fill = () => {
      const f = $('lblf').value.trim().toLowerCase();
      const rows = lblAll.filter((r) => !f || r[1].toLowerCase().includes(f) || r[0].toLowerCase().startsWith(f)).slice(0, 3000);
      $('lbll').innerHTML = rows.map((r) => `<option value="${escH(r[0])}">${escH(r[0].padEnd(8))} ${escH(r[1])}</option>`).join('');
      if (rows.length) $('lbll').selectedIndex = 0;
      dlgMsg(lblAll.length + ' labels' + (f ? ', ' + rows.length + ' shown' : '') + '. Other pages: page:offset (not mapped now)');
    };
    const reload = () => { const n = E.web_lbl_get(); lblAll = txtGet(E.web_txt()).split('\n').filter(Boolean).map((l) => l.split('\t')); fill(); return n; };
    reload();
    const go = (mem) => { const v = $('lbll').value; if (!/^[0-9A-F]{4}$/.test(v)) { dlgMsg(v ? 'This label is not in the mapped memory now' : '', true); return; } E.web_dbg_goto(parseInt(v, 16), mem ? 1 : 0); dbgRefresh(); };
    $('lblf').oninput = fill;
    $('lblf').onkeydown = (e) => { if (e.key === 'ArrowDown') { e.preventDefault(); $('lbll').focus(); } if (e.key === 'Enter') { e.preventDefault(); go(false); } };
    $('lbll').ondblclick = () => go(false);
    $('lbll').onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); go(false); } };
    $('lblgo').onclick = () => go(false); $('lblmem').onclick = () => go(true);
    $('lblclr').onclick = () => { E.web_lbl_clear(); reload(); dbgRefresh(); };
    $('lblload').onclick = () => pickFile('.l,.sym,.lab,.txt,.lbl,.map', async (name, b) => {
      const r = labelsToUnreal(new TextDecoder('latin1').decode(b));
      fs.write('user.l', new TextEncoder().encode(r.text));
      const n = E.web_lbl_user(); reload(); dbgRefresh();
      dlgMsg(name + ': ' + n + ' labels loaded' + (r.skipped ? ', ' + r.skipped + ' skipped (ROM or not mapped)' : ''), !n);
    });
  }
  // a labels file → Unreal user.l ("bb:xxxx name"): Unreal lines as they are; "name EQU addr", "name = addr", "name: addr",
  // "addr name" with a Z80 address go to the RAM page mapped at that address now
  function labelsToUnreal(t) {
    const out = []; let skipped = 0;
    const page = (a) => E.web_bank_page(a >> 14);
    const z80 = (a, name) => { const p = page(a); if (p < 0) { skipped++; return; } out.push(p.toString(16).toUpperCase().padStart(2, '0') + ':' + hex4(a & 0x3FFF) + ' ' + name); };
    for (let ln of t.split(/\r?\n/)) {
      ln = ln.replace(/;.*$/, '').trim(); if (!ln) continue;
      let m;
      if ((m = ln.match(/^([0-9a-f]{2}):([0-9a-f]{4})\s+(\S+)/i))) { out.push(m[1].toUpperCase() + ':' + m[2].toUpperCase() + ' ' + m[3]); continue; }
      if ((m = ln.match(/^([A-Za-z_.@?$!][\w.@?$!]*)\s*:?\s*(?:equ|=|defl)\s*([#$]|0x|%)?([0-9a-f]+)(h)?\b/i)) && m[2] !== '%') { z80(parseInt(m[3], m[2] || m[4] || /[a-f]/i.test(m[3]) || m[3].length >= 4 ? 16 : 10) & 0xFFFF, m[1].replace(/:$/, '')); continue; }
      if ((m = ln.match(/^([A-Za-z_.@?$!][\w.@?$!]*):?\s+(?:#|\$|0x)?([0-9a-f]{4})h?$/i))) { z80(parseInt(m[2], 16), m[1]); continue; }
      if ((m = ln.match(/^(?:#|\$|0x)?([0-9a-f]{4})h?:?\s+([A-Za-z_.@?$!][\w.@?$!]*)$/i))) { z80(parseInt(m[1], 16), m[2]); continue; }
    }
    return { text: out.join('\n') + '\n', skipped };
  }
  function pickFile(accept, cb) {
    const i = document.createElement('input'); i.type = 'file'; i.accept = accept;
    i.onchange = async () => { const f = i.files[0]; if (f) try { await cb(f.name, new Uint8Array(await f.arrayBuffer())); } catch (e) { toast(f.name + ': ' + e.message, true); } };
    i.click();
  }
  // ---- memory search (Alt+F6): values in the whole RAM, as the cheat finder of Unreal
  const srch = { mask: null, last: null, n: -1, model: null };
  function searchDialog() {
    dlgOpen('search', 'Memory search', `
      <div class="ldrow"><input id="srv" placeholder="value (dec, or hex: #A0)" spellcheck="false" autocomplete="off"><label class="lddrv"><input type="checkbox" id="srw">word</label></div>
      <div class="ldrow"><button id="srnew" title="Start again: every byte of RAM is a candidate">New</button><button id="sreq" class="primary">= value</button><button id="srinc" title="Bigger than at the last step">Increased</button><button id="srdec" title="Smaller than at the last step">Decreased</button><button id="srsame" title="Same as at the last step">Same</button></div>
      <select id="srl" size="10" class="ddlist mono"></select>
      <div class="ldrow"><input id="srset" placeholder="new value" spellcheck="false" autocomplete="off"><button id="srpoke" title="Write the value at the selected address">Set</button><button id="srgo" title="Memory dump at the address (when mapped)">Dump</button></div>
      <p class="note" id="ddmsg"></p>`);
    const ramKB = +(siData().ram || 128), size = ramKB * 1024;
    const ram = () => new Uint8Array(E.memory.buffer, E.web_gfx_mem(1, 0, 0), size);
    const word = () => $('srw').checked;
    const rd = (m, i) => (word() ? m[i] | (m[i + 1] << 8) : m[i]);
    const rdw = (w) => (w ? (m, i) => m[i] | (m[i + 1] << 8) : (m, i) => m[i]); // for a whole pass: the checkbox read once
    const show = () => {
      const m = ram(), rows = [];
      if (srch.mask) for (let i = 0; i < size && rows.length < 300; i++) if (srch.mask[i]) rows.push(i);
      const z80 = (i) => { const p = i >> 14; for (let b = 0; b < 4; b++) if (E.web_bank_page(b) === p) return b * 0x4000 + (i & 0x3FFF); return -1; };
      $('srl').innerHTML = rows.map((i) => { const z = z80(i); return `<option value="${i}">${(i >> 14).toString(16).toUpperCase().padStart(2, '0')}:${hex4(i & 0x3FFF)}  ${z >= 0 ? hex4(z) : '----'}  = ${rd(m, i)}</option>`; }).join('');
      dlgMsg(srch.n < 0 ? 'New search: ' + ramKB + ' KB of RAM. Change the value in the program, then narrow down.' : srch.n + ' found' + (srch.n > 300 ? ' (first 300 shown)' : '') + '. page:offset, Z80 address when mapped');
    };
    const step = (test) => {
      const m = ram();
      // another machine (or RAM size) since the last step: a new search (the last values were of the other machine)
      if (!srch.mask || srch.mask.length !== size || srch.model !== model) { srch.mask = new Uint8Array(size).fill(1); srch.n = -1; srch.last = null; srch.model = model; }
      if (test) { const w = word(), r = rdw(w); let n = 0; const last = srch.last; for (let i = 0, e = size - (w ? 1 : 0); i < e; i++) if (srch.mask[i]) { if (test(r(m, i), last ? r(last, i) : 0)) n++; else srch.mask[i] = 0; } if (w) srch.mask[size - 1] = 0; srch.n = n; }
      srch.last = m.slice(); show();
    };
    $('srnew').onclick = () => { srch.mask = null; srch.n = -1; step(null); };
    $('sreq').onclick = () => { const v = parseNum($('srv').value); if (isNaN(v)) { dlgMsg('Value: decimal, or hex as #A0 / $A0 / 0xA0', true); return; } step((x) => x === (v & (word() ? 0xFFFF : 0xFF))); };
    $('srinc').onclick = () => { if (!srch.last) { dlgMsg('Press New first, then change the value in the program', true); return; } step((x, o) => x > o); };
    $('srdec').onclick = () => { if (!srch.last) { dlgMsg('Press New first, then change the value in the program', true); return; } step((x, o) => x < o); };
    $('srsame').onclick = () => { if (!srch.last) { dlgMsg('Press New first', true); return; } step((x, o) => x === o); };
    $('srpoke').onclick = () => { const i = +$('srl').value, v = parseNum($('srset').value); if ($('srl').selectedIndex < 0 || isNaN(v)) return; const m = ram(); m[i] = v & 255; if (word()) m[i + 1] = (v >> 8) & 255; show(); dbgRefresh(); };
    $('srgo').onclick = () => { const o = $('srl').selectedOptions[0]; if (!o) return; const z = o.textContent.split(/\s+/)[1]; if (/^[0-9A-F]{4}$/.test(z)) { E.web_dbg_goto(parseInt(z, 16), 1); dbgRefresh(); } else dlgMsg('This page is not mapped now', true); };
    show();
  }
  // ---- pokes (Alt+P): "address,value" pairs as in Unreal (decimal; hex with # $ 0x)
  function pokeDialog() {
    dlgOpen('poke', 'Pokes', `
      <textarea id="pkt" rows="4" class="ddarea" spellcheck="false" placeholder="35136,0; 35137,201  or  #8940,#C9"></textarea>
      <div class="ldrow"><span class="note" id="ddmsg" style="flex:1">address,value pairs (separated by space , ; :)</span><button id="pkgo" class="primary">Poke</button></div>`);
    $('pkt').value = load('dbg.poke') || '';
    $('pkgo').onclick = () => {
      const tok = $('pkt').value.split(/[\s,;:]+/).filter(Boolean), pairs = [];
      if (tok.length % 2) { dlgMsg('Incorrect format: an address without a value', true); return; }
      for (let i = 0; i < tok.length; i += 2) { const a = parseNum(tok[i]), v = parseNum(tok[i + 1]); if (isNaN(a) || a < 0x4000 || a > 0xFFFF || isNaN(v) || v > 255) { dlgMsg('Incorrect: ' + tok[i] + ',' + tok[i + 1] + ' (address 16384…65535, value 0…255)', true); return; } pairs.push([a, v]); }
      for (const [a, v] of pairs) E.web_poke(a, v);
      store('dbg.poke', $('pkt').value); dbgRefresh(); dlgMsg(pairs.length + ' pokes done');
    };
  }
  // ---- tape browser (Shift+F7)
  function tapeDialog() {
    dlgOpen('tape', 'Tape', `
      <select id="tpl" size="12" class="ddlist mono"></select>
      <div class="ldrow"><button id="tpset" class="primary" title="Next block to play (double click)">Set position</button><button id="tpplay">Play / Stop</button><span style="flex:1"></span><span class="note" id="ddmsg"></span></div>`, true);
    const fill = () => { const cur = E.web_tape_list(), ls = txtGet(E.web_txt()).split('\n').filter((l, i, a) => i < a.length - 1 || l);
      $('tpl').innerHTML = cur < 0 ? '' : ls.map((l, i) => `<option value="${i}">${i === cur ? '▶ ' : '  '}${escH(l)}</option>`).join('');
      if (cur >= 0) $('tpl').selectedIndex = cur;
      dlgMsg(cur < 0 ? 'No tape loaded' : (E.web_tape_playing() ? 'playing' : 'stopped')); };
    fill();
    $('tpset').onclick = () => { if ($('tpl').selectedIndex >= 0) { E.web_tape_set(+$('tpl').value); fill(); dbgRefresh(); } };
    $('tpl').ondblclick = () => $('tpset').click();
    $('tpplay').onclick = () => { E.web_tape(); fill(); };
  }
  // ---- load a block (Alt+R → from binary file): a file from the computer into memory
  function loadBlockDialog() {
    const a0 = txtGet(E.web_txt()).trim() || '8000';
    dlgOpen('loadblock', 'Load block', `
      <div class="ldrow"><button id="lbfile">Choose File…</button><b id="lbname" class="lbname">— no file —</b></div>
      <div class="ldrow"><span class="lddrv">address</span><input id="lbaddr" data-hex="" value="${escH(a0)}" spellcheck="false" autocomplete="off"><span class="lddrv">offset in file</span><input id="lboff" value="0" spellcheck="false" autocomplete="off"></div>
      <div class="ldrow"><span class="note" id="ddmsg" style="flex:1"></span><button id="lbgo" class="primary" disabled>Load</button></div>`);
    let data = null;
    $('lbfile').onclick = () => pickFile('', (name, b) => { data = b; $('lbname').textContent = name + ' · ' + b.length + ' bytes'; $('lbgo').disabled = false; });
    $('lbgo').onclick = () => {
      const a = parseHex($('lbaddr').value), off = parseNum($('lboff').value || '0');
      if (isNaN(a)) { dlgMsg('Address in hex: 8000', true); return; }
      if (isNaN(off) || off >= data.length) { dlgMsg('Offset beyond the file', true); return; }
      const n = Math.min(data.length - off, 0x10000 - a);
      for (let i = 0; i < n; i++) E.web_poke(a + i, data[off + i]);
      dbgRefresh(); dlgMsg('Loaded ' + n + ' bytes to ' + hex4(a) + '–' + hex4(a + n - 1) + (n < data.length - off ? ' (cut at FFFF)' : ''));
    };
  }

  // debugger key reference (only what works in the web version)
  const DBG_HELP = [
    ['General', [
      ['Run', [
        ['Shift+F1 / Esc', 'exit debugger'], ['F7', 'step'], ['F8', 'step over'],
        ['F11 or Shift+F8', 'run to return'], ['F6', 'breakpoints on range'], ['Shift+F6', 'clear range']]],
      ['Windows', [
        ['Tab / Shift+Tab', 'next / prev window'], ['Alt+D or Alt+Shift+D', 'dump 8 / 32 bytes'],
        ['Ctrl+D', 'dump: mem / CMOS / NVRAM'], ['Alt+S', 'watches / screen / ray-painted'],
        ['Ctrl+U', 'user watch address'], ['Alt+Y', 'active AY'], ['Ctrl+`', 'next CPU']]],
      ['Dialogs', [
        ['Alt+C', 'breakpoints: conditions, execution, memory R/W (kept in browser)'], ['Alt+O', 'watches setup'],
        ['Ctrl+J', 'labels: list, go to, load file (.l, .sym); sos.l loaded by default'], ['Alt+F6', 'memory search (cheats)'], ['Alt+P', 'pokes'],
        ['Shift+F7', 'tape browser'], ['F1', 'this help'], ['F2 / F3', 'Save / Load window'], ['F6', 'Screenshot (PNG or SCR)'], ['Alt+F1', 'Options']]],
      ['Screen (any key returns)', [
        ['F9', 'video memory'], ['Shift+F9', 'shadow screen'], ['Alt+F9', 'ray-painted']]],
      ['Memory & ports', [
        ['Alt+R', 'load block: binary file from computer, TR-DOS sectors'], ['Alt+W', 'save block: binary / disassembly downloaded, TR-DOS file or sectors'],
        ['Alt+F or Alt+Shift+F', 'fill block'], ['Alt+B', 'out #7FFD'], ['Alt+M', 'out extended memory port'], ['Alt+T', 'ripper (result downloaded)']]],
      ['Reset & NMI', [
        ['F12', 'reset'], ['Shift+F12', 'BASIC 48'], ['Alt+Shift+F12', 'BASIC 48, 128K locked'],
        ['Ctrl+Shift+F12', 'BASIC 128'], ['Ctrl+F12', 'TR-DOS'], ['Alt+F12', 'service ROM'], ['Alt+Ctrl+F12', 'cache'],
        ['Alt+Shift+F11', 'NMI'], ['Ctrl+F11', 'TR-DOS magic'], ['Alt+F11', 'NMI to cache'],
        ['Shift+F12, Alt+Shift+F11', 'ZX Spectrum Next: Multiface (NextZXOS: NMI menu)'], ['Ctrl+F11', 'ZX Spectrum Next: DivMMC NMI (when NR #06 D4 is on)']]],
      ['Snapshots*', [
        ['Alt / Ctrl / Shift+F2', 'quick save 1/2/3'], ['Alt / Ctrl / Shift+F3', 'quick load 1/2/3']]],
    ]],
    ['Expressions', [[null, [
      ['C000', 'numbers: bare hex'], ['M x', 'byte at x'], ['a->b', 'byte at a+b'], ['OUT / IN', 'port of the last OUT / IN'], ['VAL', 'its value'], ['DOS', 'TR-DOS ports on'], ['FD', 'value of #7FFD']]]]],
    ['Browser stand-ins', [[null, [
      ['Alt+Shift+1…8', 'for Ctrl+1…8 (browser takes Ctrl)'], ['Alt+Shift+D / F', 'for Alt+D / Alt+F'],
      ['Alt+Shift+H / T', 'for Ctrl+Tab / Ctrl+T'], ['Shift+F8', 'for F11']]]]],
    ['Registers', [[null, [
      ['←→↑↓', 'select'], ['Enter', 'edit'], ['Ctrl+A / Ctrl+F', 'A / flags'], ['Ctrl+B / Ctrl+D', 'BC / DE'],
      ['H P S X Y', 'HL, PC, SP, IX, IY'], ['I R M', 'I, R, IM'], ['Ctrl+1 / 2 or Alt+Shift+1 / 2', 'IFF1 / IFF2'],
      ['Alt+S Z 5 H 3 P N C', 'toggle flag'], ["'", 'go to address (code)'], [';', 'go to address (dump)']]]]],
    ['Disassembler', [[null, [
      ['↑↓←→ PgUp PgDn', 'move'], ['Home', 'cursor to PC'], ['G', 'go to address'],
      ["'", 'follow operand'], ['Backspace', 'back'], [';', 'operand in dump'],
      ['F4', 'run to cursor'], ['Space / right click', 'breakpoint'], ['Enter', 'assemble'], ['Z', 'PC = cursor'],
      ['Alt+F7', 'find text'], ['Ctrl+F7', 'find code'],
      ['Ctrl+1…8 or Alt+Shift+1…8', 'save position'], ['1…8', 'go to position'], ['Ctrl+L', 'labels on/off'], ['Ctrl+A', 'import XAS/ALASM labels']]]]],
    ['Memory', [[null, [
      ['↑↓←→ PgUp PgDn', 'move'], ['Home / End', 'line start / end'], ['Ctrl+Tab or Alt+Shift+H', 'hex ↔ ASCII'],
      ['digits, chars', 'edit'], ['Ctrl+G', 'go to address'], ['Ctrl+P S B D H X Y', 'go to PC, SP, BC, DE, HL, IX, IY'],
      ['Alt+F7', 'find text'], ['Ctrl+F7', 'find code'],
      ['Ctrl+M', 'memory editor'], ['Ctrl+V', 'disk: physical track'], ['Ctrl+O', 'disk: logical sectors'],
      ['Ctrl+T or Alt+Shift+T', 'drive / track / sector']]]]],
    ['Mouse', [[null, [['Left click', 'select window, place cursor'], ['Right click', 'breakpoint in disassembler']]]]],
  ];
  function dbgHelpHtml() {
    return helpHtml(DBG_HELP, '<p>Unreal Speccy debugger (full port; Win32 dialogs are page windows).<br>⚠️ may be taken by browser<br>* stored in page memory, not on disk</p>') + '<p class="hnote">Keys can be reassigned in [SYSTEM.KEYS] of unreal.ini.</p>';
  }
  // deBUGa key reference
  const DGA_HELP = [
    ['Run', [[null, [
      ['F9', 'run / stop'], ['F7', 'step'], ['F8', 'step over CALL, RST, LDIR, DJNZ…'], ['F4', 'run to the cursor line'],
      ['F6', 'run to return (out of the subroutine)'], ['Esc / ✕', 'close: the machine runs on'], ['F1', 'this help'],
      ['PPU step (Ctrl+F7)', 'ZX ULAX with a dux applied: run to the next instruction with a PPU opcode (stops before it)'],
      ['CPU: ZX / GS', 'General Sound on: its Z80 instead of the machine\'s (registers, listing, GS 64K / RAM / ROM pages, steps); a breakpoint set in its listing stops the machine there']]]]],
    ['Window', [[null, [
      ['Tab / Shift+Tab', 'next / previous part: listing, registers, memory, breakpoints (lit at its left edge)'], ['click', 'a part gets the keys'],
      ['Go #', 'listing from an address (hex), Enter'], ['borders', 'drag: width of the registers, height of the lower part']]]]],
    ['Listing', [[null, [
      ['↑↓ PgUp PgDn wheel', 'move'], ['Home', 'cursor to PC'], ['Enter / double click', 'go to the jump target'], ['Backspace', 'back'],
      ['Space / left edge', 'breakpoint (execution)'], ['Shift+↑↓', 'select lines'],
      ['right click / long press', 'line menu: marks, label, comment, assemble'], ['Menu key', 'line menu'],
      ['magenta text', 'ZX ULAX: the PPU opcode run at the M1 of the instruction (code and short name)'], [':', 'label of the line'], [';', 'comment of the line'], ['letters, digits', 'assemble here (Enter: next line, Esc: drop)']]]]],
    ['Assembler', [[null, [
      ['ld a,#10  jp LOOP', 'Z80 commands, labels as addresses'], ['nextreg 7,3  mul d,e', 'ZX Spectrum Next: Z80N commands too (disassembler as well)'], ['db 1,2,"text"', 'bytes, text'], ['dw #4000,LOOP', 'words'],
      ['#10 $10 0x10 10h', 'hex numbers'], ['%1010', 'binary'], ['16', 'decimal'], ["'a'", 'character']]]]],
    ['Marks (Mark ▾)', [[null, [
      ['Code', 'disassemble (no mark)'], ['Bytes', 'db'], ['Words', 'dw'], ['Addresses', 'dw with labels'], ['Text', 'db "…"']]]]],
    ['Registers & stack', [[null, [
      ['click a value', 'edit (hex), Enter'], ['click a flag', 'toggle it'], ['IM / IFF', 'click: next value'], ['click a stack word', 'listing from it']]]]],
    ['Memory', [[null, [
      ['↑↓←→ PgUp PgDn', 'move'], ['Home / End', '0000 / FFFF'], ['click', 'byte'], ['hex digits', 'type over'], ['#', 'dump from an address, Enter'],
      ['CPU 64K / RAM nn / ROM nn', 'the Z80 memory as paged now, or one 16K page (@: where it is mapped now)'],
      ['Fill…', 'a block with bytes (AA 55) or "text", repeated'], ['Save…', 'a block: binary or Hobeta (.$C) download'], ['Load…', 'a file into memory (Hobeta: at its start)']]]]],
    ['Watches', [[null, [
      ['+', 'add: address (8000, #8000), label, register (HL, IX…)'], ['press', 'the dump from it'], ['×', 'remove']]]]],
    ['Devices', [[null, [
      ['memory', 'the machine: what each 16K window shows, its paging and video ports decoded (#7FFD, #1FFD, #DFFD, #EFF7, #77, #xxF7 map, GMX, Quorum, ATM 1), TR-DOS, border, palette; Sprinter: windows, system ports, accelerator, Covox Blaster; SAM Coupé: LMPR, HMPR, VMPR, line INT, CLUT'],
      ['AY', 'registers (selected one lit), tone / volume / mixer of A B C, noise, envelope, ports'], ['WD1793', 'registers, beta port, state'], ['µPD765', 'Spectrum +3: main status, command, ST0-3, C H R N, cylinders'],
      ['sound cards', 'General Sound (clock, #BB, bytes, #0F, banks, channels), SAA1099 registers, MoonSound / OPL3 (timers, keys, FM registers), SounDrive, Covox'],
      ['IDE, SD, CMOS', 'IDE master / slave registers; Z-Controller and the SD card; CMOS address and cells'],
      ['ULAX tab', 'ZX ULAX memory as the stop left it; a click on a word: edit (hex, Enter). Code: Z80 addresses as paged now - byte, PPU opcode, 8 pixels from the left (Cursor: from the listing cursor); Palette: the 64K palette (flash half from 8000); Tables: 7A, 7B, 7C, 7E, 7D; dux: its text, the lines of the cursor address lit (a click on an address: listing from it). Stop at: a PPU opcode, X for any digit (C0XX); empty: off'],
      ['ZX ULAX', 'mode, dux, the PPU opcode decoded, shown screen, active color ring (ACR), palette index ring (PIRB), protection mask, registers Z M X W T r2-rF and the border colors as swatches (hover: the value)'],
      ['Tape', 'blocks; a press plays from that block'],
      ['Next', 'ZX Spectrum Next: system (speed, MMU, ports, DivMMC, Multiface, INT), video (layers, blending, sprite status, copper), the 256 NextRegs and the ports; a press on a register or a port writes it']]]]],
    ['Screen', [[null, [
      ['shown now / RAM nn', 'ZX screen of a RAM page (6144 + 768 bytes) as the stop left it'], ['SPframe / SP VRAM', 'Sprinter: the picture from its video RAM now / the video RAM, a byte a pixel (1024×256)'], ['Profi 512', 'Profi: the 512×240 screen of page 4 / 6 as the video would draw it now'],
      ['TS T0 / T1 map, TS sprites', 'TS-Conf: a tile layer\'s whole map (64×64 tiles) / the sprites alone, 512×512'], ['RAM nn + 16c / 256c', 'TS-Conf: the RAM from the page as a 512×512 picture of 16 / 256 colors'], ['pointer', 'x, y, pixel and attribute byte'],
      ['ULAX shown / 0 / 1', 'ZX ULAX: its picture now, or the raster of ZX screen 0 / 1 (352×256 with the border)'],
      ['click', 'the pixel byte in the dump'], ['Shift+click', 'the attribute byte in the dump']]]]],
    ['Breakpoints', [[null, [
      ['Z80 addr', 'address or range, X / R / W'], ['RAM / ROM page', 'physical byte: 05:1A00 (whatever is mapped)'],
      ['IN / OUT port', 'port and mask (00FF: low byte)'], ['INT', 'interrupt'], ['Stop / Count', 'stop, or only count the hits'],
      ['Cursor', 'from the cursor line'], ['Save / Load', '.xbrk list']]]]],
    ['Project', [[null, [
      ['marks, labels, comments', 'bound to RAM / ROM pages, kept per model in the browser'], ['.xmap', 'project file: save / load'],
      ['labels', 'load / save lists: PP:AAAA name, AAAA name, name equ #AAAA']]]]],
  ];
  function helpHtml(list, intro) {
    const esc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    let h = intro;
    for (const [title, groups] of list) {
      h += `<h4>${esc(title)}</h4>`;
      for (const [sub, rows] of groups) {
        if (sub) h += `<h5>${esc(sub)}</h5>`;
        h += '<dl>' + rows.map(([k, d]) => `<dt>${esc(k)}</dt><dd>${esc(d)}</dd>`).join('') + '</dl>';
      }
    }
    return h;
  }

  // ------------------------------------------------------------------ keyboard
  function locks(e) {
    const g = (k) => e.getModifierState && e.getModifierState(k);
    return (g('CapsLock') ? 1 : 0) | (g('NumLock') ? 2 : 0) | (g('ScrollLock') ? 4 : 0);
  }
  const modalOpen = () => false; // no blocking windows any more: every window is a floating one
  const held = new Set();
  // SAM Coupé: the PC's symbols as the SAM types them ([0 / 1 SHIFT / 2 SYMBOL, the key: row * 8 + bit as IN #FE])
  const SAM_SYM = { '!': [1, 24], '@': [1, 25], '#': [1, 26], '$': [1, 27], '%': [1, 28], '&': [1, 36], "'": [1, 35], '(': [1, 34], ')': [1, 33],
    '~': [1, 32], '-': [0, 37], '/': [1, 37], '+': [0, 38], '*': [1, 38], '<': [2, 16], '>': [2, 17], '[': [2, 19], ']': [2, 20],
    '=': [0, 45], '_': [1, 45], '"': [0, 46], '`': [1, 46], '{': [2, 11], '}': [2, 12], '^': [2, 52], '£': [2, 49], ';': [0, 53],
    ':': [0, 54], '?': [2, 2], '.': [0, 62], ',': [0, 61], '\\': [1, 63], '|': [2, 33] };
  const samHeld = new Map();
  function releaseAll() {
    if (!E) return;
    for (const code of held) { const sc = SCAN[code]; if (sc !== undefined) E.web_key(sc, 0, 0); }
    held.clear();
    for (const c of samHeld.values()) E.web_sam_combo(c[0], c[1], 0);
    samHeld.clear();
    E.web_keys_clear();
    if (vkbd) vkbd.releaseAll();
    kjBits = 0; E.web_kjoy(0); E.web_zx_clear();
  }
  const HOTKEYS = new Set(['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F12', 'Slash', 'NumpadDivide']);
  function hotkey(e) {
    if (e.ctrlKey && e.altKey && !e.metaKey && e.code === 'KeyZ' && MODELS[model].xt) { toggleXT(); return true; } // ATM mode on / off
    if (e.ctrlKey && e.altKey && !e.metaKey && !e.shiftKey && e.code === 'KeyU' && dux) { if (!e.repeat) ulaxToggle(true); return true; } // ZX ULAX: its picture / the ZX one
    if (e.code === 'KeyV' && !e.altKey && ((e.ctrlKey && e.shiftKey && !e.metaKey) || (e.metaKey && !e.ctrlKey))) { if (!e.repeat) { for (const c of held) afterDbg.add(c); releaseAll(); pasteClip(); } return true; } // the Ctrl / Shift of the combination are let go for the machine, or they would join the typed keys // Ctrl+Shift+V, Cmd+V: paste text
    if (E.web_xt_kbd()) { // in ATM (XT) mode every key goes to the machine (Alt+F1 too: Wild Commander picks a panel's drive with it)
      if (HOTKEYS.has(e.code) && !(e.shiftKey || e.ctrlKey || e.altKey || e.metaKey)) xtMsg();
      return false;
    }
    if (e.altKey && !(e.ctrlKey || e.shiftKey || e.metaKey) && e.code === 'F1') { showOptions(!optOpen()); return true; } // Alt+F1: Options (as in the debugger)
    if (e.code === 'F1' && e.shiftKey && !(e.ctrlKey || e.altKey || e.metaKey)) { if (!e.repeat) dbgShiftF1(); return true; } // Shift+F1: the debugger chosen in Options / System
    if (e.code === 'F12' && e.shiftKey && !(e.ctrlKey || e.altKey || e.metaKey) && M() === 'TSCONF') { if (!e.repeat) tsSetup(); return true; } // TS-BIOS Setup
    if (M() === 'NEXT' && ((e.code === 'F12' && e.shiftKey && !(e.ctrlKey || e.altKey || e.metaKey)) || (e.code === 'F11' && e.shiftKey && e.altKey && !(e.ctrlKey || e.metaKey)) || (e.code === 'F11' && e.ctrlKey && !(e.shiftKey || e.altKey || e.metaKey)))) { // the NMI buttons of the Next
      if (!e.repeat) { const k = e.code === 'F11' && e.ctrlKey ? 2 : 1, r = E.web_nx_nmi(k); toast(r > 0 ? (k === 1 ? 'Multiface (NMI)' : 'DivMMC NMI') : r === -2 ? (k === 1 ? 'Multiface' : 'DivMMC NMI') + ' button is off (NR #06 D' + (k === 1 ? 3 : 4) + ')' : 'NMI: no NextZXOS ROMs (enNextMf.rom, enNxtmmc.rom)', r <= 0); }
      return true;
    }
    if (e.code === 'F11' && e.ctrlKey && !(e.shiftKey || e.altKey || e.metaKey) && dmOn()) { // the NMI button of the DivMMC (esxDOS: its NMI menu); TR-DOS magic of Pentagon otherwise
      if (!e.repeat) { E.web_nmi(0); toast('DivMMC NMI'); }
      return true;
    }
    if (e.code === 'Backquote' && e.shiftKey && !(e.ctrlKey || e.altKey || e.metaKey)) { setBare(!bare, !bareLink && !land); return true; } // ~: menu bar and frame
    if (e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) return false;
    if (e.code === 'F12') { userReset(); return true; }
    // OSZ: Ext + key (Caps Shift + Symbol Shift + key: three ZX keys, more than a key of the ini keyset gives) on F keys too:
    // F8 = Ext+1 (the system process), F9 = Ext+9 (None Commander), F10 = Ext+0 (shadow monitor)
    if (M() === 'GMX' && OSZ_FKEYS[e.code] !== undefined) { if (!e.repeat) runMacro([{ key: [ZK.CS, ZK.SS, OSZ_FKEYS[e.code]], hold: 8 }]); return true; }
    if (e.code === 'F2') { openSave(); return true; }
    if (e.code === 'F3') { showLoad(); return true; }
    if (e.code === 'F4') { toggleSound(); return true; }
    if (e.code === 'F5') { setUserPaused(!userPaused); return true; }
    if (e.code === 'Slash' || e.code === 'NumpadDivide') { toggleTurbo(); return true; }
    if (e.code === 'F6') { if (!e.repeat) shotOpen(); return true; }
    if (e.code === 'F7') { E.web_tape(); return true; }
    if (e.code === 'Escape' && (mouseLocked || performance.now() - mouseUnlockAt < 400)) return true; // this Esc released the mouse
    if (e.code === 'F1') { releaseMouse(); fc.show(!fc.open); fcVk = fc.open; return true; } // F1: File Commander
    return false;
  }
  window.addEventListener('keydown', (e) => {
    if (!e.isTrusted) return; // keys of the on-screen keyboard sent to a window (File Commander) never reach the machine
    if (!E) return;
    const fwEl = document.activeElement && document.activeElement.closest ? document.activeElement.closest('.fwin') : null;
    if (fwEl) { // keys for the controls of a floating window; Esc closes it
      if (e.code === 'Escape') { fwinShow(fwEl.id, false); e.preventDefault(); }
      return;
    }
    if (optOpen() && !dbgOn) {
      if (e.code === 'Escape') { showOptions(false); e.preventDefault(); return; }
      if ($('options').contains(document.activeElement)) return; // keys for the option controls
    }
    if (fc && fc.open && fc.hasFocus()) return; // keys for File Commander
    if (gfx && gfx.open && gfx.hasFocus()) { // keys for Graf Search, not for the debugger / emulator
      if (!gfx.typing() && gfx.key(e)) e.preventDefault();
      return;
    }
    if (dga && dga.open && (dbgOn || dga.hasFocus())) { // deBUGa: its keys (F7 F8 F4 F6 F9…), nothing for the machine while stopped
      if (e.code === 'F1' && e.shiftKey && !(e.ctrlKey || e.altKey || e.metaKey) && !(e.target && e.target.tagName === 'INPUT')) { e.preventDefault(); if (!e.repeat) dbgShiftF1(); return; }
      if (dga.key(e) || dbgOn) e.preventDefault();
      if (dbgOn || dga.hasFocus()) return;
    }
    if (dbgOn) { e.preventDefault(); debugKey(e, true); return; }
    if (afterDbg.has(e.code)) { e.preventDefault(); return; } // still held since the debugger was closed
    startAudio();
    if (!e.repeat && hotkey(e)) { e.preventDefault(); return; }
    if (isPaused()) return;
    const sc = SCAN[e.code];
    if (sc === undefined) return;
    e.preventDefault();
    if (M() === 'SAM' && !e.ctrlKey && E.web_sam_combo) { const c = SAM_SYM[e.key]; if (c) { if (!e.repeat && !samHeld.has(e.code)) { samHeld.set(e.code, c); E.web_sam_combo(c[0], c[1], 1); } return; } }
    held.add(e.code);
    E.web_key(sc, 1, locks(e));
  });
  window.addEventListener('keyup', (e) => {
    if (E && dbgOn && dga && dga.open) { e.preventDefault(); return; }
    if (E && dbgOn) { e.preventDefault(); debugKey(e, false); return; }
    if (E && dbgIgnore === e.code) dbgIgnore = null;
    if (afterDbg.delete(e.code)) { e.preventDefault(); return; }
    // macOS sends no keyup for a letter pressed while Cmd is down (Cmd+R, Cmd+C): with Cmd let go, every key is let go
    if (E && (e.code === 'MetaLeft' || e.code === 'MetaRight') && held.size > (held.has(e.code) ? 1 : 0)) { releaseAll(); return; }
    if (E && samHeld.has(e.code)) { const c = samHeld.get(e.code); samHeld.delete(e.code); E.web_sam_combo(c[0], c[1], 0); e.preventDefault(); return; }
    if (!E || !held.has(e.code)) return;
    e.preventDefault();
    held.delete(e.code);
    E.web_key(SCAN[e.code], 0, locks(e));
  });
  window.addEventListener("blur", () => { releaseAll(); afterDbg.clear(); });

  function toggleXT() { releaseAll(); E.web_toggle_xt(); updateUI(); xtMsg(); }
  // XT mode label next to the XT icon (bottom left), in the color of the icon
  let xtMsgT = 0;
  function xtMsg() {
    if (!E || $('xt').hidden) return;
    const on = !!E.web_xt_kbd(), m = $('xtmsg');
    const nm = isTS() || M() === 'SPRINTER' ? 'PC keys' : 'XT mode'; // TS-Conf, Sprinter: no ATM keyboard controller, the mode only gives F1-F12 and the like to the machine
    m.textContent = on ? nm + ' on · emulator hotkeys off' : nm + ' off · emulator hotkeys on';
    m.classList.toggle('on', on);
    clearTimeout(xtMsgT); xtMsgT = setTimeout(() => { m.textContent = ''; }, 2600);
  }
  function toggleTurbo() { turbo = !turbo; $('turbo').classList.toggle('on', turbo); $('turbo').title = turbo ? 'Max speed: on' : 'Max speed'; }

  // ------------------------------------------------------------------ disks
  const DRV = 'ABCD';
  function extOf(name) { const m = /\.([^.]+)$/.exec(name); return m ? m[1].toLowerCase() : ''; }
  function insertFromFs(name, drive, quiet) {
    setName(name);
    // autorun into A:: the emulator's boot (boot6.$b) is not added at first — a disk without its own boot gets RUN "first BASIC"
    if (runRestore && !quiet && (drive === runRestore.d || (drive < 0 && runRestore.d === 0))) runRestore = null; // another disk: the run= catalogue is not put back into it
    const noBoot = !!autorunNext && !quiet && drive <= 0 && M() !== 'SAM'; // the boot is added (or not) once the catalogue has been seen (SAM Coupé: no TR-DOS boot)
    if (noBoot) E.web_noboot(1);
    let ok; try { ok = E.web_load(drive); } finally { if (noBoot) E.web_noboot(0); }
    if (!ok) { toast('Cannot load ' + name, true); return false; }
    const withBoot = (d) => E.web_addboot(d); // as a load without autorun: the emulator's boot added (when the disk has none)
    const ext = extOf(name);
    const isDisk = ['trd', 'scl', 'fdi', 'udi', 'td0', 'isd', 'pro', 'hob', 'dsk', 'ipf', 'img', 'ima', 'mgt', 'sad'].includes(ext) || ext.startsWith('$');
    if (isDisk) {
      let d = drive;
      if (d < 0) {
        for (let i = 0; i < 4; i++) if (E.web_disk_present(i) && cstr(E.web_disk_name(i)).toLowerCase().endsWith(name.toLowerCase())) d = i;
        if (d < 0) d = 0;
      }
      drives[d] = { name, ext, url: loadingUrl || (quiet && drives[d] ? drives[d].url : null) }; // url: for the REST API link
      if (!quiet) toast('Drive ' + DRV[d] + ': ' + name);
      if (autorunNext && d === 0 && !quiet && M() === 'SAM') { // SAM Coupé: Reset, a key past the start screen, F9 (BOOT)
        autorunNext = false; samBoot(); toast('Drive A: ' + name + ' — autorun (BOOT)');
      } else if (autorunNext && d === 0 && !quiet) {
        const useBoot = autorunNext === 'boot', found = noBoot ? diskRunPlan(0) : null;
        const plan = !useBoot && found && found.run ? found : null; // Autostart TRDOS / autorun=1: RUN "first BASIC"
        const added = noBoot && !plan && !(found && found.boot); // no boot of its own: the emulator's boot (its menu)
        if (added) withBoot(0);
        autorunNext = false; autorun(plan); toast('Drive A: ' + name + ' — autorun' + (plan ? ' (RUN "' + plan.run + '")' : ''));
        // keys for the boot's menu: press= of a link (the emulator's boot or the disk's own: the link knows its disk), or
        // Load / Use boot.b (the emulator's boot only: the disk's own may have no menu)
        const press = linkLoading ? String(LINK.press || '').trim() : useBoot && added ? $('ldpress').value.trim() : '';
        if (found && press && macro && (added || found.boot)) macro.steps.push({ wait: added ? 60 : 100 }, ...zxPress(press)); // its own boot: longer to load
      } else if (noBoot) withBoot(d);
    } else {
      if (!quiet) toast('Loaded: ' + name);
      if (['tap', 'tzx', 'csw'].includes(ext)) tapeName = name; // Load / Media
      if (autorunNext && !quiet && ['tap', 'tzx', 'csw'].includes(ext)) { autorunNext = false; autorunTape(); toast('Tape: ' + name + ' — autorun'); }
    }
    updateUI();
    return true;
  }
  const LOADABLE = /\.(trd|scl|fdi|udi|td0|isd|pro|hob|dsk|mgt|sad|ipf|tap|tzx|csw|sna|z80|sp|spg|nex|dot|wmf|pal|rzx|dux|\$.)$/i;
  // the page's question box: resolves true (OK) / false (Cancel, Esc); OK has the focus
  // the page's question: one at a time (a second one waits until the first is answered; it took over the box and the
  // first never got its answer). Esc: null (false-like; a choice of two buttons can tell it from the second button)
  let askQ = Promise.resolve();
  function askBox(title, text, ok, no, alt) { // alt: a third button (its answer: 'alt')
    const r = askQ.then(() => askNow(title, text, ok, no, alt));
    askQ = r.then(() => {}, () => {});
    return r;
  }
  function askNow(title, text, ok, no, alt) {
    const w = $('askbox'), okb = w.querySelector('.ok'), nob = w.querySelector('.no'), altb = w.querySelector('.alt');
    altb.hidden = !alt; altb.textContent = alt || '';
    w.querySelector('.t').textContent = title || ''; w.querySelector('.t').hidden = !title; w.querySelector('.x').textContent = text || '';
    okb.textContent = ok || 'OK'; nob.textContent = no || 'Cancel';
    releaseAll(); w.hidden = false;
    { // centred on the window that asks (the active floating window: Load, Options…), else the emulator window; inside the screen
      const own = actWin && !actWin.hidden && actWin.getBoundingClientRect().width ? actWin : $('mainwin');
      const b = w.querySelector('.box'), r = own.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = window.innerHeight;
      b.style.position = 'absolute';
      b.style.left = Math.max(8, Math.min(r.left + (r.width - b.offsetWidth) / 2, vw - b.offsetWidth - 8)) + 'px';
      b.style.top = Math.max(8, Math.min(r.top + (r.height - b.offsetHeight) / 2, vh - b.offsetHeight - 8)) + 'px';
    }
    okb.focus();
    return new Promise((res) => {
      const done = (v) => { w.hidden = true; w.onkeydown = null; okb.onclick = nob.onclick = altb.onclick = null; canvas.focus(); res(v); };
      okb.onclick = () => done(true); nob.onclick = () => done(false); altb.onclick = () => done('alt');
      w.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); done(null); } else if (e.key === 'Enter') { e.preventDefault(); done(document.activeElement === altb ? 'alt' : document.activeElement !== nob); }
        else if (['ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) { e.preventDefault(); const bs = [okb, nob, altb].filter((b) => !b.hidden), i = bs.indexOf(document.activeElement); bs[(i + (e.key === 'ArrowLeft' ? bs.length - 1 : 1)) % bs.length].focus(); } };
    });
  }
  const DISK_EXT = /\.(trd|scl|fdi|udi|td0|isd|pro|hob|dsk|mgt|sad|ipf|\$.)$/i;
  const FD_IMG = (name, len) => /\.(img|ima)$/i.test(name) && (len === 737280 || len === 368640); // a raw PC floppy (720K / 360K): a disk, not an SD / HDD image
  let coreAnswer = null; // the answer for the core's next MessageBox question (6 yes, 7 no)
  // DSK (CPCEMU / EXTENDED): the sector size of its first track (N = 2: 512 bytes)
  function dsk512(b) {
    const sig = String.fromCharCode(...b.subarray(0, 8));
    if (sig !== 'MV - CPC' && sig !== 'EXTENDED' || b.length < 0x200) return false;
    const t = 0x100; return String.fromCharCode(...b.subarray(t, t + 10)) === 'Track-Info' && b[t + 0x14] === 2;
  }
  // a SAM Coupé disk: MGT / SAD, a raw .dsk of 800K, or a DSK (CPCEMU / EXTENDED) of 80 tracks or more on 2 sides
  function samDisk(name, b) {
    if (/\.(mgt|sad)$/i.test(name)) return true;
    if (!/\.dsk$/i.test(name)) return false;
    if (b.length === 819200) return true;
    const sig = String.fromCharCode(...b.subarray(0, 8));
    if (sig !== 'MV - CPC' && sig !== 'EXTENDED') return false;
    return b[0x30] >= 80 && b[0x31] === 2; // 80 tracks × 2 sides (games with their own formats too); +3 disks: 40 tracks, 1 side
  }
  async function putAndInsert(name, buf, drive, src) {
    name = name.replace(/^.*[\\/]/, '').replace(/[:]/g, '_');
    if (/\.(sna|z80|sp|spg|nex|dot|rzx)$/i.test(name) && dux) duxDrop(); // another program: the dux is not for it (a disk / tape: it may be the next of the same program)
    if (drive === ROM_TARGET) { const a = autorunNext; autorunNext = false; await loadRomDisk(name, buf, a); return; }
    if (/\.spg$/i.test(name)) { autorunNext = false; await spgLoad(name, buf); return; }
    if (/\.dux$/i.test(name)) { autorunNext = false; duxLoad(name, buf, true); return; } // ZX ULAX colors: onto the program in memory now
    if (/\.(nex|dot)$/i.test(name)) { autorunNext = false; await nexLoad(name, buf); return; }
    if (/\.(sna|z80|sp|spg|rzx)$/i.test(name) && !await recGate()) return; // a snapshot: the recording cannot go on
    if (/\.rzx$/i.test(name)) { autorunNext = false; await rzxOpen(name, buf); return; }
    if (rz) rzxClose(); // another image: the recording's player goes
    if (RZX_MODELS.has(model)) { const back = rzxBack || 'ATM710', a = autorunNext; toast(name + ': ' + MODELS[back].name + ' starts'); await setModel(back, true); autorunNext = a; if (model !== back) return; }
    if (/\.wmf$/i.test(name)) { autorunNext = false; await wcWmf(name, buf); return; }
    // a Spectrum snapshot on a machine whose memory is not paged by #7FFD (SAM Coupé, TS-Conf, Sprinter): Pentagon first
    if (/\.(sna|z80|sp)$/i.test(name) && (M() === 'SAM' || M() === 'SPRINTER' || M() === 'NEXT' || isTS())) { toast(name + ': a ZX Spectrum snapshot — ' + MODELS.PENTAGON.name + ' starts'); const a = autorunNext; await setModel('PENTAGON', true); autorunNext = a; if (M() !== 'PENTAGON') return; }
    // a +3 / CPC disk (DSK with 512-byte sectors): Spectrum +3 (Beta Disk machines read only TR-DOS disks of 256-byte sectors)
    if (samDisk(name, buf) && M() !== 'SAM') { toast(name + ': a SAM Coupé disk — SAM Coupé starts'); const a = autorunNext; await setModel('SAM', true); autorunNext = a; if (M() !== 'SAM') return; }
    else if (/\.dsk$/i.test(name) && M() !== 'PLUS3' && !samDisk(name, buf) && dsk512(buf)) { toast(name + ': a +3 disk — Spectrum +3 starts'); const a = autorunNext; await setModel('PLUS3', true); autorunNext = a; if (M() !== 'PLUS3') return; }
    // a disk into a drive whose disk was changed: asked here (the core's "Save disk" question is not used). No drive given:
    // the core's choice (the drive after the last one with a disk; Hobeta: that one)
    let d = drive;
    if (FD_IMG(name, buf.length)) autorunNext = false; // a PC floppy (Sprinter DSS: FAT12): no TR-DOS autostart
    if (DISK_EXT.test(name) || FD_IMG(name, buf.length)) {
      if (d < 0) { let last = -1; for (let i = 0; i < 4; i++) if (E.web_disk_present(i)) last = i; d = last < 0 ? 0 : /\.\$.$|\.hob$/i.test(name) ? last : (last + 1) & 3; }
      const k = drives.findIndex((x, j) => x && j !== d && j < 4 && x.name.toLowerCase() === name.toLowerCase() && E.web_disk_present(j));
      if (k >= 0) { // the core asks this too: asked here, the core gets the answer
        if (!await askBox('', 'This disk image is already loaded to drive ' + DRV[k] + ':\nDo you still want to load it to drive ' + DRV[d] + ':?')) return;
        coreAnswer = 6;
      }
      if (E.web_disk_present(d) && E.web_disk_changed(d)) {
        if (!loseAsked && !await askBox('Disk ' + DRV[d] + ':', 'Discard changes for ' + (drives[d] ? drives[d].name : diskBase(d)) + '?')) return;
        E.web_disk_mark(d, 0);
      }
    }
    // a TR-DOS disk with the DivMMC on (esxDOS takes #3Dxx: TR-DOS does not start): asked once whether it goes off
    if (/\.(trd|scl|fdi|udi|td0|isd|hob|\$.)$/i.test(name) && !FD_IMG(name, buf.length) && dmOn() && dmRom && !loseAsked
      && await askBox('DivMMC', 'DivMMC is on: TR-DOS disks need it off. Switch DivMMC off?', 'Switch off')) {
      dmLink = null; store('divmmc', '0'); await dmApply(); if (!autorunNext) E.web_reset(0); // esxDOS left the machine in 48 BASIC: a reset (the 128 menu; an autostart resets by itself)
      toast('DivMMC off');
    }
    fs.write(name, buf);
    let ok; try { ok = insertFromFs(name, d); } finally { coreAnswer = null; }
    if (ok && d >= 0 && !(src && /^SD/.test(src))) await wcDiskToSd(d, name, buf); // a disk from the card itself: it is there already
  }
  // NEX / DOT: a ZX Spectrum Next program (NEX: banks and loading screens; DOT: a dot command run at #2000): loaded into RAM
  // and started by the core as NextZXOS starts them; on another machine the model switches first
  async function nexLoad(name, buf) {
    if (M() !== 'NEXT') { toast(name + ': a ZX Spectrum Next program — ' + MODELS.NEXT.name + ' starts'); await setModel('NEXT', true); if (M() !== 'NEXT') return; }
    const dot = /\.dot$/i.test(name);
    const p = E.malloc(buf.length); new Uint8Array(E.memory.buffer, p, buf.length).set(buf);
    let r; try { r = dot ? E.web_nx_dot(p, buf.length) : E.web_nx_nex(p, buf.length); } finally { E.free(p); }
    const why = ['', dot ? 'not a dot command (over 8K)' : 'not a NEX file', 'the file is cut', 'a bank beyond the RAM', 'no start address (needs NextZXOS)'][r] || 'not loaded';
    if (r) { toast(name + ': ' + why, true); return; }
    setName(name); toast((dot ? 'DOT: ' : 'NEX: ') + name); updateUI();
  }
  // SPG: a TS-Conf program file (TS-Labs): loaded into RAM and started by the core; on another machine the model switches first
  async function spgLoad(name, buf) {
    if (!isTS()) { toast(name + ': a TS-Conf program — ZX Evo TS-Conf starts'); await setModel('TSCONF', true); if (!isTS()) return; }
    const p = E.malloc(buf.length); new Uint8Array(E.memory.buffer, p, buf.length).set(buf);
    let r; try { r = E.web_ts_spg(p, buf.length); } finally { E.free(p); }
    const why = ['', 'not an SPG file', 'a block is missing (the file is cut)', 'a block does not depack'][r & 0xFF];
    if (r) { toast(name + ': ' + why + (r > 0xFF ? ' (block ' + ((r >> 8) + 1) + ')' : ''), true); return; }
    setName(name); toast('SPG: ' + name); updateUI();
  }
  // ------------------------------------------------------------------ RZX: input recordings played back (web/rzx.js, web/web_rzx.cpp)
  // The recording's snapshot starts on its machine (ZX Spectrum 48 / 128 / +2 with the Sinclair ROMs, Spectrum +3, Pentagon); then each frame takes the
  // recorded port values. The player (over the screen, shown by a tap) seeks by states saved on the way (every few seconds):
  // back = the nearest state before, then the frames up to there without sound and picture.
  let rz = null; // { name, total, creator, keys: [{ f, s }], ki, speed, seeking, scratch, note, taken, pin (the player always shown) }
  const RZ_FPS = 50;
  const rzTime = (f) => { const t = Math.floor(f / RZ_FPS); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  async function rzxOpen(name, buf) {
    let r;
    try { r = await UnrealRzx.read(buf); } catch (e) { toast(name + ': ' + e.message, true); return; }
    if (rz) rzxClose();
    const want = ['RZX48', 'RZX128', 'PLUS3', 'RZXP2', 'PENTAGON'][r.mach] || 'RZX128'; // the machine of the snapshot
    const rom = MODELS[want].files[0];
    if (!await ensureFiles([rom])) { toast(name + ': the recording needs ' + srcUrl(rom) + (rom === 'sinclair.rom' ? ' (the ZX Spectrum 48 / 128 / +2 ROMs)' : ''), true); return; }
    if (M() !== want) { if (!RZX_MODELS.has(model)) rzxBack = model; toast(name + ': ' + MODELS[want].name + ' starts'); await setModel(want, true); if (M() !== want) return; }
    const p = E.malloc(r.buf.length); new Uint8Array(E.memory.buffer, p, r.buf.length).set(r.buf);
    const total = E.web_rzx_load(p, r.buf.length); // the core keeps the buffer (and frees it)
    if (!total || !E.web_rzx_start(0)) { toast(name + ': the recording cannot be read', true); E.web_rzx_free(); return; }
    rz = { name, total, creator: r.creator, keys: [], ki: Math.max(250, Math.ceil(total / 150)), speed: 1, seeking: false, scratch: E.malloc(E.web_rzx_st_size()), note: '', taken: false, pin: true };
    rzxKey(); rzxIndex(r.buf); setName(name); releaseMouse(); if (touchMouse) setTouchMouse(false);
    if (userPaused) setUserPaused(false);
    if (audio) audio.flush();
    rzxUI(); rzxShow(true);
    toast('RZX: ' + name + ' · ' + rzTime(total) + (r.creator ? ' · ' + r.creator : ''));
  }
  function rzxClose() {
    if (!rz) return;
    if (rz.ix) rz.ix.terminate();
    E.web_rzx_free(); E.free(rz.scratch); rz = null;
    $('rzxbar').hidden = true; clearTimeout(rzxHideT);
  }
  // The states of the whole recording, made ahead in a worker (a second copy of the core on the same files, no sound, no
  // picture): the playback takes only the recorded port values, so its states are the ones this machine gets at those
  // frames. A seek forward then starts from the nearest of them, as a seek back does
  let wasiSrc = null;
  async function rzxIndex(buf) {
    const my = rz;
    try {
      if (!wasiSrc) wasiSrc = (window.UnrealJsSrc && window.UnrealJsSrc['wasi_fs.js']) || await (await fetch('js/wasi_fs.js')).text();
      if (rz !== my || !module || typeof Worker === 'undefined') return;
      const files = [];
      for (const f of fs.files.values()) if (f.size < (4 << 20)) files.push([f.name, f.data.slice(0, f.size)]);
      const url = URL.createObjectURL(new Blob([wasiSrc, '\n;(' + rzxWorker.toString() + ')();'], { type: 'text/javascript' }));
      const w = new Worker(url); URL.revokeObjectURL(url);
      my.ix = w; my.ixAt = 0;
      w.onmessage = (e) => {
        const d = e.data;
        if (rz !== my) { w.terminate(); return; }
        if (d.key) { if (!my.keys.some((x) => x.f === d.f)) { my.keys.push({ f: d.f, s: new Uint8Array(d.key) }); my.keys.sort((a, b) => a.f - b.f); } my.ixAt = d.f; rzxIxUI(); }
        if (d.done || d.err) { my.ixAt = my.total; my.ix = null; w.terminate(); rzxIxUI(); if (d.err) console.warn('RZX index:', d.err); }
      };
      w.onerror = (e) => { e.preventDefault(); if (my.ix === w) { my.ix = null; w.terminate(); } };
      const b = buf.slice();
      w.postMessage({ module, files, rzx: b, ki: my.ki }, [b.buffer]);
    } catch (e) { console.warn('RZX index:', e.message); }
  }
  function rzxWorker() { // runs in the worker (after wasi_fs.js)
    onmessage = async (ev) => {
      const { module, files, rzx, ki } = ev.data;
      try {
        const fs = new self.UnrealWasi.MemFS();
        for (const [n, d] of files) fs.write(n, d);
        const wasi = new self.UnrealWasi.WASI(fs, { stdout: () => {} });
        const env = { web_fatal: () => { throw new Error('core stopped'); }, web_message: () => 1, web_tz_offset: () => 0, web_sleep: () => {}, web_debug_notify: () => {}, web_ui: () => {} };
        const E = (await WebAssembly.instantiate(module, { wasi_snapshot_preview1: wasi.imports, env })).exports;
        wasi.setMemory(E.memory); E._initialize(); E.web_init();
        const p = E.malloc(rzx.length); new Uint8Array(E.memory.buffer, p, rzx.length).set(rzx);
        const total = E.web_rzx_load(p, rzx.length);
        if (!total || !E.web_rzx_start(0)) throw new Error('the recording cannot be read');
        const size = E.web_rzx_st_size();
        for (;;) {
          const n = E.web_rzx_ff(ki - (E.web_rzx_pos() % ki || 0) || ki);
          if (!n || !(E.web_rzx_status() & 1) || E.web_rzx_pos() >= total - 1) break;
          const sp = E.web_rzx_state(), s = new Uint8Array(E.memory.buffer, sp, size).slice(); // the call first: its malloc may grow the memory (a view of the old buffer throws)
          postMessage({ f: E.web_rzx_pos(), key: s.buffer }, [s.buffer]);
        }
        postMessage({ done: true });
      } catch (e) { postMessage({ err: e.message || String(e) }); }
    };
  }
  function rzxIxUI() { // the part with states made: the seek bar shows it
    if (!rz) return;
    const v = rz.total > 1 ? Math.min(100, 100 * rz.ixAt / (rz.total - 1)) : 100;
    $('rzxseek').style.setProperty('--ix', v.toFixed(1) + '%');
  }
  function rzxKey() { // the state of this frame, kept to come back to it
    const f = E.web_rzx_pos(), k = rz.keys;
    if (k.some((x) => x.f === f)) return;
    const sp = E.web_rzx_state(), s = new Uint8Array(E.memory.buffer, sp, E.web_rzx_st_size()).slice();
    k.push({ f, s, u: ulaxSave() }); k.sort((a, b) => a.f - b.f);
    // ZX ULAX: its states take memory (a few hundred KB each): up to 64 MB of them, the ones farthest back go first
    let tot = 0; for (let i = k.length - 1; i >= 0; i--) if (k[i].u) { tot += k[i].u.length; if (tot > 64 << 20) k[i].u = null; }
  }
  const rzLastKeyBefore = (f) => { let m = -1; for (const x of rz.keys) if (x.f <= f && x.f > m) m = x.f; return m; };
  const rzLastKey = () => { let m = -1; const f = E.web_rzx_pos(); for (const x of rz.keys) if (x.f <= f && x.f > m) m = x.f; return m; };
  async function rzxSeek(f) {
    if (rz && rz.seeking) { rz.seekTo = Math.max(0, Math.min(rz.total - 1, Math.round(f))); return; } // a new place while seeking: go there
    if (!rz) return;
    const my = rz, myE = E; // this recording: another one opened meanwhile (or another machine) stops the seek
    if (!await recGate()) { rzxUI(); return; } // the player going on ends a recording
    if (rz !== my) return;
    rz.seekTo = Math.max(0, Math.min(rz.total - 1, Math.round(f)));
    rz.seeking = true; rz.taken = false; rz.note = ''; rzxUI();
    // from the nearest state before the place (when it is nearer than where the machine is now); the worker's states come
    // in while this runs, a nearer one is taken too
    const from = (f) => {
      let k = null; for (const x of rz.keys) if (x.f <= f && (!k || x.f > k.f)) k = x;
      const cur = E.web_rzx_pos(), on = E.web_rzx_status() & 1;
      if (k && (!on || f < cur || k.f > cur)) { new Uint8Array(E.memory.buffer, rz.scratch, k.s.length).set(k.s); E.web_rzx_restore(rz.scratch); if (k.u) ulaxLoad(k.u); } // ULAX: its colors of that frame (a state of the worker: the dux again)
    };
    from(f = rz.seekTo);
    let t0 = performance.now();
    for (;;) {
      if (rz !== my || E !== myE) break;
      if (rz.seekTo !== f || (rz.keys.length && E.web_rzx_pos() < f && rzLastKeyBefore(f) > E.web_rzx_pos())) from(f = rz.seekTo);
      if (!(E.web_rzx_pos() < f && (E.web_rzx_status() & 1))) break;
      const n = Math.min(f - E.web_rzx_pos(), rz.ki - (E.web_rzx_pos() - rzLastKey()), 500);
      if (!E.web_rzx_ff(Math.max(1, n))) break;
      if (E.web_rzx_pos() - rzLastKey() >= rz.ki) rzxKey();
      if (performance.now() - t0 > 40) { $('rzxtime').textContent = rzTime(E.web_rzx_pos()); $('rzxseek').value = E.web_rzx_pos(); await new Promise((r) => setTimeout(r, 0)); t0 = performance.now(); }
    }
    my.seeking = false;
    if (rz !== my || E !== myE) return;
    if (audio) audio.flush();
    render(); rzxPoll(); rzxUI();
  }
  // after the frames of a refresh: the end / out of sync, the states on the way
  function rzxPoll() {
    if (!rz || rz.seeking) return;
    const st = E.web_rzx_status(), f = E.web_rzx_pos();
    if ((st & 1) && f - rzLastKey() >= rz.ki) rzxKey();
    if ((st & 2) && rz.note !== 'end') { rz.note = 'end'; toast('RZX: Finished'); rzxUI(); rzxShow(true); }
    if ((st & 4) && rz.note !== 'sync') {
      rz.note = 'sync';
      toast('RZX: out of sync at ' + rzTime(E.web_rzx_bad()) + ' (frame ' + E.web_rzx_bad() + ') — the program went another way', true);
      rzxUI(); rzxShow(true);
    }
    if (!$('rzxbar').hidden && !rzDrag) { const t = rzTime(f), el = $('rzxtime'), sk = $('rzxseek'); if (el.textContent !== t) el.textContent = t; if (+sk.value !== f) sk.value = f; } // written on a change only (this runs every screen refresh)
  }
  const rzPlaying = () => !!(rz && (E.web_rzx_status() & 1));
  function rzxUI() {
    if (!rz) return;
    const on = rzPlaying(), run = on && !userPaused;
    setIcon('rzxplay', run ? 'i-pause' : 'i-play');
    $('rzxplay').title = run ? 'Pause' : on ? 'Play' : 'Play the recording from here';
    $('rzxpin').classList.toggle('on', rz.pin);
    $('rzxpin').title = rz.pin ? 'Player stays on screen (click: hide it, a tap on picture shows it for a while)' : 'Player hides (click: keep it on screen)';
    $('rzxmsg').textContent = rz.seeking ? 'seeking…' : rz.note === 'sync' ? 'out of sync' : rz.taken ? 'your turn' : '';
    $('rzxseek').max = rz.total - 1; $('rzxlen').textContent = rzTime(rz.total);
    $('rzxtime').style.minWidth = rzTime(rz.total).length + 'ch'; // as wide as the length: the seek bar keeps its size while it plays
    $('rzxspeed').textContent = rz.speed + '×';
    // the end of the recording: "Finished" in place of Take control, as wide as the button was (the bar keeps its geometry)
    const tb = $('rzxtake'), fin = rz.note === 'end' && !rz.seeking;
    if (!fin && tb.offsetWidth) tb.dataset.w = tb.offsetWidth;
    tb.classList.toggle('fin', fin); tb.textContent = fin ? 'Finished' : 'Take control';
    tb.style.width = fin && tb.dataset.w ? tb.dataset.w + 'px' : '';
    tb.disabled = !on || fin;
  }
  let rzxHideT = 0, rzDrag = false;
  function rzxShow(v) {
    if (!rz) return;
    clearTimeout(rzxHideT);
    $('rzxbar').hidden = !v;
    if (v && rz.pin) { rzxUI(); rzxPoll(); return; } // fixed: always there
    if (v) { rzxUI(); rzxPoll(); rzxHideT = setTimeout(() => { if (rz && rzPlaying() && !userPaused && !rzDrag && !$('rzxbar').matches(':hover') && !$('rzxbar').contains(document.activeElement)) $('rzxbar').hidden = true; else if (rz) rzxShow(true); }, 3000); }
  }
  // RZX recording (Save / Input recording): the core counts the fetches of each frame and keeps the values of the INs
  const REC_MACH = { RZX48: 0, RZX128: 1, PLUS3: 2, RZXP2: 3, PENTAGON: 4 };
  let recDone = null; // the last recording, stopped: { state, mach, frames, n, creator, major, minor, name }
  const recOn = () => !!(E && E.web_rzx_rec_on && E.web_rzx_rec_on());
  // why a recording cannot start now ('' = it can)
  const recWhyNot = () => !(M() in REC_MACH) ? 'not on this machine: 48/128K models only (Pentagon 128, Spectrum +3, a machine an RZX started)'
    : SPEEDS[speedIdx] > 3 ? 'CPU clock over 3x' : rzPlaying() ? 'RZX plays: Take control first' : '';
  // a user action that ends the recording (Reset, another machine, a snapshot, the player): asked first; yes = discarded
  async function recGate() {
    if (!recOn()) return true;
    if (!await askBox('RZX recording', 'Stop recording and discard it?', 'Stop')) return false;
    E.web_rzx_rec_stop(); recDone = null; recUI(); toast('RZX recording: discarded');
    return true;
  }
  function recStart() {
    const why = recWhyNot(); if (why) { toast('RZX recording: ' + why, true); return; }
    E.web_rzx_rec_start(REC_MACH[M()]);
    fwinShow('savedlg', false); canvas.focus();
    toast('RZX recording: on'); recUI();
  }
  function recStop(why) {
    if (!E || !recOn() && !why) return;
    E.web_rzx_rec_stop();
    const n = E.web_rzx_rec_frames(), sp = E.web_rzx_rec_snap();
    if (n && sp) {
      const v = APP_VER.split('.');
      recDone = { state: new Uint8Array(E.memory.buffer, sp, E.web_rzx_st_size()).slice(), mach: REC_MACH[M()] !== undefined ? REC_MACH[M()] : 4,
        frames: new Uint8Array(E.memory.buffer, E.web_rzx_rec_data(), E.web_rzx_rec_len()).slice(), n,
        creator: 'Web Unreal Speccy', major: +v[0] || 0, minor: (+v[1] || 0) * 100 + (+v[2] || 0),
        name: ((rz && rz.name) || cstr(E.web_disk_name(0)) || 'recording').replace(/^.*[\\/]/, '').replace(/\.[^.]*$/, '') + '_rec.rzx' };
      toast('RZX recording: ' + rzTime(n) + (why ? ' — ' + why : '') + ' (Save / Input recording)', !!why);
    }
    recUI();
  }
  function recUI() {
    const on = recOn();
    if ($('recmark').hidden === on) { $('recmark').hidden = !on; hudDraw(); } // its place: hudDraw
    if ($('svrec')) { const why = on ? '' : recWhyNot();
      $('svrec').textContent = on ? 'Stop' : 'Start'; $('svrec').classList.toggle('primary', on); $('svrec').disabled = !!why;
      $('svrecst').textContent = on ? 'recording ' + rzTime(E.web_rzx_rec_frames()) : why ? why : recDone ? rzTime(recDone.n) + ' recorded, ready to save' : 'not recording';
      if ($('svtype').value === 'rzx') $('svgo').disabled = !recDone; }
  }
  function recPoll() { // after the frames of a refresh
    if (!recOn()) { if (!$('recmark').hidden) { const e = E.web_rzx_rec_err(); recStop(e === 1 ? 'a frame too long (CPU clock)' : e === 2 ? 'out of memory' : e === 3 ? 'reset' : 'stopped'); } return; }
    { const t = rzTime(E.web_rzx_rec_frames()), el = $('rectime'); if (el.textContent !== t) el.textContent = t; }
    if (!$('savedlg').hidden && $('svtype').value === 'rzx') recUI();
  }
  function bindRzx() {
    // a tap on the picture shows the player (the program does not get the mouse while the recording plays)
    $('screenwrap').addEventListener('pointerdown', (e) => {
      if (!rz || e.target !== canvas) return;
      e.stopPropagation(); e.preventDefault();
      if (!rz.pin) rzxShow($('rzxbar').hidden);
    }, true);
    const done = () => { rzxShow(true); canvas.focus(); };
    $('rzxplay').onclick = () => {
      if (!rz) return;
      if (rzPlaying()) setUserPaused(!userPaused);
      else { setUserPaused(false); rzxSeek(rz.note === 'end' || rz.note === 'sync' ? 0 : E.web_rzx_pos()); }
      rzxUI(); done();
    };
    $('rzxseek').oninput = () => { rzDrag = true; $('rzxtime').textContent = rzTime(+$('rzxseek').value); clearTimeout(rzxHideT); };
    $('rzxseek').onchange = async () => { rzDrag = false; await rzxSeek(+$('rzxseek').value); done(); };
    $('rzxspeed').onclick = () => { if (!rz) return; rz.speed = rz.speed >= 8 ? 1 : rz.speed * 2; rzxUI(); done(); };
    $('rzxtake').onclick = async () => { // the recording stops where it is, the player goes: the game is yours from here
      if (!rzPlaying()) return;
      if (!await askBox('RZX', 'Take control? (RZX player will be closed).', 'Take control')) { done(); return; }
      if (!rz) return;
      const at = rzTime(E.web_rzx_pos());
      E.web_rzx_stop(); rzxClose(); setUserPaused(false); canvas.focus();
      toast('RZX: your turn from ' + at);
    };
    $('rzxpin').onclick = () => { if (!rz) return; rz.pin = !rz.pin; done(); }; // hide: shown by a tap, for a while; fix: always
  }
  async function loadFile(file, drive) { await loadBytes(file.name, new Uint8Array(await file.arrayBuffer()), drive); }
  // autorunNext: set by the Load window just before a load, used by the first disk inserted into A: — true: its boot or its
  // first BASIC program (REST API autorun=1, Server list, Autostart TRDOS); 'boot': its boot, the emulator's boot added when
  // the disk has none (Use boot.b)
  let keepNext = false; // the file being loaded: Load / Local file, Save to Browser Storage (withLocal)
  let autorunNext = false, loadingUrl = null, linkLoading = false; // loadingUrl: where the file being loaded came from
  // Load / Local file: Autostart (and its choices) for the files of this computer — Choose File, a drop on the screen, Local server
  let hdBoot = false; // Autostart + Boot from HDD / SD: an HDD / SD card image boots
  const ldAuto = () => $('ldauto').checked;
  const runMode = (run) => run ? ($('ldboot').checked ? 'boot' : true) : false; // autorunNext: 'boot' = boot.b menu, true = first BASIC program
  const ldMode = () => runMode(ldAuto());
  // One load at a time: what a load is to do (autorunNext, tsNoAuto, hdBoot, keepNext, imgHint, loadingUrl, linkLoading,
  // loseAsked) is set by the load that runs and cleared after it; another load (a drop, File Commander, a link during
  // a question) waits for its turn instead of taking or clearing these. Only the entries (UI actions, the link at start)
  // take the turn: what they call inside does not
  let loadQ = Promise.resolve();
  const loadReset = () => { autorunNext = false; tsNoAuto = false; hdBoot = false; keepNext = false; imgHint = null; loadingUrl = null; linkLoading = false; loseAsked = false; };
  function loadLocked(fn) {
    const run = loadQ.then(() => { loadReset(); return fn(); });
    loadQ = run.then(loadReset, loadReset);
    return run;
  }
  function withLocal(fn, local) {
    return loadLocked(async () => {
      autorunNext = ldMode(); tsNoAuto = !ldAuto(); hdBoot = ldAuto() && $('ldhdboot').checked;
      keepNext = !!local && $('ldkeep').checked; // Choose File, a drop: Save to Browser Storage
      await fn();
    });
  }
  // unsaved changes of the media a load replaces: one question (Run of the server list asks first for all it replaces: loseAsked)
  let loseAsked = false;
  function loseList(keys) { // 'a'…'d', 'hdd0', 'hdd1', 'sd'
    const out = [];
    for (const k of keys) {
      if (/^[a-d]$/.test(k)) { const i = 'abcd'.indexOf(k); if (E && E.web_disk_present(i) && E.web_disk_changed(i)) out.push(DRV[i] + ': ' + (drives[i] ? drives[i].name : diskBase(i))); }
      else if (/^hdd[01]$/.test(k)) { const d = +k[3]; if (hdds[d] && hddDirty[d]) out.push('HDD ' + d + ': ' + hdds[d]); }
      else if (k === 'sd' && sdName && sdDirty && !sdWcOwn) out.push('SD: ' + sdName);
      else if (k === 'sd2' && sd2Name && sd2Dirty) out.push('MMC: ' + sd2Name);
      else if (k === 'usb' && usbName && usbDirty) out.push('USB: ' + usbName.slice(4));
    }
    return out;
  }
  async function loseOk(keys) {
    if (loseAsked) return true;
    const l = loseList(keys);
    return !l.length || askBox('Unsaved changes', 'These changes will be lost:\n' + l.join('\n'), 'Continue');
  }
  // an HDD or SD card image from Load (Local file, Local server, a drop): HDD 0 or the SD card. .hdd / .hdf (or a .chs with
  // it): HDD; ZX Evo (Z-Controller built in): SD; else asked (the last answer first)
  async function imgFromBytes(name, buf) {
    let inner = name, img = buf;
    if (UnrealZip.isZip(buf)) {
      const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name));
      const big = all.reduce((a, b) => (b.size > a.size ? b : a), { size: -1, name });
      inner = all.some((e) => /\.chs$/i.test(e.name)) ? 'x.hdd' : big.name;
      img = big.size > 0 ? await UnrealZip.extract(buf, big) : null;
    }
    const card = img ? sdCardKind(img) : ''; // 'nedo': NedoOS (sd_boot.$C), 'wc': Wild Commander (boot.$C) — an SD card for sure
    let to; // 'hdd', 'sd', 'mmc'
    if (imgHint) to = imgHint; // saved in the browser as an HDD / SD / MMC image
    else if (card === 'esx') to = 'mmc'; // an esxDOS card: the DivMMC's (the machine: Pentagon if this one has none)
    else if (/\.(hdd|hdf)$/i.test(inner)) to = 'hdd';
    else if (card || sdBuiltIn()) to = 'sd';
    else { // asked; the last answer is the first button
      const opts = dmHere() ? ['hdd', 'sd', 'mmc'] : ['hdd', 'sd'], label = { hdd: 'HDD 0', sd: 'SD card', mmc: 'MMC' };
      let last = load('ld.imgto'); if (!opts.includes(last)) last = 'hdd';
      const order = [last, ...opts.filter((x) => x !== last)];
      const a = await askBox(name, dmHere() ? 'An HDD, an SD card or an MMC card (DivMMC) image?' : 'An HDD or an SD card image?', label[order[0]], label[order[1]], order[2] && label[order[2]]);
      if (a === null) return false; // Esc: not loaded
      to = a === true ? order[0] : a === 'alt' ? order[2] : order[1];
      store('ld.imgto', to);
    }
    if (to === 'mmc') return mmcPut(name, buf, hdBoot);
    const toSd = to === 'sd';
    if (toSd) {
      if (!await sdFromBytes(name, buf)) return;
      sdSrc = null;
      sdEnable(); // the Z-Controller switched on for this machine
      if (hdBoot) { // a card of an OS boots on its machine: NedoOS on ZX Evo BaseConf, Wild Commander on TS-Conf (the card stays in)
        const want = card === 'nedo' && M() !== 'EVO' ? 'EVO' : card === 'wc' && !isTS() ? 'TSCONF' : null;
        if (want) { toast(sdName + ': ' + (card === 'nedo' ? 'NedoOS' : 'Wild Commander') + ' — ' + MODELS[want].name + ' starts'); await setModel(want, true); if (M() !== want) return; }
        sdBoot();
      }
    } else {
      if (!await hddFromBytes(0, name, buf)) return;
      if (hdBoot && hdds[0]) hddBoot();
    }
  }
  // what boots from an SD card image: its FAT root has sd_boot.$C (NedoOS) or boot.$C (Wild Commander, TS-Conf)
  function sdCardKind(img) {
    try {
      const T = UnrealFC._test, base = T.fatFind(img)[0]; if (base === undefined) return '';
      const vol = T.fatVol(img, base), root = vol.list(), names = root.map((x) => (x.name + (x.ext ? '.' + x.ext : '')).toLowerCase());
      if (names.includes('sd_boot.$c')) return 'nedo';
      if (names.includes('boot.$c')) return 'wc';
      const sys = root.find((x) => x.dir && /^sys$/i.test(x.name)); // esxDOS: SYS/ESXDOS.SYS
      if (sys) { vol.enter(sys); if (vol.list().some((x) => /^esxdos$/i.test(x.name) && /^sys$/i.test(x.ext || ''))) return 'esx'; }
      return '';
    } catch (e) { return ''; }
  }
  function hddBoot() { // Boot from HDD: the machine boots its HDD 0 (xBIOS: Boot → HDD in its setup; the others: Reset)
    if (!E.web_hdd_scheme(-1)) { toast('HDD 0: ' + MODELS[model].name + ' has no HDD interface on (Options / Disk / HDD)', true); return; }
    const w = (f1x) => Math.ceil(f1x / Math.max(1, mclk()));
    if (M() === 'XBIOS136') runMacro([{ reset: 0 }, { wait: w(100) }, { xtmode: 1 }, { xt: ['Space'] }, { wait: w(60) }, ...rep(2, { xt: ['ArrowDown'] }), { wait: 10 }, { xt: ['Enter'] }]);
    else E.web_reset(0);
    toast('HDD 0: ' + hdds[0] + ' — boot');
  }
  function sdBoot() { // Boot from SD: TS-Conf: Wild Commander (and the card's program, its .json); ZX Evo BaseConf: Reset Service 5 = SD card; the others: Reset
    if (isTS()) { tsBootSd(); if (sdRun) wcAutorun(); return; }
    if (M() === 'NEXT') { nxCardBoot(); return; }
    if (M() === 'EVO') { const k = Math.max(1, 2 / mclk()); runMacro([{ reset: 0 }, { wait: Math.ceil(150 * k) }, { xtmode: 1 }, { xt: ['Digit5'] }]); }
    else E.web_reset(0);
    toast('SD card: ' + sdName + ' — boot');
  }
  async function loadBytes(name, buf, drive) {
    if (buf.length > 18 && buf[0] === 0x1F && buf[1] === 0x8B && typeof DecompressionStream !== 'undefined') { // gzip (SimCoupe's .dsk.gz, a packed .dsk / .mgt): unpacked
      try { buf = new Uint8Array(await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()); name = name.replace(/\.gz$/i, ''); }
      catch (e) { toast(name + ': ' + e.message, true); return; }
    }
    const keep = keepNext; keepNext = false; // a local file: into the browser storage too, once it is loaded (on the machine it starts on)
    if (!UnrealZip.isZip(buf)) { if (HDD_EXT.test(name) && buf.length >= 1 << 20) await imgFromBytes(name, buf); else await putAndInsert(name, buf, drive); if (keep) await brwKeep(name, buf); return; }
    try {
      if (await cardZip(name, buf) || await tsZip(name, buf)) { if (keep) await brwKeep(name, buf); return; }
      const all = UnrealZip.list(buf), duxes = all.filter((e) => /\.dux$/i.test(e.name));
      const entries = all.filter((e) => LOADABLE.test(e.name) || FD_IMG(e.name, e.size));
      if (duxes.length) return await duxZip(name, buf, entries, duxes, drive, keep);
      if (!entries.length && UnrealZip.list(buf).some((e) => HDD_EXT.test(e.name) || e.size >= 4 << 20)) { await imgFromBytes(name, buf); if (keep) await brwKeep(name, buf); return; }
      if (!entries.length) { toast('No disk, tape or snapshot images in the archive', true); return; }
      const pick = async (e) => { const d = await UnrealZip.extract(buf, e); await putAndInsert(e.name, d, drive); return d; };
      if (entries.length === 1) { await pick(entries[0]); if (keep) await brwKeep(name, buf); return; } // the archive itself is kept (not unpacked)
      const zctx = { autorunNext, tsNoAuto, hdBoot, imgHint, loadingUrl, linkLoading }; // the choice is made later in the ZIP window: this load as it was
      const list = $('ziplist'); list.innerHTML = '';
      for (const e of entries) {
        const b = document.createElement('button');
        b.textContent = e.name.replace(/^.*[\\/]/, '') + '  (' + Math.round(e.size / 1024) + ' KB)';
        b.onclick = async () => {
          fwinShow('zippick', false); let d = null;
          await loadLocked(async () => { ({ autorunNext, tsNoAuto, hdBoot, imgHint, loadingUrl, linkLoading } = zctx); try { d = await pick(e); } catch (err) { toast(err.message, true); } });
          if (!keep || !d) return; // a local ZIP kept after open: the archive itself (Mount / Run from the storage asks again)
          await brwKeep(name, buf);
        };
        list.appendChild(b);
      }
      releaseAll(); fwinShow('zippick', true);
    } catch (err) { toast(err.message, true); }
  }
  // a ZIP with a .dux (ZX ULAX colors) and its program: a snapshot / RZX first, then the dux (the one of the same name, or the
  // only one); a tape / disk: the dux waits until the program has loaded (Load / Media: Apply). Pentagon 128 starts when
  // this machine has no ULAX. No program in it: the dux onto the memory now
  async function duxZip(name, buf, entries, duxes, drive, keep) {
    const all = UnrealZip.list(buf);
    entries = entries.filter((e) => !/\.dux$/i.test(e.name)); // the dux goes with its program: not a choice of its own
    const base = (n) => n.replace(/^.*[\\/]/, '').replace(/\.[^.]*$/, '').toLowerCase();
    const duxFor = (e) => duxes.find((d) => base(d.name) === base(e.name)) || duxes.find((d) => base(d.name).startsWith(base(e.name))) || (duxes.length === 1 ? duxes[0] : null);
    const go = async (e) => {
      if (!ulaxFits() && !/\.rzx$/i.test(e.name)) { // this machine has no ULAX: asked first (Cancel: nothing is loaded)
        const d0 = duxFor(e);
        if (d0 && !await askBox('ZX ULAX', d0.name.replace(/^.*[\\/]/, '') + ' needs Pentagon or Spectrum +3. Switch to Pentagon?', 'Switch', 'Cancel')) return;
        const a = autorunNext; await setModel('PENTAGON', true); autorunNext = a; if (!ulaxFits()) return;
      }
      await putAndInsert(e.name, await UnrealZip.extract(buf, e), drive);
      const d = duxFor(e); if (!d) return;
      const db = await UnrealZip.extract(buf, d);
      if (/\.(sna|z80|sp|rzx)$/i.test(e.name)) {
        duxLoad(d.name, db, true);
        const u = all.find((x) => /\.ulx$/i.test(x.name) && base(x.name) === base(e.name)); // a snapshot saved with ULAX: its colors as they were
        if (u && /\.sna$/i.test(e.name) && !ulaxLoad(await UnrealZip.extract(buf, u))) toast(u.name.replace(/^.*[\\/]/, '') + ': not a ULAX state of this version (the dux is applied)', true);
      }
      else duxLoad(d.name, db, false);
    };
    if (!entries.length) { const d = duxes[0]; duxLoad(d.name, await UnrealZip.extract(buf, d), true); return; }
    const snaps = entries.filter((e) => /\.(sna|z80|sp|rzx)$/i.test(e.name));
    const one = entries.length === 1 ? entries[0] : snaps.length === 1 ? snaps[0] : null; // a game pack's pair: its snapshot
    if (one) { await go(one); if (keep) await brwKeep(name, buf); return; }
    const list = $('ziplist'); list.innerHTML = '';
    const zctx = { autorunNext, tsNoAuto, hdBoot, imgHint, loadingUrl, linkLoading };
    for (const e of entries) {
      const b = document.createElement('button');
      b.textContent = e.name.replace(/^.*[\\/]/, '') + '  (' + Math.round(e.size / 1024) + ' KB)' + (duxFor(e) ? ' + dux' : '');
      b.onclick = async () => {
        fwinShow('zippick', false);
        await loadLocked(async () => { ({ autorunNext, tsNoAuto, hdBoot, imgHint, loadingUrl, linkLoading } = zctx); try { await go(e); } catch (err) { toast(err.message, true); } });
        if (keep) await brwKeep(name, buf);
      };
      list.appendChild(b);
    }
    releaseAll(); fwinShow('zippick', true);
  }
  // ZX Evo TS-Conf programs come as the files of an SD card (run from Wild Commander): a ZIP for TS-Conf (the machine is
  // TS-Conf, or the ZIP has an SPG) with an SD card image in it goes into the SD card; one with boot.$C (Wild Commander and
  // its folder) is put on a new FAT32 SD card. Then TS-BIOS boots boot.$C of the card (Caps Shift + Reset). true: done
  let tsNoAuto = false; // the Load window with Autostart TRDOS off: Wild Commander starts, the card's program (its .json) does not
  // ZX Spectrum Next: a program of its SD card (the card's .json: { "model": "next", "run": "symbos.nex" }) started as a
  // NEX / DOT loaded from the card (the card stays in); no program: NextZXOS boots from the card (reset)
  function cardFile(path) {
    const img = sdName && fs.exists(sdName) ? fs.read(sdName) : null; if (!img) return null;
    const T = UnrealFC._test, base = T.fatFind(img)[0]; if (base === undefined) return null;
    const v = T.fatVol(img, base), p = path.toLowerCase().split('/').filter(Boolean), fname = (it) => (it.name + (it.ext ? '.' + it.ext : '')).toLowerCase();
    for (let k = 0; k < p.length; k++) {
      const it = v.list().find((x) => !x.up && fname(x) === p[k] && x.dir === (k < p.length - 1));
      if (!it) return null;
      if (k < p.length - 1) v.enter(it); else return v.read(it).data;
    }
    return null;
  }
  async function nxCardBoot(run) {
    run = run || sdRun;
    if (!run) { E.web_reset(0); toast('SD card: ' + sdName + ' · NextZXOS boots'); return; }
    const d = cardFile(run);
    if (!d) { toast(sdName + ': no ' + run + ' on the card · NextZXOS boots', true); E.web_reset(0); return; }
    await nexLoad(run.replace(/^.*\//, ''), d);
  }
  async function tsZip(name, buf) {
    const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name));
    const spg = all.some((e) => /\.spg$/i.test(e.name)) || (all.some((e) => /\.json$/i.test(e.name)) && /\.(spg|\$c|wmf)$/i.test(await zipRun(buf, all))); // a card with its program to start
    if (!isTS() && !spg) return false;
    const img = all.filter((e) => /\.(img|vhd|ima|sd)$/i.test(e.name) && e.size >= 1 << 20).sort((a, b) => b.size - a.size)[0];
    const boot = all.filter((e) => /(^|\/)boot\.\$c$/i.test(e.name)).sort((a, b) => a.name.length - b.name.length)[0];
    if (!img && !(boot && (isTS() || spg))) return false;
    if (!isTS()) { toast(name + ': a TS-Conf SD card — ZX Evo TS-Conf starts'); await setModel('TSCONF', true); if (!isTS()) return true; }
    if (img) { if (!await sdFromBytes(name, buf)) return true; } // not loaded (Cancel, a bad image): the card in the slot is not booted
    else { // the folder of boot.$C and all under it: a new card
      const base = boot.name.replace(/[^/]*$/, ''), files = [], dirs = [];
      for (const e of all) if (e.name.startsWith(base) && e.name.length > base.length) files.push({ path: e.name.slice(base.length).replace(/\\/g, '/'), data: await UnrealZip.extract(buf, e) });
      toast('Making an SD card of ' + name + '…');
      const r = await nedoImage({ files, dirs }, 64, 'TSCONF');
      if (!await sdFromBytes(name.replace(/\.zip$/i, '') + '.img', r.img)) return true;
    }
    if (!sdName) return true;
    sdEnable(true);
    tsBootSd(); // Wild Commander of the card
    if (tsNoAuto) { toast('SD card: ' + sdName + ' · Wild Commander starts (Autostart off: ' + (sdRun || 'the program') + ' is not run)'); return true; }
    wcAutorun();
    toast('SD card: ' + sdName + ' · TS-BIOS starts boot.$C (Caps Shift + Reset)' + (sdRun ? ', Wild Commander starts ' + sdRun : ''));
    return true;
  }
  let pendingDrive = -1, fromLoadWin = false;
  // F3, the Load button and the drive Insert buttons open the Load window
  function openFile(drive) { pendingDrive = drive; fromLoadWin = false; $('file').click(); } // Options / Disk: Insert into this drive (no autostart)

  // ------------------------------------------------------------------ floating windows (Load, server browser, Save, ZIP)
  const fwins = {};
  function fwinShow(id, v) {
    const w = $(id);
    if (!fwins[id]) fwins[id] = floatWin(w, 'pos.' + id, () => {
      const r = $('screenwrap').getBoundingClientRect(), vw = document.documentElement.clientWidth;
      return { x: Math.max(4, Math.min(r.left + (r.width - w.offsetWidth) / 2, vw - w.offsetWidth - 4)), y: Math.max(8, r.top + 24) };
    });
    if (v) {
      releaseAll(); releaseMouse(); w.hidden = false; fwins[id].place();
      // touch screens: focus the window itself, a focused select / input would pop up its picker or the on-screen keyboard
      if (matchMedia('(pointer: coarse)').matches) { w.tabIndex = -1; w.focus({ preventScroll: true }); }
      else { const f = w.querySelector('[data-autofocus], input:not([hidden]):not([type=checkbox]):not([type=radio]), select, button.primary:not([hidden])'); if (f) f.focus(); }
    }
    else { w.hidden = true; if (id === 'loadwin') ldHelp(false); if (id === 'savedlg') svHelp(false); canvas.focus(); }
  }

  // ------------------------------------------------------------------ autorun: reset to TR-DOS and type RUN (boots "boot")
  // steps run in emulated frames: { wait } or { key: matrix index, hold } (index = half-row * 8 + bit)
  const ZK = { CS: 0, Z: 1, R: 2 * 8 + 3, T: 2 * 8 + 4, ENTER: 6 * 8 + 0, K6: 4 * 8 + 4, K7: 4 * 8 + 3,
    K5: 3 * 8 + 4, K8: 4 * 8 + 2, SPACE: 7 * 8 + 0, SS: 7 * 8 + 1, K1: 3 * 8 + 0, K3: 3 * 8 + 2, K4: 3 * 8 + 3, L: 6 * 8 + 1, O: 5 * 8 + 1, A: 1 * 8 + 0, D: 1 * 8 + 2, P: 5 * 8 + 0 };
  const UP = [ZK.CS, ZK.K7], DOWN = [ZK.CS, ZK.K6]; // cursor keys = CAPS SHIFT + 7 / 6
  const OSZ_FKEYS = { F8: 3 * 8 + 0, F9: 4 * 8 + 1, F10: 4 * 8 + 0 }; // OSZ: F8 / F9 / F10 = Ext + 1 / 9 / 0 (ZX keys 1, 9, 0)
  let macro = null;
  const zxKeys = (k, d) => [].concat(k).forEach((x) => E.web_zxkey(x, d));
  // a macro that has turned ATM mode off for its menus (xtBack) and is replaced before its end: the new one turns it back on
  // SAM Coupé: keys of its matrix (row * 8 + bit) pressed by a macro
  const samKey = (k, frames) => [{ fn: () => E.web_sam_combo(0, k, 1) }, { wait: frames || 6 }, { fn: () => E.web_sam_combo(0, k, 0) }];
  function samBoot() { runMacro([{ reset: 0 }, { wait: 150 }, ...samKey(56), { wait: 50 }, ...samKey(23)]); } // SPACE, then F9 = BOOT
  function runMacro(steps) { if (macro && macro.key) zxKeys(macro.key, 0); const back = !!(macro && macro.xtBack); macro = { steps: steps.slice(), n: 0, key: null, xtBack: back, pw: 0 }; }
  const xtUser = () => (macro && macro.xtBack ? true : !!E.web_xt_kbd()); // ATM mode as the user has it (a menu macro may hold it off)
  function macroFrame() {
    if (!macro) return;
    if (macro.n > 0) { macro.n--; return; }
    if (macro.key) { zxKeys(macro.key, 0); macro.key = null; macro.n = macro.gap || 6; return; } // release, short gap
    if (macro.xtq && macro.xtq.length) { const c = macro.xtq.shift(); E.web_key(SCAN[c], 1, 0); macro.xt.push(c); macro.n = macro.xtq.length ? 2 : 3; return; }
    if (macro.xt) { macro.xt.slice().reverse().forEach((c) => E.web_key(SCAN[c], 0, 0)); macro.xt = null; macro.n = 3; return; }
    const st = macro.steps[0];
    if (!st) { if (macro.xtBack && E.web_xt_kbd && !E.web_xt_kbd()) { E.web_toggle_xt(); updateUI(); } macro = null; return; }
    if (st.prompt) { // CP/M: wait until the screen shows a bare "X>" prompt that stays for a few frames
      const k = cpmPrompt();
      if (k && k === macro.pk) { if (++macro.ps >= 10) { macro.steps.shift(); macro.pk = null; } }
      else { macro.pk = k; macro.ps = 0; }
      if (++macro.pw > 3000) { toast('CP/M: no command prompt', true); macro = null; } // ~1 min
      return;
    }
    if (st.until) { // wait for a state of the screen (each frame), at most st.max frames
      if (st.until()) { macro.steps.shift(); macro.pw = 0; return; }
      if (++macro.pw > (st.max || 3000)) { if (st.soft) { macro.steps.shift(); macro.pw = 0; return; } if (st.fail) toast(st.fail, true); macro = null; }
      return;
    }
    macro.steps.shift(); macro.pw = 0;
    if (st.reset !== undefined) { E.web_reset(st.reset); return; }
    if (st.fn) { st.fn(); return; }
    if (st.wait) { macro.n = st.wait; return; }
    if (st.xtmode !== undefined) { if (!!E.web_xt_kbd() !== !!st.xtmode) { E.web_toggle_xt(); updateUI(); } return; }
    if (st.xt) { macro.xtq = st.xt.slice(); macro.xt = []; return; } // keys go down one after another (Shift first)
    zxKeys(st.key, 1); macro.key = st.key; macro.n = st.hold || 6; macro.gap = st.gap || 0;
  }
  // ATM CP/M text screen (page 5): even columns at #01C0 + row × 64, odd columns at #21C0 + row × 64
  function cpmPrompt() {
    if ((E.web_ff77() & 7) !== 6) return null; // not the 80×25 text mode (the BIOS menu, a leftover "A>" in text memory)
    const ram = new Uint8Array(E.memory.buffer, E.web_gfx_mem(1, 0, 0), E.web_gfx_size(1)), base = 5 * 0x4000;
    const ch = (r, c) => ram[base + (c & 1 ? 0x21C0 : 0x01C0) + r * 64 + (c >> 1)];
    const blank = (b) => b === 0x20 || b === 0 || b === 0x5F;
    for (let r = 24; r >= 0; r--) {
      let last = -1; for (let c = 0; c < 80; c++) if (!blank(ch(r, c))) last = c;
      if (last < 0) continue;
      const d = ch(r, 0);
      return last === 1 && d >= 0x41 && d <= 0x50 && ch(r, 1) === 0x3E ? r + ':' + String.fromCharCode(d) : null;
    }
    return null;
  }
  // text → XT key codes (CP/M upper-cases commands itself)
  // cased: capitals with Shift (a paste); else letters as they are (CP/M upper-cases commands itself)
  function xtType(text, cased) {
    const out = [], SH = { ':': 'Semicolon', '_': 'Minus', '>': 'Period', '<': 'Comma', '*': 'Digit8', '?': 'Slash', '"': 'Quote',
      '!': 'Digit1', '@': 'Digit2', '#': 'Digit3', '$': 'Digit4', '%': 'Digit5', '^': 'Digit6', '&': 'Digit7', '(': 'Digit9', ')': 'Digit0',
      '+': 'Equal', '{': 'BracketLeft', '}': 'BracketRight', '|': 'Backslash', '~': 'Backquote' };
    const PL = { '.': 'Period', ' ': 'Space', '/': 'Slash', '-': 'Minus', ',': 'Comma', '=': 'Equal', ';': 'Semicolon', '[': 'BracketLeft', ']': 'BracketRight', "'": 'Quote', '\\': 'Backslash', '`': 'Backquote' };
    for (const c of text) {
      if (cased && /[A-Z]/.test(c)) out.push({ xt: ['ShiftLeft', 'Key' + c] });
      else if (/[a-z]/i.test(c)) out.push({ xt: ['Key' + c.toUpperCase()] });
      else if (/\d/.test(c)) out.push({ xt: ['Digit' + c] });
      else if (SH[c]) out.push({ xt: ['ShiftLeft', SH[c]] });
      else if (PL[c]) out.push({ xt: [PL[c]] });
    }
    return out;
  }
  // REST API cpm=: boot CP/M from the ATM BIOS menu and type the commands ("b:|alasm" or "b:alasm")
  function cpmCommands(v) {
    const cmds = [];
    for (let c of String(v).split(/[|;]/)) {
      c = c.trim(); if (!c) continue;
      const m = /^([a-p]):(\S.*)$/i.exec(c);
      if (m) { cmds.push(m[1] + ':'); c = m[2]; }
      cmds.push(c.replace(/\.com\b/i, ''));
    }
    return cmds;
  }
  // an OS model: its HDD image into HDD 0 (ATM IDE on), then xBIOS XT setup: Space, 2 × ↓ (vTR-dos cold → IDE hard drive master), Enter
  // ------------------------------------------------------------------ Options / System / Update: SD card images of the OS models from
  // GitHub (or a ZIP): NedoOS (BaseConf), Wild Commander (TS-Conf). The build of the image in use is shown, Make Image builds a new one
  const UPD = {
    NEDOOS: { os: 'NEDOOS', sd: 'sd/nedoos.zip', repo: 'alfishe/NedoOS', dir: 'release', boot: /^sd_boot\.\$c$/i, bootName: 'sd_boot.$C', zip: 'nedoos.zip', vhd: 'nedoos.vhd', vol: 'NEDOOS', key: 'nedoos', title: 'NedoOS',
      what: 'folder <b>release</b> of NedoOS' },
    WCTS: { os: 'TSCONF', sd: 'sd/wc.zip', repo: 'tslabs/zx-evo', dir: 'pentevo/soft/WC/exe', boot: /^boot\.\$c$/i, bootName: 'boot.$C', zip: 'wc.zip', vhd: 'wc.vhd', vol: 'WC', key: 'wc', title: 'Wild Commander',
      what: 'Wild Commander: folder <b>pentevo/soft/WC/exe</b> of TS-Labs zx-evo' },
    // OSZ: the folder goes to OSZ\ of the card; OS.TRD and the card's .json (machine, disk for A:) go into the ZIP beside the image
    OSZ: { os: 'OSZ', sd: 'sd/osz.zip', repo: 'izzx-git/OSZ', dir: 'Release/OSZ', boot: /^os\.\$c$/i, bootName: 'os.$C', zip: 'osz.zip', vhd: 'osz.vhd', vol: 'OSZ', key: 'osz', title: 'OSZ',
      sub: 'OSZ', disk: /^os\.trd$/i, card: { model: 'gmx', a: 'OS.TRD' }, what: 'OSZ: folder <b>Release/OSZ</b> of izzx-git/OSZ (OS.TRD in the ZIP for A:)' },
  };
  let updKey = UPD[load('upd.sel')] ? load('upd.sel') : 'NEDOOS';
  const updT = () => UPD[updKey];
  const nedoDate = (d) => { const t = new Date(d), z = (n) => String(n).padStart(2, '0'); return isNaN(t) ? '' : t.getFullYear() + '-' + z(t.getMonth() + 1) + '-' + z(t.getDate()); };
  function nedoNote(b, t) { // the build of a loaded image ZIP: its .json, else the date of the image in the archive (none: nothing)
    const done = (o) => { try { if (o) localStorage.setItem('unreal.' + t.key + '.build', JSON.stringify(o)); else localStorage.removeItem('unreal.' + t.key + '.build'); } catch (e) {} nedoUI(); };
    const dated = (t) => t && !isNaN(t) && t.getFullYear() > 1980; // a ZIP entry without a date reads as 1980-01-01 (DOS date 0)
    try {
      if (!UnrealZip.isZip(b)) { done(null); return; }
      const ents = UnrealZip.list(b), j = ents.find((e) => /\.json$/i.test(e.name)), img = ents.reduce((a, e) => (e.size > a.size ? e : a), { size: -1 });
      const byImg = () => done(dated(img.time) ? { date: img.time.toISOString(), commit: '', zipdate: true } : null);
      if (!j) { byImg(); return; }
      UnrealZip.extract(b, j).then((d) => {
        const o = JSON.parse(new TextDecoder().decode(d)), date = o.date || o.built;
        if (dated(new Date(date))) done({ date, commit: o.commit || '', built: o.built || '' }); else byImg();
      }).catch(byImg);
    } catch (e) { done(null); }
  }
  function nedoUI() {
    if (!$('updsel')) return;
    $('updsel').value = updKey;
    let o = null; try { o = JSON.parse(load(updT().key + '.build') || 'null'); } catch (e) {}
    const d = o && o.date ? nedoDate(o.date) : '', ok = d && d > '1980-12-31'; // no data (or the DOS zero date): nothing is written
    $('nedobuild').textContent = ok ? (o.zipdate ? 'from ' : 'build ') + d + (o.commit ? ' · ' + o.commit.slice(0, 7) : '') : '';
    if (!ok) $('nedobuild').textContent = 'no data (start once or make an image)';
    $('nedobuild').title = ok && o.zipdate ? updT().zip + ' has no .json: date of the image file in it' : ok && o.built ? 'image made ' + o.built : '';
  }
  let nedoFW = null, nedoLast = null, nedoBusy = false;
  function nedoStat(t, err) { $('nedostat').textContent = t; $('nedostat').classList.toggle('err', !!err); }
  function nedoProg(v) { const p = $('nedoprog'); p.hidden = v === null; if (v !== null) p.value = v; }
  function showNedo(v) {
    $('nedowin').hidden = !v;
    if (v) { const t = updT(); $('nedotitle').textContent = t.title + ' SD image'; $('nedowhat').innerHTML = 'New SD card image: ' + t.what + ' on FAT32 VHD, saved as ' + t.zip + ' (asks before download).';
      $('nedodl').textContent = 'Download ' + t.zip; $('nedogit').title = 'Folder ' + t.dir + ' of github.com/' + t.repo + ' (latest commit), file by file'; $('nedodone').hidden = true; nedoStat(''); }
    if (v) { if (!nedoFW) nedoFW = floatWin($('nedowin'), 'nedopos', () => { const r = $('screenwrap').getBoundingClientRect(), w = $('nedowin').offsetWidth; return { x: Math.max(4, r.left + (r.width - w) / 2), y: Math.max(8, r.top + 60) }; });
      $('nedomb').value = load('nedo.mb') || '100'; nedoFW.place(); }
  }
  // the release folder from GitHub: 4 API calls (head commit, trees, last change of the folder), then each file from raw.githubusercontent.com
  async function nedoFromGit(kind) {
    const t0 = kind || updT(), NEDO_REPO = t0.repo;
    const A = 'https://api.github.com/repos/' + NEDO_REPO, j = async (u) => {
      let r; try { r = await fetch(u, { headers: { Accept: 'application/vnd.github+json' } }); } catch (e) { throw new Error('GitHub cannot be reached from this page (network or CORS)'); }
      if (r.status === 403 || r.status === 429) throw new Error('GitHub API limit for this address (60 requests an hour): try later or use From file');
      if (!r.ok) throw new Error('GitHub API: HTTP ' + r.status);
      return r.json();
    };
    nedoStat('GitHub: ' + NEDO_REPO + ' · reading the file list…');
    const head = await j(A + '/commits/HEAD');
    let sha = head.commit.tree.sha, rel = null; // the folder: one tree request a level (pentevo / soft / WC / exe)
    for (const seg of t0.dir.split('/')) {
      const tr = await j(A + '/git/trees/' + sha); rel = tr.tree.find((x) => x.path.toLowerCase() === seg.toLowerCase() && x.type === 'tree');
      if (!rel) throw new Error('no folder ' + t0.dir + ' in ' + NEDO_REPO); sha = rel.sha;
    }
    rel = { sha, path: t0.dir };
    const t = await j(A + '/git/trees/' + rel.sha + '?recursive=1'); if (t.truncated) throw new Error('GitHub gave a cut list of files');
    let date = head.commit.committer.date; try { const c = await j(A + '/commits?path=' + rel.path + '&per_page=1'); if (c[0]) date = c[0].commit.committer.date; } catch (e) {}
    const blobs = t.tree.filter((x) => x.type === 'blob'), dirs = t.tree.filter((x) => x.type === 'tree').map((x) => x.path), files = new Array(blobs.length);
    const total = blobs.reduce((n, x) => n + (x.size || 0), 0); let got = 0, done = 0, next = 0;
    const raw = (p) => 'https://raw.githubusercontent.com/' + NEDO_REPO + '/' + head.sha + '/' + rel.path + '/' + p.split('/').map(encodeURIComponent).join('/');
    const one = async (k) => {
      for (let a = 0; ; a++) {
        try { const r = await fetch(raw(blobs[k].path)); if (!r.ok) throw new Error('HTTP ' + r.status); files[k] = { path: blobs[k].path, data: new Uint8Array(await r.arrayBuffer()) }; break; }
        catch (e) { if (a >= 2) throw new Error(blobs[k].path + ': ' + e.message); await new Promise((res) => setTimeout(res, 500 * (a + 1))); }
      }
      got += files[k].data.length; done++;
      if (!failed && (done % 20 === 0 || done === blobs.length)) { nedoStat(`GitHub: ${done} / ${blobs.length} files · ${(got / 1048576).toFixed(1)} of ${(total / 1048576).toFixed(1)} MB`); nedoProg(got / Math.max(1, total)); }
    };
    let failed = false; // the first error stops the other downloads (its message stays)
    await Promise.all(Array.from({ length: 12 }, async () => { while (next < blobs.length && !failed) { try { await one(next++); } catch (e) { failed = true; throw e; } } }));
    return { files, dirs, info: { source: 'https://github.com/' + NEDO_REPO + '/tree/' + head.sha + '/' + rel.path, commit: head.sha, date } };
  }
  // a ZIP from this computer: the folder with sd_boot.$C (release/ of a repository ZIP, or a ZIP of that folder)
  async function nedoFromZip(b, t) {
    if (!UnrealZip.isZip(b)) throw new Error('not a ZIP');
    const t0 = t || updT(), bn = t0.bootName.length;
    const ents = UnrealZip.list(b, true).map((e) => Object.assign(e, { name: e.name.replace(/\\/g, '/') })), boots = ents.filter((e) => t0.boot.test(e.name.replace(/^.*\//, ''))).map((e) => e.name.slice(0, e.name.length - bn));
    if (!boots.length) throw new Error('no ' + t0.bootName + ' in the archive: it is not ' + t0.title);
    const tail = t0.dir.toLowerCase() + '/', base = boots.find((x) => x.toLowerCase().endsWith(tail)) || boots.sort((x, y) => x.length - y.length)[0];
    const mine = ents.filter((e) => e.name.startsWith(base) && e.name.length > base.length), files = [], dirs = [];
    let latest = 0, k = 0;
    for (const e of mine) {
      const p = e.name.slice(base.length);
      if (p.endsWith('/')) { dirs.push(p.slice(0, -1)); continue; }
      files.push({ path: p, data: await UnrealZip.extract(b, e) }); if (e.time && e.time.getFullYear() > 1980 && +e.time > latest) latest = +e.time; // 1980: no date in the ZIP
      if (++k % 50 === 0) { nedoStat(`Unpacking: ${k} / ${mine.length}`); nedoProg(k / mine.length); await new Promise((r) => setTimeout(r, 0)); }
    }
    const sha = (/^[0-9a-f]{40}$/i.exec(UnrealZip.comment(b).trim()) || [''])[0]; // GitHub ZIPs carry the commit id as the comment
    return { files, dirs, info: { source: 'ZIP: ' + (base || '(root)'), commit: sha, date: latest ? new Date(latest).toISOString() : new Date().toISOString() } };
  }
  // the files on a new FAT32 image (New Disk / SD card logic); a size too small for them grows to what they need
  async function nedoImage(set, mb0, volName, t) { // t: the kind of image (Update panel's choice when it started); none: a plain card
    const T = UnrealFC._test, files = set.files.slice().sort((a, b) => a.path.localeCompare(b.path)), dirs = new Set(set.dirs);
    for (const f of files) { const p = f.path.split('/'); for (let i = 1; i < p.length; i++) dirs.add(p.slice(0, i).join('/')); }
    const data = files.reduce((n, f) => n + f.data.length, 0);
    let mb = Math.max(64, mb0 | 0), note = ''; const skipped = [];
    for (let tries = 0; tries < 6; tries++) {
      // 512-byte clusters, as the images NedoOS ships (its kernel of 13-14.10.2026 does not find bin/term.com on 1K clusters)
      const img = T.fatFormat(mb * 1048576, volName || (t && t.vol) || 'NO NAME', { start: 2048, type: 32, spc: 1, noLabelEntry: !!t && t.key === 'osz' }), base = T.fatFind(img)[0], vol = T.fatVol(img, base);
      const cb = (img[base + 11] | img[base + 12] << 8) * img[base + 13];
      const per = new Map(); for (const p of [...files.map((f) => f.path), ...dirs]) { const d = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '', n = p.slice(p.lastIndexOf('/') + 1); per.set(d, (per.get(d) || 0) + 1 + (/^[a-z0-9_$~!#%&'()@^`{}-]{1,8}(\.[a-z0-9_$~!#%&'()@^`{}-]{1,3})?$/i.test(n) ? 0 : Math.ceil(n.length / 13))); } // entries: short + long-name ones
      const need = files.reduce((n, f) => n + Math.ceil(f.data.length / cb) * cb, 0) + [...dirs, ''].reduce((n, d) => n + Math.ceil(((per.get(d) || 0) * 32 + 64) / cb) * cb, 0);
      if (need > vol.free()) { const nmb = mb + Math.ceil((need - vol.free()) * 1.05 / 1048576) + 1; note = `${mb} MB is too small for ${(data / 1048576).toFixed(1)} MB of files in ${files.length} files: the image is ${nmb} MB`; mb = nmb; continue; }
      try {
        nedoStat(`Writing ${files.length} files on a ${mb} MB FAT32 image…`); skipped.length = 0;
        // each folder gets all its entries' room at once, in clusters that follow each other (no folder spread over the disk)
        vol.setPath([]); vol.reserve((per.get('') || 0) * 32 + 64);
        for (const d of [...dirs].sort((a, b) => a.split('/').length - b.split('/').length || a.localeCompare(b))) { const p = d.split('/'); vol.setPath(p.slice(0, -1)); vol.mkdir(p[p.length - 1]); vol.setPath(p); vol.reserve((per.get(d) || 0) * 32 + 64); }
        let k = 0;
        for (const f of files) {
          const p = f.path.split('/'), nm = p.pop(), dot = nm.lastIndexOf('.');
          vol.setPath(p);
          try { vol.write(dot > 0 ? { name: nm.slice(0, dot), ext: nm.slice(dot + 1), data: f.data } : { name: nm, ext: '', data: f.data }); }
          catch (e) { if (!/exists/i.test(e.message)) throw e; skipped.push(f.path); } // same name in another case: FAT keeps one
          if (++k % 100 === 0) { nedoStat(`Writing: ${k} / ${files.length}`); nedoProg(k / files.length); await new Promise((r) => setTimeout(r, 0)); }
        }
        if (skipped.length) note += (note ? '\n' : '') + skipped.length + ' file(s) left out (same name in another case): ' + skipped.slice(0, 3).join(', ');
        return { img, mb, note, nfiles: files.length - skipped.length, data };
      } catch (e) { if (!/full/i.test(e.message)) throw e; const nmb = Math.ceil(mb * 1.15) + 1; note = `${mb} MB was not enough: the image is ${nmb} MB`; mb = nmb; }
    }
    throw new Error('the image cannot be made');
  }
  async function nedoRun(get) {
    if (nedoBusy) return; nedoBusy = true;
    $('nedodone').hidden = true; $('nedogit').disabled = $('nedofile').disabled = true; nedoProg(0);
    try {
      const mb = Math.max(64, Math.min(2047, parseInt($('nedomb').value, 10) || 100)); store('nedo.mb', String(mb));
      const t = updT(); // the choice at the start (it may change while the files come)
      const set = await get(t);
      const boot = set.files.find((f) => t.boot.test(f.path));
      if (!boot) throw new Error('no ' + t.bootName + ' in the folder');
      // the programs the loader starts (its texts: "term.com cmd.com autoexec.bat") must be in bin/
      const want = [...new Set((String.fromCharCode(...boot.data).match(/[a-z0-9_]{1,8}\.(com|bat)/gi) || []).map((x) => x.toLowerCase()))];
      const have = new Set(set.files.map((f) => f.path.toLowerCase()));
      const lost = t.key !== 'nedoos' ? [] : want.filter((x) => !have.has('bin/' + x) && !have.has(x));
      if (lost.length) throw new Error('sd_boot.$C starts ' + lost.join(', ') + ', but the release has no bin/' + lost[0] + ' — this ZIP is not a whole NedoOS release (' + set.files.length + ' files)');
      const disk = t.disk && set.files.find((f) => t.disk.test(f.path)); // OSZ: OS.TRD for A:, beside the image
      if (t.disk && !disk) throw new Error('no ' + t.card.a + ' in the folder');
      const r = await nedoImage(t.sub ? { files: set.files.map((f) => ({ path: t.sub + '/' + f.path, data: f.data })), dirs: [t.sub, ...set.dirs.map((d) => t.sub + '/' + d)] } : set, mb, null, t);
      nedoStat('Packing ' + t.zip + '…'); nedoProg(null);
      const info = Object.assign({}, t.card || {}, { os: t.title, date: set.info.date, commit: set.info.commit, source: set.info.source, built: new Date().toISOString(), size_mb: r.mb, files: r.nfiles });
      const vhd = vhdFixed(r.img);
      const zip = await UnrealZip.create([{ name: t.vhd, data: vhd }, ...(disk ? [{ name: t.card.a, data: disk.data }] : []), { name: t.key + '.json', data: new TextEncoder().encode(JSON.stringify(info, null, 2) + '\n') }]);
      nedoLast = { zip, vhd, info, t };
      store(t.key + '.build', JSON.stringify({ date: info.date, commit: info.commit, built: info.built })); nedoUI(); // the image to go onto the server
      nedoProg(null); nedoStat('Image made: ' + t.zip + ' ' + (zip.size / 1048576).toFixed(1) + ' MB');
      if (await askBox(t.title + ' image', `Image made: ${r.mb} MB FAT32 VHD, ${r.nfiles} files, build ${nedoDate(info.date)}${info.commit ? ' · ' + info.commit.slice(0, 7) : ''}.\nDownload ${t.zip} (${(zip.size / 1048576).toFixed(1)} MB)?`, 'Download')) downloadBytes(t.zip, zip);
      nedoStat((r.note ? r.note + '\n' : '') + `Done: ${t.zip} (${(zip.size / 1048576).toFixed(1)} MB) · ${r.mb} MB FAT32 VHD · ${r.nfiles} files, ${(r.data / 1048576).toFixed(1)} MB\nbuild ${nedoDate(info.date)}${info.commit ? ' · ' + info.commit.slice(0, 7) : ''}`);
      $('nedodone').hidden = false;
    } catch (e) { nedoProg(null); nedoStat(e.message + (/GitHub/.test(e.message) ? '\nFrom file: download the repository (GitHub: Code / Download ZIP) or a ZIP of its release folder and choose it here' : ''), true); }
    finally { nedoBusy = false; $('nedogit').disabled = $('nedofile').disabled = false; }
  }
  // ------------------------------------------------------------------ About / changes: the history (changes.txt) to read, not to copy
  let chFW = null, chText = null;
  // changes.txt with its lines joined again: each entry wraps by words at the width of the window (hanging indent)
  function chShow(text) {
    const t = $('chtext'); t.textContent = '';
    let cur = null;
    for (const ln of text.replace(/\r/g, '').split('\n')) {
      if (cur && /^  \S/.test(ln) && !/^  \[/.test(ln)) { cur.textContent += ' ' + ln.trim(); continue; } // a continuation line
      const d = document.createElement('div');
      if (/^[+!*@\-?] /.test(ln)) { d.className = 'che'; cur = d; }
      else { d.className = ln.trim() ? 'chl' : 'chb'; cur = null; }
      d.textContent = ln.trim() ? (d.className === 'che' ? ln : ln.replace(/^\s+/, (m) => m)) : '';
      t.appendChild(d);
    }
  }
  // the same window shows LICENSE (About / Credits: license), from its top
  let licText = null, chMode = 'ch';
  async function showChanges(v, mode) {
    const w = $('chwin');
    if (!v) { w.hidden = true; return; }
    mode = mode || 'ch';
    if (!chFW) {
      chFW = floatWin(w, 'chpos', () => { const r = $('options').getBoundingClientRect(); return { x: Math.max(4, r.left + 24), y: Math.max(8, r.top + 24) }; });
      edgeResize(w, { minW: () => 300, minH: 200, end: (r) => store('chsize', JSON.stringify({ w: Math.round(r.width), h: Math.round(r.height) })) });
      let sz = null; try { sz = JSON.parse(load('chsize') || 'null'); } catch (e) {}
      const o = $('options').getBoundingClientRect(); // first time: the height of Options, wide enough for the 72-character lines
      w.style.width = (sz ? sz.w : Math.min(document.documentElement.clientWidth - 8, Math.max(540, Math.round(o.width) || 440))) + 'px'; w.style.height = (sz ? sz.h : Math.round(o.height) || 420) + 'px';
      const t = $('chtext');
      for (const ev of ['copy', 'cut', 'contextmenu', 'selectstart', 'dragstart']) t.addEventListener(ev, (e) => e.preventDefault());
      t.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && /^Key[ACX]$/.test(e.code)) e.preventDefault(); });
      w.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); showChanges(false); } });
      $('chclose').onclick = () => showChanges(false);
    }
    w.hidden = false; chFW.place();
    $('chtitle').textContent = mode === 'lic' ? 'License' : 'Changes history';
    w.setAttribute('aria-label', mode === 'lic' ? 'License' : 'Changes history');
    const file = mode === 'lic' ? 'LICENSE' : 'changes.zip'; // the history: changes.txt in changes.zip
    let text = mode === 'lic' ? licText : chText;
    if (text === null || chMode !== mode) {
      chMode = mode;
      if (text === null) {
        $('chtext').textContent = 'Loading…';
        try {
          const r = await fetch(file, { cache: 'no-cache' }); if (!r.ok) throw new Error('HTTP ' + r.status);
          if (mode === 'lic') text = await r.text();
          else {
            const zip = new Uint8Array(await r.arrayBuffer()), e = UnrealZip.isZip(zip) && UnrealZip.list(zip).find((x) => /(^|\/)changes\.txt$/i.test(x.name));
            if (!e) throw new Error('no changes.txt in it');
            text = new TextDecoder().decode(await UnrealZip.extract(zip, e));
          }
        }
        catch (e) { $('chtext').textContent = file + ': ' + e.message; return; }
        if (mode === 'lic') licText = text; else chText = text;
      }
      if (mode === 'lic') { const t = $('chtext'); t.textContent = ''; for (const ln of text.replace(/\r/g, '').split('\n')) { const d = document.createElement('div'); d.className = ln.trim() ? 'chl' : 'chb'; d.textContent = ln; t.appendChild(d); } }
      else chShow(text);
    }
    const t = $('chtext'); t.scrollTop = mode === 'lic' ? 0 : t.scrollHeight; // changes: the newest versions are at the end; the license: from its top
    t.focus({ preventScroll: true });
  }
  function bindNedo() {
    $('nedobtn').onclick = () => showNedo($('nedowin').hidden);
    $('nedoclose').onclick = () => showNedo(false);
    $('nedowin').addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); showNedo(false); } });
    $('updsel').onchange = () => { updKey = $('updsel').value; store('upd.sel', updKey); nedoUI(); if (!$('nedowin').hidden) showNedo(true); };
    $('nedogit').onclick = () => nedoRun(nedoFromGit);
    $('nedofile').onclick = () => $('nedoinput').click();
    $('nedoinput').onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) nedoRun(async (t) => { nedoStat('Reading ' + f.name + '…'); return nedoFromZip(new Uint8Array(await f.arrayBuffer()), t); }); };
    $('nedodl').onclick = () => { if (nedoLast) downloadBytes(nedoLast.t.zip, nedoLast.zip); };
    $('nedouse').onclick = async () => { if (!nedoLast) return; const t = nedoLast.t; if (!await sdFromBytes(t.zip, new Uint8Array(await nedoLast.zip.arrayBuffer()))) return; /* the ZIP: its .json too (OSZ: the machine, OS.TRD) */ if (sdName) sdSrc = new URL(lowDir(t.sd), location.href).href; /* the model start keeps it */ store(t.key + '.build', JSON.stringify({ date: nedoLast.info.date, commit: nedoLast.info.commit, built: nedoLast.info.built })); nedoUI(); };
  }
  // Sprinter: Estex DSS from hdd/dss.zip into HDD 0 when it is empty or holds an image another machine brought (CP/M, iS-DOS);
  // its BIOS looks for the disk once at the start: reset after the image is in. ATM mode on (PC keys: F1-F12 for FN / FM)
  const SP_HDD = 'hdd/dss.zip', OTHER_HDD = /(^|\/)(cpm\.(zip|hdd)|tasis540\.zip|isdos501\.zip)$/i;
  async function spBoot(first) {
    if (!E.web_xt_kbd()) { E.web_toggle_xt(); updateUI(); }
    if (first && (LINK.hdd || LINK.hdd0)) return; // the link's image comes next (linkApply)
    if (hdds[0] && !OTHER_HDD.test(hddSrc[0] || hdds[0])) return; // the visitor's own image stays
    toast('Loading ' + SP_HDD + '…');
    let ok = false;
    try { ok = await hddFromBytes(0, SP_HDD.replace(/^.*\//, ''), await fetchBytes(SP_HDD), true); if (ok) hddSrc[0] = SP_HDD; }
    catch (e) { toast(SP_HDD + ': ' + e.message, true); return; }
    if (!ok || !hdds[0] || M() !== 'SPRINTER') return;
    if (!E.web_hdd_scheme(-1)) E.web_hdd_scheme(+hddIfPref());
    hddMount(0); hddUI();
    E.web_reset(0);
  }
  // ZX Spectrum Next: NextZXOS from sd/next.zip (the System/Next distribution, made into an FAT32 card) when no card is in or
  // the card is another machine's; the boot looks for the card once: reset after it is in
  const NX_SD = 'sd/next.zip';
  async function nxBoot(first) {
    if (first && LINK.sd) return; // the link's card comes next (linkApply)
    const url = new URL(lowDir(NX_SD), location.href).href;
    if (sdName && fs.exists(sdName) && (sdSrc === url || !sdSrc)) return; // its own card, or the visitor's
    toast('Loading ' + NX_SD + '…');
    let buf; try { buf = await fetchBytes(NX_SD); } catch (e) { toast(NX_SD + ': ' + e.message + ' — NextZXOS needs its SD card (Options / Disk / SD card)', true); return; }
    if (M() !== 'NEXT' || !await sdFromBytes('next.zip', buf, true) || !sdName) return;
    sdSrc = url; sdEnable(true);
    if (!(first && LINK.snap)) E.web_reset(0); // a link's program (NEX, DOT) runs without NextZXOS: the card is in, no reset
  }
  async function osBoot(first) {
    if (model === 'TSCONF') { await tsWc(); return; }
    if (model === 'SPRINTER') { await spBoot(first); return; }
    if (model === 'NEXT') { await nxBoot(first); return; }
    const os = OS_MODELS[model]; if (!os) return;
    if (os.sd) { // an SD card OS: the image (kept when it is already in: its changes stay), Reset, 5 in the EVO Reset Service
      const url = new URL(lowDir(os.sd), location.href).href;
      if (!(sdName && fs.exists(sdName) && sdSrc === url)) {
        toast('Loading ' + os.sd + '…');
        let ok = false;
        try { const b = await fetchBytes(os.sd); if (UPD[model]) nedoNote(b, UPD[model]); ok = await sdFromBytes(os.sd.replace(/^.*\//, ''), b, true); if (ok) sdSrc = url; } catch (e) { toast(os.sd + ': ' + e.message, true); return; }
        if (!ok) return;
      }
      sdEnable(true);
      if (M() === 'TSCONF') { tsBootSd(); return; } // TS-BIOS: Caps Shift + Reset boots boot.$C of the SD card
      if (M() === 'GMX') { if (!await sdDisks(true)) toast(os.sd + ': no disk in its .json', true); return; } // OSZ: OS.TRD of the card's ZIP boots
      const k = Math.max(1, 2 / mclk());
      runMacro([{ reset: 0 }, { wait: Math.ceil(150 * k) }, { xtmode: 1 }, { xt: ['Digit5'] }]);
      return;
    }
    let hok = false;
    try { hok = await hddFromBytes(0, os.hdd.replace(/^.*\//, ''), await fetchBytes(os.hdd), true); if (hok) hddSrc[0] = os.hdd; } catch (e) { toast(os.hdd + ': ' + e.message, true); return; }
    if (!hok || !hdds[0]) return;
    if (!E.web_hdd_scheme(-1)) { E.web_hdd_scheme(1); hddMount(0); }
    hddUI();
    const w = (f1x) => Math.ceil(f1x / Math.max(1, mclk()));
    runMacro([{ reset: 0 }, { wait: w(100) }, { xtmode: 1 }, { xt: ['Space'] }, { wait: w(60) }, ...rep(2, { xt: ['ArrowDown'] }), { wait: 10 }, { xt: ['Enter'] }]);
  }
  const CPM_MODELS = ['ATM710', 'XBIOS136', 'EVO'];
  function cpmRun(v) {
    if (!CPM_MODELS.includes(M())) { toast('cpm=: CP/M needs atm710, xbios136 or evo', true); return; }
    const w = (f1x) => Math.ceil(f1x / Math.max(1, mclk()));
    const k = Math.max(1, 2 / mclk());
    // into CP/M in ATM mode (XT keyboard): ATM BIOS menu Enter; xBIOS XT setup Space, 3 × ↑ (Boot → CP/M 2.2), Enter;
    // EVO Reset Service R (Service), C (CP/M). Backspace drops a menu key that reached the command line
    const boot = {
      ATM710: [{ reset: 0 }, { wait: Math.max(100, w(250)) }, { xtmode: 1 }, { xt: ['Enter'] }],
      XBIOS136: [{ reset: 0 }, { wait: w(100) }, { xtmode: 1 }, { xt: ['Space'] }, { wait: w(60) }, ...rep(3, { xt: ['ArrowUp'] }), { wait: 10 }, { xt: ['Enter'] }, { wait: w(100) }, { xt: ['Backspace'] }],
      EVO: [{ reset: 3 }, { wait: Math.ceil(120 * k) }, { xtmode: 1 }, { xt: ['KeyR'] }, { wait: w(60) }, { xt: ['KeyC'] }, { wait: w(100) }, { xt: ['Backspace'] }],
    }[M()];
    const steps = [...boot, { prompt: true }];
    for (const c of cpmCommands(v)) steps.push(...xtType(c), { xt: ['Enter'] }, { wait: 20 }, { prompt: true });
    steps.pop(); // the last command runs: no prompt to wait for
    runMacro(steps); macro.pw = 0;
  }
  // REST API nedoos=: after NedoOS has booted (its file manager shows the "M:/bin>" command line), type the commands there
  // ("m:/nedogame/ufo2"; several with | or ; between them, each after the command line is back)
  function nedoPrompt() { // the command line of the NedoOS file manager: "X:/path>" alone on a row of the 80×25 text screen
    if ((E.web_ff77() & 7) !== 6) return null;
    const ram = new Uint8Array(E.memory.buffer, E.web_gfx_mem(1, 0, 0), E.web_gfx_size(1)), base = 5 * 0x4000;
    for (let r = 24; r >= 0; r--) {
      let t = ''; for (let c = 0; c < 80; c++) { const b = ram[base + (c & 1 ? 0x21C0 : 0x01C0) + r * 64 + (c >> 1)]; t += b >= 32 && b < 127 ? String.fromCharCode(b) : ' '; }
      t = t.trim(); if (/^[A-P]:\/[^>]*>$/.test(t)) return r + ':' + t;
    }
    return null;
  }
  function nedoosRun(v) {
    if (model !== 'NEDOOS') { toast('nedoos=: needs model nedoos', true); return; }
    const ready = (max, fail) => { let k = null, n = 0; return { until: () => { const p = nedoPrompt(); if (p && p === k) return ++n >= 25; k = p; n = 0; return false; }, max, fail }; }; // the same for half a second
    const steps = [ready(6000, 'NedoOS: no command line')]; // the card loads and NedoOS boots: up to 2 minutes
    const cmds = String(v).split(/[|;]/).map((c) => c.trim()).filter(Boolean); // typed as they are (m:/nedogame/ufo2 is one command)
    for (const c of cmds) steps.push(...xtType(c), { xt: ['Enter'] }, { wait: 20 }, ready(3000, 'NedoOS: no command line'));
    steps.pop(); // the last command runs: no command line to wait for
    if (macro) macro.steps.push(...steps); else { runMacro(steps); macro.pw = 0; } // after the boot of the card (Reset, 5), when it is still going
    toast('NedoOS: ' + cmds.join(' | '));
  }
  // ZX matrix keys for typed characters (press=): digits, letters, space; "enter" = ENTER
  const ZXM = {};
  ['CS', 'Z', 'X', 'C', 'V', 'A', 'S', 'D', 'F', 'G', 'Q', 'W', 'E', 'R', 'T', '1', '2', '3', '4', '5', '0', '9', '8', '7', '6', 'P', 'O', 'I', 'U', 'Y', 'ENT', 'L', 'K', 'J', 'H', 'SPC', 'SS', 'M', 'N', 'B']
    .forEach((n, i) => { ZXM[n] = Math.floor(i / 5) * 8 + (i % 5); });
  function zxPress(v) {
    if (/^enter$/i.test(v)) return [{ key: ZXM.ENT }];
    const out = [];
    for (const c of String(v)) {
      const u = c.toUpperCase();
      if (c === ' ') out.push({ key: ZXM.SPC });
      else if (ZXM[u] !== undefined && u.length === 1) out.push({ key: c !== u ? ZXM[u] : /[A-Z]/.test(u) ? [ZXM.CS, ZXM[u]] : ZXM[u] });
    }
    return out;
  }
  // Paste (Ctrl+Shift+V, Cmd+V): the text of the clipboard typed on the keyboard of the machine. ATM (XT) mode: XT keys,
  // capitals with Shift; else the ZX keys in L mode: letters (capitals with CAPS SHIFT), digits, the SYMBOL SHIFT
  // symbols; a new line = ENTER, then a pause (the BASIC editor checks the line). Characters that have no key are left out
  async function pasteClip() {
    let t = '';
    try { t = await navigator.clipboard.readText(); } catch (e) { toast('Paste: the browser gives no clipboard text (allow it, or use another browser)', true); return; }
    pasteText(t);
  }
  function pasteText(t) {
    t = String(t || '').replace(/\r\n?/g, '\n').replace(/\t/g, ' ').replace(/\n+$/, '\n'); // a text that ends with a new line: its last line is entered too
    if (!t.trim()) { toast('Paste: the clipboard has no text', true); return; }
    if (M() === 'SAM') { toast('Paste: not on the SAM Coupé', true); return; }
    if (t.length > 32768) t = t.slice(0, 32768);
    const xt = !!E.web_xt_kbd(), steps = []; let lost = 0;
    for (const [i, line] of t.split('\n').entries()) {
      if (i) steps.push(xt ? { xt: ['Enter'] } : { key: ZXM.ENT, hold: 3, gap: 3 }, { wait: 25 });
      for (const c of line) {
        let st = null;
        if (xt) { const k = xtType(c, true); st = k[0] || null; }
        else {
          const u = c.toUpperCase();
          const k = /^[a-z0-9]$/.test(c) ? ZXM[u] : /^[A-Z]$/.test(c) ? [ZXM.CS, ZXM[c]] : c === ' ' ? ZXM.SPC : c === '"' ? [ZXM.SS, ZXM.P] : ZX_SYM[c] ? [ZXM.SS, ZXM[ZX_SYM[c]]] : undefined;
          if (k !== undefined) st = { key: k, hold: 3, gap: 3 };
        }
        if (st) steps.push(st); else lost++;
      }
    }
    if (macro) { toast('Paste: wait, keys are being typed', true); return; }
    runMacro(steps); macro.pw = 0;
    toast('Paste: ' + t.length + ' characters' + (lost ? ', ' + lost + ' with no key left out' : '') + (xt ? ' (ATM mode)' : ''));
  }
  // autorun of a disk without its own boot: RUN "name" typed in TR-DOS (L mode: a-z plain, A-Z with CAPS SHIFT, symbols with
  // SYMBOL SHIFT); null when the name has a character that cannot be typed this way (then the boot of the emulator is used)
  const ZX_SYM = { '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '&': '6', "'": '7', '(': '8', ')': '9', '_': '0', '<': 'R', '>': 'T',
    ';': 'O', '=': 'L', '+': 'K', '-': 'J', '^': 'H', ':': 'Z', '?': 'C', '/': 'V', '*': 'B', ',': 'N', '.': 'M' };
  function zxRunKeys(name) {
    const out = [{ key: ZXM.R }, { key: [ZXM.SS, ZXM.P] }]; // RUN (keyword mode), "
    for (const c of name) {
      const u = c.toUpperCase();
      if (/^[a-z0-9]$/.test(c)) out.push({ key: ZXM[u] });
      else if (/^[A-Z]$/.test(c)) out.push({ key: [ZXM.CS, ZXM[c]] });
      else if (c === ' ') out.push({ key: ZXM.SPC });
      else if (ZX_SYM[c]) out.push({ key: [ZXM.SS, ZXM[ZX_SYM[c]]] });
      else return null;
    }
    out.push({ key: [ZXM.SS, ZXM.P] }, { key: ZXM.ENT });
    return out;
  }
  // a Profi CP/M disk (5 × 1024-byte sectors, CP/M directory in its first sector) in drive d
  function profiCpmDisk(d) {
    if (!E.web_disk_peek_isd) return false;
    setName('__plan.isd');
    let img = null; if (E.web_disk_peek_isd(d)) img = new Uint8Array(fs.read('__plan.isd'));
    try { fs.remove('__plan.isd'); } catch (e) {}
    const T = UnrealFC._test;
    return !!img && T.looksCpm(img.subarray(0, 2048)) && !T.looksIsdos(img);
  }
  // what autorun starts on the TR-DOS disk in drive d: { boot } its own boot, { run } its first BASIC program, { none }
  // neither (no BASIC / a name that cannot be typed); null: not a TR-DOS disk
  function diskRunPlan(d) {
    setName('__plan.trd');
    let img = null;
    if (E.web_disk_peek_trd(d)) img = new Uint8Array(fs.read('__plan.trd'));
    try { fs.remove('__plan.trd'); } catch (e) {}
    if (!img || img[0x8E7] !== 0x10) return null;
    const list = UnrealFC._test.trdos(img).list().filter((x) => x.zx.type === 'B');
    if (list.some((x) => x.name.trim() === 'boot')) return { boot: true };
    const first = list[0], name = first && first.name.replace(/ +$/, '');
    return name && zxRunKeys(name) ? { run: name } : { none: true }; // none: a TR-DOS disk with nothing to type
  }
  // REST API run=: a TR-DOS file is started through a small "boot" (RANDOMIZE USR 15619: REM: RUN "name"), then the usual autorun
  const zxNum = (n) => [...String(n)].map((c) => c.charCodeAt(0)).concat([0x0E, 0, 0, n & 255, (n >> 8) & 255, 0]);
  function zxLine(no, body) { const b = body.concat([0x0D]); return [no >> 8, no & 255, b.length & 255, b.length >> 8].concat(b); }
  function bootFor(name, type, start) {
    const str = (t) => [...t].map((c) => c.charCodeAt(0) & 255), q = 0x22, dos = [0xF9, 0xC0].concat(zxNum(15619), [0x3A, 0xEA, 0x3A]);
    let prog;
    if (type === 'B') prog = zxLine(10, dos.concat([0xF7, q], str(name), [q]));
    else {
      prog = [];
      if (start > 24000) prog = prog.concat(zxLine(5, [0xFD].concat(zxNum(start - 1))));           // CLEAR start-1
      prog = prog.concat(zxLine(10, dos.concat([0xEF, q], str(name), [q, 0xAF])));                   // LOAD "name"CODE
      prog = prog.concat(zxLine(20, [0xF9, 0xC0].concat(zxNum(start))));                             // RANDOMIZE USR start
    }
    const n = prog.length, data = new Uint8Array(prog.concat([0x80, 0xAA, type === 'B' ? 10 : (start > 24000 ? 5 : 10), 0]));
    return { name: 'boot', zx: { type: 'B', start: n, len: n }, data };
  }
  // our own small boot (see bootFor): "boot", BASIC, a few bytes, RANDOMIZE USR 15619: REM: ...
  function isInjectedBoot(img, e) {
    if (String.fromCharCode(...e.subarray(0, 8)) !== 'boot    ' || e[8] !== 0x42 || e[13] !== 1) return false;
    const off = (e[15] * 16 + e[14]) * 256, d = img.subarray(off, off + 256), sig = [0xF9, 0xC0, 0x31, 0x35, 0x36, 0x31, 0x39, 0x0E, 0, 0, 0x03, 0x3D, 0, 0x3A, 0xEA, 0x3A];
    for (let i = 0; i < 40; i++) if (sig.every((v, k) => d[i + k] === v)) return true;
    return false;
  }
  // run=: the disk gets a small "boot" (the disk's own boot is renamed boot_ for the time being); once the program
  // has loaded (the drive has been quiet for a while) the catalogue is written back as it was — boot_ is gone again
  let runRestore = null;
  function runInject(d, fname, type) {
    setName('__run.trd');
    if (!E.web_disk_peek_trd(d)) { toast('run=: drive ' + DRV[d] + ' is not a TR-DOS disk', true); return false; }
    const img = new Uint8Array(fs.read('__run.trd')); fs.remove('__run.trd');
    if (img[0x8E7] !== 0x10) { toast('run=: drive ' + DRV[d] + ' is not a TR-DOS disk', true); return false; }
    if (runRestore) restoreRun(); // an earlier run that has not been tidied up yet
    const ok = (x) => !type || x.zx.type === type;
    const find = (list) => list.find((x) => x.name.trim() === fname && ok(x)) || list.find((x) => x.name.trim().toLowerCase() === fname.toLowerCase() && ok(x));
    const T = UnrealFC._test;
    if (!find(T.trdos(img).list())) { toast('run=: "' + fname + '" is not on the disk in ' + DRV[d] + ':', true); return false; }
    // leftovers of older versions: an injected boot in the catalogue, the disk's boot kept as boot_
    let cnt = img[0x8E4];
    for (let i = 0; i < cnt; i++) {
      const e = img.subarray(i * 16, i * 16 + 16);
      if (e[0] < 2 || !isInjectedBoot(img, e)) continue;
      const end = e[15] * 16 + e[14] + e[13];
      if (end === img[0x8E2] * 16 + img[0x8E1]) {
        const free = img[0x8E5] + (img[0x8E6] << 8) + e[13];
        img[0x8E1] = e[14]; img[0x8E2] = e[15]; img[0x8E5] = free & 255; img[0x8E6] = free >> 8;
      }
      img.copyWithin(i * 16, (i + 1) * 16, cnt * 16); img.fill(0, (cnt - 1) * 16, cnt * 16);
      img[0x8E4] = --cnt; i--;
    }
    let list = T.trdos(img).list();
    const old = list.find((x) => x.name.trim() === 'boot_' && x.zx.type === 'B');
    if (old && !list.some((x) => x.name.trim() === 'boot' && x.zx.type === 'B')) img.set([...'boot    '].map((c) => c.charCodeAt(0)), old.id * 16);
    list = T.trdos(img).list();
    const it = find(list);
    if (it.zx.type !== 'B' && it.zx.type !== 'C') { toast('run=: "' + fname + '" is neither BASIC nor code', true); return false; }
    const was = !!E.web_disk_changed(d), clean = img.slice(0, 9 * 256); // the catalogue to write back
    const isBoot = it.name.trim() === 'boot' && it.zx.type === 'B';
    if (!isBoot) {
      for (const x of list) if (x.name.trim() === 'boot' && x.zx.type === 'B') img.set([...'boot_   '].map((c) => c.charCodeAt(0)), x.id * 16);
      T.trdos(img).write(bootFor(it.name.trim(), it.zx.type, it.zx.start));
      if (M() === 'EVO') { // the EVO boot menu starts the first BASIC file: our boot changes places with the first entry
        cnt = img[0x8E4]; const first = img.slice(0, 16);
        img.copyWithin(0, (cnt - 1) * 16, cnt * 16); img.set(first, (cnt - 1) * 16);
      }
    }
    const keep = drives[d], name = baseName(keep ? keep.name : 'disk') + '.trd';
    fs.write(name, img); insertFromFs(name, d, true); E.web_disk_mark(d, was ? 1 : 0);
    if (keep) drives[d].url = keep.url;
    runRestore = isBoot ? null : { d, data: clean, inj: img.slice(0, 9 * 256), was, disk: cstr(E.web_disk_name(d)), t: 0, seen: false, idle: 0 };
    return true;
  }
  function restoreRun() {
    const r = runRestore; runRestore = null;
    if (!r || !E.web_disk_present(r.d) || cstr(E.web_disk_name(r.d)) !== r.disk) return; // another disk by now
    // the program wrote to the catalogue (saved a file): it stays as it is (the next run= tidies the boot up)
    setName('__runc.trd'); const ok = E.web_disk_peek_trd(r.d), now = ok && fs.read('__runc.trd'); try { fs.remove('__runc.trd'); } catch (e) {}
    if (!now || now.length < r.inj.length || r.inj.some((x, i) => now[i] !== x)) return;
    const p = E.malloc(r.data.length);
    new Uint8Array(E.memory.buffer, p, r.data.length).set(r.data);
    E.web_disk_poke_trd(r.d, 0, 9, p);
    E.free(p);
    E.web_disk_mark(r.d, r.was ? 1 : 0);
  }
  function runRestoreFrame() { // after the start macro: activity on the drive, then 1.5 s of quiet (or 30 s anyway)
    const r = runRestore;
    if (!r) return;
    const k = new Uint8Array(E.memory.buffer, E.web_led(), 1)[0]; // 1 read, 2 / 3 write
    if (k >= 1 && k <= 3) { r.seen = true; r.idle = 0; } else r.idle++;
    if (macro) { r.idle = 0; return; }
    r.t++;
    if ((r.seen && r.idle > 75) || r.t > 1500) restoreRun();
  }
  // File Commander quick run (Enter / double click): o = { kind, src, name, ext, type }; dry = only check.
  // Returns an error text or '' (started).
  function fcRun(o, dry) {
    if (/^spg$/i.test(o.ext) && o.read) { // a TS-Conf program (any disk, SD, HDD): loaded and started (the model switches to TS-Conf)
      if (dry) return '';
      const data = o.read(); spgLoad(o.name + '.spg', data); return '';
    }
    if (/^(sna|z80|sp|tap|tzx|csw|rzx)$/i.test(o.ext) && o.read) { // a snapshot, a tape (e.g. made by Compile, sjasmplus) or an RZX (its player): loaded as from Load
      if (dry) return '';
      const f = o.read(); loadBytes(o.name + '.' + o.ext, f.data || f, -1); return '';
    }
    if (/^wmf$/i.test(o.ext) && o.read) { // a Wild Commander program: onto the SD card (from the card itself: run it there)
      if (/^SD/.test(o.src || '')) return 'Quick run: start it in Wild Commander (Enter on it)';
      if (dry) return '';
      const f = o.read(); wcWmf(o.name + '.wmf', f.data || f); return '';
    }
    if (o.kind === 'TR-DOS') {
      if (o.src !== 'A') return 'Quick run: TR-DOS boots from drive A: only';
      if (o.type !== 'B' && o.type !== 'C') return 'Quick run: only BASIC and code files can be started';
      if (dry) return '';
      if (!runInject(0, o.name, o.type)) return 'Quick run failed';
      autorun(); return '';
    }
    if (o.kind === 'CP/M' && o.profi) return 'Quick run: Profi CP/M disks (.PRO) can\'t be started from here';
    if (o.kind === 'CP/M') {
      if (!/^com$/i.test(o.ext)) return 'Quick run: only .COM files can be started';
      if (!CPM_MODELS.includes(M())) return 'Quick run: CP/M .COM file needs Turbo 2+ or ZX Evo BaseConf';
      // ATM CP/M: A: = RAM disk, B: = floppy A:, C: = HDD (ZX-Evolution: HDD is not seen this way)
      // partitioned HDD 0 (config in cylinder 0): D:, E:, … as the panel shows them
      const drv = M() === 'EVO' ? { A: 'b' }[o.src] : o.src === 'A' ? 'b' : /^H0/.test(o.src) ? o.drive : '';
      if (!drv) return M() === 'EVO' ? 'Quick run: ZX Evo BaseConf CP/M — floppy A: only (as B:)' : 'Quick run: CP/M sees only floppy A: (as B:) and HDD 0';
      if (dry) return '';
      cpmRun(drv + ':' + o.name); return '';
    }
    return 'Quick run: ' + o.kind + ' files can\'t be started from here';
  }
  // tapes: 128 menu "Tape Loader" (the ini has TapeAutoStart=1: the tape starts when the ROM reads it)
  // ROM disk: setup utility → Options → Virtual drive mode = ROM (drive A:), then Boot → vTR-dos cold (boot) or ZX-Spectrum menu
  const LEFT = [ZK.CS, ZK.K5], RIGHT = [ZK.CS, ZK.K8];
  function romDiskMacro(boot) {
    const w = (f1x) => Math.ceil(f1x / Math.max(1, mclk()));
    runMacro([{ reset: 0 }, { wait: w(100) }, { key: ZK.SPACE }, { wait: w(30) },
      { key: LEFT }, { key: DOWN }, { key: RIGHT }, ...rep(6, { key: DOWN }), { key: ZK.ENTER },
      { key: LEFT }, { key: UP }, { key: RIGHT }, ...rep(5, { key: UP }), ...rep(boot ? 3 : 4, { key: DOWN }), { key: ZK.ENTER }]);
  }
  async function loadRomDisk(name, buf, boot) {
    const ext = extOf(name);
    if (!(['trd', 'scl', 'fdi', 'udi', 'td0', 'isd', 'pro', 'dsk'].includes(ext))) { toast('ROM disk: choose a disk image (TRD, SCL, FDI, UDI, TD0…)', true); return; }
    // any disk format → TRD through the core: a short stay in drive D:
    if (E.web_disk_present(3)) { toast('ROM disk: drive D: is busy', true); return; }
    fs.write(name, buf); setName(name);
    let img = null;
    if (E.web_load(3)) { setName('__romdisk.trd'); if (E.web_disk_peek_trd(3)) { img = new Uint8Array(fs.read('__romdisk.trd')); fs.remove('__romdisk.trd'); } E.web_eject(3); }
    try { fs.remove(name); } catch (e) {}
    if (!img || img.length < 0x900 || img[0x8E7] !== 0x10) { toast('ROM disk: ' + name + ' is not a TR-DOS disk', true); return; }
    const rdModel = xbiosOf(model), xrom = MODELS[rdModel].ini.ROM.ATM2; // xBIOS 1.36XT
    await ensureFiles([xrom]);
    if (!fs.exists(xrom)) { toast('ROM disk: rom/' + xrom + ' not found', true); return; }
    const x = fs.read(xrom), rom = new Uint8Array(1 << 20).fill(0xFF);
    rom.fill(0, 0, ROMDISK_TRD); rom.set(img.subarray(0, ROMDISK_TRD), 0); rom.set(new Uint8Array(x), rom.length - x.byteLength);
    fs.write(ROMDISK_FILE, rom);
    romDisk = { name, model: rdModel };
    await setModel(rdModel, true);
    romDiskMacro(boot);
    toast('ROM disk: ' + name + (boot ? ' — autorun' : ''));
  }
  // xBIOS: Space opens the setup menu (cursor list, no wrap)
  const rep = (n, st) => Array.from({ length: n }, () => st);
  const LOAD_QQ = [{ key: ZK.L }, { key: ZK.O }, { key: ZK.A }, { key: ZK.D }, { key: [ZK.SS, ZK.P] }, { key: [ZK.SS, ZK.P] }, { key: ZK.ENTER }];
  function autorunTape() {
    const k = Math.max(1, 2 / mclk());
    const w = (f1x) => Math.ceil(f1x / Math.max(1, mclk()));
    if (M() === 'XBIOS136') // menu → ZX-Spectrum menu → 128 menu: 128 BASIC → LOAD ""
      runMacro([{ reset: 0 }, { wait: w(100) }, { key: ZK.SPACE }, { wait: w(30) },
        ...rep(5, { key: UP }), ...rep(4, { key: DOWN }), { key: ZK.ENTER },
        { wait: w(100) }, { key: DOWN }, { key: DOWN }, { key: ZK.ENTER }, { wait: w(60) }, ...LOAD_QQ]);
    else if (M() === 'EVO') // EVO Reset Service: T = Tape load
      runMacro([{ reset: 3 }, { wait: Math.ceil(120 * k) }, { key: ZK.T }]);
    else if (M() === 'TSCONF') // TS-BIOS: Reset to ROM #00, bank Basic 128 (NVRAM, for this reset only) → its menu: Tape Loader
      runMacro([...tsResetTo(2), { wait: w(80) }, { key: ZK.ENTER }]);
    else if (M() === 'ATM710' || M() === 'ATM450') // BIOS menu → SPECTRUM 128 → Tape Loader
      runMacro([{ reset: 0 }, { wait: w(100) }, { key: DOWN }, { key: DOWN }, { key: ZK.ENTER }, { wait: w(80) }, { key: ZK.ENTER }]);
    else // Pentagon: the 128 menu comes up with Tape Loader selected
      runMacro([{ reset: 0 }, { wait: w(80) }, { key: ZK.ENTER }]);
  }
  // plan { run: name }: the disk has no boot — RUN "name" instead of RUN (boot); menus that start boot by themselves
  // (xBIOS, Scorpion, Profi, Quorum) stop in TR-DOS with "No file", then RUN "name" is typed; the EVO boot menu runs the
  // first BASIC file by itself
  // F12 / Reset: the OSZ machine boots OSZ again (OS.TRD in A:, through the 128 menu: "128 TR-DOS"); the others: Reset
  async function userReset() {
    if (!await recGate()) return; // RZX recording: asked first
    if (rz) rzxClose(); // the recording does not go on after a reset
    if (model === 'OSZ' && E.web_disk_present(0)) { autorun(); return; }
    E.web_reset(0);
  }
  // GMX after a reset: the loader's blocks first (#7EFD D3 on), then flash block 4 — the 128 ROM (#7EFD = #C0, #40 with True clock: turbo off)
  function gmx128() { let ld = false; return () => { const v = E.web_gmx_state() & 0x7F; if (v & 8) ld = true; return ld && v === 0x40; }; }
  function autorun(plan) {
    // the clock the ROM runs at: True clock — the machine's own (3.5 MHz after a reset), else the CPU clock slider
    const clk = mclk();
    // the EVO service ROM needs CPU time: waits are longer at lower clock (tuned for 2x, doubled at 1x)
    const k = Math.max(1, 2 / clk);
    const w = (f1x) => Math.ceil(f1x / Math.max(1, clk)); // ROM boot waits, tuned at 1x (shorter at higher clock)
    // the menus are walked with ZX keys: ATM mode (XT keyboard) off meanwhile, back on at the end when it was on
    const xtWas = !!(E.web_xt_kbd && E.web_xt_kbd());
    // the 128 menu takes keys after it has run a while: 1 s at the usual clock (2.5x), longer at a lower one
    const m128 = (f) => Math.max(f, Math.ceil(f * 2.5 / clk));
    const run = plan && plan.run ? zxRunKeys(plan.run) : null;
    const R_ENTER = run || [{ key: ZK.R }, { key: ZK.ENTER }]; // RUN (boot) or RUN "name"
    const after = (wt) => (run ? [{ wait: wt }, ...run] : []); // after a menu that boots by itself
    // Custom ROM on Pentagon / KAY with a 128 ROM and TR-DOS in its set: through its 128 menu as the model does (128K mode);
    // other Custom ROMs: reset straight into TR-DOS
    const cm = model === 'CUSTOM' && MACHINES[customCfg.mach] && MACHINES[customCfg.mach].set && customCfg.slots['128'] && customCfg.slots.dos
      ? ({ PENT128: 'PENTAGON', PENT1024: 'PENTAGON', KAY: 'KAY' })[customCfg.mach] : null;
    if (M() === 'TSCONF') // TS-BIOS: Reset to ROM #00, bank TR-DOS (NVRAM, for this reset only) → RUN
      runMacro([...tsResetTo(0), { wait: w(160) }, ...R_ENTER]);
    else if (M() === 'XBIOS136') // setup utility: Boot → "TR-dos boot" (TR-DOS 5.04R runs boot from A:)
      runMacro([{ reset: 0 }, { wait: w(100) }, { key: ZK.SPACE }, { wait: w(30) }, ...rep(5, { key: UP }), { key: DOWN }, { key: ZK.ENTER }, ...after(w(150))]);
    else if (M() === 'EVO') // ZX-Evolution: EVO Reset Service, Z = TR-DOS boot, Enter = run the first program
      runMacro([{ reset: 3 }, { wait: Math.ceil(120 * k) }, { key: ZK.Z }, { wait: Math.ceil(150 * k) }, { key: ZK.ENTER }]); // its boot menu starts the first BASIC file by itself (no boot: the program)
    else if (M() === 'ATM710' || M() === 'ATM450') // ATM BIOS menu → SPECTRUM 128 → 128 menu: ↑ = TR-DOS (128K) → RUN
      runMacro([{ reset: 0 }, { wait: w(120) }, { key: DOWN }, { key: DOWN }, { key: ZK.ENTER }, { wait: m128(50) }, // the 128 menu counts frames (interrupts) before it takes keys
        { key: UP }, { key: ZK.ENTER }, { wait: w(120) }, ...R_ENTER]);
    else if (M() === 'QUORUM') // ROM-MENU: 3 = Boot DOS
      runMacro([{ reset: 0 }, { wait: w(100) }, { key: ZK.K3 }, ...after(w(150))]);
    else if (M() === 'PLUS3') // the +3 menu: Loader (first) loads "DISK" from A:, as the real machine does
      runMacro([{ reset: 0 }, { wait: m128(60) }, { key: ZK.ENTER }]);
    // Pentagon, Scorpion, KAY, Profi: through the reset menu into TR-DOS in 128K mode (128 BASIC set up, #7FFD paging works);
    // reset straight into TR-DOS gives 48K mode: programs then see "ZX 48K" (Quick Commander: no memory pages)
    else if (M() === 'PENTAGON' || cm === 'PENTAGON') // 128 menu: ↑ from Tape Loader = TR-DOS (a Custom ROM may reset elsewhere: 128 ROM)
      runMacro([{ reset: cm ? 2 : 0 }, { wait: m128(50) }, { key: UP }, { key: ZK.ENTER }, { wait: w(120) }, ...R_ENTER]);
    else if (M() === 'SCORPION' || M() === 'GMX') // reset to the 128 menu (not the service ROM): "128 TR-DOS" is its first item and runs boot by itself
      runMacro([{ reset: 2 }, ...(M() === 'GMX' && E.web_gmx_state ? [{ until: gmx128(), max: 1500, soft: true }] : []), // GMX: the loader, the monitor's test (and the SD card) first: until its flash block 4 runs the 128 ROM
        { wait: m128(70) }, { key: ZK.ENTER }, ...after(w(150))]); // its 128 ROM tests memory first: a bit longer
    else if (M() === 'KAY' || cm === 'KAY') // reset to the 128 menu (not the service menu): "TR-DOS" is its first item
      runMacro([{ reset: 2 }, { wait: m128(50) }, { key: ZK.ENTER }, { wait: w(120) }, ...R_ENTER]);
    else if (M() === 'PROFI' && profiCpmDisk(0)) // Profi CP/M disk (.PRO) in A:: main menu "CP/M system" → "from FDD"
      runMacro([{ reset: 0 }, { wait: Math.max(120, w(300)) }, { key: ZK.ENTER }, { wait: 25 }, { key: ZK.ENTER }]);
    else if (M() === 'PROFI') // main menu: "TR-DOS 128K" is two below CP/M; it runs boot by itself
      runMacro([{ reset: 0 }, { wait: Math.max(120, w(300)) }, { key: DOWN }, { wait: 20 }, { key: DOWN }, { wait: 20 }, { key: ZK.ENTER }, ...after(w(150))]);
    else // other machines (Custom ROM): reset straight into TR-DOS, R = RUN, Enter
      runMacro([{ reset: 1 }, { wait: w(160) }, ...R_ENTER]);
    if (macro && xtWas) { macro.steps.unshift({ xtmode: 0 }); macro.xtBack = true; } // keys added later (press=) still go as ZX keys
  }

  // ------------------------------------------------------------------ browser storage (IndexedDB): Save puts files there, Load lists them
  // meta: { name, kind (disk / hdd / sd / snap / tape / file), model, date, size }; data: the file (as Save would download it)
  let brwP = null;
  function brwDb() {
    if (!brwP) brwP = new Promise((res, rej) => {
      if (!window.indexedDB) { rej(new Error('this browser has no storage for pages')); return; }
      const r = indexedDB.open('unreal-saves', 1);
      r.onupgradeneeded = () => { r.result.createObjectStore('meta', { keyPath: 'name' }); r.result.createObjectStore('data'); };
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error || new Error('storage is not available'));
    }).catch((e) => { brwP = null; throw e; });
    return brwP;
  }
  const idbReq = (q) => new Promise((res, rej) => { q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
  const idbDone = (tx) => new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error || new Error('not saved (no room?)')); });
  // the storage cannot be opened (a private window, blocked site data, a full disk): said once, then it is just empty
  let brwErrSaid = false;
  async function brwList() { try { const d = await brwDb(); return await idbReq(d.transaction('meta').objectStore('meta').getAll()); }
    catch (e) { if (!brwErrSaid) { brwErrSaid = true; toast('Browser storage is not available: ' + (e && e.message || e), true); } return []; } }
  async function brwGet(name) { const d = await brwDb(); return idbReq(d.transaction('data').objectStore('data').get(name)); }
  // replaced: an old record of the same name in another case goes in the same transaction (both or neither)
  async function brwPut(meta, data, replaced) { const d = await brwDb(), tx = d.transaction(['meta', 'data'], 'readwrite');
    if (replaced && replaced !== meta.name) { tx.objectStore('meta').delete(replaced); tx.objectStore('data').delete(replaced); }
    tx.objectStore('meta').put(meta); tx.objectStore('data').put(data, meta.name); await idbDone(tx); }
  async function brwPutDir(meta) { const d = await brwDb(), tx = d.transaction('meta', 'readwrite'); tx.objectStore('meta').put(meta); await idbDone(tx); }
  async function brwDel(name) { const d = await brwDb(), tx = d.transaction(['meta', 'data'], 'readwrite'); tx.objectStore('meta').delete(name); tx.objectStore('data').delete(name); await idbDone(tx); }
  // File Commander drives of the page: Browser (the browser storage: read, write, delete) and Local server (the folder opened
  // in Load / Local server: read only). Their listings and files come in the background: list() starts the reading and the
  // panel is drawn again (redraw); prepare() fetches the files before File Commander reads them
  const splitName = (n) => { const d = n.lastIndexOf('.'); return d > 0 ? [n.slice(0, d), n.slice(d + 1)] : [n, '']; };
  // folders of the browser storage: a record { name: 'a/b', dir: true } (an empty folder too); a file in one: name 'a/b/x.trd'.
  // brwDir(metas, prefix) → what is right in the folder prefix ('' = the root, 'a/b/'): { dirs: [names], files: [metas] }
  const brwBase = (n) => n.slice(n.lastIndexOf('/') + 1);
  function brwDir(metas, prefix) {
    const dirs = new Map(), files = [], lp = prefix.toLowerCase();
    for (const m of metas) {
      if (!m.name.toLowerCase().startsWith(lp) || m.name.length === prefix.length) continue;
      const rest = m.name.slice(prefix.length), k = rest.indexOf('/');
      if (k >= 0) { const d = rest.slice(0, k); if (!dirs.has(d.toLowerCase())) dirs.set(d.toLowerCase(), d); } // a folder known by what is in it
      else if (m.dir) { if (!dirs.has(rest.toLowerCase())) dirs.set(rest.toLowerCase(), rest); }
      else files.push(m);
    }
    return { dirs: [...dirs.values()].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })), files };
  }
  function brwVolume() {
    const T = UnrealFC._test;
    let path = [];
    const pre = () => (path.length ? path.join('/') + '/' : '');
    const up = { id: null, up: true, dir: true, name: '..', ext: '', size: 0, show: '', sub: '' };
    // a database write: kept for flush(); the list read again once (a burst of writes: one refresh); a failed one: the
    // listing comes back from the database (the cache had it already)
    const pend = [];
    const track = (pr, what) => { pend.push(pr); pr.then(() => brwRefreshSoon(), (e) => { toast('Browser storage: ' + what + ': ' + e.message, true); brwRefreshSoon(); }); };
    const v = {
      kind: 'Browser', label: '',
      get path() { return '/' + path.join('/'); },
      setPath(ns) { // the folders that are there (the list not read yet: as asked)
        path = [];
        for (const n of ns || []) { if (brwCache && !brwDir(brwCache.metas, pre()).dirs.some((d) => d.toLowerCase() === String(n).toLowerCase())) break; path.push(n); }
        return path.slice();
      },
      enter(it) { if (it.up) path.pop(); else path.push(it.name); return path.slice(); },
      list() {
        if (!brwCache) {
          if (!v.pending) v.pending = brwList().then((m) => { brwCache = { metas: m, data: new Map() }; }, (e) => { brwCache = { metas: [], data: new Map() }; v.err = 'Browser: ' + e.message; })
            .finally(() => { v.pending = null; if (v.redraw) v.redraw(); });
          return path.length ? [up] : [];
        }
        const { dirs, files } = brwDir(brwCache.metas, pre());
        return (path.length ? [up] : []).concat(dirs.map((d) => ({ id: pre() + d, dir: true, name: d, ext: '', size: 0, show: '<DIR>', sub: '' })),
          files.map((m) => { const [n, x] = splitName(brwBase(m.name)); return { id: m.name, name: n, ext: x, size: m.size, show: m.size, sub: '' }; }));
      },
      mkdir(name0) {
        const name = (name0 || '').trim(); if (!name) throw new Error('no name');
        if (/[\/\\:*?"<>|]/.test(name) || name === '.' || name === '..') throw new Error('not a name for a folder');
        if (!brwCache) throw new Error('not read yet');
        const full = pre() + name, l = full.toLowerCase();
        if (brwCache.metas.some((m) => m.name.toLowerCase() === l || m.name.toLowerCase().startsWith(l + '/'))) throw new Error('exists');
        const meta = { name: full, dir: true, kind: 'dir', model, date: Date.now(), size: 0 };
        brwCache.metas.push(meta);
        track(brwPutDir(meta), full);
      },
      free() { return brwFree; },
      async prepare(items) { for (const it of items) if (brwCache && !it.dir && !brwCache.data.has(it.id)) { const d = await brwGet(it.id); if (!d) throw new Error(it.id + ' is not there any more'); brwCache.data.set(it.id, d); } },
      read(it) { if (it.dir) throw new Error('a directory'); const d = brwCache && brwCache.data.get(it.id); if (!d) throw new Error('not read yet'); const [n, x] = splitName(brwBase(it.id)); return { name: n, ext: x, data: d }; },
      // the database writes go on after write() / del() return: flush() waits for them (Move deletes its sources only then)
      async flush() { const ps = pend.splice(0); const r = await Promise.allSettled(ps); const bad = r.find((x) => x.status === 'rejected'); if (bad) throw bad.reason; },
      write(f0) { // a TR-DOS file comes as Hobeta (.$C), as FAT takes it
        const f = f0.zx ? (T.partExt(f0.zx) ? { name: f0.name.trim(), ext: T.partExt(f0.zx), data: f0.data.slice(0, f0.zx.len || f0.data.length) } : { name: f0.name.trim(), ext: '$' + f0.zx.type.toLowerCase(), data: T.hobetaMake(f0) }) : f0;
        const name = pre() + ((f.name || 'file').trim() + (f.ext && String(f.ext).trim() ? '.' + String(f.ext).trim() : '')).replace(/[\\/:*?"<>|]/g, '_');
        if (!brwCache) throw new Error('not read yet');
        if (brwCache.metas.some((m) => m.name.toLowerCase() === name.toLowerCase())) throw Object.assign(new Error('file exists'), { hit: v.list().find((x) => x.id && x.id.toLowerCase() === name.toLowerCase()) });
        const data = f.data.slice(), meta = { name, kind: brwKind(name, 'file:'), model: null, date: Date.now(), size: data.length };
        brwCache.metas.push(meta); brwCache.data.set(name, data);
        track(brwPut(meta, data), name);
      },
      del(it) { // a folder goes with all inside
        if (!brwCache || it.up) return;
        const l = it.id.toLowerCase(), gone = brwCache.metas.filter((m) => m.name.toLowerCase() === l || (it.dir && m.name.toLowerCase().startsWith(l + '/')));
        brwCache.metas = brwCache.metas.filter((m) => !gone.includes(m)); gone.forEach((m) => brwCache.data.delete(m.name));
        track(Promise.all(gone.map((m) => brwDel(m.name))), it.id);
      },
    };
    return v;
  }
  let brwSoonT = 0; const brwRefreshSoon = () => { clearTimeout(brwSoonT); brwSoonT = setTimeout(() => brwRefresh(), 120); };
  let brwFree = 0; // bytes the browser still gives (its estimate)
  const brwFreeUpd = () => { try { navigator.storage.estimate().then((e) => { brwFree = Math.max(0, (e.quota || 0) - (e.usage || 0)); }, () => {}); } catch (e) {} };
  const lsCache = new Map(); // a folder's URL → its items; a file's URL → its bytes
  function lsVolume() {
    const base = brBase; let path = [];
    for (const k of [...lsCache.keys()]) if (k.endsWith('/')) lsCache.delete(k); // the folders are read again (F2, a new panel)
    const dirUrl = () => base + path.map((n) => encodeURIComponent(n) + '/').join('');
    const up = { id: null, up: true, dir: true, name: '..', ext: '', size: 0, show: '', sub: '' };
    const v = {
      kind: 'HTTP', label: new URL(base).host,
      get path() { return '/' + path.join('/'); },
      setPath(ns) { path = (ns || []).slice(); return path.slice(); },
      enter(it) { if (it.up) path.pop(); else path.push(it.name); return path.slice(); },
      list() {
        const u = dirUrl(), c = lsCache.get(u), head = path.length ? [up] : [];
        if (!c) {
          if (!v.pending) v.pending = fetchFile(u).then((r) => r.text()).then((html) => {
            const { dirs, files } = lsParse(html, u, true);
            lsCache.set(u, dirs.map((d) => ({ id: d.href, dir: true, name: d.name, ext: '', size: 0, show: '<DIR>', sub: '' }))
              .concat(files.map((f) => { const [n, x] = splitName(f.name); return { id: f.href, name: n, ext: x, size: 0, show: '', sub: '' }; })));
          }, (e) => { v.err = 'Local server: ' + e.message; lsCache.set(u, []); }).finally(() => { v.pending = null; if (v.redraw) v.redraw(); });
          return head;
        }
        return head.concat(c);
      },
      async prepare(items) { for (const it of items) if (!lsCache.has(it.id)) lsCache.set(it.id, new Uint8Array(await (await fetchFile(it.id)).arrayBuffer())); },
      read(it) { const d = lsCache.get(it.id); if (!d) throw new Error('not read yet'); return { name: it.name, ext: it.ext, data: d }; },
    };
    return v;
  }
  // Load / Browser storage: its list (hidden when nothing is saved); FC's Browser panel reads it again
  let brwMetas = [], brwUI = () => {}, brwCache = null; // brwCache: File Commander's copy { metas, data }
  async function brwRefresh(pick) {
    brwMetas = (await brwList()).sort((a, b) => b.date - a.date); brwFreeUpd();
    if (brwCache) brwCache.metas = brwMetas.slice(); // File Commander's copy: the same list (the read files stay)
    $('ldbrwsec').hidden = !brwMetas.length;
    brwFill(pick);
  }
  // Load / Browser storage: the folder shown (its own, not File Commander's): '..' first, then the folders (▸ at the right:
  // a click opens it), then the files, newest first. A folder that is gone: the nearest one up that is there
  let brwPath = '';
  function brwFill(pick, nav) { // nav: a folder opened, no file chosen yet (a hidden placeholder, nothing highlighted)
    const sel = $('ldbrw'), was = pick || sel.value;
    const there = (pf) => brwMetas.some((m) => { const n = m.name.toLowerCase(); return n.startsWith(pf.toLowerCase()) || n === pf.slice(0, -1).toLowerCase(); });
    while (brwPath && !there(brwPath)) brwPath = brwPath.replace(/[^/]*\/$/, '');
    const { dirs, files } = brwDir(brwMetas, brwPath);
    sel.innerHTML = '';
    const add = (v, t, nav) => { const o = document.createElement('option'); o.value = v; o.textContent = t; if (nav) o.dataset.nav = nav; sel.appendChild(o); return o; };
    const f = files.find((m) => m.name === was) || null; // nothing chosen until a file is picked
    if (!f) { const o = add('', 'Select file'); o.disabled = o.hidden = true; }
    if (brwPath) add('\u0001..', '..', 'up').title = 'Up: /' + brwPath.replace(/[^/]*\/$/, '');
    for (const d of dirs) add('\u0002' + brwPath + d, d, 'dir');
    for (const m of files) add(m.name, brwBase(m.name));
    sel.value = f ? f.name : sel.options.length ? sel.options[0].value : '';
    $('ldbrwpath').textContent = brwPath ? '/' + brwPath.replace(/\/$/, '') : '';
    brwUI();
  }
  async function brwUsage() { try { const e = await navigator.storage.estimate(); return e && e.usage ? (e.usage / 1048576).toFixed(1) + ' MB used' + (e.quota ? ' of ' + Math.round(e.quota / 1048576) + ' MB' : '') : ''; } catch (e) { return ''; } }
  const brwKind = (name, t) => t.startsWith('disk:') ? 'disk' : t.startsWith('hdd:') ? 'hdd' : t === 'sd' ? 'sd' : t === 'sd2' ? 'mmc' : t === 'sna' ? 'snap'
    : /\.(tap|tzx|csw)$/i.test(name) ? 'tape' : /\.(sna|z80|sp|rzx)$/i.test(name) ? 'snap' : DISK_EXT.test(name) ? 'disk' : brwImgKind(name);
  // an HDD / SD image kept after it was loaded: what it went in as (the same name in a slot), else by its extension
  function brwImgKind(name) {
    const b = name.replace(/^.*[\\/]/, '').toLowerCase(), is = (n) => !!n && n.replace(/^.*[\\/]/, '').toLowerCase() === b;
    if (is(sdName)) return 'sd';
    if (is(sd2Name)) return 'mmc';
    if (is(hdds[0]) || is(hdds[1])) return 'hdd';
    return /\.(hdd|hdf)$/i.test(name) ? 'hdd' : /\.(vhd|sd)$/i.test(name) ? 'sd' : 'file';
  }

  // Load / Local file, Save to Browser Storage: the same data there already — only its date; other data — asked
  async function brwKeep(name, data) {
    name = name.replace(/^.*[\\/]/, '').replace(/[:]/g, '_');
    try {
      const old = (await brwList()).find((m) => m.name.toLowerCase() === name.toLowerCase());
      if (old && old.size === data.length) {
        const od = await brwGet(old.name);
        if (od && od.length === data.length && od.every((v, i) => v === data[i])) { await brwPut({ ...old, model: keepModel(old.name), date: Date.now() }, od); brwRefresh(old.name); return; }
      }
      if (await brwSave(name, data, brwKind(name, ''))) toast('Browser storage: ' + name);
    } catch (e) { toast('Browser storage: ' + e.message, true); }
  }
  async function brwSave(name, data, kind) {
    if (data instanceof Blob) data = new Uint8Array(await data.arrayBuffer()); else if (data instanceof ArrayBuffer) data = new Uint8Array(data); // a ZIP comes as a Blob
    const old = (await brwList()).find((m) => m.name.toLowerCase() === name.toLowerCase());
    if (old && !await askBox('Browser storage', name + ' is there already (' + new Date(old.date).toLocaleString() + '). Replace it?', 'Replace')) return false;
    try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (e) {}
    await brwPut({ name, kind, model: keepModel(name), date: Date.now(), size: data.length }, data, old && old.name);
    brwRefresh(name);
    return true;
  }
  // a saved file from Load: Run (on the machine it was saved on; started as Local file does with Autostart) or Mount
  let imgHint = null; // 'hdd' / 'sd': what a saved image is (no question)
  async function brwLoad(it, run) {
    const m = { ...it.brw }; let data;
    if (RZX_MODELS.has(m.model) && !/\.rzx$/i.test(m.name)) m.model = rzxBack || 'ATM710'; // kept by 1.17-1.19.0 after an RZX
    try { data = await brwGet(m.name); } catch (e) { ldMsg(e.message, true); return false; }
    if (!data) { ldMsg(m.name + ': not in the browser storage any more', true); brwRefresh(); return false; }
    if (run && MODELS[m.model] && m.model !== model && !['hdd', 'sd'].includes(m.kind)) {
      if (!await loseOk(['a', 'b', 'c', 'd'])) return false;
      loseAsked = true; await setModel(m.model, true); loseAsked = false;
      if (model !== m.model) return false;
    }
    autorunNext = runMode(run); tsNoAuto = !run; hdBoot = run; imgHint = ['hdd', 'sd', 'mmc'].includes(m.kind) ? m.kind : null;
    await loadBytes(m.name, data, 0);
    return true;
  }

  // ------------------------------------------------------------------ Load window: local server, local file, server list, URL
  const LOAD_EXT = /\.(zip|trd|scl|fdi|udi|td0|isd|pro|hob|dsk|mgt|sad|ipf|tap|tzx|csw|sna|z80|sp|spg|wmf|pal|rzx|\$.)$/i;
  const ldDrive = () => 0; // Load mounts disks into A: (B: and the ROM disk: Options / Disk)
  function ldMsg(t, err) { $('ldmsg').textContent = t || ''; $('ldmsg').classList.toggle('err', !!err); }
  function showLoad(drive) {
    ldMsg(''); ldStoreUI();
    fwinShow('loadwin', true);
  }
  // "//host/dir" and "host/dir" become http(s) URLs
  function normUrl(u, dir) {
    u = u.trim();
    if (!u) return '';
    if (u.startsWith('//')) u = (location.protocol === 'https:' ? 'https:' : 'http:') + u;
    else if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = 'http://' + u;
    if (dir && !u.endsWith('/')) u += '/';
    return u;
  }
  function urlName(u) {
    try { const p = new URL(u).pathname; return decodeURIComponent(p.slice(p.lastIndexOf('/') + 1)) || 'download'; } catch (e) { return 'download'; }
  }
  async function fetchFile(u) {
    // brw:NAME — a file of this browser's storage (Load / Browser storage; REST API links offer them): only in this browser
    if (/^brw:/i.test(u)) {
      let name = u.slice(4); try { name = decodeURIComponent(name); } catch (e) {}
      let d = null; try { d = await brwGet(name); } catch (e) {}
      if (!d) throw new Error('not in this browser\'s storage');
      return new Response(d);
    }
    let r;
    try { r = await fetch(u, { cache: 'no-cache' }); } catch (e) { throw new Error('cannot reach the server (network, CORS or https→http)'); }
    if (!r.ok) throw new Error(r.status === 404 ? 'not found (404)' : 'HTTP ' + r.status);
    return r;
  }
  async function loadUrl(u, drive, msg, auto) { // auto: the server list's "Autostart after load" (a disk boots, a TS-Conf card runs its program)
    const name = urlName(u);
    if (!LOAD_EXT.test(name) && !HDD_EXT.test(name)) { msg('Not a disk, tape, snapshot, HDD / SD image or ZIP: ' + name, true); return false; }
    msg('Loading ' + name + '…');
    try {
      const buf = new Uint8Array(await (await fetchFile(u)).arrayBuffer());
      autorunNext = auto || false; // true: boot or the first BASIC program; 'boot': boot or the boot.b menu (Local file / Local server)
      loadingUrl = u; try { await loadBytes(name, buf, drive); } finally { loadingUrl = null; }
      autorunNext = false;
      msg('');
      return true;
    } catch (err) { msg(name + ': ' + err.message, true); return false; }
  }
  // server lists: trd/trd.json (disks) and hdd/hdd.json (HDD images) — ["game.trd", ...] or [{ "name": "...", "url": "...", "tag": "..." }, ...];
  // a path is relative to its folder ("game.trd" = trd/game.trd); "trd/game.trd" (from the site root) is accepted too.
  // Folders on the site are lower case ("TRD/x.trd" → "trd/x.trd")
  const lowDir = (u) => /^[a-z][a-z0-9+.-]*:|^\/\//i.test(u) ? u : u.replace(/^(.*\/)/, (d) => d.toLowerCase());
  // trd.json entries may carry "run": a REST API link (?model=atm710&a=trd/x.zip&cpm=b:x&xt=1); the file it mounts is the
  // entry's file, so "url" is not needed; "tag": labels drawn after the name (ATM HDD PRO SD ZX OS TSC SPR, several with spaces; CPM, TRD, SPG of before read as ATM, ZX, TSC)
  const MOUNT_KEYS = ['a', 'hdd', 'hdd1', 'sd', 'mmc', 'b', 'tape', 'snap'];
  // one parameter into the link's keys: fdd=a:path / b:path (no drive: A:) → a / b; hdd0= → hdd (HDD 0), hdd1= → hdd1
  function linkPut(o, k, v) {
    k = k.toLowerCase();
    if (k === 'fdd') { const m = /^([ab]):(.*)$/i.exec(v); if (m) o[m[1].toLowerCase()] = m[2]; else o.a = v; return; } // the rest as is: a:/x is from the site root, like a=/x
    o[k === 'hdd0' ? 'hdd' : k] = v;
  }
  function linkParse(q) { const o = {}; for (const [k, v] of new URLSearchParams(String(q).replace(/^[^?]*\?/, ''))) linkPut(o, k, v); return o; }
  const TAGS = ['ATM', 'HDD', 'PRO', 'SD', 'MMC', 'ZX', 'OS', 'TSC', 'SPR', 'SAM', 'NEX'];
  const TAG_OLD = { CPM: 'ATM', 'CP/M': 'ATM', TRD: 'ZX', SPG: 'TSC' }; // the names of before (lists written for them)
  const tagList = (t) => String(t || '').split(/[\s,;]+/).filter(Boolean).map((x) => { x = x.toUpperCase(); return (TAG_OLD[x] || x).slice(0, 6); });
  // a file of a list's link with no folder (sd=osz.zip in sd/sd.json) is in the list's folder; with a folder (trd/x.zip): from the site root
  function listRel(run, dir) {
    if (!dir) return run;
    const q = new URLSearchParams(run.slice(1)); let ch = false;
    for (const [k, v] of [...q]) {
      if (!/^(a|b|c|d|fdd\d?|hdd\d?|sd|mmc|sd2|gotek|tape|snap)$/i.test(k)) continue;
      const dk = /^(fdd|gotek)/i.test(k), m = /^([a-d]:)?(.*)$/i.exec(v), drv = dk ? m[1] || '' : '', f = dk ? m[2] : v;
      if (!f || /[\\/]/.test(f) || /^[a-z]+:/i.test(f)) continue;
      q.set(k, drv + dir + f); ch = true;
    }
    return ch ? '?' + q.toString() : run;
  }
  async function fetchList(json) {
    let list = [];
    try {
      const r = await fetch(json, { cache: 'no-cache' });
      // lines that start with # are comments (not JSON: they go before the parse; a # inside a line stays as it is)
      if (r.ok) { const j = jsonC(await r.text()); list = Array.isArray(j) ? j : (j && Array.isArray(j.files) ? j.files : []); }
    } catch (e) {}
    const dir = json.replace(/[^/]*$/, ''), out = [];
    for (const it of list) {
      let url = typeof it === 'string' ? it : it && (it.url || it.file);
      let run = typeof it === 'object' && it && typeof it.run === 'string' && it.run.trim() ? it.run.trim().replace(/^[^?]*\?/, '?') : '';
      if (run) run = listRel(run, dir);
      const rp = run ? linkParse(run) : null;
      let fromLink = false;
      if (!url && rp) { // the file the link mounts (from the site root), or the image of its OS (model=nedoos / osz / tasis…)
        const os = OS_MODELS[linkModelKey(rp.model)];
        url = MOUNT_KEYS.map((k) => rp[k]).find(Boolean) || (os && (os.sd || os.hdd)) || ''; fromLink = !!url;
      }
      if (!url && !run) continue;
      if (!url) { // a link that only picks a model (an OS on its own HDD / SD card)
        const tags = typeof it === 'object' && it.tag ? String(it.tag) : '';
        out.push({ url: '', run, rp, tag: tags, tags: tagList(tags), cpm: /cp\/?m/i.test(tags), name: (typeof it === 'object' && it.name) || (rp.model || 'link') });
        continue;
      }
      if (fromLink && !/^[a-z][a-z0-9+.-]*:|^\/\//i.test(url) && !url.startsWith('/')) url = '/' + url.replace(/^\.\//, ''); // run link paths are from the site root
      url = lowDir(String(url).trim().replace(/^\.\//, ''));
      if (!/^[a-z][a-z0-9+.-]*:|^\/\//i.test(url)) url = url.replace(/%(?![0-9a-f]{2})/gi, '%25').replace(/#/g, '%23').replace(/\?/g, '%3F'); // a file name, not a URL: # ? % are part of it
      const base = url.toLowerCase().startsWith(dir) ? location.href : new URL(dir, location.href).href;
      const tag = typeof it === 'object' && it.tag ? String(it.tag) : '';
      const ub = fromLink && url.startsWith("/") && !url.startsWith("//") ? pageDir() + url.slice(1) : null; // a run link file: from the folder of index.html
      out.push({ url: ub ? new URL(ub).href : new URL(url, base).href, run, rp, tag, tags: tagList(tag), cpm: /cp\/?m/i.test(tag),
        name: (typeof it === 'object' && it.name) || (() => { const n = url.replace(/^.*\//, ''); try { return decodeURIComponent(n); } catch (e) { return n; } })() });
    }
    return out;
  }
  let hddList = [];
  // the "Select from server" lists show the server image that is mounted (default HDD, an OS, one chosen there); else the title
  function srvShow() {
    const abs = (u) => { try { return new URL(u, location.href).href; } catch (e) { return ''; } };
    const show = (sel, list, src, on) => { if (!sel) return; const i = on && src ? list.findIndex((x) => x.url === abs(src)) : -1; sel.value = i >= 0 ? String(i) : ''; };
    const hdOn = (d) => !!(hdds[d] && E && E.web_hdd_get(d, 5));
    for (let d = 0; d < NHDD; d++) { const g = $('hddgeo' + d); if (g) show(g.querySelector('.srv'), hddList, hddSrc[d], hdOn(d)); }
    const sdIn = !!(sdName && fs.exists(sdName));
    show($('sdgeo') && $('sdgeo').querySelector('.srv'), sdList, sdSrc, sdIn);
  }
  // Load window, Media: what is mounted now (a changed image with *), ⏏ as in Options / Disk; empty drives are not listed
  let tapeName = '', brwMnt = null, brwMntSeen = false; // brwMnt: the browser storage file mounted (Run / Mount); ejected: the list chooses none
  function ldStoreUI() {
    const box = $('ldmedia'); if (!box || !E) return;
    const rows = [];
    for (let i = 0; i < NDRIVES; i++) if (E.web_disk_present(i))
      rows.push([DRV[i] + ':', (drives[i] ? drives[i].name : cstr(E.web_disk_name(i)).replace(/^.*[\\/]/, '')) + (E.web_disk_changed(i) ? ' *' : ''), () => $('drv' + i).querySelector('.eject').click()]);
    if (romDisk && M() === 'XBIOS136') rows.push(['ROM', romDisk.name, () => $('romdiskdel').click()]);
    for (let d = 0; d < NHDD; d++) if (hdds[d] && E.web_hdd_get(d, 5)) rows.push(['HDD ' + d, hdds[d] + (hddDirty[d] ? ' *' : ''), () => $('hdd' + d).querySelector('.eject').click()]);
    if (sdName && fs.exists(sdName)) rows.push(['SD', sdName + (sdDirty && !sdWcOwn ? ' *' : '') + (sdOn() ? '' : ' (off)'), () => $('sdcard').querySelector('.eject').click(), !sdOn()]);
    if (usbName && fs.exists(usbName)) rows.push(['USB', usbName.slice(4) + (usbDirty ? ' *' : '') + (gkOn ? '' : ' (off)'), () => $('usbcard').querySelector('.eject').click(), !gkOn]);
    if (sd2Name && fs.exists(sd2Name)) rows.push(['MMC', sd2Name + (sd2Dirty ? ' *' : '') + (dmOn() ? '' : ' (off)'), () => $('sd2card').querySelector('.eject').click(), !dmOn()]);
    { // ZX ULAX: the dux loaded (⏏ removes it)
      if (dux) rows.push(['ULAX', dux.name + (dux.applied && ulaxActive ? '' : dux.applied ? ' (off)' : ' (not applied)'), duxRemove, !(dux.applied && ulaxActive)]); }
    if (tapeName && E.web_tape_list() >= 0) rows.push(['Tape', tapeName, E.web_tape_eject ? () => { E.web_tape_eject(); tapeName = ''; toast('Tape ejected'); } : null]);
    if (brwMnt) {
      const on = new Set(rows.map((r) => String(r[1]).replace(/ (\*|\(off\))$/g, '').toLowerCase()));
      if (on.has(brwMnt.replace(/^.*\//, '').toLowerCase())) brwMntSeen = true; // (mounted under another name, from a ZIP: not followed)
      else { if (brwMntSeen && $('ldbrw').value === brwMnt) brwFill('\u0000', 1); brwMnt = null; }
    }
    box.textContent = '';
    const add = (cls, t) => { const e = document.createElement('span'); e.className = cls; e.textContent = t; box.appendChild(e); return e; };
    $('ldmodel').textContent = MODELS[model].name; // in the line of the title
    if (!rows.length) add('mm', '— nothing mounted —');
    for (const [l, n, ej, off, act] of rows) {
      add('ml', l); add('mn' + (off ? ' off' : ''), n);
      const mb = add('mb', '');
      if (act) { const b = document.createElement('button'); b.className = 'ldej'; b.textContent = act[0]; b.onclick = async () => { await act[1](); ldStoreUI(); }; mb.appendChild(b); }
      if (ej) { const b = document.createElement('button'); b.className = 'ldej'; b.title = 'Eject'; b.textContent = '⏏'; b.onclick = async () => { await ej(); ldStoreUI(); }; mb.appendChild(b); }
    }
  }
  function bindLdStore() {
    $('lddisk').onclick = () => { showOptions(true); const t = document.querySelector('#options [data-tab="opt"]'); if (t) t.click(); };
  }

  async function loadHddList() {
    hddList = await fetchList('hdd/hdd.json');
    document.querySelectorAll('#hdds .srv').forEach((sel) => {
      sel.innerHTML = '<option value="" hidden disabled selected>Select from server</option>'; // the entries with an image (a link with no file is for the Server list only)
      hddList.forEach((it, i) => { if (!it.url) return; const o = document.createElement('option'); o.value = i; o.textContent = it.name; sel.appendChild(o); });
      sel.hidden = sel.options.length < 2;
    });
    srvShow();
  }
  // Server list: trd/trd.json, hdd/hdd.json, sd/sd.json one after another, each entry as written (no merging: an image or
  // an OS is written once, in its list; an entry may have "url" and "run" both). hdd.json / sd.json entries get the tag
  // HDD / SD when they have none and go to Options / Disk too (their "url", or the file of "run"). Tag buttons: one tag
  async function loadServerList() {
    const trd = await fetchList('trd/trd.json');
    const own = (list, kind, tag) => list.map((it) => Object.assign({}, it, { kind }, it.tag ? {} : { tag, tags: [tag] }));
    srvList = trd.map((it) => Object.assign({ kind: 'trd' }, it)).concat(own(hddList, 'hdd', 'HDD'), own(sdList, 'sd', 'SD'));

    const pop = $('ldpop'); pop.innerHTML = '';
    srvList.forEach((it, i) => {
      const d = document.createElement('div');
      d.className = 'dditem'; d.dataset.i = i;
      d.innerHTML = '<span class="ddname"></span>' + (it.tags && it.tags.length ? tagIcon(it) : '');
      d.firstChild.textContent = it.name;
      d.onmousedown = (e) => { e.preventDefault(); srvPick(i); ddOpen(false); };
      pop.appendChild(d);
    });
    const tags = [...new Set(srvList.flatMap((it) => it.tags || []))].sort((x, y) => (TAGS.indexOf(x) + 1 || 99) - (TAGS.indexOf(y) + 1 || 99) || x.localeCompare(y));
    const bar = $('ldtags'); bar.innerHTML = '';
    for (const t of tags.length > 1 ? ['All', ...tags] : []) {
      const b = document.createElement('button'); b.textContent = t; b.dataset.t = t === 'All' ? '' : t;
      b.onclick = () => { // several tags at once (an entry with any of them); All: every entry
        const set = new Set(ldTags()), t = b.dataset.t;
        if (!t) set.clear(); else if (set.has(t)) set.delete(t); else set.add(t);
        store('ld.tags', [...set].join(' ')); srvFilter();
      };
      bar.appendChild(b);
    }
    $('ldlistsec').hidden = !srvList.length;
    srvFilter();
  }
  const ldTags = () => (load('ld.tags') || '').split(' ').filter(Boolean);
  const srvShown = (it) => { const ts = ldTags(); return !ts.length || ts.some((t) => (it.tags || []).includes(t)); };
  function srvFilter() {
    const ts = ldTags().filter((t) => srvList.some((it) => (it.tags || []).includes(t)));
    store('ld.tags', ts.join(' '));
    $('ldtags').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.t ? ts.includes(b.dataset.t) : !ts.length));
    $('ldpop').querySelectorAll('.dditem').forEach((d) => { d.hidden = !srvShown(srvList[+d.dataset.i]); });
    srvPick(srvSel >= 0 && srvShown(srvList[srvSel]) ? srvSel : -1);
  }
  const srvStep = (from, dir) => { for (let i = from + dir; i >= 0 && i < srvList.length; i += dir) if (srvShown(srvList[i])) return i; return from; };
  // the tag of a list entry is drawn on the right as a small framed label (CP/M images: ATM)
  function tagIcon(it) {
    return (it.tags || []).map((t) => { t = t.replace(/[<>&"]/g, ''); return `<span class="tagic txt${TAGS.includes(t) ? ' tag-' + t.toLowerCase() : ''}" title="${t}">${t}</span>`; }).join('');
  }
  let srvList = [], srvSel = -1;
  function srvPick(i) {
    if (!srvList.length) return;
    const cur = $('ldlist').querySelector('.ddcur');
    if (i < 0) { // nothing chosen yet
      srvSel = -1; cur.innerHTML = '<span class="ddname ddph">Select from server</span>';
      $('ldpop').querySelectorAll('.dditem').forEach((d) => d.classList.remove('on')); runRowUI(); return;
    }
    srvSel = Math.max(0, Math.min(srvList.length - 1, i));
    const it = srvList[srvSel];
    cur.innerHTML = '<span class="ddname"></span>' + (it.tag ? tagIcon(it) : '');
    cur.firstChild.textContent = it.name;
    $('ldpop').querySelectorAll('.dditem').forEach((d) => d.classList.toggle('on', +d.dataset.i === srvSel));
    runRowUI();
  }
  const linkModelKey = (v) => { if (!v) return null; const k = v.toLowerCase().replace(/[\s_-]/g, ''); return MODEL_ALIASES[k] || Object.keys(MODELS).find((x) => x.toLowerCase() === k) || null; };
  // Run: only for an entry with a link (its machine and autostart); Mount: any entry
  let goMode = 'mount', goFor = null; // the action of the Run / Mount button for the chosen entry
  function runRowUI() {
    const it = srvList[srvSel], m = it && it.run ? linkModelKey(it.rp.model) : null;
    if (it !== goFor) { goFor = it; goMode = it && it.run ? 'run' : 'mount'; } // another entry: Run when it has a link
    const run = goMode === 'run', b = $('ldlistgo');
    b.textContent = run ? 'Run' : 'Mount'; b.classList.toggle('primary', run); b.disabled = !it;
    b.title = run ? 'Start the entry' + (m ? ' on ' + MODELS[m].name : '') + ' as the server has it' : 'Mount the entry: the machine stays';
    $('ldlistmore').hidden = !(it && it.run); $('ldlistmore').classList.toggle('primary', run); $('ldgo').classList.toggle('single', $('ldlistmore').hidden); // single: Mount alone, a plain button // an entry with a link: ▾ chooses Run or Mount
  }
  // before Run: what the entry replaces (the disks when the machine changes, its HDD / SD card, an OS's own image) — asked
  // only when unsaved changes would be lost
  async function runAsk(it) {
    const p = it.rp || {}, want = linkModelKey(p.model), os = want && OS_MODELS[want];
    const change = !!(want && (want !== model || os)), keys = [];
    if (change) keys.push('a', 'b', 'c', 'd'); else { if (p.a) keys.push('a'); if (p.b) keys.push('b'); }
    if (p.hdd || (os && os.hdd)) keys.push('hdd0');
    if (p.hdd1) keys.push('hdd1');
    if (p.sd || (os && os.sd) || (want === 'TSCONF' && (change || p.a))) keys.push('sd');
    const l = loseList(keys);
    if (!l.length) return true;
    return askBox('Run: ' + it.name, (change ? 'Machine: ' + MODELS[model].name + ' → ' + MODELS[want].name + '\n' : '') + 'Unsaved changes will be lost:\n' + l.join('\n'), 'Run');
  }
  // Mount of an hdd.json / sd.json entry: into HDD 0 / the SD card, the machine stays
  async function mountSrv(it) {
    ldMsg('Loading ' + it.name + '…');
    try {
      const b = await fetchBytes(it.url), n = it.url.replace(/^.*\//, '');
      if (it.kind === 'hdd') { if (!await hddFromBytes(0, n, b)) return false; hddSrc[0] = it.url; }
      else if ((it.tags || []).includes('MMC')) { if (!await mmcPut(n, b, false)) return false; sd2Src = it.url; }
      else { if (!await sdFromBytes(n, b)) return false; sdSrc = it.url; sdEnable(); if (M() === 'NEXT') nxCardMounted(); }
      ldMsg(''); srvShow(); return true;
    } catch (err) { ldMsg(err.message, true); return false; }
  }
  // start a REST API link on this page (the model is switched when it is another one), or mount its files only
  async function runLink(q, mk, mountOnly) {
    const p = linkParse(q);
    if (mountOnly) { // Autostart off: only the files go in, the machine stays (an OS entry: its HDD / SD card image)
      const os = OS_MODELS[linkModelKey(p.model)];
      for (const k of Object.keys(p)) if (!MOUNT_KEYS.includes(k)) delete p[k];
      if (os && !p.hdd && !p.sd) { if (os.sd) p.sd = os.sd; else if (os.hdd) p.hdd = os.hdd; }
      // HDD / SD card as in Load / Options: no interface switching, no reset
      const hddPut = (d) => async (n, b, u) => { cpmDirNoReset = true; let ok; try { ok = await hddFromBytes(d, n, b); } finally { cpmDirNoReset = false; } if (ok) hddSrc[d] = u; hddUI(); };
      for (const [k, put] of [['hdd', hddPut(0)], ['hdd1', hddPut(1)], ['mmc', async (n, b, u) => { if (await sd2FromBytes(n, b)) sd2Src = u; }], ['sd', async (n, b, u) => {
        if (!await sdFromBytes(n, b)) return;
        if (sdRun && !isTS() && !(sdCfg && sdCfg.model && sdCfg.model !== 'TSCONF')) { await setModel('TSCONF', true); if (!isTS() || !await sdFromBytes(n, b)) return; } // a TS-Conf card with its program (.json): on TS-Conf
        sdSrc = u; sdUI(); if (isTS() && sdName && sdRun) tsBootSd(); if (M() === 'NEXT' && sdName) nxCardMounted(); }]]) { // Autostart off: Wild Commander starts, the card's program does not
        if (!p[k]) continue;
        const url = new URL(lowDir(p[k]), location.href).href, name = urlName(url); delete p[k];
        ldMsg('Loading ' + name + '…');
        try { await put(name, new Uint8Array(await (await fetchFile(url)).arrayBuffer()), url); ldMsg(''); toast((k === 'sd' ? 'SD card: ' : k === 'mmc' ? 'MMC: ' : k === 'hdd1' ? 'HDD 1: ' : 'HDD 0: ') + name); }
        catch (err) { ldMsg(name + ': ' + err.message, true); return false; }
      }
      if (!Object.keys(p).length) { srvShow(); return true; }
    }
    else if (mk) p.model = LINK_NAME[mk] || mk;
    if (!mountOnly && p.cpm) p.xt = '1'; // CP/M programs: ATM mode (XT keyboard) always on
    if (!Object.keys(p).length) { ldMsg('Nothing to mount in this entry', true); return false; }
    const want = mountOnly ? null : linkModelKey(p.model);
    if (!mountOnly) tcFromLink(p);
    LINK = p;
    try {
      if (want && (want !== model || OS_MODELS[want] || (want === 'PENTAGON' && PENT_RAMS.includes(+p.ram) && +p.ram !== pentRun))) await setModel(want, true);
      if (!mountOnly && E) trueClkApply(); // trueclock= / speed= of the entry
      tsNoAuto = !!mountOnly; // Autostart off: a TS-Conf card (in fdd=, sd=…) starts Wild Commander only, not its program
      await linkApply();
    } finally { LINK = {}; tsNoAuto = false; }
    return true;
  }
  function ddOpen(v) {
    const pop = $('ldpop');
    pop.hidden = !v; $('ldlist').classList.toggle('open', v);
    if (v) { // fixed position, inside the visible screen and the Load window (as the other lists, usel.js)
      const r = $('ldlist').getBoundingClientRect(), vv = window.visualViewport, wr = $('loadwin').getBoundingClientRect();
      let lo = Math.max(4, vv ? vv.offsetTop + 4 : 4), hi = Math.min(window.innerHeight, vv ? vv.height + vv.offsetTop : 1e9) - 4;
      hi = Math.min(hi, wr.bottom - 4); lo = Math.max(lo, wr.top + 4); // never out of the Load window (a small one: the list scrolls)
      pop.style.left = r.left + 'px'; pop.style.width = r.width + 'px'; pop.style.maxHeight = ''; pop.style.bottom = '';
      const below = hi - r.bottom - 2, above = r.top - 2 - lo, want = Math.min(pop.scrollHeight, 320);
      if (below >= Math.min(want, 120) || below >= above) { pop.style.top = (r.bottom + 2) + 'px'; pop.style.maxHeight = Math.max(60, below) + 'px'; }
      else { pop.style.top = Math.max(lo, r.top - 2 - Math.min(pop.scrollHeight, above)) + 'px'; pop.style.maxHeight = Math.max(60, above) + 'px'; }
      const on = pop.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' });
    }
  }
  // local server: browse an HTTP directory listing (Apache / nginx / IIS autoindex, python -m http.server …)
  let brBase = '', brCur = '';
  function brStat(t, err) { $('brstat').textContent = t || ''; $('brstat').classList.toggle('err', !!err); }
  async function brOpen(u) {
    const from = brCur; brCur = u; // back up a level: the cursor on the folder we came from
    const pu = new URL(u); $('brpath').textContent = decodeURIComponent(pu.pathname); $('brpath').title = decodeURI(u);
    const list = $('brlist'); list.innerHTML = '';
    brStat('Reading…');
    let html;
    try { html = await (await fetchFile(u)).text(); }
    catch (err) { if (brCur === u) { brStat(err.message, true); addUp(); } return; }
    if (brCur !== u) return; // another folder was opened meanwhile: its listing, not this one
    const { dirs, files } = lsParse(html, u);
    const cmp = (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
    dirs.sort(cmp); files.sort(cmp);
    addUp();
    for (const d of dirs) addItem('dir', d.name + '/', () => brOpen(d.href)).dataset.href = d.href;
    for (const f of files) addItem('file', f.name, async () => {
      await withLocal(async () => { if (await loadUrl(f.href, 0, brStat, ldMode())) brStat('Loaded: ' + f.name); }); // as Local file
    });
    brStat(dirs.length + files.length ? `${dirs.length} folders, ${files.length} files` : 'No folders or loadable files here');
    const back = [...list.querySelectorAll('button.dir')].find((b) => b.dataset.href === from), first = back || list.querySelector('button');
    if (first) { first.focus(); first.scrollIntoView({ block: 'nearest' }); }
  }
  // a folder listing of a web server (Apache / nginx / IIS autoindex, python http.server, ldserver.py): its folders and the
  // files Load takes (only what is inside this folder)
  function lsParse(html, u, all) { // all: every file (File Commander), not only what Load takes
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const here = new URL(u), seen = new Set(), dirs = [], files = [];
    for (const a of doc.querySelectorAll('a[href]')) {
      const raw = a.getAttribute('href');
      if (!raw || raw.startsWith('?') || raw.startsWith('#') || /^(mailto|javascript):/i.test(raw)) continue;
      let t; try { t = new URL(raw, here); } catch (e) { continue; }
      if (t.origin !== here.origin || !t.pathname.startsWith(here.pathname) || t.pathname === here.pathname) continue; // only what is inside this folder
      const rest = decodeURIComponent(t.pathname.slice(here.pathname.length));
      const isDir = rest.endsWith('/');
      const name = isDir ? rest.slice(0, -1) : rest;
      if (!name || name.includes('/') || seen.has(t.href)) continue;
      seen.add(t.href);
      if (isDir) dirs.push({ name, href: t.href });
      else if (all || LOAD_EXT.test(name) || HDD_EXT.test(name)) files.push({ name, href: t.href }); // HDD / SD images too (as Local file)
    }
    return { dirs, files };
  }

  function addItem(cls, text, fn) {
    const b = document.createElement('button');
    b.className = cls;
    b.innerHTML = '<span class="ic">' + (cls === 'dir' ? '▸' : cls === 'up' ? '↰' : '·') + '</span><span></span>';
    b.lastChild.textContent = text;
    b.onclick = fn;
    $('brlist').appendChild(b);
    return b;
  }
  function addUp() {
    const here = new URL(brCur);
    if (here.pathname === '/' ) return;
    const up = new URL('..', here).href;
    addItem('up', '..', () => brOpen(up));
  }
  function bindLoad() {
    const saved = load('ldsrv'); if (saved) $('ldsrv').value = saved;
    $('ldfile').onclick = () => { pendingDrive = ldDrive(); fromLoadWin = true; $('file').click(); };
    // Local file: Autostart (on by default); a disk without boot: the boot.b menu (default) or its first BASIC program;
    // Boot from HDD / SD (on). The settings of before (ld.start: boot / auto / none) carried over once
    const ls = load('ld.start');
    if (load('ld.auto') === null && ls !== null) { store('ld.auto', ls === 'none' ? '0' : '1'); if (ls === 'auto') store('ld.nb', 'basic'); }
    $('ldauto').checked = load('ld.auto') !== '0';
    $('ldkeep').checked = load('ld.keep') !== '0'; $('ldkeep').onchange = () => store('ld.keep', $('ldkeep').checked ? '1' : '0');
    $(load('ld.nb') === 'basic' ? 'ldbasic' : 'ldboot').checked = true;
    $('ldhdboot').checked = load('ld.hdboot') !== '0';
    const ldOptUI = () => {
      $('ldsub').hidden = !ldAuto(); // its choices only while Autostart is on
      $('ldpressrow').hidden = !$('ldboot').checked;
    };
    $('ldauto').onchange = () => { store('ld.auto', ldAuto() ? '1' : '0'); ldOptUI(); };
    $('ldboot').onchange = $('ldbasic').onchange = () => { store('ld.nb', $('ldbasic').checked ? 'basic' : 'boot'); ldOptUI(); };
    $('ldhdboot').onchange = () => store('ld.hdboot', $('ldhdboot').checked ? '1' : '0');
    ldOptUI();
    if (load('ldpress') !== null) $('ldpress').value = load('ldpress');
    $('ldpress').addEventListener('input', () => store('ldpress', $('ldpress').value));
    $('ldsrvgo').onclick = () => {
      const u = normUrl($('ldsrv').value, true);
      if (!u) { ldMsg('Enter the server folder, e.g. //192.168.1.1/trd/', true); return; }
      store('ldsrv', $('ldsrv').value.trim());
      ldMsg('');
      brBase = u; $('brtitle').textContent = new URL(u).host;
      fwinShow('browsewin', true);
      if (!fwins.browsewin.moved) { // first time: next to the Load window
        const r = $('loadwin').getBoundingClientRect();
        const bw = $('browsewin'), vw = document.documentElement.clientWidth, sp = snapRight(r, bw);
        sp.x = Math.max(4, Math.min(sp.x, vw - bw.offsetWidth - 4)); // no room on either side: overlap, but stay on screen
        fwins.browsewin.setPos(sp); fwins.browsewin.moved = true;
      }
      brOpen(u);
    };
    $('ldsrv').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('ldsrvgo').click(); });
    // the Local server window: ↑ ↓ Home End PgUp PgDn move, Enter opens / loads, Backspace goes up
    $('brlist').addEventListener('keydown', (e) => {
      const bs = [...$('brlist').querySelectorAll('button')]; if (!bs.length) return;
      const k = bs.indexOf(document.activeElement), go = (n) => { const b = bs[Math.max(0, Math.min(bs.length - 1, n))]; b.focus(); b.scrollIntoView({ block: 'nearest' }); };
      if (e.key === 'ArrowDown') go(k + 1); else if (e.key === 'ArrowUp') go(k < 0 ? 0 : k - 1);
      else if (e.key === 'Home') go(0); else if (e.key === 'End') go(bs.length - 1);
      else if (e.key === 'PageDown') go(k + 10); else if (e.key === 'PageUp') go(k - 10);
      else if (e.key === 'Backspace') { const up = $('brlist').querySelector('button.up'); if (up) up.click(); }
      else return;
      e.preventDefault(); e.stopPropagation();
    });
    // Run: the entry as the server has it (its link: machine, media, autostart); Mount: its files only, the machine stays
    const srvRun = async () => {
      const it = srvList[srvSel]; if (!it || !it.run) return;
      ddOpen(false);
      if (!await runAsk(it)) return;
      if (await loadLocked(() => { loseAsked = true; return runLink(it.run); })) fwinShow('loadwin', false);
    };
    const srvMount = async () => {
      const it = srvList[srvSel]; if (!it) return;
      ddOpen(false);
      const ok = await loadLocked(() => it.run ? runLink(it.run, null, true) : it.kind === 'hdd' || it.kind === 'sd' ? mountSrv(it)
        : (tsNoAuto = true, loadUrl(it.url, 0, ldMsg, false))); // a disk is only inserted, a TS-Conf card boots Wild Commander
      if (ok) { ldStoreUI(); ldMsg('Mounted: ' + it.name); } // Mount: Load stays open (Media shows it)
    };
    $('ldlistgo').onclick = () => (goMode === 'run' && srvList[srvSel] && srvList[srvSel].run ? srvRun() : srvMount());
    // ▾: Run or Mount (a compact list, as the menus of File Commander)
    let goPop = null;
    const goClose = () => { if (goPop) { goPop.more.classList.remove('open'); goPop.remove(); goPop = null; } };
    // ▾ of a split button (Server list, Browser storage): its actions; the choice is put on the button, the button does it
    const goMenu = (more, anchor, opts, cur, pick) => {
      if (goPop) { const was = goPop.more; goClose(); if (was === more) return; }
      ddOpen(false);
      const p = document.createElement('div'); p.className = 'usel-pop fcmpop'; p.more = more;
      for (const [t, v] of opts) {
        const it = document.createElement('div'); it.className = 'usel-it' + (cur === v ? ' on' : ''); it.textContent = t;
        it.onclick = (ev) => { ev.stopPropagation(); goClose(); pick(v); };
        p.appendChild(it);
      }
      document.body.appendChild(p); goPop = p; more.classList.add('open');
      const r = anchor.getBoundingClientRect(), w = p.offsetWidth;
      const wr = $('loadwin').getBoundingClientRect(), h = p.offsetHeight, lo = Math.max(4, wr.top + 4), hi = Math.min(window.innerHeight, wr.bottom) - 4; // inside the Load window
      p.style.left = Math.max(wr.left + 4, Math.min(r.right - w, wr.right - 4 - w)) + 'px';
      if (r.bottom + 2 + h <= hi || hi - r.bottom >= r.top - lo) { p.style.top = (r.bottom + 2) + 'px'; p.style.maxHeight = Math.max(40, hi - r.bottom - 2) + 'px'; }
      else { p.style.top = Math.max(lo, r.top - 2 - h) + 'px'; p.style.maxHeight = Math.max(40, r.top - 2 - lo) + 'px'; }
    };
    $('ldlistmore').onclick = (e) => { e.stopPropagation(); goMenu($('ldlistmore'), $('ldgo'), [['Run', 'run'], ['Mount', 'mount']], goMode, (v) => { goMode = v; runRowUI(); $('ldlistgo').focus(); }); };
    // Browser storage: the files Save put there; Run (on the machine it was saved on, with Autostart), Mount, Delete
    const bSel = () => brwMetas.find((m) => m.name === $('ldbrw').value) || null;
    const bUI = () => {
      const m = bSel(), b = $('ldbgo1');
      if (m !== bFor) { bFor = m; bMode = m && !['hdd', 'sd'].includes(m.kind) ? 'run' : 'mount'; }
      const shown = m ? bMode : 'mount'; // no file chosen: Mount, plain (one color with ▾)
      b.textContent = shown === 'run' ? 'Run' : shown === 'delete' ? 'Delete' : 'Mount';
      b.classList.toggle('primary', shown === 'run'); b.classList.toggle('danger', shown === 'delete'); b.disabled = !m;
      $('ldbmore').disabled = !m; $('ldbmore').classList.toggle('primary', shown === 'run'); $('ldbmore').classList.toggle('danger', shown === 'delete');
      b.title = !m ? '' : bMode === 'run' ? 'Load it with Autostart, on ' + (MODELS[m.model] ? MODELS[m.model].name : 'this machine') : bMode === 'delete' ? 'Delete it from the browser storage' : 'Load it: the machine stays';
      $('ldbrw').title = m ? 'Saved ' + new Date(m.date).toLocaleString() + ' · ' + (MODELS[m.model] ? MODELS[m.model].name : 'any machine') + ' · ' + (m.size >= 10240 ? Math.round(m.size / 1024) + ' KB' : m.size + ' bytes') : '';
    };
    let bMode = 'run', bFor = null;
    brwUI = bUI;
    $('ldbrw').onchange = () => { // a folder or '..': opened (the list stays open, usel.js: data-nav)
      const v = $('ldbrw').value;
      if (v.startsWith('\u0001')) { brwPath = brwPath.replace(/[^/]*\/$/, ''); brwFill('', 1); return; }
      if (v.startsWith('\u0002')) { brwPath = v.slice(1) + '/'; brwFill('', 1); return; }
      bUI();
    };
    $('ldbdelall').onclick = async () => {
      if (!brwMetas.length || !await askBox('', 'Clean Browser Storage?', 'Clean')) return;
      try { for (const m of brwMetas.slice()) await brwDel(m.name); ldMsg('Browser storage cleaned'); } catch (e) { ldMsg(e.message, true); }
      bFor = null; brwCache = null; await brwRefresh();
    };
    $('ldbmore').onclick = (e) => { e.stopPropagation(); goMenu($('ldbmore'), $('ldbgo'), [['Run', 'run'], ['Mount', 'mount'], ['Delete', 'delete']], bMode, (v) => { bMode = v; bUI(); $('ldbgo1').focus(); }); };
    $('ldbgo1').onclick = async () => {
      const m = bSel(); if (!m) return;
      if (bMode === 'delete') {
        if (!await askBox('Browser storage', 'Delete ' + m.name + ' from the browser storage?', 'Delete')) return;
        try { await brwDel(m.name); ldMsg('Deleted: ' + m.name); } catch (e) { ldMsg(e.message, true); }
        bFor = null; brwRefresh(); return;
      }
      const run = bMode === 'run';
      if (await loadLocked(() => brwLoad({ brw: m, name: m.name }, run))) { brwMnt = m.name; brwMntSeen = false; ldStoreUI(); if (run) fwinShow('loadwin', false); else { ldStoreUI(); ldMsg('Mounted: ' + m.name); } }
    };
    document.addEventListener('pointerdown', (e) => { if (goPop && !goPop.contains(e.target) && !goPop.more.contains(e.target)) goClose(); }, true);
    document.addEventListener('keydown', (e) => { if (goPop && e.key === 'Escape') { e.stopPropagation(); goClose(); } }, true);
    const dd = $('ldlist');
    dd.onmousedown = (e) => { e.preventDefault(); dd.focus(); ddOpen($('ldpop').hidden); };
    dd.onblur = () => ddOpen(false);
    document.addEventListener('pointerdown', (e) => { if (!$('ldpop').hidden && !$('ldpop').contains(e.target) && !dd.contains(e.target)) ddOpen(false); }, true); // e.g. dragging the window
    dd.onkeydown = (e) => {
      const open = !$('ldpop').hidden;
      if (e.key === 'ArrowDown') { srvPick(srvStep(srvSel, 1)); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { srvPick(srvSel < 0 ? srvStep(-1, 1) : srvStep(srvSel, -1)); e.preventDefault(); }
      else if (e.key === 'Home') { srvPick(srvStep(-1, 1)); e.preventDefault(); }
      else if (e.key === 'End') { srvPick(srvStep(srvList.length, -1)); e.preventDefault(); }
      else if (e.key === 'Enter') { if (open) ddOpen(false); else $('ldlistgo').click(); e.preventDefault(); }
      else if (e.key === ' ') { ddOpen(!open); e.preventDefault(); }
      else if (e.key === 'Escape' && open) { ddOpen(false); e.preventDefault(); e.stopPropagation(); }
      if (open) { const on = $('ldpop').querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' }); }
    };
    $('ldhelpbtn').onclick = (e) => { e.stopPropagation(); ldHelp($('ldhelp').hidden); };
    $('ldhelpclose').onclick = () => ldHelp(false);
    $('shotgo').onclick = shotGo;
    $('shotdlg').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); shotGo(); } });
    document.querySelectorAll('[name=shotfmt]').forEach((r) => r.addEventListener('change', () => { $('shotfx').disabled = !(shot && shot.pngFx) || r.value === 'scr' && r.checked; })); // a filter: PNG only
    for (const id of ['loadwin', 'browsewin', 'savedlg', 'zippick', 'shotdlg'])
      $(id).querySelector('[data-close]').onclick = () => fwinShow(id, false);
    Promise.all([loadHddList(), loadSdList()]).then(loadServerList);
    brwRefresh(); // Browser storage // the server list takes the HDD / SD card lists too
  }
  // ------------------------------------------------------------------ Save dialog: everything is downloaded to the PC
  // F6: a screenshot of that very moment (the machine runs on): PNG (the canvas as shown) or SCR (6912 bytes of the ZX
  // screen page 5 / 7), the choice remembered; Download (Enter)
  let shot = null;
  // the picture of this moment as PNG bytes: plain (no filter) or as the filter draws it. Scale 2x and Anti-Text are drawn by the
  // core (off for a moment for the plain one); CRT, PAL, Scale 3x, xBR: the shader at 3 output pixels a ZX pixel; Scanlines: the
  // dark lines in the picture; Smooth: the browser's, nothing to save
  const pngOf = async (c) => new Uint8Array(await (await new Promise((res) => c.toBlob(res, 'image/png'))).arrayBuffer());
  const imgCanvas = (img) => { const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').putImageData(img, 0, 0); return c; };
  function fbImage() { const w = E.web_fb_w(), h = E.web_fb_h(), im = new ImageData(w, h); im.data.set(new Uint8ClampedArray(E.memory.buffer, E.web_fb(), w * h * 4)); return im; }
  const CORE_FX = ['scale2x', 'text64', 'text42'];
  function shotHasFx() { return fxMode === 'scan' || CORE_FX.includes(fxMode) || (GL_FX.includes(fxMode) && !!glfx); }
  async function shotPng(withFx) {
    if (!withFx) {
      if (!CORE_FX.includes(fxMode)) return pngOf(canvas); // the canvas: the frame as the core drew it (Mix Frames too)
      E.web_text64(0); E.web_advmame(0); E.web_render(); const im = fbImage(); applyText64(); // the core's filter off for this frame
      return pngOf(imgCanvas(im));
    }
    if (GL_FX.includes(fxMode) && glfx && imageData) return pngOf(imgCanvas(glfx.capture(imageData, canvas.width, canvas.height, E.web_fb_dbl(), fxMode, 3)));
    if (fxMode === 'scan' && imageData) {
      const im = new ImageData(new Uint8ClampedArray(imageData.data), imageData.width, imageData.height), d = im.data, row = im.width * 4;
      for (let y = 1; y < im.height; y += 2) for (let i = y * row; i < (y + 1) * row; i += 4) { d[i] *= 0.62; d[i + 1] *= 0.62; d[i + 2] *= 0.62; }
      return pngOf(imgCanvas(im));
    }
    return pngOf(canvas);
  }
  async function shotOpen() {
    const fxOn = shotHasFx(), png = await shotPng(false), pngFx = fxOn ? await shotPng(true) : null;
    const page = (E.web_p7ffd() & 8) ? 7 : 5, scr = new Uint8Array(E.memory.buffer, E.web_gfx_mem(1, 0, 0) + page * 0x4000, 6912).slice();
    const d = new Date(), p2 = (v) => String(v).padStart(2, '0');
    shot = { png, pngFx, scr, base: 'screen_' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '_' + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()), w: canvas.width, h: canvas.height };
    const f = load('shot.fmt') === 'scr' ? 'scr' : 'png';
    document.querySelector('[name=shotfmt][value=' + f + ']').checked = true;
    const fsel = $('fxsel'), fname = fsel.options[fsel.selectedIndex] ? fsel.options[fsel.selectedIndex].text : '';
    $('shotfx').disabled = !fxOn; $('shotfx').checked = fxOn && load('shot.fx') !== '0'; $('shotfxl').classList.toggle('dis', !fxOn);
    $('shotfxname').textContent = fxOn ? '(' + fname + ')' : '';
    $('shotfxl').title = fxOn ? 'PNG as the filter ' + fname + ' draws it' + (GL_FX.includes(fxMode) ? ' (3 pixels a ZX pixel)' : '') + '; off: the machine\u2019s own picture' : fxMode === 'smooth' ? 'Smooth can\u2019t be saved: it is the browser\u2019s' : 'No filter on (Options / Video / Filter)';
    fwinShow('shotdlg', true); $('shotgo').focus();
  }
  function shotGo() {
    if (!shot) return;
    const f = document.querySelector('[name=shotfmt]:checked').value; store('shot.fmt', f);
    const fx = f === 'png' && shot.pngFx && $('shotfx').checked; if (shot.pngFx) store('shot.fx', $('shotfx').checked ? '1' : '0');
    downloadBytes(shot.base + (fx ? '_' + fxMode : '') + '.' + f, f === 'png' ? (fx ? shot.pngFx : shot.png) : shot.scr); toast('Downloaded: ' + shot.base + (fx ? '_' + fxMode : '') + '.' + f);
    fwinShow('shotdlg', false); shot = null;
  }
  function downloadBytes(name, data) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([data], { type: 'application/octet-stream' }));
    a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }
  // files the emulator itself wrote (debugger Alt+W blocks, quick saves): kept in page memory until downloaded
  const emuFiles = new Map(); // key -> display name
  fs.onChange = (path) => {
    const name = path.replace(/^.*[\\/]/, '');
    if (name.startsWith('__')) return;   // our own temporary files
    if (/^(cmos|nvram|web_model\.ini)$/i.test(name)) return; // CMOS / NVRAM: each machine's own, kept in the browser (nvKeep)
    const hd = hdds.findIndex((h) => h && h.toLowerCase() === name.toLowerCase());
    if (hd >= 0) { if (!hddDirty[hd]) { hddDirty[hd] = true; hddUI(); } return; } // HDD images: written by the emulator → '*'
    if (sdName && sdName.toLowerCase() === name.toLowerCase()) { sdWcOwn = false; if (!sdDirty) { sdDirty = true; sdUI(); } return; }
    if (sd2Name && sd2Name.toLowerCase() === name.toLowerCase()) { if (!sd2Dirty) { sd2Dirty = true; dmUI(); } return; }
    if (usbName && usbName.toLowerCase() === name.toLowerCase()) { gkStale = true; gkStaleAt = performance.now(); if (!usbDirty) { usbDirty = true; gkUI(); } return; }
    if (/^gotek_/i.test(name)) return; // the Gotek's mounted image: its writes go onto the stick
    const isNew = !emuFiles.has(name.toLowerCase());
    emuFiles.set(name.toLowerCase(), name);
    if (isNew) toast('Written: ' + name + ' — Save to download');
  };
  const DISK_FMT = ['trd', 'fdi', 'udi', 'td0', 'img', 'mgt'];
  const hexv = (t) => { const v = parseInt(String(t).trim().replace(/^#|^0x|^\$/i, ''), 16); return isNaN(v) ? null : v; };
  const baseName = (n) => n.replace(/^.*[\\/]/, '').replace(/\.[^.]+$/, '');
  function diskBase(d) {
    if (drives[d]) return baseName(drives[d].name);
    const n = E.web_disk_present(d) ? cstr(E.web_disk_name(d)) : '';
    return n ? baseName(n) : 'disk' + DRV[d];
  }
  const svExt = () => (['isd', 'pro', 'scl'].includes($('svfmt').value) ? $('svfmt').value : DISK_FMT[+$('svfmt').value]);
  function diskIsIsd(d) { // 1024-byte sectors (iS-DOS 800K)
    if (!E.web_disk_peek_isd) return false;
    setName('__chk.isd'); const ok = !!E.web_disk_peek_isd(d);
    try { fs.remove('__chk.isd'); } catch (e) {}
    return ok;
  }
  // Save / ROM: the ROMs of the models, the General Sound ROM and everything rom/roms.json lists — one entry per file
  function svRomList() {
    const sel = $('svrom'), was = sel.value, seen = new Map();
    const put = (f, t) => { if (!/\.rom$/i.test(f)) return; const k = f.toLowerCase(); if (!seen.has(k)) seen.set(k, [f, []]); if (!seen.get(k)[1].includes(t)) seen.get(k)[1].push(t); };
    for (const [k, v] of Object.entries(MODELS)) if (!OS_MODELS[k] && !v.custom && !v.hidden) put(v.files[0], v.sysName || v.name);
    put(GS_ROM, 'General Sound');
    for (const r of romJson.length ? romJson : romParts) if (r.page === undefined || !seen.has(r.file.toLowerCase())) put(r.file, r.name); // pages of a model ROM: the model says it
    sel.innerHTML = '';
    for (const [f, t] of seen.values()) { const o = document.createElement('option'); o.value = f; o.textContent = f + ' · ' + t.join(', '); sel.appendChild(o); }
    sel.value = seen.has(was.toLowerCase()) ? was : sel.options.length ? sel.options[0].value : '';
  }
  // Save / Memory block / RAM: which 16K banks to write (the mapped ones at first; kept for the session)
  let svBankSel = null, svMapped = new Set(), svBankN = 0; // chosen banks; mapped now; banks of this machine
  function svBanks() {
    const n = E.web_gfx_size(1) >> 14, box = $('svbanks');
    const mapped = new Set([0, 1, 2, 3].map((a) => (E.web_gfx_page ? E.web_gfx_page(a) : -1)).filter((p) => p >= 0 && p < n));
    if (!svBankSel) svBankSel = new Set(mapped.size ? mapped : [0]);
    for (const p of [...svBankSel]) if (p >= n) svBankSel.delete(p);
    if (box.childElementCount !== n) {
      box.innerHTML = '';
      for (let p = 0; p < n; p++) { const b = document.createElement('button'); b.type = 'button'; b.textContent = p.toString(16).toUpperCase().padStart(2, '0'); b.dataset.p = p; box.appendChild(b); }
    }
    for (const b of box.children) { const p = +b.dataset.p; b.classList.toggle('on', svBankSel.has(p)); b.classList.toggle('map', mapped.has(p)); b.title = 'Bank ' + p + ' (#' + b.textContent + ')' + (mapped.has(p) ? ', mapped now' : ''); }
    $('svbsum').textContent = svBankSel.size + ' × 16K = ' + svBankSel.size * 16 + ' KB';
    svMapped = mapped; svBankN = n;
  }
  // the range in one bank: offset 0000-3FFF, length 1 … to the end of the bank (a value over the limit is cut to it)
  function svRange(edited) {
    const fo = $('svboff'), fl = $('svblen');
    let off = parseInt(fo.value || '0', 16) || 0; if (off > 0x3FFF) { off = 0x3FFF; fo.value = '3FFF'; }
    const max = 0x4000 - off;
    let len = parseInt(fl.value, 16); if (!(len > 0)) len = edited === 'len' ? 0 : max;
    if (len > max || (edited === 'off' && fl.dataset.full === '1')) { len = max; fl.value = hex4(max); } // the whole rest stays the whole rest
    fl.dataset.full = len === max ? '1' : '';
    $('svbend').textContent = len ? '#' + hex4(off) + '–#' + hex4(off + len - 1) : '';
    return { off, len };
  }
  function openSave(what) {
    if (!E) return;
    if (!what && recOn()) what = 'rzx'; // recording: Save opens at it (as ● REC does)
    svRomList(); if (!romPartsLoaded) loadRomParts().then(() => { svRomList(); if ($('svtype').value === 'srvrom') svUpdate(true); });
    const sel = $('svtype'); sel.innerHTML = '';
    const add = (v, t, parent) => { const o = document.createElement('option'); o.value = v; o.textContent = t; (parent || sel).appendChild(o); };
    for (let i = 0; i < NDRIVES; i++) if (E.web_disk_present(i)) add('disk:' + i, `Disk ${DRV[i]}: ${diskBase(i)}${E.web_disk_changed(i) ? ' *' : ''}`);
    for (let d = 0; d < NHDD; d++) if (hdds[d] && fs.exists(hdds[d])) add('hdd:' + d, `HDD ${d}: ${hdds[d]}${hddDirty[d] ? ' *' : ''}`);
    if (sdName && fs.exists(sdName)) add('sd', `SD card: ${sdName}${sdDirty ? ' *' : ''}`);
    if (usbName && fs.exists(usbName)) add('usb', `USB stick (Gotek): ${usbName.slice(4)}${usbDirty ? ' *' : ''}`);
    if (sd2Name && fs.exists(sd2Name)) add('sd2', `MMC card (DivMMC): ${sd2Name}${sd2Dirty ? ' *' : ''}`);
    add('sna', 'Snapshot (SNA)');
    add('rzx', 'Input recording (RZX)');
    add('scr', 'Screen (SCR)');
    add('png', 'Screenshot (PNG)');
    add('mem', 'Memory block (BIN)');
    add('srvrom', 'ROM');
    add('rom', 'Custom ROM');
    if (emuFiles.size) {
      const g = document.createElement('optgroup'); g.label = 'Written by the emulator'; sel.appendChild(g);
      for (const n of emuFiles.values()) add('file:' + n, n, g);
    }
    if (what && [...sel.options].some((o) => o.value === what)) sel.value = what;
    releaseAll(); releaseMouse();
    svUpdate(true);
    fwinShow('savedlg', true);
  }
  let svExtCur = ''; // extension of the file to save (trd, scl, sna…): the name field may drop it, the file keeps it
  const svBase = (v, ext) => { let b = String(v).trim().replace(/\.zip$/i, ''); const e = ext === undefined ? svExtCur : ext; if (e && b.toLowerCase().endsWith('.' + e.toLowerCase())) b = b.slice(0, -(e.length + 1)); return b || 'file'; };
  const svName = (base, zip) => base + (zip ? '.zip' : svExtCur ? '.' + svExtCur : '');
  function svUpdate(resetName) {
    const t = $('svtype').value, disk = t.startsWith('disk:'), mem = t === 'mem';
    document.querySelectorAll('#savedlg .sv-disk').forEach((e) => { e.hidden = !disk; });
    const ram = mem && $('svsrc').value === '1';
    document.querySelectorAll('#savedlg .sv-mem').forEach((e) => { e.hidden = !mem; });
    document.querySelectorAll('#savedlg .sv-cpu').forEach((e) => { e.hidden = !mem || ram; });
    document.querySelectorAll('#savedlg .sv-ram').forEach((e) => { e.hidden = !ram; });
    if (ram) svBanks();
    const one = ram && svBankSel.size === 1, rg = one ? svRange() : null; // one bank: a range inside it
    document.querySelectorAll('#savedlg .sv-one').forEach((e) => { e.hidden = !one; });
    if (rg) $('svbsum').textContent = rg.len + ' bytes';
    document.querySelectorAll('#savedlg .sv-rom').forEach((e) => { e.hidden = t !== 'srvrom'; });
    document.querySelectorAll('#savedlg .sv-rzx').forEach((e) => { e.hidden = t !== 'rzx'; });
    $('svgo').disabled = t === 'rzx' && !recDone; if (t === 'rzx') recUI();
    let name = '', note = '';
    if (disk) {
      const d = +t.slice(5);
      if (resetName) {
        // iS-DOS disks (5 × 1024-byte sectors, 800K): ISD instead of TRD; others: as loaded (TRD/FDI), otherwise UDI
        const ext = drives[d] ? drives[d].ext : 'trd', sam = M() === 'SAM' || ext === 'mgt' || ext === 'sad', pc = !sam && (ext === 'img' || ext === 'ima'); // a PC floppy (512-byte sectors): IMG, FDI, UDI, TD0; SAM Coupé: MGT
        const isd = !pc && !sam && diskIsIsd(d);
        $('svfmt').querySelector('[value="0"]').hidden = isd || pc || sam; $('svfmt').querySelector('[value="scl"]').hidden = isd || pc || sam; $('svfmt').querySelector('[value="isd"]').hidden = !isd; $('svfmt').querySelector('[value="pro"]').hidden = !isd;
        $('svfmt').querySelector('[value="4"]').hidden = !pc; $('svfmt').querySelector('[value="5"]').hidden = !sam;
        $('svfmt').value = sam ? (ext === 'fdi' ? '1' : ext === 'udi' ? '2' : ext === 'td0' ? '3' : '5') : pc ? '4' : isd ? (ext === 'fdi' ? '1' : ext === 'udi' ? '2' : ext === 'td0' ? '3' : ext === 'pro' ? 'pro' : 'isd')
          : ext === 'fdi' ? '1' : ext === 'scl' ? 'scl' : ['trd', 'hob'].includes(ext) || ext.startsWith('$') ? '0' : ext === 'td0' ? '3' : '2';
      }
      name = diskBase(d) + '.' + svExt();
      note = $('svfmt').value === '0' ? 'TRD holds only standard 80 tracks (16×256 sectors). Suits for TR-DOS and CP/M. For iS-DOS and other formats use FDI or UDI.'
        : $('svfmt').value === 'scl' ? 'SCL: TR-DOS files only (no free space, deleted files dropped).'
        : $('svfmt').value === '5' ? 'MGT: raw SAM Coupé disk (800K, 10 × 512-byte sectors a track).' + (E.web_disk_changed(d) ? ' The disk was modified (*). Downloading clears the mark.' : '')
        : $('svfmt').value === '4' ? 'IMG: raw PC floppy (9 × 512-byte sectors a track).' + (E.web_disk_changed(d) ? ' The disk was modified (*). Downloading clears the mark.' : '')
        : $('svfmt').value === 'isd' || $('svfmt').value === 'pro' ? ($('svfmt').value === 'pro' ? 'PRO: raw Profi CP/M image (800K, 5 × 1024-byte sectors, boot sector 9).' : 'ISD: raw iS-DOS image (800K, 5 × 1024-byte sectors).') + (E.web_disk_changed(d) ? ' The disk was modified (*). Downloading clears the mark.' : '')
        : E.web_disk_changed(d) ? 'The disk was modified (*). Downloading clears the mark.' : '';
    } else if (t.startsWith('hdd:')) {
      const d = +t.slice(4);
      name = hdds[d];
      note = 'HDD image with its geometry.chs (Interface, CHS, drives).' + (hddDirty[d] ? ' The image was modified (*). Downloading clears the mark.' : '');
    } else if (t === 'sd') {
      name = sdName.replace(/\.[^.]*$/, '') + '.vhd';
      note = 'SD image as VHD (can be mounted on PC).' + (sdDirty ? ' It was modified (*). Downloading clears the mark.' : '');
    } else if (t === 'usb') {
      const vhd = /\.vhd$/i.test(usbName); // a stick put in as a VHD goes back as one (fixed: the raw image and its footer)
      name = usbName.slice(4).replace(/\.[^.]*$/, '') + (vhd ? '.vhd' : '.img');
      note = 'USB stick image of the Gotek' + (vhd ? ' as VHD (can be mounted on PC).' : ' (raw).') + (usbDirty ? ' It was modified (*). Downloading clears the mark.' : '');
    } else if (t === 'sd2') {
      name = sd2Name.replace(/\.[^.]*$/, '') + '.vhd';
      note = 'MMC card (DivMMC) as VHD (can be mounted on PC).' + (sd2Dirty ? ' It was modified (*). Downloading clears the mark.' : '');
    } else if (t === 'sna') {
      name = 'snapshot.sna';
      note = 'SNA holds 128K only. Memory above 128K and ATM ports will be lost.';
    } else if (t === 'rzx') {
      name = (recDone && recDone.name) || 'recording.rzx';
      note = 'RZX record starts from the next frame. Works with 48/128K models (without extra RAM). CPU clock up to 3x. ZIP for RZX is useless.';
    } else if (t === 'png') {
      name = 'screen.png';
      note = 'Screenshot as on screen (any video mode, border included).';
    } else if (t === 'scr') {
      name = 'screen.scr';
      note = 'ZX screen (6912 bytes) of the active page 5 or 7. ATM EGA/text modes are not a ZX screen.';
    } else if (mem && ram) {
      const b = [...svBankSel].sort((x, y) => x - y), h2 = (v) => v.toString(16).toUpperCase().padStart(2, '0'), runs = [];
      for (const v of b) { const r = runs[runs.length - 1]; if (r && r[1] === v - 1) r[1] = v; else runs.push([v, v]); }
      name = b.length ? 'ram_' + (runs.length > 4 ? b.length + 'banks' : runs.map(([x, y]) => (x === y ? h2(x) : h2(x) + '-' + h2(y))).join('_')) + '.bin' : 'ram.bin';
      if (rg && (rg.off || rg.len < 0x4000)) name = name.replace(/\.bin$/, '_' + hex4(rg.off) + '-' + hex4(rg.off + rg.len - 1) + '.bin'); // ram_05_2000-2FFF.bin
      note = one ? 'One bank: offset and length inside it (hex, the bank is 4000 bytes).' : 'RAM banks of 16K, one after another in the order of their numbers. Outlined: mapped into the Z80 address space now.';
    } else if (mem) {
      const st = hexv($('svstart').value) || 0;
      name = 'block_' + st.toString(16).toUpperCase().padStart(4, '0') + '.bin';
      note = 'Start and length in hex (CPU 64K: as the Z80 sees it now).';
    } else if (t === 'srvrom') {
      name = $('svrom').value || 'rom';
      note = 'The ROM file as it is on the server (rom/), not changed.';
    } else if (t === 'rom') {
      const z = romZip(); name = z ? z.name.replace(/\.zip$/i, '') : 'rom';
      note = 'ROM + json. Can be loaded as a custom ROM.';
    } else if (t.startsWith('file:')) {
      name = t.slice(5);
      note = 'Written by the emulator into page memory (e.g. debugger Alt+W, quick save).';
    }
    // the field: aaa.zip when packed (the file inside always gets the extension of the format), else aaa.<ext>
    const was = svExtCur; svExtCur = t === 'rom' ? '' : (/\.([^.]+)$/.exec(name) || ['', ''])[1];
    const base = resetName || !$('svname').value ? name.replace(/\.[^.]*$/, '') : svBase($('svname').value, was);
    $('svname').value = svName(base, ($('svzip').checked && t !== 'rzx') || t === 'rom');
    document.querySelectorAll('#savedlg .sv-zip').forEach((e) => { e.hidden = t === 'rzx'; }); // RZX: packed inside already
    // Where: the browser storage takes what Load can load again (disks, HDD / SD images, snapshots, files the emulator wrote)
    const canBrw = disk || t.startsWith('hdd:') || t === 'sd' || t === 'sna' || t === 'rzx' || t.startsWith('file:');
    $('svdest').querySelector('[value="brw"]').disabled = !canBrw;
    $('svdest').value = canBrw && load('sv.dest') === 'brw' ? 'brw' : 'pc';
    const brw = $('svdest').value === 'brw';
    $('svgo').textContent = brw ? 'Save' : 'Download';
    $('svnote').textContent = note.replace(/Downloading clears/, brw ? 'Saving clears' : 'Downloading clears');
    if (brw) brwUsage().then((u) => { if ($('svdest').value === 'brw') $('svnote').textContent = $('svnote').textContent.replace(/\s*Browser storage:.*$/, '') + ' Browser storage: Load lists it (tag SAVED)' + (u ? '; ' + u : '') + '.'; });
  }
  // the geometry.chs of HDD d: the one it came with (if the geometry is still the same) or made from the settings
  function hddChs(d) {
    const g = hddGeom(d), old = g.chs && parseChs(g.chs);
    if (old && old.c === g.c && old.h === g.h && old.s === g.s) return g.chs;
    return [`# ${hdds[d]}`, `CHS=${g.c}/${g.h}/${g.s}`, `Interface=${IF_NAMES[E.web_hdd_scheme(-1)] || 'ATM'}`, ...(g.dir ? [`DirEntries=${g.dir}`] : []), ...(g.parts || []).map((p) => `${p.fs === 'isdos' ? 'ISDOS' : 'CPM'}=${p.letter} ${p.c0}-${p.c1}` + (p.note ? '  # ' + p.note : '')), ''].join('\r\n');
  }
  // SCL: "SINCLAIR", file count, 14-byte headers (TR-DOS catalogue entries without the position), the files' sectors, a 32-bit sum
  function trdToScl(img) {
    if (img.length < 0x900 || img[0x8E7] !== 0x10) return null;
    const files = [];
    for (let i = 0; i < 128; i++) {
      const e = img.subarray(i * 16, i * 16 + 16);
      if (e[0] === 0) break;
      if (e[0] === 1) continue;
      files.push(e);
    }
    const size = 9 + files.length * 14 + files.reduce((n, e) => n + e[13] * 256, 0);
    const out = new Uint8Array(size + 4);
    out.set([...'SINCLAIR'].map((c) => c.charCodeAt(0))); out[8] = files.length;
    let o = 9;
    for (const e of files) { out.set(e.subarray(0, 14), o); o += 14; }
    for (const e of files) { const off = (e[15] * 16 + e[14]) * 256, n = e[13] * 256; out.set(img.subarray(off, off + n), o); o += n; }
    let sum = 0; for (let i = 0; i < size; i++) sum = (sum + out[i]) >>> 0;
    out[size] = sum & 255; out[size + 1] = (sum >>> 8) & 255; out[size + 2] = (sum >>> 16) & 255; out[size + 3] = sum >>> 24;
    return out;
  }
  async function doSave() {
    const t = $('svtype').value, brw = $('svdest').value === 'brw', zip = ($('svzip').checked && t !== 'rzx') || (brw && t.startsWith('hdd:')); // the browser keeps an HDD with its .chs: one ZIP
    store('sv.zip', $('svzip').checked ? '1' : '0');
    // the file goes to the computer (download) or into the browser storage
    const out = async (fn, bytes) => {
      if (!brw) { downloadBytes(fn, bytes); return true; }
      try { return await brwSave(fn, bytes, brwKind(fn.replace(/\.zip$/i, '') === fn ? fn : full, t)); } catch (e) { toast('Browser storage: ' + e.message, true); return false; }
    };
    const done = (fn) => { toast((brw ? 'Saved in the browser: ' : 'Downloaded: ') + fn); };
    const sbase = svBase($('svname').value.replace(/[\\/:*?"<>|]/g, '_')), full = sbase + (svExtCur ? '.' + svExtCur : ''); // aaa.trd: the file itself
    let name = zip || t === 'rom' ? sbase + '.zip' : full;
    let data = null, clean = null; // clean: the "changed" mark goes only when the file was saved
    if (t === 'rom') { // always a ZIP: the image and custom.json
      const z = romZip(); if (!z) { toast('No ROM to save', true); return; }
      const fn = /\.zip$/i.test(name) ? name : name + '.zip';
      downloadBytes(fn, await UnrealZip.create(z.files)); toast('Downloaded: ' + fn);
      fwinShow('savedlg', false); return;
    }
    if (t.startsWith('hdd:')) { // image + geometry.chs: one ZIP, or two files
      const d = +t.slice(4), img = hdds[d] && fs.read(hdds[d]);
      if (!img) { toast('Nothing to save', true); return; }
      // a VHD carries its geometry in its footer: no geometry.chs with it
      const vhd = img.length > 512 && String.fromCharCode(...img.subarray(img.length - 512, img.length - 504)) === 'conectix';
      const chs = vhd ? null : new TextEncoder().encode(hddChs(d)), inner = full;
      const zn = /\.zip$/i.test(name) ? name : sbase + '.zip';
      if (zip) { toast('Packing ' + zn + '…'); if (!await out(zn, await UnrealZip.create([{ name: inner, data: img }, ...(chs ? [{ name: 'geometry.chs', data: chs }] : [])]))) return; }
      else { downloadBytes(name, img); if (chs) downloadBytes('geometry.chs', chs); }
      hddDirty[d] = false; hddUI();
      done(zip ? zn : name + (chs ? ' + geometry.chs' : ''));
      fwinShow('savedlg', false); updateUI(); return;
    }
    if (t.startsWith('disk:') && ($('svfmt').value === 'isd' || $('svfmt').value === 'pro')) { // raw 800K: the same bytes, the loader numbers the sectors by the extension
      const d = +t.slice(5);
      setName('__save.isd');
      if (!E.web_disk_peek_isd(d)) { toast('Drive ' + DRV[d] + ': not a disk of 1024-byte sectors', true); return; }
      data = fs.read('__save.isd').slice(); fs.remove('__save.isd'); clean = () => E.web_disk_mark(d, 0);
    } else if (t.startsWith('disk:') && $('svfmt').value === 'scl') {
      const d = +t.slice(5);
      setName('__save.trd');
      if (!E.web_save_disk(d, 0)) { toast('Cannot save drive ' + DRV[d] + ' as SCL', true); return; }
      const trd = fs.read('__save.trd'); fs.remove('__save.trd');
      data = trdToScl(trd); if (!data) { toast('Drive ' + DRV[d] + ': not a TR-DOS disk', true); return; }
    } else if (t === 'png') {
      data = await shotPng(shotHasFx() && load('shot.fx') !== '0'); // as Screenshot (F6) last chose: with the filter or without
    } else if (t.startsWith('disk:')) {
      const d = +t.slice(5), type = +$('svfmt').value, ext = DISK_FMT[type];
      setName('__save.' + ext);
      if (!E.web_save_disk(d, type)) { toast('Cannot save drive ' + DRV[d] + ' as ' + ext.toUpperCase(), true); return; }
      data = fs.read('__save.' + ext); fs.remove('__save.' + ext);
    } else if (t === 'sna') {
      setName('__save.sna');
      if (!E.web_save_sna()) { toast('Cannot save the snapshot', true); return; }
      data = fs.read('__save.sna'); fs.remove('__save.sna');
      const dx = dux && dux.applied && ulaxMode() === 2 ? dux.buf : null; // ZX ULAX with a dux: a ZIP of the snapshot, its dux and the colors now (.ulx)
      if (dx) {
        const b = full.replace(/\.[^.]*$/, ''), zn = sbase + '.zip', u = ulaxSave();
        if (!await out(zn, await UnrealZip.create([{ name: b + '.sna', data }, { name: b + '.dux', data: dx }, ...(u ? [{ name: b + '.ulx', data: u }] : [])]))) return;
        done(zn + ' (snapshot + ZX ULAX)'); fwinShow('savedlg', false); updateUI(); return;
      }
    } else if (t === 'rzx') {
      if (!recDone) { toast('No recording: Start, play, Stop', true); return; }
      data = await UnrealRzx.write(recDone);
    } else if (t === 'scr') {
      const page = (E.web_p7ffd() & 8) ? 7 : 5;
      data = new Uint8Array(E.memory.buffer, E.web_gfx_mem(1, 0, 0) + page * 0x4000, 6912).slice();
    } else if (t === 'mem' && $('svsrc').value === '1') {
      const b = [...svBankSel].sort((x, y) => x - y), n = E.web_gfx_size(1) >> 14;
      if (!b.length) { toast('Choose the banks to save', true); return; }
      const base = E.web_gfx_mem(1, 0, 0), ram = new Uint8Array(E.memory.buffer, base, n << 14);
      if (b.length === 1) { // one bank: its range
        const { off, len } = svRange(); if (!len) { toast('Check the length', true); return; }
        data = ram.slice((b[0] << 14) + off, (b[0] << 14) + off + len);
      } else { data = new Uint8Array(b.length << 14); b.forEach((p, i) => data.set(ram.subarray(p << 14, (p + 1) << 14), i << 14)); }
    } else if (t === 'mem') {
      const src = +$('svsrc').value, size = E.web_gfx_size(src);
      const st = hexv($('svstart').value), len = hexv($('svlen').value);
      if (st === null || !len || st >= size) { toast('Check start and length', true); return; }
      const n = Math.min(len, size - st);
      const p = E.web_gfx_mem(src, st, n);
      data = new Uint8Array(E.memory.buffer, p + (src === 1 ? st : 0), src === 1 ? n : 0x10000).slice(src === 1 ? 0 : st, src === 1 ? n : st + n);
    } else if (t.startsWith('file:')) {
      data = fs.read(t.slice(5));
    } else if (t === 'srvrom') {
      const f = $('svrom').value; if (!f) { toast('Choose a ROM', true); return; }
      try { data = fs.exists(f) ? fs.read(f).slice() : await fetchSrv(f); } catch (e) { toast(f + ': ' + e.message, true); return; }
    } else if (t === 'sd') {
      data = sdImage(0); if (data) { data = vhdFixed(data); clean = () => { sdDirty = false; sdUI(); }; }
    } else if (t === 'usb') {
      data = usbImage(); if (data) { if (/\.vhd$/i.test(usbName)) data = vhdFixed(data); clean = () => { usbDirty = false; gkUI(); }; }
    } else if (t === 'sd2') {
      data = sdImage(1); if (data) { data = vhdFixed(data); clean = () => { sd2Dirty = false; dmUI(); }; }
    }
    if (!data) { toast('Nothing to save', true); return; }
    if (zip) { // aaa.zip with aaa.trd inside (an SD card with its file to start: the .json next to it)
      const files = [{ name: full, data }];
      if (t === 'sd' && sdRun) files.push({ name: full.replace(/\.[^.]*$/, '') + '.json', data: new TextEncoder().encode(JSON.stringify({ run: sdRun }, null, 1) + '\n') });
      if (!await out(name, await UnrealZip.create(files))) return;
    } else if (!await out(name, data)) return;
    if (clean) clean();
    done(name);
    fwinShow('savedlg', false); updateUI();
  }
  // hex fields (data-hex, its value: other characters allowed, e.g. ":" for page:offset or "-" for a range): typing and
  // pasting keep 0-9, A-F (a-f); anything else is dropped, so a stray key does not end up in an address
  function bindHexFields() {
    const ok = (t, c) => /[0-9a-f]/i.test(c) || (t.dataset.hex || '').includes(c);
    document.addEventListener('beforeinput', (e) => {
      const t = e.target; if (!t.dataset || t.dataset.hex === undefined || !e.data) return;
      if (![...e.data].every((c) => ok(t, c))) {
        e.preventDefault();
        const keep = [...e.data].filter((c) => ok(t, c)).join(''); // a paste: its hex part
        if (keep && e.inputType !== 'insertText') { t.setRangeText(keep, t.selectionStart, t.selectionEnd, 'end'); t.dispatchEvent(new Event('input', { bubbles: true })); }
      }
    }, true);
    document.addEventListener('input', (e) => { // what beforeinput could not stop (autofill, some mobile keyboards)
      const t = e.target; if (!t.dataset || t.dataset.hex === undefined) return;
      const v = [...t.value].filter((c) => ok(t, c)).join('');
      if (v !== t.value) { const at = Math.max(0, t.selectionStart - (t.value.length - v.length)); t.value = v; t.setSelectionRange(at, at); }
    }, true);
  }
  function bindSave() {
    $('savebtn').onclick = () => openSave();
    $('svtype').onchange = () => svUpdate(true);
    $('svdest').onchange = () => { store('sv.dest', $('svdest').value); svUpdate(false); };
    $('svrom').onchange = () => svUpdate(true);
    $('svfmt').onchange = () => svUpdate(false);
    $('svstart').addEventListener('input', () => { if ($('svtype').value === 'mem') svUpdate(true); });
    $('svsrc').onchange = () => svUpdate(true);
    $('svboff').addEventListener('input', () => { svRange('off'); svUpdate(true); });
    $('svblen').addEventListener('input', () => { svRange('len'); svUpdate(true); });
    for (const id of ['svboff', 'svblen']) $(id).addEventListener('blur', () => { const f = $(id); f.value = hex4(parseInt(f.value || '0', 16) || 0); if (id === 'svblen' && !(parseInt(f.value, 16) > 0)) f.value = hex4(0x4000 - (parseInt($('svboff').value, 16) || 0)); svRange(); svUpdate(true); });
    const rangeReset = () => { $('svboff').value = '0000'; $('svblen').value = '4000'; $('svblen').dataset.full = '1'; }; // a new bank: the whole of it
    $('svbanks').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; const p = +b.dataset.p; if (svBankSel.has(p)) svBankSel.delete(p); else svBankSel.add(p); rangeReset(); svUpdate(true); };
    $('svball').onclick = () => { svBankSel = new Set(Array.from({ length: svBankN }, (x, i) => i)); svUpdate(true); };
    $('svbnone').onclick = () => { svBankSel.clear(); svUpdate(true); };
    $('svbmap').onclick = () => { svBankSel = new Set(svMapped); svUpdate(true); };
    $('svgo').onclick = doSave;
    $('svhelpbtn').onclick = (e) => { e.stopPropagation(); svHelp($('svhelp').hidden); };
    $('svhelpclose').onclick = () => svHelp(false);
    $('svrec').onclick = () => { if (recOn()) { recStop(); svUpdate(true); $('svgo').focus(); } else recStart(); };
    $('recmark').onclick = () => openSave('rzx');
    $('dbgdlg').querySelector('[data-close]').onclick = dlgClose;
    $('svzip').checked = load('sv.zip') !== '0';
    $('svzip').onchange = () => { $('svname').value = svName(svBase($('svname').value), $('svzip').checked || $('svtype').value === 'rom'); };
    $('savedlg').addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); doSave(); } });
  }

  // ------------------------------------------------------------------ System Info: everything about the machine, the emulator and the browser in one window
  let siFW = null, siTimer = 0;
  const VMODES = { 0: 'EGA 320×200, 16 colors', 2: 'hi-res 640×200', 3: 'ZX 256×192', 6: 'text 80×25', 7: 'ZX 256×192' };
  function siData() {
    const kv = {};
    for (const ln of cstr(E.web_sysinfo()).split('\n')) { const i = ln.indexOf('\t'); if (i > 0) kv[ln.slice(0, i)] = ln.slice(i + 1); }
    return kv;
  }
  const optText = (id) => { const s = $(id); return s && s.selectedIndex >= 0 ? s.options[s.selectedIndex].textContent : ''; };
  const mb = (n) => n >= 1048576 ? (n / 1048576).toFixed(n >= 10485760 ? 0 : 1) + ' MB' : Math.round(n / 1024) + ' KB';
  function siSections() {
    const k = siData(), x = SPEEDS[speedIdx], m = MODELS[model], atm = /^ATM|XBIOS|EVO/.test(M());
    const secs = Math.floor(+k.frames / (+k.intfq || 50));
    const state = dbgOn ? 'debugger' : userPaused ? 'stopped' : hiddenPaused ? 'paused (tab hidden)' : turbo ? 'running, max speed' : 'running';
    const ff77 = parseInt(k.pff77, 16), vmode = atm ? (VMODES[ff77 & 7] || 'mode ' + (ff77 & 7)) : 'ZX 256×192';
    const out = [];
    out.push(['Machine', [
      ['Model', m.name], ['Core', k.model], ['RAM', k.ram + ' KB'],
      ['ROM', model === 'CUSTOM' ? MACHINES[customCfg.mach].name + ': ' + m.files.filter((f) => /\.rom$/i.test(f)).map((f) => (crFile(f) || { name: f }).name).join(', ') : m.files.filter((f) => /\.rom$/i.test(f)).join(', ') + (romDisk && M() === 'XBIOS136' ? ' + ROM disk ' + romDisk.name : '')],
      ['CPU clock', hud.mhz + ' (' + (tsMult || x) + 'x)' + (tsMult ? ', set by the program' : m.fixed ? ', fixed' : '')],
      ['Frame', k.frame + ' t-states, ' + k.intfq + ' Hz'],
      ['State', state + ' · ' + hud.fps],
      ['Emulated time', Math.floor(secs / 60) + ':' + String(secs % 60).padStart(2, '0') + ' (' + k.frames + ' frames)'],
    ]]);
    out.push(['CPU', [['PC', k.pc], ['SP', k.sp], ['AF', k.af], ['BC', k.bc], ['DE', k.de], ['HL', k.hl], ['IX', k.ix], ['IY', k.iy], ['IR', k.ir], ['IM', k.im], ['IFF', k.iff1], ['HALT', k.halted === '1' ? 'yes' : 'no']], 'regs']);
    const mem = [['#7FFD', k.p7ffd + ' (RAM page ' + (parseInt(k.p7ffd, 16) & 7) + ', screen ' + ((parseInt(k.p7ffd, 16) & 8) ? 7 : 5) + ', ROM ' + ((parseInt(k.p7ffd, 16) >> 4) & 1) + ')']];
    if (atm) mem.push(['#FF77', k.pff77 + ' (video: ' + vmode + ')'], ['#xFF7 map', k.pfff7], ['#EFF7', k.peff7]);
    else if (M() === 'PENTAGON') mem.push(['#EFF7', k.peff7]);
    out.push(['Memory & video', mem.concat([
      ['Video mode', vmode], ['Picture', canvas.width + '×' + canvas.height + ' → ' + canvas.style.width + ' × ' + canvas.style.height],
      ['Border', k.border], ['Palette', $('palsel').value], ['Filter', optText('fxsel')],
    ])]);
    const dk = [];
    for (let i = 0; i < 4; i++) {
      const f = (k['fdd' + i] || '').split('|');
      if (f[0] !== '1') { if (i < NDRIVES) dk.push([DRV[i] + ':', '<span class="dim">empty</span>']); continue; }
      const nm = drives[i] ? drives[i].name : cstr(E.web_disk_name(i)).replace(/^.*[\\/]/, '');
      dk.push([DRV[i] + ':', esc(nm) + ` <span class="dim">· ${f[1]} cyl × ${f[2]} · track ${f[3]}${f[4] === '1' ? ' · modified' : ''}${E.web_get_wp(i) ? ' · WP' : ''}${f[5] === '1' ? ' · selected' : ''}${f[6] === '1' ? ' · motor' : ''}</span>`]);
    }
    dk.push(['TR-DOS', k.trdos === '1' ? 'present' : 'none']);
    const hsc = E.web_hdd_scheme(-1);
    dk.push(['FDD', E.web_fdd_accurate && E.web_fdd_accurate(-1) ? 'accurate (WD1793 timing, no traps)' : 'fast (TR-DOS traps)']);
    dk.push(['HDD', hsc ? optText('hddif') : '<span class="dim">off</span>']);
    if (hsc) for (let d = 0; d < NHDD; d++) {
      const on = !!E.web_hdd_get(d, 5), g = hddGeom(d);
      dk.push([d ? 'Slave' : 'Master', on ? esc(hdds[d]) + ` <span class="dim">· CHS ${g.c}/${g.h}/${g.s}${g.ro ? ' · RO' : ''}</span>` : '<span class="dim">empty</span>']);
    }
    if (dmHere() && E.web_dm_info) { // DivMMC and Gotek (Pentagon, ZX Spectrum 128, Scorpion)
      const v = new Uint32Array(E.memory.buffer, E.web_dm_info(), 11), dim = (t) => ' <span class="dim">· ' + t + '</span>';
      dk.push(['DivMMC', !v[0] ? '<span class="dim">off</span>' : (v[7] ? 'esxDOS' : 'no ROM (rom/esxmmc.zip)') + dim((v[1] ? 'paged in' + (v[2] ? ' (automap)' : ' (CONMEM)') : 'paged out') + ' · bank ' + v[5] + (v[4] ? ' · MAPRAM' : ''))]);
      if (v[0]) dk.push(['MMC', sd2Name && fs.exists(sd2Name) ? esc(sd2Name) + dim(mb(fs.read(sd2Name).length) + (load('sd2.ro') === '1' ? ' · RO' : '') + (sd2Dirty ? ' · modified' : '') + ((v[6] & 1) ? '' : ' · selected')) : '<span class="dim">empty</span>']);
      const g = new Uint32Array(E.memory.buffer, E.web_gk_info(), 14), gd = g[0] | 0;
      dk.push(['Gotek', gd < 0 ? '<span class="dim">off</span>' : DRV[gd] + ':' + dim('head ' + g[13] + (g[1] ? ' · Direct Access, lba ' + (g[4] === 0xFFFFFFFF ? 'name' : g[4]) + ', commands ' + g[5] : '') + (g[12] ? ' · mounting' : '') + (gkSlots[g[2]] ? ' · slot ' + g[2] + ': ' + esc(gkSlots[g[2]].name) : '') + (gkErr ? ' · error ' + gkErr + ' (' + GK_ERR[gkErr] + ')' : ''))]);
      if (gd >= 0) dk.push(['USB stick', usbName && fs.exists(usbName) ? esc(usbName.slice(4)) + dim(mb(fs.read(usbName).length) + ' · ' + gkSlots.length + ' slots' + (usbDirty ? ' · modified' : '')) : '<span class="dim">none</span>']);
    }
    dk.push(['SD timing', optText('sdtime')]);
    const tp = (k.tape || '').split('|');
    dk.push(['Tape', tp[0] === '1' || +k.tapeblocks ? (tp[1] === '1' ? 'playing' : 'stopped') + ', block ' + (+tp[2] + 1) + ' of ' + k.tapeblocks : '<span class="dim">none</span>']);
    out.push(['Storage', dk]);
    out.push(['WD1793', wdRows(k.wdx)]);
    const ac = audio && audio.ctx;
    out.push(['Sound', [
      ['Output', ac ? ac.state + ', ' + ac.sampleRate + ' Hz' + (ac.baseLatency ? ', latency ' + Math.round(ac.baseLatency * 1000) + ' ms' : '') + (audio.sp ? ', ScriptProcessor' : ', AudioWorklet') : 'not started (needs a click or key)'],
      ['Volume', muted ? 'muted' : 'on'], ['Emulator rate', k.sndrate + ' Hz'],
      ['AY', optText('aysel') + ', ' + optText('aychip') + (+k.activeay ? ', active chip ' + (+k.activeay + 1) : '')],
      ['General Sound', optText('gssel') + ($('gssel').value === '2' ? (E.web_get_gs() ? ' — on now' : ' — off now') : '')], ['Visualizer', optText('vizsel')],
    ]]);
    out.push(['Input', [
      ['Keyboard', k.xt === '1' ? 'XT mode: emulator hotkeys off' : 'ZX matrix, emulator hotkeys on'],
      ['Mouse', E.web_mouse_type() === 1 ? 'Kempston: ' + (mouseLocked ? 'on (captured)' : touchMouse ? 'on (touch taps)' : 'off') : 'none'],
      ['On-screen', $('vkbd').hidden ? 'hidden' : (vkbd ? vkbd.tab.toUpperCase() : '') + ' panel'],
      ['Joystick', ((UnrealVKbd.JOY_MAPS[load('vkjoy') || 'sinclair2'] || {}).name || 'Sinclair 2')],
      ...(M() === 'NEXT' ? [['Next keys', optText('nxkeys')]] : []),
    ]]);
    const ua = navigator.userAgent, br = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox' : /CriOS|Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'browser';
    const ver = (ua.match(/(?:Edg|OPR|Firefox|CriOS|Chrome|Version)\/(\d+)/) || [])[1] || '';
    out.push(['Host', [
      ['Browser', br + (ver ? ' ' + ver : '') + ' · ' + (navigator.userAgentData && navigator.userAgentData.platform || navigator.platform || '')],
      ['Screen', screen.width + '×' + screen.height + ', DPR ' + (window.devicePixelRatio || 1) + ', window ' + innerWidth + '×' + innerHeight],
      ['Viewport', (window.visualViewport ? 'visual ' + Math.round(visualViewport.width) + '×' + Math.round(visualViewport.height) + ' at ' + Math.round(visualViewport.offsetTop) + ', ' : '') + 'page ' + document.documentElement.clientWidth + '×' + document.documentElement.clientHeight +
        (navigator.standalone || (window.matchMedia && matchMedia('(display-mode: standalone)').matches) ? ', home screen' : '') + (land ? ', landscape layout' : '') + ', stage at ' + Math.round($('stage').getBoundingClientRect().top)],
      ['CPU threads', navigator.hardwareConcurrency || '?'], ['Device memory', navigator.deviceMemory ? navigator.deviceMemory + ' GB' : '?'],
      ['Touch', matchMedia('(pointer: coarse)').matches ? 'yes' : 'no'],
      ['WASM memory', mb(E.memory.buffer.byteLength)],
      ['Page', 'Web Unreal Speccy v.' + APP_VER],
    ]]);
    return out;
  }
  // WD1793 (Beta 128): registers, state machine and the selected drive, as the Windows debugger shows them
  const WD_STATES = ['S_IDLE', 'S_WAIT', 'S_DELAY_BEFORE_CMD', 'S_CMD_RW', 'S_FOUND_NEXT_ID', 'S_RDSEC', 'S_READ', 'S_WRSEC', 'S_WRITE', 'S_WRTRACK',
    'S_WR_TRACK_DATA', 'S_TYPE1_CMD', 'S_STEP', 'S_SEEKSTART', 'S_RESTORE', 'S_SEEK', 'S_VERIFY', 'S_VERIFY2', 'S_WAIT_HLT', 'S_WAIT_HLT_RW', 'S_EJECT1', 'S_EJECT2'];
  function wdRows(t) {
    const f = (t || '').split('|'); if (f.length < 20) return [['—', '<span class="dim">no data</span>']];
    const hx = (v) => '#' + v, cmd = parseInt(f[0], 16), st = parseInt(f[1], 16), rq = parseInt(f[5], 16);
    const type1 = !(cmd & 0x80) || (cmd & 0xF0) === 0xD0; // type I and IV: index / track 0 / head loaded / seek error
    const bits = type1 ? ['WDS_BUSY', 'WDS_INDEX', 'WDS_TRK00', 'WDS_CRCERR', 'WDS_SEEKERR', 'WDS_HEADL', 'WDS_WRITEP', 'WDS_NOTRDY']
      : ['WDS_BUSY', 'WDS_DRQ', 'WDS_LOST', 'WDS_CRCERR', 'WDS_NOTFOUND', (cmd & 0xE0) === 0xA0 || (cmd & 0xF0) === 0xF0 ? 'WDS_WRFAULT' : 'WDS_RECORDT', 'WDS_WRITEP', 'WDS_NOTRDY'];
    const flags = (v, names) => { const n = names.filter((x, i) => x && (v >> i) & 1); return n.length ? ' <span class="dim">[' + n.join(' ') + ']</span>' : ''; };
    const yn = (v) => (v === '1' ? 'True' : 'False');
    return [['CMD', hx(f[0])], ['STATUS', hx(f[1]) + flags(st, bits)], ['TRK', hx(f[2])], ['SEC', hx(f[3])], ['DATA', hx(f[4])],
      ['beta', hx(f[5]) + flags(rq, [0, 0, 0, 0, 0, 0, 'DRQ', 'INTRQ'])], ['system', hx(f[6])],
      ['state', WD_STATES[+f[7]] || f[7]], ['state2', WD_STATES[+f[8]] || f[8]], ['drive', f[9]], ['side', f[10]],
      ['time', f[11]], ['next', f[12]], ['tshift', f[13]], ['rwptr', f[14]], ['rwlen', f[15]],
      ['CYL COUNT', f[16]], ['HEAD POS', f[17]], ['READY', yn(f[18])], ['TR00', yn(f[19])]];
  }
  const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  // the window is built once (again only when its rows change); then a value that changes gets a canvas of its own and
  // is redrawn there: text written into the page twice a second wakes ad blockers' page scans (stalls of ~1/3 s)
  const si = { sig: '', cells: [], vals: [] };
  const siCellHtml = (v) => (typeof v === 'string' && /<span/.test(v) ? v : esc(v));
  function siRender() {
    if (!E || $('sysinfo').hidden) return;
    const secs = siSections(), b = $('sibody');
    const sig = secs.map(([t, rows]) => t + ':' + rows.map((r) => r[0]).join(',')).join('|');
    const vals = []; secs.forEach(([, rows]) => rows.forEach((r) => vals.push(siCellHtml(r[1]))));
    if (sig !== si.sig) {
      const top = b.scrollTop;
      b.innerHTML = secs.map(([t, rows, kind]) => `<h4>${t}</h4>` + (kind === 'regs'
        ? '<div class="regs">' + rows.map(([a, v]) => `<b>${a}</b><span class="v">${siCellHtml(v)}</span>`).join('') + '</div>'
        : '<table>' + rows.map(([a, v]) => `<tr><td>${esc(a)}</td><td class="v">${siCellHtml(v)}</td></tr>`).join('') + '</table>')).join('');
      b.scrollTop = top;
      si.sig = sig; si.cells = [...b.querySelectorAll('.v')]; si.vals = vals;
      return;
    }
    vals.forEach((v, i) => { if (v !== si.vals[i]) { si.vals[i] = v; siLive(si.cells[i], v); } });
  }
  // a value on its canvas: the same font and colors, wrapped at spaces to the cell's width
  function siLive(cell, html) {
    let cv = cell.firstChild && cell.firstChild.tagName === 'CANVAS' ? cell.firstChild : null;
    if (!cv) { cell.textContent = ''; cv = document.createElement('canvas'); cv.className = 'sicv'; cell.appendChild(cv); }
    const dpr = window.devicePixelRatio || 1, cs = getComputedStyle(cell), W = cell.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    const key = html + '|' + W + '|' + dpr; if (cv.key === key) return; cv.key = key; cv.html = html;
    const g = cv.getContext('2d'), font = '12px ui-monospace, Consolas, monospace'; g.font = font;
    const un = (t) => t.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');
    const segs = []; html.split(/(<span class="dim">.*?<\/span>)/).forEach((p) => { if (!p) return; const m = /^<span class="dim">(.*)<\/span>$/.exec(p); segs.push([un((m ? m[1] : p).replace(/<[^>]+>/g, '')), !!m]); });
    // words (with their spaces) laid out in lines
    const lines = [[]]; let x = 0;
    for (const [t, dim] of segs) for (const w of t.match(/[^ ]+ *| +/g) || []) { // a word with its spaces (no look-behind: older Safari)
      const ww = g.measureText(w).width;
      if (x + ww > W && x > 0 && w.trim()) { lines.push([]); x = 0; }
      lines[lines.length - 1].push([w, dim, x]); x += ww;
    }
    const lh = 16, H = lines.length * lh;
    if (cv.style.height !== H + 'px') cv.style.height = H + 'px';
    const pw = Math.max(1, Math.round(W * dpr)), ph = Math.round(H * dpr);
    if (cv.width !== pw || cv.height !== ph) { cv.width = pw; cv.height = ph; }
    g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H); g.font = font; g.textBaseline = 'middle';
    const col = cs.color, dimc = getComputedStyle(document.documentElement).getPropertyValue('--dim').trim() || '#888';
    lines.forEach((ln, i) => ln.forEach(([w, dim, wx]) => { g.fillStyle = dim ? dimc : col; g.fillText(w, wx, i * lh + lh / 2 + 0.5); }));
  }
  function siText() {
    return siSections().map(([t, rows, kind]) => '[' + t + ']\n' + (kind === 'regs' ? rows.map(([a, v]) => a + '=' + v).join(' ') : rows.map(([a, v]) => a.padEnd(16) + String(v).replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&amp;/g, '&')).join('\n'))).join('\n\n');
  }
  function showSysInfo(v) {
    const w = $('sysinfo');
    w.hidden = !v; $('sibtn').classList.toggle('on', v);
    clearInterval(siTimer);
    if (v) {
      siFW.place(); siRender(); siTimer = setInterval(siRender, 500);
      if (window.ResizeObserver && !si.ro) { si.ro = new ResizeObserver(() => si.cells.forEach((c) => { if (c.firstChild && c.firstChild.tagName === 'CANVAS') siLive(c, c.firstChild.html); })); si.ro.observe($('sibody')); }
    }
    else canvas.focus();
  }
  // ------------------------------------------------------------------ Performance (Tools): live graphs of the machine's load
  // Z80: the part of each frame before a HALT; Host: browser time spent emulating; Memory: RAM pages written;
  // Disk: frames with drive activity; I/O: port accesses per frame; Frames: emulated frames per second
  const PF_N = 60, PF_DT = 500; // 60 samples, 2 a second (30 s)
  const pf = { host: 0, core: 0, frames: 0, disk: 0, diskW: 0, sums: null, t: 0, timer: null, tiles: {} };
  const PF_TILES = [
    { id: 'z80', name: 'Z80 code at', color: '#f0a050', max: 100 },
    { id: 'host', name: 'Host', color: '#5aa9ff', max: 100 },
    { id: 'mem', name: 'Memory', color: '#c084fc', max: 100 },
    { id: 'disk', name: 'Disk', color: '#4ade80', max: 100 },
    { id: 'io', name: 'I/O', color: '#22d3ee', max: 0 },
    { id: 'fps', name: 'Frames', color: '#facc15', max: 0, limit: 55 },
  ];
  // the value (top right) and the line under the graph are drawn on canvases too: text written into the page twice a
  // second wakes ad blockers' page scans (stalls of a third of a second); a canvas is redrawn only when its text changes
  function pfBuild() {
    const g = $('pfgrid'); g.innerHTML = '';
    for (const t of PF_TILES) {
      const el = document.createElement('div'); el.className = 'pft';
      el.innerHTML = `<div class="h"><span>${t.name}</span><canvas class="pv"></canvas></div><canvas class="pg"></canvas><canvas class="ps"></canvas>`;
      g.appendChild(el);
      pf.tiles[t.id] = { def: t, el, val: el.querySelector('.pv'), sub: el.querySelector('.ps'), cv: el.querySelector('.pg'), data: [], data2: [] };
      pfText(pf.tiles[t.id].val, '—', PF_VFONT, t.color, 'right');
    }
    if (window.ResizeObserver && !pf.ro) {
      pf.ro = new ResizeObserver(() => { for (const id in pf.tiles) { const t = pf.tiles[id]; for (const c of [t.val, t.sub]) if (c.txt) { c.key = ''; pfText(c, c.txt.text, c.txt.font, c.txt.color, c.txt.align); } } });
      pf.ro.observe(g);
    }
  }
  const PF_VFONT = '600 13px ui-monospace, Consolas, monospace', PF_SFONT = '10.5px ui-monospace, Consolas, monospace';
  function pfText(cv, text, font, color, align) {
    const dpr = window.devicePixelRatio || 1, w = Math.max(1, Math.round(cv.clientWidth * dpr)), h = Math.max(1, Math.round(cv.clientHeight * dpr));
    const key = [text, font, color, w, h].join('|');
    cv.txt = { text, font, color, align };
    if (cv.key === key) return;
    cv.key = key;
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    g.font = font; g.fillStyle = color; g.textBaseline = 'middle';
    const cw = w / dpr; let s = String(text);
    if (g.measureText(s).width > cw) { while (s.length > 1 && g.measureText(s + '…').width > cw) s = s.slice(0, -1); s += '…'; }
    g.textAlign = align === 'right' ? 'right' : 'left';
    g.fillText(s, align === 'right' ? cw : 0, h / dpr / 2 + 0.5);
  }
  function pfCanvas(cv) {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(cv.clientWidth * dpr)), h = Math.max(1, Math.round(cv.clientHeight * dpr));
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const g = cv.getContext('2d'); g.clearRect(0, 0, w, h);
    return { g, w, h, dpr };
  }
  // memory: one cell per 16K page, lit when written (fades out over a few seconds), mapped pages outlined
  function pfMemMap(tile, heat, mapped) {
    const { g, w, h, dpr } = pfCanvas(tile.cv), n = heat.length;
    const cols = n <= 8 ? 8 : n <= 64 ? 16 : 32, rows = Math.ceil(n / cols), gap = Math.max(1, Math.round(dpr));
    const cw = (w - gap * (cols - 1)) / cols, ch = Math.min((h - gap * (rows - 1)) / rows, cw * 1.6);
    const y0 = (h - (ch * rows + gap * (rows - 1))) / 2;
    for (let p = 0; p < n; p++) {
      const x = (p % cols) * (cw + gap), y = y0 + Math.floor(p / cols) * (ch + gap), v = heat[p];
      g.fillStyle = v > 0.02 ? `rgba(192,132,252,${(0.18 + 0.82 * v).toFixed(3)})` : 'rgba(255,255,255,.06)';
      g.fillRect(x, y, cw, ch);
      if (mapped.has(p)) { g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = gap; g.strokeRect(x + gap / 2, y + gap / 2, cw - gap, ch - gap); }
    }
  }
  // Z80: where the code runs in the 64K address space — 4 rows (16K banks) × 16 cells of 1K, brighter = more time there
  function pfZ80Map(tile, heat, banks) {
    const { g, w, h, dpr } = pfCanvas(tile.cv), lw = Math.round(26 * dpr), gap = Math.max(1, Math.round(dpr));
    const cw = (w - lw - gap * 15) / 16, ch = (h - gap * 3) / 4;
    g.font = `${Math.round(9 * dpr)}px ui-monospace, Consolas, monospace`; g.textBaseline = 'middle';
    for (let r = 0; r < 4; r++) {
      const y = r * (ch + gap);
      g.fillStyle = banks[r] < 0 ? 'rgba(240,160,80,.75)' : 'rgba(225,232,240,.55)';
      g.fillText(banks[r] < 0 ? 'ROM' : 'R' + banks[r], 0, y + ch / 2);
      for (let c = 0; c < 16; c++) {
        const v = heat[r * 16 + c], x = lw + c * (cw + gap);
        g.fillStyle = v > 0.02 ? `rgba(240,160,80,${(0.15 + 0.85 * v).toFixed(3)})` : 'rgba(255,255,255,.05)';
        g.fillRect(x, y, cw, ch);
      }
    }
  }
  function pfDraw(tile) {
    const { cv, data, def } = tile;
    const { g, w, h, dpr } = pfCanvas(cv);
    g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1;
    for (let i = 1; i < 4; i++) { const y = Math.round(h * i / 4) + .5; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
    const max = def.max || Math.max(def.limit ? def.limit * 1.25 : 8, ...data) * 1.15;
    if (data.length < 2) return;
    const x = (i) => w - (data.length - 1 - i) * (w / (PF_N - 1)), y = (v) => h - 1 - Math.min(1, v / max) * (h - 3);
    // a series drawn in its color; with a limit (Frames: real time), the part above it in red
    const paint = (color, clip, d = data, a = ['55', '08']) => {
      g.save();
      if (clip) { g.beginPath(); g.rect(0, clip[0], w, clip[1] - clip[0]); g.clip(); }
      g.beginPath(); g.moveTo(x(0), h); d.forEach((v, i) => g.lineTo(x(i), y(v))); g.lineTo(x(d.length - 1), h); g.closePath();
      const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, color + a[0]); gr.addColorStop(1, color + a[1]);
      g.fillStyle = gr; g.fill();
      if (d !== data) { g.restore(); return; } // Host's emulation part: the fill alone
      g.beginPath(); data.forEach((v, i) => (i ? g.lineTo(x(i), y(v)) : g.moveTo(x(i), y(v))));
      g.strokeStyle = color; g.lineWidth = 1.5 * dpr; g.lineJoin = 'round'; g.stroke();
      g.restore();
    };
    if (def.limit) {
      const yl = y(def.limit);
      paint(def.color, [yl, h]); paint('#f05252', [0, yl]);
      g.strokeStyle = 'rgba(240,82,82,.35)'; g.setLineDash([3 * dpr, 3 * dpr]); g.lineWidth = dpr;
      g.beginPath(); g.moveTo(0, Math.round(yl) + .5); g.lineTo(w, Math.round(yl) + .5); g.stroke(); g.setLineDash([]);
    } else {
      // Host: the emulation (core) a solid layer at the bottom, the picture (draw) the light part above it up to the line
      if (tile.data2 && tile.data2.length === data.length) paint(def.color, null, tile.data2, ['b0', '50']);
      paint(def.color);
    }
  }
  function pfPut(id, v, text, sub, over) {
    const t = pf.tiles[id]; t.data.push(v); if (t.data.length > PF_N) t.data.shift();
    t.over = !!over;
    pfText(t.val, text, PF_VFONT, over ? '#f05252' : t.def.color, 'right'); pfText(t.sub, sub, PF_SFONT, '#7d8794', 'left');
    if (id !== 'mem' && id !== 'z80') pfDraw(t);
  }
  function pfFrame(hostMs, coreMs) { pf.host += hostMs; pf.core += Math.min(coreMs, hostMs); }
  function pfDisk() { // per frame: the drive LED (1 read, 2 / 3 write)
    const k = new Uint8Array(E.memory.buffer, E.web_led(), 1)[0];
    if (k >= 1 && k <= 3) { pf.disk++; if (k > 1) pf.diskW++; }
    pf.frames++;
  }
  function pfSample() {
    if (!E) return;
    const now = performance.now(), dt = pf.t ? now - pf.t : PF_DT; pf.t = now;
    const r = new Uint32Array(E.memory.buffer, E.web_perf(), 6 + 256 + 64);
    const busy = r[1] ? r[0] / r[1] / 10 : 0, frames = pf.frames;
    // where the Z80 runs its code (sampled every 256 t-states): ROM (BIOS, BASIC, TR-DOS) or the program in RAM
    const code = r[4] + r[5], rom = code ? r[4] * 100 / code : 0;
    let hot = -1; for (let p = 0; p < 256; p++) if (r[6 + p] && (hot < 0 || r[6 + p] > r[6 + hot])) hot = p;
    // address map: share of the samples per 1K block, kept glowing for a moment
    if (!pf.zheat) pf.zheat = new Float32Array(64);
    let hmax = 0, hk = -1; for (let k = 0; k < 64; k++) if (r[262 + k] > hmax) { hmax = r[262 + k]; hk = k; }
    for (let k = 0; k < 64; k++) pf.zheat[k] = Math.max(pf.zheat[k] * 0.55, hmax ? Math.sqrt(r[262 + k] / hmax) : 0);
    const banks = [0, 1, 2, 3].map((a) => (E.web_gfx_page ? E.web_gfx_page(a) : -1));
    pfPut('z80', rom, hk >= 0 ? '#' + (hk << 10).toString(16).toUpperCase().padStart(4, '0') : '—',
      !r[1] ? (isPaused() ? 'paused' : 'stopped') : 'ROM ' + Math.round(rom) + '% · RAM ' + Math.round(100 - rom) + '% · busy ' + Math.round(busy) + '%');
    pfZ80Map(pf.tiles.z80, pf.zheat, banks);
    const host = pf.host / dt * 100;
    pf.tiles.host.data2.push(pf.core / dt * 100); if (pf.tiles.host.data2.length > PF_N) pf.tiles.host.data2.shift(); // the emulation part of it
    pfPut('host', host, Math.round(host) + '%', frames ? 'core ' + (pf.core / frames).toFixed(2) + ' · draw ' + ((pf.host - pf.core) / frames).toFixed(2) + ' ms' : 'idle');
    // RAM: pages (16K) whose contents changed since the last sample
    const n = E.web_gfx_size(1), ram = new Int32Array(E.memory.buffer, E.web_gfx_mem(1, 0, 0), n >> 2), pages = n >> 14;
    if (!pf.sums || pf.sums.length !== pages) { pf.sums = new Int32Array(pages); pf.heat = new Float32Array(pages); }
    let changed = 0;
    for (let p = 0; p < pages; p++) {
      let h = 0; const o = p << 12;
      for (let i = 0; i < 4096; i += 3) h = (h * 31 + ram[o + i]) | 0;
      pf.heat[p] *= 0.7;
      if (h !== pf.sums[p]) { changed++; pf.sums[p] = h; pf.heat[p] = 1; }
    }
    // RAM pages mapped into the Z80 address space right now (ATM / Pentagon paging): outlined in the map
    const mapped = new Set();
    for (let a = 0; a < 4; a++) { const pa = E.web_gfx_page ? E.web_gfx_page(a) : -1; if (pa >= 0) mapped.add(pa); }
    pfPut('mem', changed * 100 / pages, changed + ' / ' + pages, 'pages written · ' + (n >> 10) + ' KB');
    pfMemMap(pf.tiles.mem, pf.heat, mapped);
    const disk = frames ? pf.disk * 100 / frames : 0;
    pfPut('disk', disk, Math.round(disk) + '%', pf.disk ? (pf.diskW ? 'writing' : 'reading') + ' · ' + pf.disk + ' frames' : 'idle');
    const io = r[1] ? (r[2] + r[3]) / r[1] : 0;
    pfPut('io', io, Math.round(io) + '/f', r[1] ? 'in ' + Math.round(r[2] / r[1]) + ' · out ' + Math.round(r[3] / r[1]) + ' per frame' : 'idle');
    const fps = frames * 1000 / dt;
    pfPut('fps', fps, Math.round(fps), fps > 55 ? 'frames / s · faster than real time' : 'frames / s · target 50', fps > 55);
    pf.host = 0; pf.core = 0; pf.frames = 0; pf.disk = 0; pf.diskW = 0;
    const ms = model === 'EVO' ? 'ZXEVO' : model; if (pf.state !== ms) { pf.state = ms; $('pfstate').textContent = ms; } // only when the model changes
  }
  let pfFW = null, pfHelpFW = null;
  // the help opens at the Performance window's side (right, or left when there is no room) with the same height; then it can be dragged
  function pfHelp(v) {
    const h = $('pfhelp'), w = $('perfwin');
    if (!pfHelpFW) pfHelpFW = floatWin(h, 'pfhelppos', () => ({ x: 0, y: 0 }));
    h.hidden = !v; $('pfhelpbtn').classList.toggle('on', v);
    if (!v) return;
    const r = w.getBoundingClientRect();
    h.style.height = r.height + 'px'; pfHelpFW.setPos(snapRight(r, h));
  }
  function showPerf(v) {
    $('perfwin').hidden = !v; $('pfbtn').classList.toggle('on', v);
    if (!v) pfHelp(false);
    clearInterval(pf.timer); pf.timer = null;
    if (v) {
      if (!pf.tiles.z80) pfBuild();
      pfFW.place(); E && E.web_perf(); pf.t = performance.now(); pf.host = pf.core = pf.frames = pf.disk = pf.diskW = 0;
      pf.timer = setInterval(pfSample, PF_DT);
    } else canvas.focus();
  }
  function bindPerf() {
    pfFW = floatWin($('perfwin'), 'perfpos', () => {
      const r = $('screenwrap').getBoundingClientRect(), w = $('perfwin').offsetWidth, vw = document.documentElement.clientWidth;
      return { x: Math.max(4, Math.min(r.right - w - 8, vw - w - 4)), y: Math.max(8, r.top + 8) };
    });
    $('pfbtn').onclick = () => { toolsMenu(false); showPerf($('perfwin').hidden); };
    $('pfclose').onclick = () => showPerf(false);
    $('pfhelpbtn').onclick = (e) => { e.stopPropagation(); pfHelp($('pfhelp').hidden); };
    $('pfhelpclose').onclick = () => pfHelp(false);
    $('perfwin').addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); showPerf(false); } });
  }
  function bindSysInfo() {
    siFW = floatWin($('sysinfo'), 'sysinfopos', () => {
      const r = $('screenwrap').getBoundingClientRect(), w = $('sysinfo').offsetWidth, vw = document.documentElement.clientWidth;
      return { x: Math.max(4, Math.min(r.right - w - 8, vw - w - 4)), y: Math.max(8, r.top + 8) };
    });
    $('sibtn').onclick = () => { toolsMenu(false); showSysInfo($('sysinfo').hidden); };
    $('siclose').onclick = () => showSysInfo(false);
    $('sicopy').onclick = async () => {
      const t = siText();
      try { await navigator.clipboard.writeText(t); toast('System info copied'); }
      catch (e) { downloadBytes('sysinfo.txt', new TextEncoder().encode(t)); }
    };
    $('sysinfo').addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); showSysInfo(false); } });
  }

  // ------------------------------------------------------------------ REST API link builder (Tools): the link for the current machine, to copy
  const LINK_NAME = { ATM710: 'atm710', XBIOS136: 'xbios136', ATM450: 'atm450', EVO: 'evo', TSCONF: 'tsconf', SPRINTER: 'sprinter', PENTAGON: 'pentagon', ZX128: 'zx128', SCORPION: 'scorpion', GMX: 'gmx', PROFI: 'profi', KAY: 'kay', PLUS3: 'plus3', QUORUM: 'quorum', SAM: 'sam', NEXT: 'specnext', TASIS: 'tasis', CHIC: 'chic', NEDOOS: 'nedoos', OSZ: 'osz' };
  let raFW = null;
  const pageDir = () => location.href.replace(/[?#].*$/, '').replace(/[^/]*$/, '');
  function relUrl(u) { // a file on this site → its path next to index.html
    try { const x = new URL(u, location.href), d = pageDir(); return x.href.startsWith(d) ? decodeURI(x.href.slice(d.length)) : x.href; } catch (e) { return u; }
  }
  const linkEnc = (v) => encodeURIComponent(v).replace(/%2F/gi, '/').replace(/%3A/gi, ':').replace(/%7C/gi, '|');
  function raBuild() {
    const on = (k) => $('ra_' + k).checked, q = [], rom = on('rom') && $('rav_rom').value.trim();
    if (rom) q.push('rom=' + linkEnc(rom)); // the Custom ROM ZIP brings its machine: no model=
    else if (on('model')) { q.push('model=' + $('rav_model').value); if ($('rav_model').value === 'pentagon') q.push('ram=' + $('rav_ram').value); } // always: with no ram= another browser takes its own Options one
    $('rav_ram').hidden = $('rav_model').value !== 'pentagon'; $('rav_ram').disabled = !!rom || !on('model');
    $('rav_model').disabled = $('ra_model').disabled = !!rom;
    const tc = $('ra_trueclk').checked && !$('ra_trueclk').disabled;
    $('rav_speed').disabled = $('ra_speed').disabled = tc;
    if (tc) q.push('trueclock=1');
    else if (on('speed')) q.push('speed=' + $('rav_speed').value);
    if (on('a') && $('rav_a').value.trim()) q.push('fdd=' + $('rav_fdrv').value + ':' + linkEnc($('rav_a').value.trim()));
    if (on('hdd') && $('rav_hdd').value.trim()) q.push('hdd' + $('rav_hdrv').value + '=' + linkEnc($('rav_hdd').value.trim()));
    if (on('sd') && $('rav_sd').value.trim()) q.push('sd=' + linkEnc($('rav_sd').value.trim()));
    if (on('sd2') && $('rav_sd2').value.trim()) q.push('mmc=' + linkEnc($('rav_sd2').value.trim()));
    if (on('gk') && $('rav_gk').value.trim()) q.push('gotek=' + $('rav_gkd').value + ':' + linkEnc($('rav_gk').value.trim()));
    if (on('sdtime') && $('rav_sdtime').value !== '0') q.push('sdtiming=' + ['ideal', 'realistic', 'slow'][+$('rav_sdtime').value] + ($('rav_sdtime').value === '1' ? '&sdseed=' + sdSeed : ''));
    const st = $('rav_start').value;
    const nedo = !rom && $('rav_model').value === 'nedoos', nopt = $('rav_start').querySelector('option[value="nedoos"]');
    if (nopt.hidden === nedo) nopt.hidden = !nedo; // nedoos=: only with the NedoOS model
    if (st === 'nedoos' && !nedo) { $('rav_start').value = ''; return raBuild(); }
    $('ral_run').hidden = $('rar_run').hidden = st !== 'run'; $('ral_cpm').hidden = $('rav_cpm').hidden = st !== 'cpm';
    $('ral_nedo').hidden = $('rav_nedo').hidden = st !== 'nedoos';
    $('ral_press').hidden = $('rav_press').hidden = st !== 'autorun';
    if (st === 'autorun') { q.push('autorun=' + ($('rav_start').dataset.ar || 'boot')); if ($('rav_press').value.trim()) q.push('press=' + linkEnc($('rav_press').value.trim())); } // use boot.b (a list entry's own autorun= kept)
    if (st === 'run') { const f = ($('rav_run').hidden ? $('rav_runtxt').value : $('rav_run').value).trim(); q.push(f ? 'run=' + linkEnc(f) : 'autorun=1'); } // no name: its boot, or its first BASIC program
    if (st === 'cpm' && $('rav_cpm').value.trim()) q.push('cpm=' + linkEnc($('rav_cpm').value.trim()));
    if (st === 'nedoos' && $('rav_nedo').value.trim()) q.push('nedoos=' + linkEnc($('rav_nedo').value.trim()));
    if (on('xt')) q.push('xt=1');
    if (on('mute')) q.push('mute=1');
    if (on('swapmouse')) q.push('swapmouse=1');
    if (on('hidemenu')) q.push('hidemenu=1');
    if (on('kbd')) q.push('kbd=' + $('rav_kbd').value);
    if (on('fx')) q.push('fx=' + $('rav_fx').value);
    $('raout').value = location.href.replace(/[?#].*$/, '') + (q.length ? '?' + q.join('&') : '');
    let note = '';
    if (st === 'cpm' && !rom && !CPM_MODELS.includes($('rav_model').value.toUpperCase())) note = 'cpm= needs model atm710 / evo';
    // ATM CP/M sees only drive A: of the emulator (its B:) and only HDD 0 (its C:)
    const it = srvList.find((x) => relUrl(x.url) === $('rav_a').value.trim()), cpm = st === 'cpm' || !!(it && it.cpm);
    const warn = [];
    if (cpm && on('a') && $('rav_fdrv').value === 'b') warn.push("fdd b: doesn't work with ATM CP/M, use a:");
    if (cpm && on('hdd') && $('rav_hdrv').value === '1') warn.push("hdd1 doesn't work with ATM CP/M, use hdd0");
    if (warn.length) note = (note ? note + '; ' : '') + warn.join('; ');
    if (on('rom') && !rom) note = 'rom=: put the path or URL of a Custom ROM ZIP';
    if (/[=:]brw:/i.test($('raout').value)) note = (note ? note + '; ' : '') + 'brw: files are in this browser only: the link works here, not on another device';
    $('ranote').textContent = note;
  }
  function raFiles() {
    const dl = $('ra_files'); dl.innerHTML = '';
    for (const it of srvList) { if (!it.url || (it.rp && !it.rp.a) || it.kind === 'hdd' || it.kind === 'sd') continue; const o = document.createElement('option'); o.value = relUrl(it.url); o.label = it.name + (it.cpm ? ' [CP/M]' : ''); o.textContent = o.label; dl.appendChild(o); }
    const add = (dl, v, name) => { if ([...dl.options].some((o) => o.value === v)) return; const o = document.createElement('option'); o.value = v; o.label = name; o.textContent = name; dl.appendChild(o); };
    const hl = $('ra_hdds'); hl.innerHTML = '';
    for (const it of hddList) add(hl, relUrl(it.url), it.name);
    const sl = $('ra_sds'); sl.innerHTML = '';
    for (const it of sdList) add(sl, relUrl(it.url), it.name);
    // server list entries whose link mounts an SD card or an HDD (sd=, hdd=): in those lists too
    for (const it of srvList) if (it.rp && it.url) { if (it.rp.sd && !it.rp.a) add(sl, relUrl(it.url), it.name); else if ((it.rp.hdd || it.rp.hdd1) && !it.rp.a) add(hl, relUrl(it.url), it.name); }
    // the files of Browser storage (when there are any): brw:NAME, its disks / HDDs / SD cards in those lists
    brwList().then((ms) => {
      for (const m of ms) {
        if (!m || m.dir || !m.name) continue;
        const k = m.kind || brwKind(m.name, ''), v = 'brw:' + encodeURI(m.name), nm = m.name.replace(/^.*\//, '') + ' [Browser]';
        if (k === 'hdd') add(hl, v, nm); else if (k === 'sd') add(sl, v, nm); else if (k === 'disk') add($('ra_files'), v, nm);
      }
    });
  }
  // a list entry (trd.json, hdd.json, sd.json) with its own "run" link chosen in a file field: the whole link goes into the
  // fields once (machine, clock, drives, start, keyboard…); then they can be changed
  function raApplyRun(it) {
    const rp = it && it.rp; if (!rp) return false;
    raEntryModel(it);
    const set = (k, v) => { $('ra_' + k).checked = !!v; };
    const tc = /^(1|on|yes|true)$/i.test(rp.trueclock || ''); if (!$('ra_trueclk').disabled) $('ra_trueclk').checked = tc;
    const fd = rp.a ? 'a' : rp.b ? 'b' : ''; if (fd) { $('rav_fdrv').value = fd; $('rav_a').value = relUrl(rp[fd]); } set('a', fd);
    const hd = rp.hdd ? '0' : rp.hdd1 ? '1' : ''; if (hd) { $('rav_hdrv').value = hd; $('rav_hdd').value = relUrl(hd === '0' ? rp.hdd : rp.hdd1); } set('hdd', hd);
    if (rp.sd) $('rav_sd').value = relUrl(rp.sd); set('sd', rp.sd);
    const st = $('rav_start'); st.dataset.ar = '';
    if (rp.cpm) { st.value = 'cpm'; $('rav_cpm').value = rp.cpm; }
    else if (rp.nedoos) { st.value = 'nedoos'; $('rav_nedo').value = rp.nedoos; }
    else if (rp.run) { st.value = 'run'; const sel = $('rav_run'); if ([...sel.options].some((o) => o.value === rp.run)) sel.value = rp.run; $('rav_runtxt').value = rp.run; }
    else if (rp.autorun && (rp.autorun !== '1' || rp.press !== undefined)) { st.value = 'autorun'; st.dataset.ar = rp.autorun; $('rav_press').value = rp.press || ''; }
    else if (rp.autorun) { st.value = 'run'; $('rav_run').value = ''; $('rav_runtxt').value = ''; }
    else st.value = '';
    for (const k of ['xt', 'mute', 'swapmouse', 'hidemenu']) set(k, /^(1|on|yes|true)$/i.test(rp[k] || ''));
    if (rp.kbd) $('rav_kbd').value = rp.kbd; set('kbd', rp.kbd);
    if (rp.fx) $('rav_fx').value = FX_LINK[rp.fx] || rp.fx; set('fx', rp.fx);
    $('rav_ram').value = String(PENT_RAMS.includes(+rp.ram) ? +rp.ram : pentRam());
    return true;
  }
  // a server list entry with its own link chosen in a file field: its machine (and the clock of its link) come along
  function raEntryModel(it) {
    if (!it || !it.rp) return;
    const mk = linkModelKey(it.rp.model); if (!mk || !LINK_NAME[mk]) return;
    $('rav_model').value = LINK_NAME[mk]; $('ra_model').checked = true; raSpeedOpts();
    if (it.rp.speed) { const sp = $('rav_speed'), v = String(parseFloat(it.rp.speed)); if ([...sp.options].some((o) => o.value === v)) { sp.value = v; $('ra_speed').checked = true; } }
  }
  function raPicked(d) { // a disk from files.json chosen: its tag decides the start (CP/M: atm710, ATM mode, cpm=)
    const v = $('rav_a').value.trim(); $('ra_a').checked = !!v;
    const it = srvList.find((x) => relUrl(x.url) === v);
    if (raApplyRun(it)) return; // its own link: as it is
    if (!it || !it.cpm) return;
    $('rav_model').value = 'atm710'; $('ra_model').checked = true; $('ra_xt').checked = true; $('rav_start').value = 'cpm';
    if (!$('rav_cpm').value.trim() && !d) $('rav_cpm').value = 'b:'; // drive A: of the emulator is B: in CP/M (its B: is not seen)
  }
  // the boot the emulator added on load (boot6.$b: Hobeta, 17-byte header) — not on the disk a link brings
  function emuBoot(v, x) {
    if (x.name.trim() !== 'boot' || x.zx.type !== 'B' || !fs.exists('boot6.$b')) return false;
    const h = new Uint8Array(fs.read('boot6.$b')), n = h[11] | (h[12] << 8), d = v.read(x).data;
    if (h.length < 17 + n || d.length < n) return false;
    for (let i = 0; i < n; i++) if (d[i] !== h[17 + i]) return false;
    return true;
  }
  // speed=: the clock slider steps; tsconf: the CPU Speed of TS-BIOS, 3.5 / 7 / 14 MHz
  function raSpeedOpts() {
    const sp = $('rav_speed'), rm = $('rav_model').value, spr = rm === 'sprinter', ts = rm === 'tsconf' || spr, kind = spr ? 'sp' : ts ? 'ts' : 'x';
    if (sp.dataset.kind !== kind) {
      sp.innerHTML = ''; sp.dataset.kind = kind;
      if (ts) for (const m of spr ? ['3.5', '21'] : ['3.5', '7', '14']) { const o = document.createElement('option'); o.value = m; o.textContent = m + ' MHz'; sp.appendChild(o); }
      else SPEEDS.forEach((x) => { const o = document.createElement('option'); o.value = String(x); o.textContent = x + 'x (' + (3.5 * x).toFixed(2).replace(/\.?0+$/, '') + ' MHz)'; sp.appendChild(o); });
    }
    $('ra_trueclk').disabled = ts; $('ra_trueclk').closest('label').hidden = ts; // TS-Conf: its own clock always
    if (spr) { const no = M() === 'SPRINTER' && E && E.web_sp_noturbo && E.web_sp_noturbo(-1); sp.value = no ? '3.5' : '21'; $('ra_speed').checked = !!no; } // Sprinter: 21 MHz as the program sets, or 3.5 only
    else if (ts) { const m = isTS() && E && E.web_ts_mult ? E.web_ts_mult() : 1; sp.value = m >= 4 ? '14' : m >= 2 ? '7' : '3.5'; $('ra_speed').checked = isTS() && m > 1; }
    else { sp.value = String(SPEEDS[speedIdx]); $('ra_speed').checked = SPEEDS[speedIdx] !== MODELS[model].speed; }
  }
  function raFill() {
    raFiles();
    const ms = $('rav_model');
    if (!ms.options.length) for (const [k, v] of Object.entries(LINK_NAME)) { const o = document.createElement('option'); o.value = v; o.textContent = v + ' — ' + MODELS[k].name; ms.appendChild(o); }
    ms.value = LINK_NAME[model] || ms.value;
    $('rav_rom').value = model === 'CUSTOM' && romLinkUrl ? relUrl(romLinkUrl) : ''; $('ra_rom').checked = !!$('rav_rom').value; // a Custom ROM from a file of this computer has no URL: put the ZIP on a site
    $('ra_trueclk').checked = trueClk() && !MODELS[model].fixed;
    raSpeedOpts();
    const durl = (i) => (drives[i] && drives[i].url && E.web_disk_present(i) ? relUrl(drives[i].url) : '');
    const fd = durl(0) || !durl(1) ? 0 : 1, u = durl(fd); // the disk in A: (or in B: when A: has none from the site)
    $('rav_fdrv').value = fd ? 'b' : 'a'; $('rav_a').value = u; $('ra_a').checked = !!u;
    const hsrc = (d) => (hdds[d] && hddSrc[d] && !OS_MODELS[model] ? relUrl(hddSrc[d]) : '');
    const dflt = (u) => /(^|\/)cpm\.(zip|hdd)$/i.test(u); // the default cpm.zip in HDD 0 needs no hdd0=
    const hd = (hsrc(0) && !dflt(hsrc(0))) || !hsrc(1) ? 0 : 1, h = hsrc(hd);
    $('rav_hdrv').value = String(hd); $('rav_hdd').value = h; $('ra_hdd').checked = !!h && !(hd === 0 && dflt(h));
    const sv = sdName && sdSrc && !(OS_MODELS[model] && OS_MODELS[model].sd) ? relUrl(sdSrc) : '';
    $('rav_sd').value = sv; $('ra_sd').checked = !!sv;
    const sv2 = sd2Name && sd2Src && dmOn() ? relUrl(sd2Src) : '';
    $('rav_sd2').value = sv2; $('ra_sd2').checked = !!sv2;
    const gv = usbName && usbSrc && gkDrive() >= 0 ? relUrl(usbSrc) : '';
    $('rav_gk').value = gv; $('ra_gk').checked = !!gv; if (gkDrive() >= 0) $('rav_gkd').value = gkDrive() ? 'b' : 'a';
    $('rav_sdtime').value = String(sdTiming()); $('ra_sdtime').checked = sdTiming() > 0;
    // run=: BASIC and code files of the TR-DOS disk in A:
    const sel = $('rav_run'); sel.innerHTML = '';
    let names = [];
    if (E.web_disk_present(0)) {
      setName('__ra.trd');
      if (E.web_disk_peek_trd(0)) {
        const img = new Uint8Array(fs.read('__ra.trd'));
        if (img[0x8E7] === 0x10) { const v = UnrealFC._test.trdos(img); names = v.list().filter((x) => (x.zx.type === 'B' || x.zx.type === 'C') && !emuBoot(v, x)).map((x) => x.name.trim() + ' <' + x.zx.type + '>'); }
      }
      try { fs.remove('__ra.trd'); } catch (e) {}
    }
    if (names.length) { const o = document.createElement('option'); o.value = ''; o.textContent = '— its boot or first BASIC —'; sel.appendChild(o); }
    names.forEach((n) => { const o = document.createElement('option'); o.value = n.replace(/ <.>$/, ''); o.textContent = n; sel.appendChild(o); });
    sel.hidden = !names.length; $('rav_runtxt').hidden = !!names.length;
    $('ra_xt').checked = !!E.web_xt_kbd() && MODELS[model].xt; $('ra_mute').checked = muted; $('ra_swapmouse').checked = !!(E.web_mouse_swap && E.web_mouse_swap(-1));
    $('rav_kbd').value = $('vkbd').hidden ? 'off' : (vkbd && vkbd.tab) || 'zx';
    $('ra_hidemenu').checked = bare;
    $('rav_ram').value = String(model === 'PENTAGON' ? pentRun || pentRam() : pentRam()); // the running Pentagon's, else the one of Options
    raBuild();
  }
  function showRest(v) {
    $('restwin').hidden = !v; $('rabtn').classList.toggle('on', v);
    if (!v) raHelp(false);
    if (v) { raFill(); raFW.place(); } else canvas.focus();
  }
  function bindRest() {
    raFW = floatWin($('restwin'), 'restpos', () => {
      const r = $('screenwrap').getBoundingClientRect(), w = $('restwin').offsetWidth, vw = document.documentElement.clientWidth;
      return { x: Math.max(4, Math.min(r.left + (r.width - w) / 2, vw - w - 4)), y: Math.max(8, r.top + 40) };
    });
    $('rabtn').onclick = () => { toolsMenu(false); showRest($('restwin').hidden); };
    $('raclose').onclick = () => showRest(false);
    $('rav_a').addEventListener('change', () => raPicked($('rav_fdrv').value === 'b' ? 1 : 0)); $('rav_hdd').addEventListener('change', () => { const v = $('rav_hdd').value.trim(); $('ra_hdd').checked = !!v; raApplyRun(hddList.concat(srvList).find((x) => x.rp && relUrl(x.url) === v)); });
    $('rav_sd').addEventListener('change', () => { const v = $('rav_sd').value.trim(); $('ra_sd').checked = !!v; raApplyRun(sdList.concat(srvList).find((x) => x.rp && relUrl(x.url) === v)); });
    $('rav_start').addEventListener('change', () => { $('rav_start').dataset.ar = ''; }); // chosen by hand: boot.b as usual
    $('rav_kbd').addEventListener('change', () => { $('ra_kbd').checked = true; });
    $('rav_sd2').addEventListener('change', () => { $('ra_sd2').checked = !!$('rav_sd2').value.trim(); });
    $('rav_gk').addEventListener('change', () => { $('ra_gk').checked = !!$('rav_gk').value.trim(); });
    $('rav_sdtime').addEventListener('change', () => { $('ra_sdtime').checked = $('rav_sdtime').value !== '0'; });
    $('rav_fx').addEventListener('change', () => { $('ra_fx').checked = true; });
    $('rav_model').addEventListener('change', raSpeedOpts); // before raBuild: tsconf has its own speed= values
    $('restwin').addEventListener('input', raBuild); $('restwin').addEventListener('change', raBuild);
    $('restwin').addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); showRest(false); } });
    $('racopy').onclick = async () => {
      try { await navigator.clipboard.writeText($('raout').value); toast('Link copied'); }
      catch (e) { $('raout').select(); document.execCommand && document.execCommand('copy'); toast('Link selected — copy it'); }
    };
    $('raopen').onclick = () => window.open($('raout').value, '_blank');
    $('rav_rom').addEventListener('input', () => { $('ra_rom').checked = !!$('rav_rom').value.trim(); });
    $('rahelpbtn').onclick = (e) => { e.stopPropagation(); raHelp($('rahelp').hidden); };
    $('rahelpclose').onclick = () => raHelp(false);
  }
  // help of the Load window: at its side, as the REST API help
  let ldHelpFW = null;
  function ldHelp(v) {
    const h = $('ldhelp'), w = $('loadwin');
    if (!ldHelpFW) ldHelpFW = floatWin(h, 'ldhelppos', () => ({ x: 0, y: 0 }));
    h.hidden = !v; $('ldhelpbtn').classList.toggle('on', v);
    if (!v) return;
    const r = w.getBoundingClientRect();
    h.style.height = Math.max(r.height, 420) + 'px'; ldHelpFW.setPos(snapRight(r, h));
  }
  // help of the Save window: at its side, as Load's
  let svHelpFW = null;
  function svHelp(v) {
    const h = $('svhelp'), w = $('savedlg');
    if (!svHelpFW) svHelpFW = floatWin(h, 'svhelppos', () => ({ x: 0, y: 0 }));
    h.hidden = !v; $('svhelpbtn').classList.toggle('on', v);
    if (!v) return;
    const r = w.getBoundingClientRect();
    h.style.height = Math.max(r.height, 420) + 'px'; svHelpFW.setPos(snapRight(r, h));
  }
  // help of the REST API window: at its side (right, or left when there is no room), the same height; then it can be dragged
  let raHelpFW = null;
  function raHelp(v) {
    const h = $('rahelp'), w = $('restwin');
    if (!raHelpFW) raHelpFW = floatWin(h, 'rahelppos', () => ({ x: 0, y: 0 }));
    h.hidden = !v; $('rahelpbtn').classList.toggle('on', v);
    if (!v) return;
    const r = w.getBoundingClientRect();
    h.style.height = Math.max(r.height, 360) + 'px'; raHelpFW.setPos(snapRight(r, h));
  }

  // ------------------------------------------------------------------ UI
  function updateUI() {
    if (!E) return;
    hddUI(); eff7UI(); ldStoreUI();
    const xt = E.web_xt_kbd(), xtt = xt ? 'XT-Keyboard: on' : 'XT-Keyboard: off';
    $('xt').classList.toggle('on', !!xt);
    if ($('xt').title !== xtt) $('xt').title = xtt;
    for (let i = 0; i < NDRIVES; i++) {
      const present = E.web_disk_present(i);
      const el = $('drv' + i);
      el.querySelector('.dname').textContent = present ? (drives[i] ? drives[i].name : cstr(E.web_disk_name(i)).replace(/^.*[\\/]/, '')) : '— empty —';
      el.classList.toggle('changed', !!(present && E.web_disk_changed(i)));
      el.querySelector('.save').disabled = !present;
      el.querySelector('.eject').disabled = !present;
      el.querySelector('.wp').checked = !!E.web_get_wp(i);
    }
  }

  // ------------------------------------------------------------------ HDD: IDE images (interface and geometry from unreal.ini)
  const HDD_DEFAULT = { url: 'hdd/cpm.hdd', name: 'cpm.hdd' }; // mounted as master by default
  const NHDD = 2, HDN = ['0', '1'];
  const hdds = [null, null];  // name of the image in the in-memory FS (survives model switches)
  let hddIni = null, hddDefaultTried = false;
  const hddGeom = (d) => { try { return JSON.parse(load('hdd.geo' + d)) || hddIni[d]; } catch (e) { return hddIni[d]; } };
  function hddMount(d) {
    const g = hddGeom(d);
    setName(hdds[d] || '');
    const ok = E.web_hdd_mount(d, g.c, g.h, g.s, g.lba, g.ro ? 1 : 0);
    if (hdds[d] && !ok) { toast('HDD ' + d + ': cannot open ' + hdds[d], true); hdds[d] = null; }
    return ok;
  }
  // HDD interface per machine: ZX-Evolution defaults to NEMO-DIVIDE, the rest keep the old common choice
  // ZX-Evolution: the IDE is built in (NEMO-DIVIDE ports) — always on: software probes it (NedoOS hung at "Drive D mounted"
  // with no controller: the ports read #FF = busy forever)
  // by memory model: +3 has its µPD765 on #2FFD/#3FFD, which the ATM IDE ports would hide (the ROM hangs at start) — no IDE;
  // Profi / Scorpion / KAY: their usual interfaces (PROFI, SMUC, NEMO)
  const HDD_IF_DEF = { ATM3: '4', TSL: '4', PLUS3: '0', QUORUM: '0', PROFI: '6', SCORPION: '5', PROFSCORP: '5', KAY: '2' }, HDD_IF_FIXED = { ATM3: '4', TSL: '4', PLUS3: '0', SPRINTER: '1' }; // ZX Evo (BaseConf and TS-Conf): the NEMO IDE is built in
  const himem = () => (MODELS[model].ini.MISC && MODELS[model].ini.MISC.HIMEM) || 'ATM710';
  const hddKey = () => (model === 'CUSTOM' ? 'CUSTOM.' + himem() : M());
  const hddIfPref = () => { const h = himem(); if (HDD_IF_FIXED[h]) return HDD_IF_FIXED[h];
    const xi = crX().hdd ? IF_NAMES.indexOf(String(crX().hdd).toUpperCase()) : -1; if (xi >= 0) return String(xi); // a Custom ROM ZIP's interface
    const v = load('hdd.if.' + hddKey()); return v !== null ? v : HDD_IF_DEF[h] !== undefined ? HDD_IF_DEF[h] : load('hdd.if'); };
  async function applyHdd() {
    if (!hddIni) hddIni = [0, 1].map((d) => ({ c: E.web_hdd_get(d, 0), h: E.web_hdd_get(d, 1), s: E.web_hdd_get(d, 2), lba: 0, ro: !!E.web_hdd_get(d, 4) })); // LBA 0 = size of the image (the ini LBA is a real drive's)
    const sc = hddIfPref();
    if (sc !== null) E.web_hdd_scheme(+sc);
    if (!hddDefaultTried && E.web_hdd_scheme(-1) !== 0 && !OS_MODELS[model] && /^(ATM710|PENTAGON)$/.test(himem())) { // the default image: fetched once, only when an interface is on (an OS model brings its own)
      hddDefaultTried = true;
      // hdd/cpm.zip (CPM.zip) first — image + geometry from the archive — then the plain hdd/cpm.hdd
      let ok = false;
      for (const u of ['hdd/cpm.zip', 'hdd/CPM.zip']) {
        try { await hddFromBytes(0, 'cpm.zip', await fetchBytes(u), true); ok = !!hdds[0]; if (ok) { hddSrc[0] = u; break; } } catch (e) {}
      }
      if (!ok) {
        try { if (await hddFromBytes(0, HDD_DEFAULT.name, await fetchBytes(HDD_DEFAULT.url), true)) hddSrc[0] = HDD_DEFAULT.url; } // as any image: its own geometry (not the one kept from another image of the last session)
        catch (e) { log('no default HDD image: hdd/cpm.zip, ' + HDD_DEFAULT.url); }
      }
    }
    for (let d = 0; d < NHDD; d++) hddMount(d);
    cpmDirApply();
    hddUI();
  }
  // ATM CP/M drive C: (HDD 0 in the BIOS 1.07 layout) with DirEntries= in its .chs: the HDD table in ROM gets that number
  // (CP/M builds the DPB from it at start), so the machine is reset when it changes. Other disks leave the ROM as it is.
  let cpmDirNoReset = false; // Load with Autostart off: the ROM is patched, the machine is not reset
  function cpmDirApply() {
    if (!E || !E.web_rom_dirents || !hdds[0] || !E.web_hdd_get(0, 5)) return '';
    const cur = E.web_rom_dirents(0), g = hddGeom(0);
    if (!cur || (g.parts && g.parts.length)) return '';
    const want = g.dir || 128;
    if (want === cur) return '';
    E.web_rom_dirents(want);
    if (cpmDirNoReset) return ` · CP/M C: directory ${want} entries from the next CP/M start (Reset)`;
    E.web_reset(0);
    return ` · CP/M C: directory ${want} entries (machine reset)`;
  }
  const hddDirty = [false, false]; // written since mounted / saved (by the emulator or File Commander)
  const hddSrc = [null, null];       // the server URL of the image (for the REST API link)
  function hddUI() {
    if (!E || !hddIni) return;
    $('hddif').value = String(E.web_hdd_scheme(-1));
    $('hddif').disabled = !!HDD_IF_FIXED[himem()]; $('hddif').title = himem() === 'ATM3' || himem() === 'TSL' ? 'ZX Evo: the IDE is built in (NEMO-DIVIDE)' : himem() === 'SPRINTER' ? 'Sprinter: its own IDE (ports set by the BIOS)' : himem() === 'PLUS3' ? 'Spectrum +3: no IDE (its floppy controller uses the same ports)' : '';
    for (let d = 0; d < NHDD; d++) {
      const el = $('hdd' + d), g = hddGeom(d), on = !!E.web_hdd_get(d, 5);
      el.querySelector('.dname').textContent = on ? hdds[d] + (hddDirty[d] ? ' *' : '') : '— empty —';
      el.querySelector('.save').disabled = !on; el.querySelector('.eject').disabled = !on;
      el.querySelector('.wp').checked = !!g.ro;
      const geo = $('hddgeo' + d);
      if (document.activeElement !== geo.querySelector('.chs')) geo.querySelector('.chs').value = g.c + '/' + g.h + '/' + g.s;
      if (document.activeElement !== geo.querySelector('.lba')) geo.querySelector('.lba').value = g.lba;
    }
    // master and slave share one interface: say when the images are for different ones (or not for the one chosen)
    const sc = E.web_hdd_scheme(-1), want = [0, 1].map((d) => (hdds[d] && E.web_hdd_get(d, 5) ? hddGeom(d).iface : undefined));
    const known = want.filter((x) => x !== undefined);
    let warn = '';
    if (known.length === 2 && known[0] !== known[1]) warn = `HDD images for different interfaces: HDD 0 ${IF_NAMES[known[0]]}, HDD 1 ${IF_NAMES[known[1]]} (one interface serves both)`;
    else if (known.length && sc && known.some((x) => x !== sc)) warn = want.map((x, d) => (x !== undefined && x !== sc ? `HDD ${d} is for ${IF_NAMES[x]}` : '')).filter(Boolean).join(', ') + `, interface is ${IF_NAMES[sc]}`;
    $('hddwarn').textContent = warn;
    ldStoreUI();
  }
  // HDD image from a file or a ZIP: the biggest file (or .hdd / .img / .hdf) is the image; a *.chs file next to it
  // in the archive describes the disk (no .chs: the geometry from the size, 16 heads × 63 sectors, or unreal.ini):
  //   # comment                       (also after a value)
  //   CHS=400/16/63                   cylinders / heads / sectors
  //   CPM=D 1-5                       a CP/M drive: letter, first-last cylinder
  //   ISDOS=C 103-135                 an iS-DOS / TASiS drive
  //   Interface=ATM                   the HDD interface it is for (NONE ATM NEMO NEMO-A8 NEMO-DIVIDE SMUC PROFI DIVIDE): switched on when mounted
  //   DirEntries=512                  ATM CP/M drive C: with a bigger directory (BIOS 1.07 has 128): the ROM table is changed while it is mounted
  // without CPM= / ISDOS= lines the disk is one CP/M drive in the ATM BIOS 1.07 layout
  const HDD_EXT = /\.(hdd|img|hdf|ima|raw|bin|vhd)$/i;
  const IF_NAMES = ['NONE', 'ATM', 'NEMO', 'NEMO-A8', 'NEMO-DIVIDE', 'SMUC', 'PROFI', 'DIVIDE']; // = Options / Disk / HDD / Interface
  function parseChs(t) {
    const out = { parts: [] };
    for (const raw of t.split(/\r?\n/)) {
      const ln = raw.replace(/#.*/, '').trim(), note = (/#\s*(.*)$/.exec(raw) || ['', ''])[1].trim(); if (!ln) continue;
      const m = /^(\w+)\s*=\s*(.*)$/.exec(ln); if (!m) continue;
      const k = m[1].toUpperCase(), v = m[2];
      let x;
      if (k === 'CHS' && (x = /^(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)$/.exec(v))) Object.assign(out, { c: +x[1], h: +x[2], s: +x[3] });
      else if (k === 'INTERFACE' && IF_NAMES.includes(v.trim().toUpperCase().replace(/[\s_]+/g, '-'))) out.iface = IF_NAMES.indexOf(v.trim().toUpperCase().replace(/[\s_]+/g, '-'));
      else if ((k === 'DIRENTRIES' || k === 'DIR') && [64, 128, 256, 512, 1024].includes(+v.trim())) out.dir = +v.trim();
      else if ((k === 'CPM' || k === 'ISDOS') && (x = /^([A-Z])\s+(\d+)\s*-\s*(\d+)$/i.exec(v)) && +x[3] >= +x[2])
        out.parts.push({ fs: k.toLowerCase(), letter: x[1].toUpperCase(), c0: +x[2], c1: +x[3], note });
    }
    return out.c ? { c: out.c, h: out.h, s: out.s, lba: 0, parts: out.parts, text: t, iface: out.iface, dir: out.dir } : null;
  }
  // a text file in any of the usual encodings: UTF-16 (Windows Notepad "Unicode"), UTF-8, 8-bit
  function textOf(b) {
    if (b[0] === 0xFF && b[1] === 0xFE) return new TextDecoder('utf-16le').decode(b.subarray(2));
    if (b[0] === 0xFE && b[1] === 0xFF) return new TextDecoder('utf-16be').decode(b.subarray(2));
    let z = 0; for (let i = 1; i < Math.min(b.length, 64); i += 2) if (!b[i]) z++;
    if (z > 8) return new TextDecoder('utf-16le').decode(b); // UTF-16 without a BOM
    return new TextDecoder('latin1').decode(b);
  }
  async function hddUnpack(name, buf) {
    if (!UnrealZip.isZip(buf)) return { name, img: buf, geo: null };
    const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name));
    const imgs = all.filter((e) => HDD_EXT.test(e.name));
    const e = (imgs.length ? imgs : all).reduce((a, b) => (b.size > a.size ? b : a), { size: -1 });
    if (!e.name) throw new Error('HDD: the archive is empty');
    let geo = null, geoFrom = '';
    const chs = all.find((x) => x !== e && /\.chs$/i.test(x.name));
    if (chs) {
      geoFrom = chs.name.replace(/^.*[\\/]/, '');
      geo = parseChs(textOf(await UnrealZip.extract(buf, chs)));
      if (!geo) throw new Error('HDD: no CHS= line in ' + geoFrom);
    }
    return { name: e.name.replace(/^.*[\\/]/, ''), img: await UnrealZip.extract(buf, e), geo, geoFrom };
  }
  async function hddFromBytes(d, name, buf, quiet) {
    if (!quiet && !await loseOk(['hdd' + d])) return false; // the image there has unsaved changes
    try {
      const r = await hddUnpack(name.replace(/[:\\/]/g, '_'), buf);
      let geo = r.geo;
      const im = r.img, vhd = im.length > 512 && String.fromCharCode(...im.subarray(im.length - 512, im.length - 504)) === 'conectix';
      if (!geo && vhd) { const v = new DataView(im.buffer, im.byteOffset + im.length - 512, 512); if (v.getUint16(56) && im[im.length - 512 + 58] && im[im.length - 512 + 59]) geo = { c: v.getUint16(56), h: im[im.length - 512 + 58], s: im[im.length - 512 + 59], lba: 0 }; } // a fixed VHD: the geometry of its footer
      if (!geo && (im.length - (vhd ? 512 : 0)) % (16 * 63 * 512) === 0) geo = { c: (im.length - (vhd ? 512 : 0)) / (16 * 63 * 512), h: 16, s: 63, lba: 0 };
      // nothing known: the unreal.ini geometry, not the one left from another image
      const base = geo || hddIni[d];
      store('hdd.geo' + d, JSON.stringify(Object.assign({}, hddGeom(d), { c: Math.min(16383, base.c), h: Math.min(16, base.h), s: Math.min(63, base.s), lba: base.lba || 0, parts: (geo && geo.parts) || [], chs: (geo && geo.text) || '', iface: geo ? geo.iface : undefined, dir: geo ? geo.dir : undefined })));
      const nm = r.name.replace(/[:\\/]/g, '_');
      fs.write(nm, r.img);
      hdds[d] = nm; hddDirty[d] = false; hddSrc[d] = null;
      const g = hddGeom(d);
      // Interface= of the .chs: switched on now (and kept for this machine); ZX-Evolution has its own built in
      let ifNote = '';
      const want = r.geo ? r.geo.iface : undefined;
      if (want !== undefined) {
        const own = HDD_IF_FIXED[himem()] || (himem() !== 'ATM710' && himem() !== 'PENTAGON' ? HDD_IF_DEF[himem()] : undefined); // a machine with its own IDE keeps it
        if (own !== undefined && +own !== want) ifNote = ` · the .chs says ${IF_NAMES[want]}, ${MODELS[model] ? MODELS[model].name : 'this machine'} keeps ${IF_NAMES[+own]} (its BIOS will not boot this disk)`;
        else if (own === undefined) {
          store('hdd.if.' + hddKey(), String(want)); E.web_hdd_scheme(want); hddMount(0); hddMount(1); ifNote = ' · interface ' + IF_NAMES[want];
        }
      } else if (!HDD_IF_FIXED[himem()] && !quiet) ifNote = ' · no Interface= in ' + (r.geo ? r.geoFrom : 'a .chs') + ': choose it in Options / Disk / HDD (now ' + IF_NAMES[E.web_hdd_scheme(-1)] + ')';
      const okm = hddMount(d); if (okm) ifNote += cpmDirApply();
      if (okm && !quiet) toast('HDD ' + d + ': ' + nm + ' · ' + g.c + '/' + g.h + '/' + g.s + (r.geo ? ' (from ' + r.geoFrom + ')' : geo ? ' (from the size)' : ' (unreal.ini: no .chs file)') + (g.parts && g.parts.length ? ', ' + g.parts.length + ' drives' : '') + ifNote, !!ifNote && /no Interface|built in|keeps/.test(ifNote));
    } catch (err) { if (!quiet) toast(err.message, true); else throw err; hddUI(); return false; }
    hddUI(); return true;
  }
  // ------------------------------------------------------------------ SD card on the Z-Controller (ZX-Evolution has one built in)
  // the image lives in the page's file system; the core opens it through WASI (ZC=1, [ZC] SDCARD=name)
  let sdName = null, sdDirty = false, sdSrc = null, sdList = [];
  let sdWcOwn = false; // the card's only changes are disks copied onto it for Wild Commander (wcDiskToSd): still "wc.zip as it was"
  const SD_EXT = /\.(img|vhd|bin|sd|ima)$/i;
  const sdBuiltIn = () => M() === 'EVO' || M() === 'TSCONF' || M() === 'NEXT'; // ZX-Evolution (BaseConf, TS-Conf): the Z-Controller is built in; the Next: its SD slot
  const sdOn = () => sdBuiltIn() || (load('sd.if.' + M()) || '1') === '1'; // the Z-Controller, per machine (on by default; built into ZX-Evolution)
  function sdMount() { // after a (re)start of the emulator too
    if (!E || !E.web_sd_mount) return false;
    if (!sdName || !fs.exists(sdName) || !sdOn()) { E.web_sd_mount(0); return false; }
    setName(sdName); return !!E.web_sd_mount(load('sd.ro') === '1' ? 2 : 1);
  }
  // an SD card ZIP may have a .json next to the image: { "run": "path/file.spg" } — the file Wild Commander starts (TS-Conf)
  // it may also say the machine of the card and disks of the ZIP for the drives: { "model": "gmx", "a": "OS.TRD" } (OSZ)
  let sdRun = '', sdCfg = null;
  async function zipCfg(buf, all) { // the card's .json (null: none)
    for (const e of all.filter((x) => /\.json$/i.test(x.name) && x.size < 65536)) {
      try { const j = jsonC(new TextDecoder().decode(await UnrealZip.extract(buf, e))); if (j && (typeof j === 'string' || typeof j === 'object')) return typeof j === 'string' ? { run: j } : j; } catch (err) {}
    }
    return null;
  }
  async function zipRun(buf, all) {
    const j = await zipCfg(buf, all), r = j && (j.run || j.autorun || j.start || j.file);
    return typeof r === 'string' && r.trim() ? r.trim().replace(/\\/g, '/').replace(/^\/+/, '') : '';
  }
  const cardModel = (j) => { const m = j && typeof j.model === 'string' ? linkModelKey(j.model) : null; return m && MODELS[m] ? m : null; };
  async function cardDisks(buf, all, j) { // "a": … "d": the disk images of the ZIP named in its .json
    const out = [];
    if (j) ['a', 'b', 'c', 'd'].forEach((k, i) => {
      const want = typeof j[k] === 'string' ? j[k].replace(/\\/g, '/').replace(/^\/+/, '').toLowerCase() : '';
      const e = want && all.find((x) => x.name.toLowerCase() === want || x.name.toLowerCase().endsWith('/' + want));
      if (e) out.push({ drive: i, e });
    });
    for (const d of out) { d.name = d.e.name.replace(/^.*[\\/]/, ''); d.data = await UnrealZip.extract(buf, d.e); delete d.e; }
    return out;
  }
  // the disks of the card (its .json) into the drives; auto: A: boots (no disks: the machine boots its SD card)
  async function sdDisks(auto, skip) {
    const ds = sdCfg ? sdCfg.disks.filter((d) => !(skip && skip[d.drive])) : [];
    if (!ds.length) return false;
    for (const d of ds) { autorunNext = d.drive === 0 ? auto : false; try { await putAndInsert(d.name, d.data, d.drive); } catch (err) { toast(d.name + ': ' + err.message, true); } }
    autorunNext = false; return true;
  }
  // a ZIP with an SD card image and a .json that names its machine: that machine starts with the card (and the disks of the .json)
  async function cardZip(name, buf) {
    const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name));
    if (!all.some((e) => SD_EXT.test(e.name) && e.size >= 1 << 20)) return false;
    const m = cardModel(await zipCfg(buf, all));
    if (!m) return false;
    const auto = autorunNext; autorunNext = false;
    if (m !== model) { toast(name + ': an SD card for ' + MODELS[m].name); await setModel(m, true); if (model !== m) return true; }
    if (!await sdFromBytes(name, buf)) return true;
    sdEnable();
    if (!await sdDisks(auto) && auto) sdBoot();
    else if (M() === 'NEXT') nxCardMounted();
    return true;
  }
  // the Z-Controller on for this machine (kept), and the card mounted: when it was off, or always (remount)
  function nxCardMounted() { E.web_reset(0); toast('SD card: ' + sdName + ' · NextZXOS boots (the Next looks for its card at the start)'); }
  function sdEnable(remount) { const was = sdOn(); if (!was) store('sd.if.' + M(), '1'); if (remount || !was) { sdMount(); sdUI(); } }
  async function sdFromBytes(name, buf, atStart) {
    if (!atStart && !await loseOk(['sd'])) return false; // the card there has unsaved changes
    try {
      let nm = name, img = buf, run = '', cfg = null;
      if (UnrealZip.isZip(buf)) { // the biggest file of the archive (or an .img / .vhd)
        const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name)), imgs = all.filter((e) => SD_EXT.test(e.name));
        const e = (imgs.length ? imgs : all).reduce((a, b) => (b.size > a.size ? b : a), { size: -1 });
        if (!e.name) throw new Error('SD: the archive is empty');
        nm = e.name.replace(/^.*[\\/]/, ''); img = await UnrealZip.extract(buf, e);
        run = await zipRun(buf, all);
        const j = await zipCfg(buf, all), ds = await cardDisks(buf, all, j);
        if (cardModel(j) || ds.length) cfg = { model: cardModel(j), disks: ds };
      }
      if (img.length < 524288) throw new Error('SD: the image is too small (at least 512 KB)');
      nm = nm.replace(/[:\\/]/g, '_');
      if (sdName && sdName !== nm) try { fs.remove(sdName); } catch (e) {}
      try { for (const b of UnrealFC._test.fatFind(img)) { const v = UnrealFC._test.fatVol(img, b); if (v.fsinfoHint) v.fsinfoHint(); } } catch (e) {} // FatFs (NedoOS) looks for a free cluster from there
      fs.write(nm, img); sdName = nm; sdDirty = false; sdWcOwn = false; sdSrc = null; sdRun = run; sdCfg = cfg;
      const ok = sdMount();
      if (ok) toast('SD card: ' + nm + ' · ' + Math.round(img.length / 1048576) + ' MB' + (M() === 'EVO' && !atStart ? ' — press Reset: the EVO Reset Service looks for the card at start' : ''));
      else if (!sdOn()) toast('SD card: ' + nm + ' (the Z-Controller is off: Options / Disk / SD card)');
      else toast('SD card: cannot open ' + nm, true);
      if (ok && M() === 'GMX' && E.web_gmx_cold) E.web_gmx_cold(); // GMX: its shadow monitor looks for the card at power-on only (a card put in: power off / on)
    } catch (err) { toast(err.message, true); sdUI(); return false; }
    sdUI(); return true;
  }
  function sdUI() {
    const el = $('sdcard'); if (!el) return;
    const on = !!(sdName && fs.exists(sdName));
    el.querySelector('.dname').textContent = on ? sdName + (sdDirty ? ' *' : '') : '— empty —';
    el.querySelector('.save').disabled = !on; el.querySelector('.eject').disabled = !on;
    const n = on ? fs.read(sdName).length : 0;
    $('sdgeo').querySelector('.sz').textContent = on ? (n >= 1048576 ? Math.round(n / 1048576) + ' MB' : Math.round(n / 1024) + ' KB') : '';
    $('sdif').value = sdOn() ? '1' : '0'; $('sdif').disabled = sdBuiltIn(); $('sdif').title = sdBuiltIn() ? 'ZX Evo: the Z-Controller is built in' : ''; el.querySelector('.wp').checked = load('sd.ro') === '1';
    el.classList.toggle('off', !sdOn());
    ldStoreUI();
  }
  // a fixed VHD: the raw disk + a 512-byte footer ("conectix", big-endian); an image that has one already is left as it is
  function vhdFixed(a) {
    if (a.length >= 512 && String.fromCharCode(...a.subarray(a.length - 512, a.length - 504)) === 'conectix') return a;
    const n = a.length, f = new Uint8Array(512), v = new DataView(f.buffer);
    f.set([...'conectix'].map((c) => c.charCodeAt(0)));
    v.setUint32(8, 2); v.setUint32(12, 0x10000); v.setUint32(16, 0xFFFFFFFF); v.setUint32(20, 0xFFFFFFFF);
    v.setUint32(24, ((Date.now() / 1000) | 0) - 946684800); f.set([117, 110, 114, 108], 28); v.setUint32(32, 0x10000); f.set([87, 105, 50, 107], 36);
    v.setUint32(40, Math.floor(n / 4294967296)); v.setUint32(44, n >>> 0); v.setUint32(48, Math.floor(n / 4294967296)); v.setUint32(52, n >>> 0);
    const cyl = Math.min(65535, Math.ceil(n / 512 / (16 * 63))); v.setUint16(56, cyl); f[58] = 16; f[59] = 63; v.setUint32(60, 2);
    crypto.getRandomValues(f.subarray(68, 84));
    let sum = 0; for (let i = 0; i < 512; i++) sum += f[i]; v.setUint32(64, (~sum) >>> 0);
    const out = new Uint8Array(n + 512); out.set(a); out.set(f, n); return out;
  }
  async function loadSdList() {
    sdList = await fetchList('sd/sd.json');
    const sel = $('sdgeo').querySelector('.srv');
    sel.innerHTML = '<option value="" hidden disabled selected>Select from server</option>';
    sdList.forEach((it, i) => { if (!it.url) return; const o = document.createElement('option'); o.value = i; o.textContent = it.name; sel.appendChild(o); });
    if (sel.options.length < 2) { const o = document.createElement('option'); o.disabled = true; o.textContent = 'sd/sd.json: nothing there'; sel.appendChild(o); }
    sel.hidden = false;  srvShow(); mmcFill();
  }
  function bindSd() {
    const el = $('sdcard'), pick = $('sdfile');
    pick.onchange = async (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) await sdFromBytes(f.name, new Uint8Array(await f.arrayBuffer())); canvas.focus(); };
    el.querySelector('.ins').onclick = () => pick.click();
    el.querySelector('.save').onclick = () => openSave('sd');
    $('sdgeo').querySelector('.srv').addEventListener('pointerdown', () => { if (!sdList.length) loadSdList(); }); // sd.json put there later
    el.querySelector('.eject').onclick = async () => {
      if (sdName && sdDirty && !sdWcOwn && !await askBox('SD card', sdName + ' was modified. Eject without saving?', 'Eject')) return;
      if (sdName) try { fs.remove(sdName); } catch (e) {} sdName = null; sdSrc = null; sdMount(); sdUI(); };
    el.querySelector('.wp').onchange = (e) => { store('sd.ro', e.target.checked ? '1' : '0'); sdMount(); sdUI(); };
    $('sdif').onchange = (e) => { store('sd.if.' + M(), e.target.value); sdMount(); sdUI(); };
    el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drop'); });
    el.addEventListener('dragleave', () => el.classList.remove('drop'));
    el.addEventListener('drop', async (e) => { e.preventDefault(); e.stopPropagation(); el.classList.remove('drop'); const f = e.dataTransfer.files[0]; if (f) await sdFromBytes(f.name, new Uint8Array(await f.arrayBuffer())); });
    $('sdgeo').querySelector('.srv').onchange = async (e) => {
      const it = e.target.value === '' ? null : sdList[+e.target.value]; if (!it) return;
      try { if (await sdFromBytes(it.url.replace(/^.*\//, ''), await fetchBytes(it.url))) sdSrc = it.url; } catch (err) { toast(err.message, true); }
      srvShow();
    };
    sdUI();
  }
  // ------------------------------------------------------------------ DivMMC on Pentagon: esxDOS (rom/esxmmc.zip / .rom), its own SD card (MMC;
  // sd2* in the code) and the waits of a real card (Options / Disk / Timing: both cards). A link: divmmc=1, mmc=card, sdtiming=, sdseed=
  let mmcFill = () => {};
  let sd2Name = null, sd2Dirty = false, sd2Src = null, dmRom = null; // dmRom: null not fetched yet, false none on the site
  let dmLink = null, tmLink = null, sdSeed = (Math.random() * 4294967296) >>> 0;
  const DM_MODELS = ['PENTAGON', 'ZX128', 'SCORPION'], DM_WHERE = 'Pentagon, ZX Spectrum 128 and Scorpion ZS 256'; // DivMMC and Gotek
  const dmHere = () => DM_MODELS.includes(M());
  const dmOn = () => dmHere() && (dmLink !== null ? dmLink : load('divmmc') === '1');
  const sdTiming = () => (tmLink !== null ? tmLink : +(load('sdtiming') || 0)) || 0;
  async function dmApply() { // after a (re)start of the emulator: the power of the interface (its RAM, MAPRAM cleared)
    if (!E || !E.web_dm_set) return;
    E.web_sd_timing(sdTiming(), sdSeed);
    if (!dmOn()) { E.web_dm_set(0); dmUI(); return; }
    if (dmRom === null) { // ESXMMC.BIN of esxDOS, as the other ROMs: rom/esxmmc.zip (the .rom / .bin inside), rom/esxmmc.rom; or rom/esxmmc.bin
      dmRom = false;
      try { dmRom = await fetchSrv('esxmmc.rom'); } catch (e) { try { dmRom = await fetchBytes(ROM_DIR + 'esxmmc.bin'); } catch (e2) {} }
    }
    E.web_dm_set(1);
    if (dmRom) { const p = E.malloc(dmRom.length); new Uint8Array(E.memory.buffer, p, dmRom.length).set(dmRom); try { E.web_dm_rom(p, dmRom.length); } finally { E.free(p); } }
    else E.web_dm_rom(0, 0);
    sd2Mount(); dmUI();
  }
  function sd2Mount() {
    if (!E || !E.web_dm_card) return false;
    if (!dmOn() || !sd2Name || !fs.exists(sd2Name)) { E.web_dm_card(0, 0); return false; }
    setName(sd2Name); return !!E.web_dm_card(E.web_namebuf(), load('sd2.ro') === '1' ? 1 : 0);
  }
  // an MMC card from Load / the server list / File Commander: the DivMMC on (kept on; Pentagon if this machine has none), the card in;
  // boot: from the power on and a reset (esxDOS starts with it), else the machine stays (esxDOS finds it at its next reset)
  async function mmcPut(name, buf, boot) {
    if (!dmHere()) { toast(name + ': an MMC card — ' + MODELS.PENTAGON.name + ' starts'); await setModel('PENTAGON', true); if (!dmHere()) return false; }
    if (!dmOn()) { dmLink = null; store('divmmc', '1'); await dmApply(); if (!boot && E) E.web_reset(0); }
    return sd2FromBytes(name, buf, false, !boot);
  }
  async function sd2FromBytes(name, buf, atStart, noReset) {
    if (!atStart && !await loseOk(['sd2'])) return false;
    try {
      let nm = name, img = buf;
      if (UnrealZip.isZip(buf)) {
        const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name)), imgs = all.filter((e) => SD_EXT.test(e.name));
        const e = (imgs.length ? imgs : all).reduce((a, b) => (b.size > a.size ? b : a), { size: -1 });
        if (!e.name) throw new Error('MMC: the archive is empty');
        nm = e.name.replace(/^.*[\\/]/, ''); img = await UnrealZip.extract(buf, e);
      }
      if (img.length < 524288) throw new Error('MMC: the image is too small (at least 512 KB)');
      if (img.length >= 512 && String.fromCharCode(...img.subarray(img.length - 512, img.length - 504)) === 'conectix' && img.length % 512 === 0) img = img.slice(0, img.length - 512); // a fixed VHD: the raw disk
      nm = nm.replace(/[:\\/]/g, '_');
      if (sdName && sdName.toLowerCase() === nm.toLowerCase()) nm = 'mmc_' + nm; // the Z-Controller's card has that name
      if (sd2Name && sd2Name !== nm) try { fs.remove(sd2Name); } catch (e) {}
      fs.write(nm, img); sd2Name = nm; sd2Dirty = false; sd2Src = null;
      const ok = sd2Mount();
      if (ok && dmOn() && !noReset) { await dmApply(); if (E) E.web_reset(0); } // a card in: the DivMMC from the power on, esxDOS starts with it (a warm reset keeps its state of before)
      if (ok) toast('MMC (DivMMC): ' + nm + ' · ' + Math.round(img.length / 1048576) + ' MB' + (dmOn() && !noReset ? ' · the machine restarts' : ''));
      else if (!dmOn()) toast('MMC: ' + nm + (dmHere() ? ' (the DivMMC is off: Options / Disk / DivMMC)' : ' (the DivMMC is on ' + DM_WHERE + ' only)'));
      else toast('MMC: cannot open ' + nm, true);
    } catch (err) { toast(err.message, true); dmUI(); return false; }
    dmUI(); return true;
  }
  // the card image as it is now (writes flushed): 0 the Z-Controller's, 1 the DivMMC's (tests: UnrealDebug.sdImage)
  const cardImage = (w) => (w === 'usb' ? usbImage() : sdImage(w === 'mmc' || w === 'sd2' || w === 1 ? 1 : 0));
  function sdImage(n) {
    const nm = n ? sd2Name : sdName; if (!nm || !fs.exists(nm)) return null;
    if (E && E.web_sd_flush) E.web_sd_flush(n ? 1 : 0);
    return fs.read(nm).slice();
  }
  function dmUI() {
    const box = $('dmbox'); if (!box) return;
    const pent = dmHere(), on = dmOn(), el = $('sd2card'), have = !!(sd2Name && fs.exists(sd2Name));
    box.hidden = !pent;
    $('dmon').checked = on;
    el.querySelector('.dname').textContent = have ? sd2Name + (sd2Dirty ? ' *' : '') : '— empty —';
    el.querySelector('.save').disabled = !have; el.querySelector('.eject').disabled = !have;
    el.querySelector('.wp').checked = load('sd2.ro') === '1';
    el.classList.toggle('off', !on);
    $('dmnote').textContent = !on ? '' : dmRom === false ? 'rom/esxmmc.zip (or .rom) not found: DivMMC without esxDOS (ESXMMC.BIN of esxDOS 0.8.9 goes there).' : '';
    $('sdtime').value = String(sdTiming());
  }
  function bindDm() {
    const el = $('sd2card'), pick = $('sd2file');
    const restart = async () => { await dmApply(); if (E) E.web_reset(0); };
    $('dmon').onchange = async (e) => { dmLink = null; store('divmmc', e.target.checked ? '1' : '0'); await restart(); toast('DivMMC ' + (e.target.checked ? 'on' + (dmRom === false ? ' (no rom/esxmmc.zip)' : '') : 'off') + ' · the machine restarts'); };
    const srv = $('sd2geo').querySelector('.srv');
    const fill = mmcFill = () => { // sd/sd.json: the cards tagged MMC (esxDOS) first, the others after them (esxDOS sees them as drives)
      srv.innerHTML = '<option value="" hidden disabled selected>Select from server</option>';
      const mmc = (it) => /\bMMC\b/.test(it.tag || '');
      sdList.map((it, i) => [it, i]).filter(([it]) => it.url).sort((a, b) => mmc(b[0]) - mmc(a[0])).forEach(([it, i]) => { const o = document.createElement('option'); o.value = i; o.textContent = it.name; srv.appendChild(o); });
      if (srv.options.length < 2) { const o = document.createElement('option'); o.disabled = true; o.textContent = 'sd/sd.json: nothing there'; srv.appendChild(o); }
    };
    srv.addEventListener('pointerdown', () => { if (!sdList.length) loadSdList(); }); // sd.json put there later (as the SD card's list)
    fill();
    srv.onchange = async (e) => {
      const it = e.target.value === '' ? null : sdList[+e.target.value]; if (!it) return;
      try { // the card, then the DivMMC on (if off), then a reset: esxDOS looks for its card as it starts
        const b = await fetchBytes(it.url);
        if (!dmOn()) { dmLink = null; store('divmmc', '1'); await dmApply(); }
        if (await sd2FromBytes(it.url.replace(/^.*\//, ''), b)) sd2Src = it.url;
      } catch (err) { toast(err.message, true); }
      srv.value = '';
    };
    $('sdtime').onchange = (e) => { tmLink = null; store('sdtiming', e.target.value); if (E && E.web_sd_timing) E.web_sd_timing(sdTiming(), sdSeed); };
    pick.onchange = async (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) await sd2FromBytes(f.name, new Uint8Array(await f.arrayBuffer())); canvas.focus(); };
    el.querySelector('.ins').onclick = () => pick.click();
    el.querySelector('.save').onclick = () => openSave('sd2');
    el.querySelector('.eject').onclick = async () => {
      if (sd2Name && sd2Dirty && !await askBox('MMC card', sd2Name + ' was modified. Eject without saving?', 'Eject')) return;
      if (sd2Name) try { fs.remove(sd2Name); } catch (e) {} sd2Name = null; sd2Src = null; sd2Mount(); dmUI(); };
    el.querySelector('.wp').onchange = (e) => { store('sd2.ro', e.target.checked ? '1' : '0'); if (E && E.web_dm_ro) E.web_dm_ro(e.target.checked ? 1 : 0); dmUI(); };
    el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drop'); });
    el.addEventListener('dragleave', () => el.classList.remove('drop'));
    el.addEventListener('drop', async (e) => { e.preventDefault(); e.stopPropagation(); el.classList.remove('drop'); const f = e.dataTransfer.files[0]; if (f) await sd2FromBytes(f.name, new Uint8Array(await f.arrayBuffer())); });
    dmUI();
  }
  // ------------------------------------------------------------------ Gotek with FlashFloppy (Pentagon): its USB stick an image here,
  // its slots the images of the stick's root; Direct Access in the core (web_gotek.cpp), the slot mounted here
  let usbName = null, usbDirty = false, usbSrc = null, gkOn = false, gkSlots = [], gkStale = false, gkStaleAt = 0, gkLink = null, gkRmLink = null, gkFwLink = null;
  const gkFw = () => (gkFwLink !== null ? gkFwLink : load('gotek.fw') === '344' ? 344 : 342); // FlashFloppy 3.42 / 3.44m1
  const gkDrive = () => (!dmHere() ? -1 : gkLink !== null ? gkLink : +(load('gotek') || -1));
  const gkRemount = () => (gkRmLink !== null ? gkRmLink : +(load('gotek.remount') || 500));
  function usbVol() { // the stick's FAT volume: { vol, v0, v1 } or null
    if (!usbName || !fs.exists(usbName)) return null;
    const a = fs.read(usbName), T = UnrealFC._test, b = T.fatFind(a)[0];
    if (b === undefined) return null;
    try { const vol = T.fatVol(a, b), [v0, v1] = vol.bounds(); return { vol, v0, v1 }; } catch (e) { return null; }
  }
  // FlashFloppy 3.42 with no display (main.c native_dir_next, image.c image_valid): the slots are the image files of the stick's
  // root (not hidden, not a dot name, not empty; adf: a whole number of tracks), sorted by the full name, A-Z as a-z
  // (strcmp_lower); a name: the long one when all its characters are in CP437 (FatFs), else the short one byte for byte, its
  // Latin letters small by the NT case flags
  const GK_EXT = ['adf', 'atr', 'd81', 'dsk', 'hdm', 'hfe', 'img', 'ima', 'out', 'sf7', 'st', 'adl', 'adm', 'mbd', 'mgt', 'fdi', 'trd', 'opd', 'ssd', 'dsd', 'sdu', 'jvc', 'vdk', 'v9t9', 'xdf'];
  const CP437 = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ';
  const cp437enc = (t) => { const b = new Uint8Array(t.length); for (let i = 0; i < t.length; i++) { const c = t.charCodeAt(i); if (c >= 0x20 && c < 0x7F) b[i] = c; else { const k = CP437.indexOf(t[i]); if (k < 0) return null; b[i] = 0x80 + k; } } return b; };
  const cp437dec = (b) => { let t = ''; for (const c of b) { if (!c) break; t += c < 0x80 ? String.fromCharCode(c) : CP437[c - 0x80]; } return t; };
  const lowA = (c) => (c >= 65 && c <= 90 ? c + 32 : c);
  const cmpLower = (x, y) => { for (let i = 0; ; i++) { const d = lowA(x[i] || 0) - lowA(y[i] || 0); if (d || i >= x.length) return d; } };
  // 3.44m1 (master, native_dir_cmp): the name up to the dot of its extension first ("GAME.DSK" before "GAME 2.DSK"), then the extension
  const cmpBase = (x, y) => {
    const bx = x.lastIndexOf(0x2E) < 0 ? x.length : x.lastIndexOf(0x2E), by = y.lastIndexOf(0x2E) < 0 ? y.length : y.lastIndexOf(0x2E);
    for (let i = 0; i < bx && i < by; i++) { const d = lowA(x[i]) - lowA(y[i]); if (d) return d; }
    return bx - by || cmpLower(x.subarray(bx), y.subarray(by));
  };
  const bytesEq = (x, y) => x.length === y.length && x.every((c, i) => c === y[i]);
  function gkFfName(u, e) { // the name as FlashFloppy has it (bytes)
    const L = e.long && cp437enc(e.long); if (L) return L;
    const a = u.vol.raw, o = e.o, nt = a[o + 12], out = [];
    for (let k = 0; k < 8 && a[o + k] !== 0x20; k++) out.push(nt & 0x08 ? lowA(a[o + k]) : a[o + k]);
    if (a[o + 8] !== 0x20) { out.push(0x2E); for (let k = 8; k < 11 && a[o + k] !== 0x20; k++) out.push(nt & 0x10 ? lowA(a[o + k]) : a[o + k]); }
    if (out[0] === 0x05) out[0] = 0xE5;
    return new Uint8Array(out);
  }
  function gkList() {
    const u = usbVol(); if (!u) return [];
    u.vol.setPath([]);
    const out = [];
    for (const x of u.vol.list()) {
      if (x.up || x.dir || !x.id) continue;
      const e = x.id; if (e.attr & 0x02 || !e.size) continue; // hidden, empty
      const b = gkFfName(u, e); if (b[0] === 0x2E) continue; // a dot name
      const dot = b.lastIndexOf(0x2E), ext = dot < 0 ? '' : String.fromCharCode(...b.subarray(dot + 1, dot + 8)).toLowerCase();
      if (!GK_EXT.includes(ext) || (ext === 'adf' && e.size % (2 * 11 * 512))) continue;
      out.push({ name: cp437dec(b), bytes: b, it: x, trd: ext === 'trd' });
    }
    const cmp = gkFw() === 344 ? cmpBase : cmpLower;
    return out.sort((x, y) => cmp(x.bytes, y.bytes));
  }
  function gkSendSlots(slot) {
    gkSlots = gkList(); gkStale = false;
    const n = gkSlots.length, len = gkSlots.reduce((t, x) => t + x.bytes.length + 1, 0);
    const p = E.malloc(len + n + 1), m = new Uint8Array(E.memory.buffer); let o = p;
    for (const x of gkSlots) { m.set(x.bytes, o); o += x.bytes.length; m[o++] = 0; }
    E.web_gk_slots(p, 0, n, slot); E.free(p);
  }
  // IMAGE_A.CFG (main.c): in the folder FF when the stick has it, else in the root; made (empty) when the Gotek starts, the name
  // of the image written to it on each selection; the slot at a start is the image of that name (none: slot 0, the file emptied)
  function gkCfgDir(u) { u.vol.setPath([]); const f = u.vol.list().find((x) => x.dir && !x.up && x.name.toUpperCase() === 'FF'); u.vol.setPath(f ? [f.name] : []); }
  function gkCfgFile(u) { gkCfgDir(u); return u.vol.list().find((x) => !x.dir && !x.up && (x.ext ? x.name + '.' + x.ext : x.name).toUpperCase() === 'IMAGE_A.CFG'); }
  function gkCfgPut(u, bytes) { gkCfgDir(u); try { u.vol.put('IMAGE_A.CFG', bytes); usbDirty = true; } catch (e) { log('Gotek: IMAGE_A.CFG: ' + e.message); } u.vol.setPath([]); }
  function gkStartSlot() { // the Gotek starts with this stick: its IMAGE_A.CFG read (made when there is none)
    const u = usbVol(); if (!u) return 0;
    const f = gkCfgFile(u);
    if (!f) { gkCfgPut(u, new Uint8Array(0)); return 0; }
    let b = u.vol.read(f).data; if (b.length >= 3 && b[b.length - 3] === 0x5C && b[b.length - 2] === 0x45 && b[b.length - 1] === 0x4A) b = b.subarray(0, b.length - 3); // \EJ: ejected
    u.vol.setPath([]);
    if (!b.length) return 0;
    const i = b.includes(0x2F) ? -1 : gkSlots.findIndex((x) => bytesEq(x.bytes, b)); // a folder path: none (no folders with no display)
    if (i < 0) { gkCfgPut(u, new Uint8Array(0)); return 0; } // IMAGE_A.CFG is bad: cleared
    return i;
  }
  const GK_ERR = { 1: 'disk error', 30: 'stick full', 31: 'bad image', 34: 'no images' };
  let gkErr = 0;
  // the slot into the drive (its TRD: a disk; another image type: mounted, no sectors for the WD1793), its blocks on the stick to
  // the core; dirty: a selection, IMAGE_A.CFG written first (as FlashFloppy does: before the image opens, so a bad image is
  // chosen again at the next start)
  function gkMount(slot, dirty) {
    const d = gkDrive(), u = usbVol();
    E.web_gk_map(0, 0);
    if (drives[d] && drives[d].gotek && fs.exists(drives[d].name)) try { fs.remove(drives[d].name); } catch (e) {}
    if (E.web_disk_present(d)) E.web_eject(d);
    drives[d] = null;
    gkSendSlots(-1);
    let st = 0;
    if (!u || !gkSlots.length) st = u ? -34 : 0;
    else {
      if (slot < 0 || slot >= gkSlots.length) slot = 0;
      const x = gkSlots[slot];
      if (dirty) gkCfgPut(u, x.bytes);
      st = 1;
      if (x.trd) st = gkTrd(u, d, x);
    }
    gkErr = st < 0 ? -st : 0;
    E.web_gk_mounted(gkSlots.length ? slot : -1, st);
    if (gkErr) toast('Gotek ' + DRV[d] + ': error ' + gkErr + ' (' + GK_ERR[gkErr] + (gkSlots[slot] ? ': ' + gkSlots[slot].name : '') + ')', true);
    updateUI(); gkUI();
  }
  function gkTrd(u, d, x) { // FlashFloppy trd_open: #10 at #8E7; its size from the catalogue; a short file made longer (extend-image)
    let f = u.vol.read(x.it).data;
    if (f.length < 0x8E8 || f[0x8E7] !== 0x10) return -31;
    let tot = f[0x8E1] + f[0x8E2] * 16 + f[0x8E5] + f[0x8E6] * 256; if ((tot & 15) || tot > 4096) tot = 0;
    tot = Math.max(tot, Math.floor(f.length / 256));
    const sides = f[0x8E3] === 0x18 || f[0x8E3] === 0x19 ? 1 : 2, cyls = Math.ceil((tot >> 4) / sides);
    if (!cyls) return -31;
    const size = cyls * sides * 4096;
    if (f.length < size) {
      try { u.vol.grow(x.it, size); usbDirty = true; } catch (e) { return -30; }
      f = u.vol.read(x.it).data;
    }
    const nm = 'gotek_' + x.name.replace(/[\\/:]/g, '_');
    fs.write(nm, f); setName(nm);
    E.web_noboot(1); let ok; try { ok = E.web_load(d); } finally { E.web_noboot(0); }
    if (!ok) return -31;
    drives[d] = { name: nm, ext: 'trd', gotek: true, gkName: x.name };
    const l = u.vol.lbas(x.it), p = E.malloc(l.length * 4); new Uint32Array(E.memory.buffer, p, l.length).set(l); E.web_gk_map(p, l.length); E.free(p);
    return 1;
  }
  function gkApply(quiet) { // after a (re)start of the emulator, a stick put in, the drive changed: the Gotek starts
    if (!E || !E.web_gk_set) return;
    const d = gkDrive(); gkOn = d >= 0;
    E.web_gk_remount(gkRemount()); E.web_gk_fw(gkFw());
    if (!gkOn) { E.web_gk_set(-1, 0, 0, 0); gkErr = 0; gkUI(); return; }
    const u = usbVol();
    if (usbName && fs.exists(usbName)) setName(usbName);
    E.web_gk_set(d, usbName && fs.exists(usbName) ? E.web_namebuf() : 0, u ? u.v0 : 0, u ? u.v1 : 0);
    gkSendSlots(-1);
    const slot = gkStartSlot();
    if (usbName) gkMount(slot, false); else { gkErr = 0; E.web_gk_mounted(-1, 0); }
    if (!quiet && usbName && !gkErr) toast('Gotek ' + DRV[d] + ': ' + (gkSlots[slot] ? 'slot ' + slot + ' ' + gkSlots[slot].name : 'no images on ' + usbName));
    gkUI();
  }
  function gkFrame() { // each frame: a slot to mount (Direct Access left); an error of Direct Access; the stick written: the slots anew
    const p = E.web_gk_poll();
    if (p === -2) { // the Gotek stopped (a read past the end of the stick): no disk until a button
      const d = gkDrive(), g = new Uint32Array(E.memory.buffer, E.web_gk_info(), 16);
      gkErr = g[15]; E.web_gk_map(0, 0);
      if (drives[d] && drives[d].gotek) { try { fs.remove(drives[d].name); } catch (e) {} if (E.web_disk_present(d)) E.web_eject(d); drives[d] = null; }
      toast('Gotek ' + DRV[d] + ': error ' + gkErr + ' (' + (GK_ERR[gkErr] || '') + ')', true); updateUI(); gkUI();
      return;
    }
    if (p >= 0 && p < 0x7FFFFFFF) { // by the list Direct Access chose from, or the name it gave (looked up in the stick read anew)
      const r = new Uint8Array(E.memory.buffer, E.web_gk_req(), 264), named = r[0], dirty = r[1];
      let slot = p;
      if (named) {
        const nm = r.slice(8, 264); const want = nm.subarray(0, nm.indexOf(0) < 0 ? 255 : nm.indexOf(0));
        const cur = gkSlots[new Uint32Array(E.memory.buffer, E.web_gk_info(), 3)[2]];
        const list = gkList(), i = list.findIndex((x) => want.every((c, k) => x.bytes[k] === c));
        slot = i >= 0 ? i : cur ? Math.max(0, list.findIndex((x) => bytesEq(x.bytes, cur.bytes))) : 0; // not found: the image there was
      }
      gkMount(slot, !!dirty);
      return;
    }
    // the stick written (File Commander, a driver through Direct Access, TR-DOS into the mounted image): once it is quiet and
    // out of Direct Access the slots anew, the mounted image found by its name, its blocks on the stick again
    if (gkStale && performance.now() - gkStaleAt > 300 && !new Uint32Array(E.memory.buffer, E.web_gk_info(), 2)[1]) gkRemap();
  }
  function gkRemap() {
    const d = gkDrive(), cur = drives[d] && drives[d].gotek ? drives[d].gkName : null, u = usbVol();
    const i = cur === null ? -1 : gkList().findIndex((x) => x.name === cur);
    gkSendSlots(i);
    if (cur === null) { gkUI(); return; }
    if (i < 0 || !u) { E.web_gk_map(0, 0); return; } // its file is gone from the stick: the disk stays in the drive, its writes not on the stick
    const l = u.vol.lbas(gkSlots[i].it), p = E.malloc(l.length * 4); new Uint32Array(E.memory.buffer, p, l.length).set(l); E.web_gk_map(p, l.length); E.free(p);
    gkUI();
  }
  // the buttons of the Gotek: the image before / after (round), mounted at once; Select mounts the image again (after an error)
  function gkButton(k) {
    if (!E || gkDrive() < 0 || !usbName) return;
    const g = new Uint32Array(E.memory.buffer, E.web_gk_info(), 16);
    if (g[1]) return; // in Direct Access: the buttons wait (FlashFloppy leaves it on a button: not here)
    gkSendSlots(-1); const n = gkSlots.length;
    if (!n) { gkMount(0, false); return; }
    const slot = k ? (g[2] + k + n) % n : Math.min(g[2], n - 1);
    gkMount(slot, k !== 0);
  }
  async function usbFromBytes(name, buf, atStart) {
    if (!atStart && !await loseOk(['usb'])) return false;
    try {
      let nm = name, img = buf;
      if (UnrealZip.isZip(buf)) {
        const all = UnrealZip.list(buf).filter((e) => !/\/$/.test(e.name)), imgs = all.filter((e) => /\.(img|ima|bin|vhd)$/i.test(e.name));
        const e = (imgs.length ? imgs : all).reduce((a, b) => (b.size > a.size ? b : a), { size: -1 });
        if (!e.name) throw new Error('USB: the archive is empty');
        nm = e.name.replace(/^.*[\\/]/, ''); img = await UnrealZip.extract(buf, e);
      }
      if (img.length >= 512 && String.fromCharCode(...img.subarray(img.length - 512, img.length - 504)) === 'conectix' && img.length % 512 === 0) img = img.slice(0, img.length - 512);
      if (!UnrealFC._test.fatFind(img).length) throw new Error('USB: ' + nm + ' has no FAT volume (FAT16 / FAT32)');
      { const d = gkDrive(); if (!atStart && d >= 0 && !(drives[d] && drives[d].gotek) && !await loseOk(['ab'[d]])) return false; }
      nm = 'usb_' + nm.replace(/[:\\/]/g, '_');
      if (usbName && usbName !== nm) try { fs.remove(usbName); } catch (e) {}
      fs.write(nm, img); usbName = nm; usbDirty = false; usbSrc = null;
      if (gkDrive() < 0) toast('USB stick: ' + nm.slice(4) + (dmHere() ? ' (the Gotek is off: Options / Disk / Gotek)' : ' (the Gotek is on ' + DM_WHERE + ' only)'));
      gkApply(false);
    } catch (err) { toast(err.message, true); gkUI(); return false; }
    gkUI(); return true;
  }
  function usbImage() { if (!usbName || !fs.exists(usbName)) return null; if (E && E.web_gk_flush) E.web_gk_flush(); return fs.read(usbName).slice(); }
  function gkUI() {
    const box = $('gkbox'); if (!box) return;
    box.hidden = !dmHere();
    const el = $('usbcard'), have = !!(usbName && fs.exists(usbName)), d = gkDrive();
    $('gkdrv').value = String(d); $('gkrm').value = String(gkRemount()); $('gkfw').value = String(gkFw());
    el.querySelector('.dname').textContent = have ? usbName.slice(4) + (usbDirty ? ' *' : '') : '— empty —';
    el.querySelector('.save').disabled = !have; el.querySelector('.eject').disabled = !have;
    el.classList.toggle('off', d < 0);
    let note = '';
    if (d >= 0 && !have) note = 'No USB stick: the drive is empty, no Direct Access.';
    else if (d >= 0) {
      const i = E && E.web_gk_info ? Array.from(new Uint32Array(E.memory.buffer, E.web_gk_info(), 16)) : null;
      note = gkSlots.length + ' slot' + (gkSlots.length === 1 ? '' : 's') + (i && gkSlots[i[2]] ? ' · slot ' + i[2] + ': ' + gkSlots[i[2]].name : '');
      if (gkErr) note += ' · error ' + gkErr + ' (' + GK_ERR[gkErr] + '): ◀ ▶ another image';
    }
    $('gknote').textContent = note;
    for (const id of ['gkprev', 'gksel', 'gknext']) $(id).disabled = d < 0 || !have;
  }
  function bindGk() {
    const el = $('usbcard'), pick = $('usbfile');
    $('gkdrv').onchange = async (e) => { // a changed disk of the user in that drive: asked first (the Gotek's image takes its place)
      const v = +e.target.value;
      if (v >= 0 && usbName && !(drives[v] && drives[v].gotek) && !await loseOk(['ab'[v]])) { gkUI(); return; }
      gkLink = null; store('gotek', e.target.value); gkApply(false);
    };
    $('gkfw').onchange = (e) => { gkFwLink = null; store('gotek.fw', e.target.value); gkApply(false); }; // another firmware: the Gotek starts again
    $('gkrm').onchange = (e) => { gkRmLink = null; const v = Math.max(0, Math.min(10000, +e.target.value || 0)); store('gotek.remount', String(v)); if (E && E.web_gk_remount) E.web_gk_remount(v); gkUI(); };
    pick.onchange = async (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) await usbFromBytes(f.name, new Uint8Array(await f.arrayBuffer())); canvas.focus(); };
    el.querySelector('.ins').onclick = () => pick.click();
    $('gkprev').onclick = () => gkButton(-1); $('gknext').onclick = () => gkButton(1); $('gksel').onclick = () => gkButton(0);
    el.querySelector('.save').onclick = () => openSave('usb');
    el.querySelector('.eject').onclick = async () => {
      if (usbName && usbDirty && !await askBox('USB stick', usbName.slice(4) + ' was modified. Remove without saving?', 'Remove')) return;
      if (usbName) try { fs.remove(usbName); } catch (e) {} usbName = null; usbSrc = null; gkApply(true); gkUI(); };
    el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drop'); });
    el.addEventListener('dragleave', () => el.classList.remove('drop'));
    el.addEventListener('drop', async (e) => { e.preventDefault(); e.stopPropagation(); el.classList.remove('drop'); const f = e.dataTransfer.files[0]; if (f) await usbFromBytes(f.name, new Uint8Array(await f.arrayBuffer())); });
    gkUI();
  }
  let hddPick = () => {};
  function buildHdds() {
    const box = $('hdds');
    let pending = 0;
    const pick = $('hddfile');
    hddPick = (d) => { pending = d; pick.click(); };
    pick.onchange = async (e) => {
      const f = e.target.files[0]; e.target.value = '';
      if (!f) return;
      await hddFromBytes(pending, f.name, new Uint8Array(await f.arrayBuffer()));
      canvas.focus();
    };
    for (let d = 0; d < NHDD; d++) {
      const el = document.createElement('div');
      el.className = 'drive'; el.id = 'hdd' + d;
      el.innerHTML = `<span class="dl" title="${d ? 'Slave' : 'Master'}">${HDN[d]}:</span><span class="dname">— empty —</span>
        <button class="ins" title="Mount an image file">Insert</button>
        <button class="save" title="Download the image (with the changes)">Save</button>
        <button class="eject" title="Unmount">⏏</button>
        <label title="Read only"><input type="checkbox" class="wp">RO</label>`;
      el.querySelector('.ins').onclick = () => hddPick(d);
      el.querySelector('.save').onclick = () => openSave('hdd:' + d);
      el.querySelector('.eject').onclick = async () => {
        if (hdds[d] && hddDirty[d] && !await askBox('HDD ' + d, hdds[d] + ' was modified. Eject without saving?', 'Eject')) return;
        hdds[d] = null; hddMount(d); hddUI(); };
      el.querySelector('.wp').onchange = (e) => { const g = Object.assign({}, hddGeom(d), { ro: e.target.checked }); store('hdd.geo' + d, JSON.stringify(g)); hddMount(d); hddUI(); };
      el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drop'); });
      el.addEventListener('dragleave', () => el.classList.remove('drop'));
      el.addEventListener('drop', (e) => { e.preventDefault(); e.stopPropagation(); el.classList.remove('drop'); const f = e.dataTransfer.files[0]; if (f) { pending = d; pick.onchange({ target: { files: [f], value: '' } }); } });
      box.appendChild(el);
      const geo = document.createElement('div');
      geo.className = 'hddgeo'; geo.id = 'hddgeo' + d;
      geo.innerHTML = `CHS <input class="chs" title="cylinders/heads/sectors (max 16383/16/63)" spellcheck="false"> LBA <input class="lba" title="sectors, 0 = image size" spellcheck="false"> <select class="srv" title="Mount an image from the server (hdd/hdd.json)" hidden></select>`;
      geo.querySelector('.srv').onchange = async (e) => {
        const it = e.target.value === '' ? null : hddList[+e.target.value]; if (!it) return;
        try { if (await hddFromBytes(d, it.url.replace(/^.*\//, ''), await fetchBytes(it.url))) hddSrc[d] = it.url; } catch (err) { toast(err.message, true); }
        srvShow();
      };
      const apply = () => {
        const m = /^\s*(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)\s*$/.exec(geo.querySelector('.chs').value), l = parseInt(geo.querySelector('.lba').value, 10);
        const g = Object.assign({}, hddGeom(d));
        if (m) { g.c = Math.min(16383, +m[1]); g.h = Math.min(16, +m[2]); g.s = Math.min(63, +m[3]); }
        if (!isNaN(l) && l >= 0) g.lba = l;
        store('hdd.geo' + d, JSON.stringify(g));
        hddMount(d); hddUI();
      };
      geo.querySelectorAll('input').forEach((i) => { i.addEventListener('keydown', (e) => { if (e.key === 'Enter') { apply(); i.blur(); } }); i.addEventListener('change', apply); });
      box.appendChild(geo);
    }
    $('hddif').onchange = () => { store('hdd.if.' + hddKey(), $('hddif').value); E.web_hdd_scheme(+$('hddif').value); applyHddDefault(); };
  }
  // interface switched on later: fetch the default image now
  async function applyHddDefault() {
    if (!hddDefaultTried && E.web_hdd_scheme(-1) !== 0) { await applyHdd(); return; }
    hddUI();
  }

  function buildDrives() {
    buildHdds(); bindSd(); bindDm(); bindGk(); bindLdStore();
    $('fddacc').onchange = (e) => { store('fdd.acc', e.target.checked ? '1' : '0'); applyFdd(true); canvas.focus(); };
    $('fddtrk').checked = load('fdd.trk') !== '0';
    $('fddtrk').onchange = (e) => { store('fdd.trk', e.target.checked ? '1' : '0'); ledKey = ''; canvas.focus(); };
    $('bordersel').onchange = (e) => { store('border', e.target.value); if (E && E.web_border) { e.target.value = String(E.web_border(+e.target.value)); render(); } };
    $('dbgdef').value = dbgDef; dbgDefUI();
    $('dbgdef').onchange = () => { dbgDef = $('dbgdef').value === 'x' ? 'x' : 'u'; store('dbgdef', dbgDef); dbgDefUI(); $('dbgdef').blur(); };
    $('mclick').checked = load('mclick') === '1';
    $('mclick').onchange = (e) => store('mclick', e.target.checked ? '1' : '0');
    $('nxkeys').onchange = (e) => { store('nxkeys', e.target.value); applyNxKeys(); e.target.blur(); };
    $('mswap').onchange = (e) => { store('mswap', e.target.checked ? '1' : '0'); if (E && E.web_mouse_swap) E.web_mouse_swap(e.target.checked || mswapLink ? 1 : 0); };
    const box = $('drives');
    for (let i = 0; i < NDRIVES; i++) {
      const el = document.createElement('div');
      el.className = 'drive'; el.id = 'drv' + i;
      el.innerHTML = `<span class="dl">${DRV[i]}:</span><span class="dname">— empty —</span>
        <button class="ins" title="Insert disk">Insert</button>
        <button class="save" title="Save the disk image">Save</button>
        <button class="eject" title="Eject">⏏</button>
        <label title="Write protect"><input type="checkbox" class="wp">WP</label>`;
      el.querySelector('.ins').onclick = () => openFile(i);
      el.querySelector('.save').onclick = () => openSave('disk:' + i);
      el.querySelector('.eject').onclick = async () => {
        if (E.web_disk_changed(i)) { if (!await askBox('Disk ' + DRV[i] + ':', 'Disk ' + DRV[i] + ' was modified. Eject without saving?', 'Eject')) return; E.web_disk_mark(i, 0); } // the core does not ask again
        E.web_eject(i); drives[i] = null; updateUI();
      };
      el.querySelector('.wp').onchange = (e) => E.web_set_wp(i, e.target.checked);
      el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drop'); });
      el.addEventListener('dragleave', () => el.classList.remove('drop'));
      el.addEventListener('drop', (e) => { e.preventDefault(); e.stopPropagation(); el.classList.remove('drop'); if (e.dataTransfer.files[0]) loadFile(e.dataTransfer.files[0], i); });
      box.appendChild(el);
    }
  }

  function modelUI() {
    // an RZX machine (not in the list) shows in it while it runs
    const sel = $('modelsel'); for (const o of [...sel.options]) if (o.dataset.hid) o.remove();
    if (MODELS[model].hidden) { const o = document.createElement('option'); o.value = model; o.textContent = MODELS[model].name; o.dataset.hid = '1'; sel.appendChild(o); }
    sel.value = model;
    modelSelUI();
    $('xt').hidden = !MODELS[model].xt;
    const rd = !!(romDisk && M() === 'XBIOS136'); // ROM disk: Turbo 2+ (it builds the xBIOS 1.36 ROM)
    $('romdiskrow').hidden = M() !== 'XBIOS136'; // the ROM disk is xBIOS 1.36's: shown only while it runs
    $('romdiskname').textContent = rd ? romDisk.name : '— empty —';
    $('romdiskboot').disabled = $('romdiskdel').disabled = !rd;
  }
  // the choice is applied with the Apply button (switching restarts the machine)
  let customDirty = false; // Custom ROM settings changed while it runs: Start applies them
  let pentDirty = false; // Pentagon RAM changed while it runs: Start applies it
  function modelSelUI() {
    const m = $('modelsel').value;
    $('customrom').hidden = m !== 'CUSTOM';
    if (m === 'CUSTOM') { customUI(); loadRomParts(); }
    $('pramrow').hidden = m !== 'PENTAGON'; $('pram').value = String(pentRam());
    $('modelnote').textContent = MODELS[m].note;
    $('nvrow').hidden = !nvHas(m);
    if (MODELS[m].link) { const a = document.createElement('a'), par = MODELS[m].linkParen; a.href = MODELS[m].link; a.target = '_blank'; a.rel = 'noopener'; a.textContent = par ? 'link' : ' · ' + MODELS[m].link.replace(/^https:\/\//, ''); if (par) $('modelnote').append(' ('); $('modelnote').appendChild(a); if (par) $('modelnote').append(')'); }
    eff7UI(); nedoUI();
    $('modelapply').disabled = (m === model && !(m === 'CUSTOM' && customDirty) && !(m === 'PENTAGON' && pentDirty)) || switching || (m === 'CUSTOM' && !customPlan().ini);
  }
  function customUI() {
    const c = MACHINES[customCfg.mach];
    $('crmach').value = customCfg.mach;
    const opt = (sel, v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; sel.appendChild(o); };
    const cur = crCur; // a whole ROM: the selected file (its name is next to the button)
    $('crname').textContent = cur ? cur.name + ' · ' + cur.kb + ' KB' + (!c.set && c.sizes && !c.sizes.includes(cur.kb) ? ' (size does not fit ' + c.name + ')' : '') : '';
    // ROM set: each slot from a page of a local file or a part on the server
    for (const [s] of SLOTS) {
      const sel = $('crs_' + s); sel.innerHTML = ''; opt(sel, '', '— none —');
      if (crCur) for (let i = 0, p = crCur; i < p.kb / 16; i++) { const pi = p.pages && p.pages[i];
        if (pi && (pi.label === 'empty' || (p.kb > 64 && !pi.slot))) continue; // a big file: the pages that look like a slot only
        opt(sel, 'f:' + p.fs + ':' + i, p.name + (p.kb > 16 ? ' · page ' + i : '') + (pi ? ' · ' + pi.label + (pi.slot && pi.slot !== s ? ' ⚠' : '') : '')); }
      for (const r of romParts.filter((x) => x.slot === s)) opt(sel, 's:' + r.file + (r.page !== undefined ? ':' + r.page : ''), r.name);
      sel.value = [...sel.querySelectorAll('option')].some((o) => o.value === customCfg.slots[s]) ? customCfg.slots[s] : '';
      $('crsrow_' + s).hidden = !c.set;
    }
    $('crresetrow').hidden = !c.set;
    $('crreset').value = customCfg.reset;
    customApply();
  }
  let romPartsLoaded = false;
  let romJson = []; // every entry of rom/roms.json (Save / ROM lists them all, also the ones that are no ROM set part)
  async function loadRomParts() { // rom/roms.json: [{ file, slot, name }] — the parts the server offers for ROM sets
    if (romPartsLoaded) return; romPartsLoaded = true;
    try { const j = jsonC(new TextDecoder().decode(await fetchBytes(ROM_DIR + 'roms.json'))); if (Array.isArray(j) && j.length) { romJson = j.filter((r) => r && r.file); romParts = romJson.filter((r) => SLOTS.some(([s]) => s === r.slot)); } } catch (e) {}
    if ($('modelsel').value === 'CUSTOM') customUI();
  }
  // What is in a 16K ROM page (by its texts and first bytes): slot it fits ('128', 'sos', 'dos', 'sys'), a label, or nothing
  function romPageInfo(pg) {
    let ff = 0, zz = 0; for (let i = 0; i < pg.length; i++) { if (pg[i] === 0xFF) ff++; else if (!pg[i]) zz++; }
    if (ff + zz > pg.length - 16) return { slot: null, label: 'empty' };
    let t = ''; for (let i = 0; i < pg.length; i++) { const c = pg[i] & 0x7F; t += c >= 32 && c < 127 ? String.fromCharCode(c) : ' '; }
    const has = (re) => re.test(t), m = (re) => { const x = re.exec(t); return x ? x[1].trim() : ''; };
    if (has(/DIGITAL RESEARCH/)) return { slot: null, label: 'ATM BIOS ' + (m(/BIOS\s+V?(\d[\d.]*\w*)/) || '') + ' + CP/M' };
    if (has(/PLUS3DOS/)) return { slot: null, label: '+3DOS' };
    if (has(/Amstrad/) && has(/128 \+3|SPECTRUM \+3/)) return { slot: null, label: '+3 ROM 0 (menu, test)' };
    if (has(/Cannot copy to\/from tap/)) return { slot: null, label: '+3 ROM 1 (128 BASIC)' };
    if ((pg[0] === 0xF3 && pg[1] === 0x11) || (has(/\* ?TR-DOS Ver/) && has(/BETA 128|Technology Research/))) { // TR-DOS: DI: LD DE,... (Scorpion's: DI: JP ...)
      const v = m(/(vTR-dos ver\.?\s*[\d.]+\w*)/i) || m(/(PereDOS v?\.?\s*[\d.]+\+?)/i) || m(/TR-DOS Ver\s*([\d.]+\w*)/i);
      if (v || has(/TR-?DOS|BETA 128/i)) return { slot: 'dos', label: /^\d/.test(v) ? 'TR-DOS ' + v : v || 'TR-DOS' };
    }
    if (has(/128 BASI/) || (has(/Tape Loade/) && has(/128/))) return { slot: '128', label: has(/Amstrad/) ? '+3 menu / 128 BASIC' : has(/Scorpion ZS/) ? 'Scorpion 128 BASIC + menu' : has(/NEMO KAY/) ? 'KAY 128 BASIC + menu' : has(/Quorum/i) ? 'Quorum 128 BASIC' : '128 BASIC + menu' };
    if (has(/Tape loading erro/) && !has(/Insert tape/)) return { slot: 'sos', label: ('48 BASIC ' + (m(/(\d{4}) (Sinclair|Amstrad)/) || '')).trim() + (has(/Amstrad/) ? ' (Amstrad)' : '') + (has(/XBIOS|xBIOS/) ? ' (xBIOS)' : '') };
    const sys = [[/GLUK|Mr Gluk/i, 'Gluk Reset Service'], [/Shadow Service Monito/, 'Shadow Service Monitor (ProfROM)'], [/Disk service|Himem menu|Rom boot/i, 'Service ROM'], [/Micco Software/, 'Profi BIOS menu'], [/ROM-MENU QUORUM/, 'Quorum ROM menu'], [/NEMO KAY/, 'KAY service menu'],
      [/Dual! TR-dos|EXTRA BIOS/i, 'xBIOS menu'], [/Reset Service/i, 'Reset Service'], [/DOS'WIN|Tr-dosN/, 'Quick Commander'], [/General\s+Sound/, 'General Sound ROM (not for Z80)'], [/INT RAM ROM SCR/, 'Scorpion service']];
    for (const [re, l] of sys) if (has(re)) return { slot: re.source.includes('General') ? null : l === 'Quick Commander' ? '128' : 'sys', label: l };
    return { slot: null, label: 'unknown code' };
  }
  // A whole ROM file: the machine it is made for (null: not sure)
  function romMachineGuess(b) {
    let t = ''; for (let i = 0; i < b.length; i++) { const c = b[i] & 0x7F; t += c >= 32 && c < 127 ? String.fromCharCode(c) : ' '; }
    const kb = b.length >> 10, has = (re) => re.test(t);
    if (has(/Micco Software/) && kb === 64) return ['PROFI', 'Profi BIOS'];
    if (has(/PLUS3DOS/) && kb === 64) return ['PLUS3', 'Spectrum +3 ROM'];
    if (has(/ROM-MENU QUORUM/) && kb === 64) return ['QUORUM', 'Quorum ROM'];
    if (has(/Scorpion ZS/) && has(/Shadow Service/) && [64, 128, 256, 512].includes(kb)) return ['PROFSCORP', 'Scorpion ProfROM'];
    if (has(/Scorpion ZS/) && kb === 64) return ['SCORPION', 'Scorpion ROM'];
    if (has(/NEMO KAY/) && kb === 64) return ['KAY', 'KAY ROM (as a ROM set)'];
    if (has(/TS-BIOS/) && [64, 512].includes(kb)) return ['TSCONF', 'TS-Conf ROM (TS-BIOS)']; // before EVO: the TS flash has an ATM BIOS set too
    if (has(/BIOS\s+V1\.07\.\d+pe/) && kb >= 512) return ['EVO', 'ZX Evo BaseConf ROM'];
    if (has(/XVR - PRO/) && has(/BIOS\s+V1\.0[34]/) && kb === 64) return ['ATM450', 'ATM Turbo 1 BIOS ' + (/BIOS\s+V(1\.0[34][\d.]*\w*)/.exec(t) || ['', ''])[1]];
    if (has(/XVR - PRO/) && [64, 128, 512, 1024].includes(kb)) return ['ATM710', has(/xBIOS|XBIOS/) ? 'ATM Turbo 2+ xBIOS' : 'ATM Turbo 2+ BIOS ' + (/BIOS\s+V(1\.07[\d.]*\w*)/.exec(t) || ['', ''])[1]];
    return null;
  }
  // a local file: a ROM image (16K pages) or a ZIP — with custom.json (saved Custom ROM) the settings come back too
  let crSeq = 0;
  // JSON with comment lines: a line starting with # (after spaces) is left out (server lists, .json in ZIPs, rom/roms.json)
  function jsonC(t) { return JSON.parse(String(t).replace(/^\s*#.*$/gm, '')); }
  async function crAdd(name, b) {
    let cfg = null; const zipName = name.replace(/^.*\//, '').replace(/\.[^.]*$/, ''); // its CMOS key with "cmos": "own" / "fresh"
    if (UnrealZip.isZip(b)) {
      const all = UnrealZip.list(b), cj = all.find((x) => /(^|\/)custom\.json$/i.test(x.name)) || all.find((x) => /\.json$/i.test(x.name));
      if (cj) try { cfg = jsonC(new TextDecoder().decode(await UnrealZip.extract(b, cj))); } catch (e) { toast(name + ': custom.json is not valid', true); }
      const ents = all.filter((x) => /\.(rom|bin)$/i.test(x.name) && x.size && !(x.size & 16383));
      const e = (cfg && cfg.rom && ents.find((x) => x.name.replace(/^.*\//, '').toLowerCase() === String(cfg.rom).toLowerCase())) || ents.sort((x, y) => y.size - x.size)[0];
      if (!e) { toast(name + ': no ROM image (.rom / .bin, 16K pages) inside', true); return; }
      b = await UnrealZip.extract(b, e); name = e.name.replace(/^.*\//, '');
    }
    if (!b.length || b.length & 16383 || b.length > 1 << 20) { toast(name + ': a ROM image is 16 KB pages, up to 1024 KB (' + b.length + ' bytes)', true); return; }
    // one ROM file at a time: the new one replaces the one selected before (its pages leave the slots too)
    if (crCur) try { fs.remove(crCur.fs); } catch (e) {}
    crCur = null; customCfg.whole = ''; customCfg.extra = null;
    for (const [s] of SLOTS) if (customCfg.slots[s].startsWith('f:')) customCfg.slots[s] = '';
    crSeq++;
    const p = { fs: 'cr' + crSeq + '.rom', name, kb: b.length >> 10 };
    p.pages = []; for (let i = 0; i < p.kb / 16; i++) p.pages.push(romPageInfo(b.subarray(i * 16384, (i + 1) * 16384)));
    p.guess = romMachineGuess(b);
    p.key = zipName.replace(/[^\w.-]/g, '_'); p.cmos = cfg && /^(own|fresh)$/i.test(cfg.cmos || '') ? cfg.cmos.toLowerCase() : '';
    fs.write(p.fs, b); crCur = p;
    if (!cfg && p.guess && MACHINES[p.guess[0]]) { customCfg.mach = p.guess[0]; toast(name + ': ' + p.guess[1] + ' → ' + MACHINES[p.guess[0]].name); }
    const c = MACHINES[customCfg.mach];
    if (cfg && MACHINES[cfg.machine]) { // settings from the saved ZIP
      customCfg.mach = cfg.machine; customCfg.reset = cfg.reset && cfg.reset !== 'auto' ? cfg.reset : ''; customCfg.name = cfg.name || '';
      const x = {}; // machine settings of the ZIP (Save / Custom ROM writes them; may be edited by hand)
      if (cfg.speed !== undefined && +cfg.speed > 0) x.speed = +cfg.speed;
      if (/^(accurate|fast)$/i.test(cfg.fdd || '')) x.fdd = cfg.fdd.toLowerCase();
      if (cfg.hdd && IF_NAMES.includes(String(cfg.hdd).toUpperCase())) x.hdd = String(cfg.hdd).toUpperCase();
      if (cfg.ini && typeof cfg.ini === 'object') x.ini = cfg.ini;
      customCfg.extra = Object.keys(x).length ? x : null;
      const pg = (v) => (typeof v === 'number' ? v : v && typeof v.page === 'number' ? v.page : null);
      if (MACHINES[cfg.machine].set) for (const [s] of SLOTS) customCfg.slots[s] = cfg.pages && pg(cfg.pages[s]) !== null ? 'f:' + p.fs + ':' + pg(cfg.pages[s]) : '';
      else customCfg.whole = p.fs;
      toast('Custom ROM: ' + (cfg.name || name) + ' on ' + MACHINES[cfg.machine].name);
    } else if (cfg && cfg.slot && SLOTS.some(([s]) => s === cfg.slot)) { // a ROM set part (e.g. a server ZIP with its .json)
      if (c.set) {
        customCfg.slots[cfg.slot] = 'f:' + p.fs + ':' + (+cfg.page || 0);
        // the rest of the set, when not chosen: the Pentagon's (a QC in place of 128 BASIC needs 48 BASIC and TR-DOS beside it)
        const STOCK = { 128: 's:pentagon.rom:0', sos: 's:pentagon.rom:1', dos: 's:trd504tm.rom' };
        for (const [k, v] of Object.entries(STOCK)) if (!customCfg.slots[k]) customCfg.slots[k] = v;
      }
      if (cfg.name) p.name = cfg.name + ' (' + name + ')';
    } else if (!c.set) customCfg.whole = p.fs;
    else { // a ROM set: each slot gets the first page that looks like it (pages of unknown code: none)
      let any = false;
      for (const [s] of SLOTS) { const i = p.pages.findIndex((x) => x.slot === s); if (i >= 0) { customCfg.slots[s] = 'f:' + p.fs + ':' + i; any = true; } }
      if (!any && p.kb === 16 && !customCfg.slots.sos) customCfg.slots.sos = 'f:' + p.fs + ':0';
    }
  }
  function bindCustom() {
    const sel = $('crmach');
    for (const [k, v] of Object.entries(MACHINES)) { const o = document.createElement('option'); o.value = k; o.textContent = v.name; sel.appendChild(o); }
    const changed = () => { customDirty = model === 'CUSTOM'; customUI(); modelSelUI(); };
    sel.onchange = () => {
      customCfg.mach = sel.value;
      if (MACHINES[sel.value].set && SLOTS.every(([s]) => !customCfg.slots[s])) // a ROM set with nothing chosen yet: pages that fit, from the files added
        if (crCur) for (const [s] of SLOTS) { const i = (crCur.pages || []).findIndex((x) => x.slot === s); if (i >= 0 && !customCfg.slots[s]) customCfg.slots[s] = 'f:' + crCur.fs + ':' + i; }
      if (!MACHINES[sel.value].set && crCur) customCfg.whole = crCur.fs;
      changed();
    };
    for (const [s] of SLOTS) $('crs_' + s).onchange = () => { customCfg.slots[s] = $('crs_' + s).value; changed(); };
    $('crreset').onchange = () => { customCfg.reset = $('crreset').value; changed(); };
    $('crfile').onclick = () => $('crinput').click();
    $('crinput').onchange = async (e) => {
      const fl = [...e.target.files]; e.target.value = '';
      for (const f of fl) try { await crAdd(f.name, new Uint8Array(await f.arrayBuffer())); } catch (err) { toast(f.name + ': ' + err.message, true); }
      changed();
    };
  }
  // Save / Custom ROM: the ROM of the running model and its settings in one ZIP — a ROM set is joined into one 64K image
  // (128, 48, service, TR-DOS; missing pages #FF), a single-file ROM goes as it is; <name>.json next to <name>.rom
  function slotFrom(v) { // what a Custom ROM slot loads, for the .json
    if (v.startsWith('f:')) { const [, f, pg] = v.split(':'), x = crFile(f); return x ? x.name + (x.kb > 16 ? ' page ' + pg : '') : f; }
    const [, f, pg] = v.split(':'), r = romParts.find((q) => q.file === f && String(q.page === undefined ? '' : q.page) === (pg || ''));
    return (r ? r.name + ' · ' : '') + f + (pg ? ' page ' + pg : '');
  }
  const srcText = (src) => { const [f, n] = src.split(':'); const x = crFile(f); return (x ? x.name : f) + (n !== undefined ? ' page ' + n : ''); };
  // pre: the Custom ROM as chosen in Options / System (also before Start); its settings then come from its json only,
  // unless this very Custom ROM is running (then as it runs, like Save / Custom ROM)
  function romZip(pre) {
    const m = pre ? 'CUSTOM' : model, custom = m === 'CUSTOM', live = !pre || (model === 'CUSTOM' && !customDirty);
    if (custom && !customPlan().ini) return null;
    const ini = modelIniObj(m), misc = ini.MISC || {}, hm = misc.HIMEM || 'ATM710', ram = +(misc.RAMSize || (hm === 'ATM710' ? 1024 : 128));
    const mach = custom ? customCfg.mach : Object.keys(MACHINES).find((k) => MACHINES[k].himem === hm && MACHINES[k].ram === ram) || Object.keys(MACHINES).find((k) => MACHINES[k].himem === hm);
    if (!mach) return null;
    const c = MACHINES[mach], set = ini.ROM && ini.ROM.ROMSET ? ini['ROM.' + ini.ROM.ROMSET] : null;
    const romOf = (f) => f.replace(/\.[^.]*$/, ''), whole = !set && ((ini.ROM && ini.ROM[c.key]) || MODELS[m].files.find((f) => /\.rom$/i.test(f)));
    if (!set && !whole) return null;
    let base = custom ? customCfg.name || (set ? 'romset' : romOf(crFile(customCfg.whole).name)) : romOf(set ? MODELS[m].files[0] : whole.split(':')[0]);
    base = base.replace(/[\\/:*?"<>|]/g, '_');
    const cfg = { type: 'unreal-web-custom-rom', name: custom && customCfg.name ? customCfg.name : base, machine: mach, machineName: c.name, rom: base + '.rom' };
    // the machine as it runs now: clock, FDD mode, HDD interface (and the ini keys a loaded ZIP brought) — a link with rom= gets the same
    const x = (custom && customCfg.extra) || {};
    if (live) { cfg.speed = SPEEDS[speedIdx]; cfg.fdd = E && E.web_fdd_accurate && E.web_fdd_accurate(-1) ? 'accurate' : 'fast'; if (E) cfg.hdd = IF_NAMES[E.web_hdd_scheme(-1)] || 'NONE'; }
    else { if (x.speed) cfg.speed = x.speed; if (x.fdd) cfg.fdd = x.fdd; if (x.hdd) cfg.hdd = x.hdd; }
    if (custom && customCfg.extra && customCfg.extra.ini) cfg.ini = customCfg.extra.ini;
    if (custom && crCur && crCur.cmos) cfg.cmos = crCur.cmos; // its CMOS: own / fresh, as the ZIP had it
    let img;
    if (set) {
      img = new Uint8Array(65536).fill(0xFF); cfg.reset = custom ? customCfg.reset || 'auto' : misc.RESET || 'auto'; cfg.pages = {};
      SLOTS.forEach(([s, label], i) => {
        const src = set[s], pg = [0, 1, 3, 2][i]; // 128 → 0, 48 → 1, TR-DOS → 3, service → 2 (as a 64K Pentagon / Scorpion ROM)
        const [f, n] = src ? src.split(':') : [], b = f && fs.exists(f) ? fs.read(f) : null;
        if (!b) { cfg.pages[s] = null; return; }
        img.set(b.subarray((+n || 0) * 16384, (+n || 0) * 16384 + 16384), pg * 16384);
        cfg.pages[s] = { page: pg, rom: label, from: custom ? slotFrom(customCfg.slots[s]) : srcText(src) };
      });
    } else {
      const f = whole.split(':')[0]; if (!fs.exists(f)) return null;
      img = fs.read(f); cfg.from = (custom ? crFile(f).name : f) + ' (' + (img.length >> 10) + ' KB)';
    }
    return { name: base + '.zip', files: [{ name: cfg.rom, data: img }, { name: base + '.json', data: new TextEncoder().encode(JSON.stringify(cfg, null, 1)) }] };
  }

  let switching = false;
  let xtPref = null; // ATM mode (XT keyboard) chosen on an ATM machine: kept across model changes in this session
  async function setModel(m, force) {
    if (!MODELS[m] || (m === model && !force) || switching) { modelUI(); return; }
    switching = true; // from here: a second switch (a drop, Apply during the question) does not start one more machine
    if (!await recGate()) { switching = false; modelUI(); return; } // RZX recording: asked first
    const dirty = [];
    for (let i = 0; i < NDRIVES; i++) if (E && E.web_disk_present(i) && E.web_disk_changed(i)) dirty.push(DRV[i] + ':');
    if (dirty.length && !loseAsked && !await askBox('', 'Unsaved changes on disk ' + dirty.join(' ') + ' will be lost.\nSwitch to ' + MODELS[m].name + '?')) { switching = false; modelUI(); return; }
    modelSelUI();
    if (rz) rzxClose();
    releaseAll(); releaseMouse();
    if (dbgOn) debugShown(false);
    nvKeep.force = true; nvKeep(); nvKeep.force = false; // the CMOS of the machine left: into the browser
    if (E && MODELS[model].xt) xtPref = xtUser(); // ATM mode stays as it was for this session (not as an autorun macro holds it)
    const prev = model; model = m;
    let up = false;
    try { await start(); up = true; }
    catch (err) { // the new machine did not start: the one before comes back (the page stays usable, Apply can try again)
      toast('Startup error: ' + err.message + (prev !== m ? ' — ' + MODELS[prev].name + ' again' : ''), true);
      if (prev !== m) { model = prev; try { await start(); } catch (e2) { toast('Startup error: ' + e2.message, true); } }
    }
    if (up) try {
      toast(MODELS[m].name); if (dga) dga.sync(); mixUI(); // deBUGa breakpoints into the new machine
      if (MODELS[m].xt && xtPref !== null && !!E.web_xt_kbd() !== xtPref) { E.web_toggle_xt(); updateUI(); }
      await osBoot();
    }
    catch (err) { toast('Startup error: ' + err.message, true); }
    switching = false;
    if (audio) audio.flush();
    modelUI(); applyScale();
  }
  // ------------------------------------------------------------------ Offline (service worker sw.js): the page, scripts, wasm and the site's files kept in the browser
  const SW_OK = 'serviceWorker' in navigator && BUILD !== 'dev' && (location.protocol === 'https:' || /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname));
  let swErr = '';
  async function swStart() {
    if (!SW_OK) return;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (optOpen()) offUI(); }); // took over this page: the tab shows it
    try { await navigator.serviceWorker.register('sw.js?v=' + BUILD); swErr = ''; } catch (e) { swErr = /404|fetch|bad http|not found/i.test(e.message) ? 'sw.js not found on the server' : 'sw.js: ' + e.message; log('offline: ' + e.message); }
    if (optOpen()) offUI();
  }
  function swAsk(msg) { // → answer of the active service worker (null: none)
    return new Promise((res) => {
      const c = navigator.serviceWorker && navigator.serviceWorker.controller; if (!c) { res(null); return; }
      const ch = new MessageChannel(); ch.port1.onmessage = (e) => res(e.data); c.postMessage(msg, [ch.port2]); setTimeout(() => res(null), 3000);
    });
  }
  const offMsg = (t, err) => { $('offstat').textContent = t; $('offstat').hidden = !t; $('offstat').classList.toggle('err', !!err); };
  async function offUI() {
    if (!SW_OK) { offMsg('needs https', true); $('ofmake').disabled = $('ofclear').disabled = true; return; }
    const a = await swAsk({ cmd: 'list' });
    if (!a) { offMsg(swErr, !!swErr); return; } // not running yet: nothing to show
    const files = a.urls.filter((u) => /\/(rom|trd|hdd|sd)\//i.test(u)).length;
    let est = ''; try { const e = await navigator.storage.estimate(); if (e && e.usage) est = ', ' + (e.usage / 1048576).toFixed(1) + ' MB used'; } catch (e) {}
    offMsg('build ' + a.build + '\n' + files + ' files' + est);
  }
  async function makeOffline() {
    if (!navigator.serviceWorker || !navigator.serviceWorker.controller) { await offUI(); return; }
    $('ofmake').disabled = true;
    let ok = 0, bad = 0;
    try {
    try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (e) {}
    const jobs = [], seen = new Set(), add = (label, fn, key) => { if (seen.has(key)) return; seen.add(key); jobs.push([label, fn]); };
    for (const [k, m] of Object.entries(MODELS)) for (const f of m.files || []) if (/\.rom$/i.test(f)) add(f, () => fetchSrv(f), 'r:' + f);
    if ($('of_parts').checked) {
      await loadRomParts().catch(() => {});
      add(GS_ROM, () => fetchSrv(GS_ROM), 'r:' + GS_ROM); add(MOON_ROM, () => fetchSrv(MOON_ROM), 'r:' + MOON_ROM);
      for (const r of (romJson.length ? romJson : romParts)) add(r.file, () => fetchSrv(r.file), 'r:' + r.file);
    }
    const lists = [];
    if ($('of_trd').checked) lists.push(['trd/trd.json', (it) => [it.url, ...(it.rp ? MOUNT_KEYS.map((k) => it.rp[k]).filter(Boolean).map((u) => new URL(lowDir(u), location.href).href) : [])]]);
    if ($('of_hdd').checked) { lists.push(['hdd/hdd.json', (it) => [it.url]]); for (const o of Object.values(OS_MODELS)) if (o.hdd) add(o.hdd, () => fetchBytes(o.hdd), o.hdd); add('hdd/cpm.zip', () => fetchBytes('hdd/cpm.zip').catch(() => fetchBytes('hdd/cpm.hdd')), 'hdd/cpm'); }
    if ($('of_sd').checked) { lists.push(['sd/sd.json', (it) => [it.url]]); for (const o of Object.values(OS_MODELS)) if (o.sd) add(o.sd, () => fetchBytes(o.sd), o.sd); }
    for (const [j, urls] of lists) { const l = await fetchList(j); for (const it of l) for (const u of urls(it)) if (u) add(decodeURIComponent(u.replace(/^.*\//, '')), () => fetchBytes(u), u); }
    for (const [i, [label, fn]] of jobs.entries()) {
      offMsg(`Downloading ${i + 1} / ${jobs.length}: ${label}`);
      try { await fn(); ok++; } catch (e) { bad++; }
    }
    } catch (e) { bad++; }
    finally { $('ofmake').disabled = false; }
    await offUI();
    if (bad) offMsg(`${ok} files kept, ${bad} not downloaded (not on the server, or no network)`, true);
  }
  function bindOffline() {
    $('ofmake').onclick = makeOffline;
    $('ofbrw').onclick = async () => { // Load / Browser storage: everything Save put there
      const n = brwMetas.filter((m) => !m.dir).length;
      if (!brwMetas.length) { offMsg('Browser storage is empty'); return; }
      if (!await askBox('Browser storage', 'Delete all ' + n + ' file' + (n === 1 ? '' : 's') + (n < brwMetas.length ? ' and folders' : '') + ' saved in this browser (Load / Browser storage)?', 'Delete')) return;
      try { for (const m of brwMetas.slice()) await brwDel(m.name); } catch (e) { toast('Browser storage: ' + e.message, true); }
      brwCache = null; await brwRefresh(); offUI();
    };
    $('ofclear').onclick = async () => { if (!await askBox('Offline', 'Drop the downloaded files of the offline copy? The emulator itself stays.', 'Drop')) return; await swAsk({ cmd: 'clear' }); offUI(); };
  }
  function bindModels() {
    const sel = $('modelsel');
    pentName();
    const put = new Set(); // in groups (optgroup), folded in the list (data-fold): the group's name, ">" unfolds it
    for (const [g, ks] of [...MODEL_GROUPS, ['Other', Object.keys(MODELS)]]) {
      const list = ks.filter((k) => MODELS[k] && !MODELS[k].hidden && !put.has(k));
      if (!list.length) continue;
      const og = document.createElement('optgroup'); og.label = g;
      for (const k of list) { const o = document.createElement('option'); o.value = k; o.textContent = (!OS_MODELS[k] && MODELS[k].sysName) || MODELS[k].name; og.appendChild(o); put.add(k); }
      sel.appendChild(og);
    }
    sel.onchange = modelSelUI;
    bindCustom();
    $('nvreset').onclick = async () => { // the typical CMOS (and NVRAM) for the chosen machine; the running one restarts with it
      const m = sel.value; if (!nvHas(m)) return;
      const run = m === model;
      if (!await askBox('Reset CMOS', 'CMOS settings of ' + MODELS[m].name + ' go back to the typical ones' + (run ? ' and the machine restarts' : '') + '.', 'Reset')) return;
      nvReset(m);
      if (run) { nvKeep.skip = true; try { await setModel(m, true); } finally { nvKeep.skip = false; } }
      toast('CMOS: typical settings' + (run ? '' : ' from the next start'));
    };
    $('pram').onchange = () => { delete LINK.ram; store('pentram', $('pram').value); pentName(); pentDirty = model === 'PENTAGON' && pentRam() !== pentRun; modelSelUI(); }; // the link's ram= was for its start
    $('modelapply').onclick = () => { const f = (sel.value === 'CUSTOM' && customDirty) || (sel.value === 'PENTAGON' && pentDirty); customDirty = false; pentDirty = false; showNedo(false); showOptions(false); setModel(sel.value, f); }; // Start: Options (and its NedoOS window) close
    $('forcefetch').checked = load('fetch.reload') === '1';
    $('forcefetch').onchange = () => store('fetch.reload', $('forcefetch').checked ? '1' : '0');
    $('romdiskboot').onclick = () => { showOptions(false); romDiskMacro(true); };
    $('romdiskins').onclick = () => openFile(ROM_TARGET);
    $('romdiskdel').onclick = async () => { romDisk = null; try { fs.remove(ROMDISK_FILE); } catch (e) {} await setModel(xbiosOf(model), true); toast('ROM disk removed'); };
    modelUI();
  }

  // all tabs share one height: the height of the Disk tab (without the DivMMC and Gotek blocks of Pentagon); longer tabs scroll
  let curPane = 'sys';
  function fixOptHeight() {
    const body = $('options').querySelector('.body');
    if (body.dataset.fixed) return;
    const cur = curPane;
    showPane('opt'); // the Disk tab sets the height (taller tabs scroll), as on the models with no DivMMC / Gotek blocks:
    const xb = ['dmbox', 'gkbox'].map((id) => $(id)).filter(Boolean), was = xb.map((e) => e.hidden); // the same on every model
    xb.forEach((e) => { e.hidden = true; });
    const h = body.scrollHeight;
    xb.forEach((e, i) => { e.hidden = was[i]; });
    if (h > 50) { body.style.height = h + 'px'; body.dataset.fixed = '1'; }
    showPane(cur);
  }
  // Keys and files: a separate floating window
  let mhFW = null;
  function showMainHelp(v) {
    const h = $('mainhelp');
    h.hidden = !v; $('mainhelpbtn').classList.toggle('on', v);
    if (v) { if (optOpen()) mhFW.setPos(snapRight($('options').getBoundingClientRect(), h)); else mhFW.place(); }
  }
  function showPane(id) {
    curPane = id; if ($('sysbtn')) $('sysbtn').classList.toggle('on', optOpen() && id === 'sys');
    // every tab has its own height; long ones (Help, About) scroll inside the window
    document.querySelectorAll('#options header [data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === id));
    document.querySelectorAll('#options .pane').forEach((p) => p.classList.toggle('gone', p.dataset.pane !== id));
    $('options').querySelector('.body').scrollTop = 0;
    if (id === 'ula') { ulaUI(); zxbusUI(); ulaxUI(); }
    if (optOpen()) optFW.place();
  }
  // Options: floating, draggable, non-blocking window
  let optFW = null;
  const optOpen = () => !$('options').hidden;
  function showOptions(v) {
    const w = $('options');
    if (v) { releaseMouse(); updateUI(); w.hidden = false; fixOptHeight(); optFW.place(); offUI(); }
    else { w.hidden = true; canvas.focus(); }
    $('optbtn').classList.toggle('on', v); sysBtnUI();
  }
  function sysBtnUI() { $('sysbtn').classList.toggle('on', optOpen() && curPane === 'sys'); }

  // ~ (Shift + `), Options / Video, REST API hidemenu=1: the emulator window without its menu bar and frame
  let bare = false, bareLink = false; // bareLink: set by the link for this visit (the setting is not changed)
  let landPrev = false; // a phone in landscape is always as with Hide Menu Bar; upright again: this (as it was before, or as set since)
  // Hide Menu Bar also hides the corner icons, MHz and FPS (not the sound meter, the disk light, Tap for sound): a click or a
  // tap on the screen shows them for 2 s
  let calmT = 0;
  // the hidden corner icons and texts shown for 2 s (a tap along the top / bottom edge)
  function calmShow() {
    if (!bare) return;
    document.body.classList.remove('calm'); hudDraw(); clearTimeout(calmT);
    calmT = setTimeout(() => { document.body.classList.toggle('calm', bare); hudDraw(); }, 2000);
  }
  function setBare(v, save) {
    bare = !!v; document.body.classList.toggle('bare', bare); $('vidbare').checked = bare;
    clearTimeout(calmT); document.body.classList.toggle('calm', bare); hudDraw();
    if (save) { store('bare', bare ? '1' : '0'); bareLink = false; if (land) landPrev = bare; }
    $('barshow').title = bare ? 'Show the menu bar and the frame (~)' : 'Hide the menu bar and the frame (~)';
    applyScale(); hudDraw();
  }
  let z48r = 0.459; // ZX48 keyboard: height / width (measured: 0.4587)
  function applyScale() {
    const v = $('scale').value;
    const w = canvas.width || 640, h = canvas.height || 480;
    let k;
    if (document.fullscreenElement) k = Math.min(window.innerWidth / w, window.innerHeight / h);
    else {
      const vk = $('vkbd');
      const vkh = vk.hidden || land ? 0 : vkbd && vkbd.tab === 'joy' ? Math.min(vk.offsetHeight, kbdRoom(canvas.offsetWidth || 640)) : vk.offsetHeight; // the joystick may hang lower
      // a phone in landscape: the whole screen, the on-screen keyboards over it (landKbd)
      const reserved = land ? $('toolbar').offsetHeight + 2 + 2 : $('toolbar').offsetHeight + 2 + (vk.hidden ? 0 : vkh + 2) + 8 + 24; // frame, gap + padding
      const vw = Math.max(360, Math.min(window.innerWidth, document.documentElement.clientWidth || window.innerWidth, (window.visualViewport && window.visualViewport.width) || 1e9)); // the page is never narrower than 360 px
      const vh = Math.min(window.innerHeight, (window.visualViewport && window.visualViewport.height) || 1e9);
      // landscape with a keyboard or the joystick on: the screen is lower than the whole height, so the halves at the sides get wider
      // and their keys bigger (the home screen app has no browser bars: 82 % keeps the height it has in the browser)
      const fh = land ? (!vk.hidden ? Math.round(vh * (HOME_APP ? 0.82 : 0.9)) : vh - 10) : vh; // the browser: a bit lower than all of it too; no keyboard: 5 px off the top and the bottom
      // ZX48: the keyboard's height follows its width (the screen's): its share of the width (measured) goes into the fit, else
      // each scale saw the keyboard of the scale before and the screen swung (iPad landscape: showing it again, the keyboard menu)
      const prop = !vk.hidden && !land && vkbd && vkbd.tab === 'zx48';
      if (prop && vk.offsetWidth > 100) z48r = vk.offsetHeight / vk.offsetWidth;
      const byH = prop ? (fh - (reserved - vkh) - z48r * 2) / (h + z48r * w) : (fh - reserved) / h;
      const fit = Math.max(0.25, Math.min((vw - 18) / w, byH));
      k = v === 'fit' ? fit : Math.min(parseFloat(v), fit); // selected zoom is the upper limit
    }
    const cw = Math.floor(w * k), ch = Math.floor(h * k);
    canvas.style.width = cw + 'px';
    canvas.style.height = ch + 'px';
    canvas.classList.toggle('smooth', Math.abs(k - Math.round(k)) > 0.01);
    placeFx();
    $('stage').style.width = document.fullscreenElement ? '' : cw + 2 + 'px'; // + the frame
    // vertical place: centred as if the on-screen keyboard (ZX / XT) were shown, so it appears below without moving the window
    if (document.fullscreenElement) { $('stage').style.margin = ''; return; }
    const vh = Math.min(window.innerHeight, (window.visualViewport && window.visualViewport.height) || 1e9);
    const total = land ? $('toolbar').offsetHeight + ch + 2 : 12 + $('toolbar').offsetHeight + ch + 2 + 8 + kbdRoom(cw) + 12;
    // landscape: the stage is fixed to the visible area, centred in its height
    if (land) { if (window.scrollX || window.scrollY) window.scrollTo(0, 0); $('stage').style.margin = ''; $('stage').style.top = Math.max(0, Math.floor((vh - total) / 2)) + 'px'; } // no scroll: iOS draws fixed things where it hit-tests them then
    else { $('stage').style.top = ''; $('stage').style.margin = Math.max(0, Math.floor((vh - total) / 2)) + 'px auto 0'; }
    landKbd();
  }
  // a phone turned to landscape: the screen fits the whole height, the on-screen keyboards are split: the left half at the
  // left edge, the right half at the right edge, beside the screen (vkbd setSplit); the JOY stick and fire at the edges too
  function landUpdate() {
    const v = !!(LAND_MQ && LAND_MQ.matches); if (v === land) { if (v) applyScale(); return; }
    land = v; document.body.classList.toggle('land', v); document.documentElement.classList.toggle('land', v); if (vkbd) vkbd.setLand(v);
    if (v) { landPrev = bare; setBare(true, false); } else setBare(landPrev, false); // landscape: as hidemenu=1 (not stored); upright: as before
  }
  function landKbd() {
    const vk = $('vkbd'), root = document.documentElement;
    if (!land) { vk.style.removeProperty('--kbw'); root.style.removeProperty('--side'); root.style.removeProperty('--ljs'); root.style.removeProperty('--lbot'); return; }
    const vw = window.innerWidth, vh = Math.min(window.innerHeight, (window.visualViewport && window.visualViewport.height) || 1e9), st = $('stage').getBoundingClientRect();
    const side = Math.max(60, Math.floor(Math.min(st.left, vw - st.right)) - 10); // the room beside the screen
    root.style.setProperty('--side', side + 'px');
    root.style.setProperty('--lbot', Math.max(2, Math.floor(vh - st.bottom)) + 'px'); // the keyboards and the stick end where the screen ends
    root.style.setProperty('--ljs', String(Math.max(0.4, Math.min(1, (side - 10) / 200)))); // the stick: as wide as the room
    let w = Math.floor(side / ((vkbd && vkbd.share) || 0.5) * 0.93); vk.style.setProperty('--kbw', w + 'px'); // a key that sits over the middle (by its centre) stays off the screen; the larger half fits the room
    const half = vkbd && !vk.hidden && vkbd.half(); if (!half) return;
    const h = half.offsetHeight, max = Math.min(vh, st.bottom) - 8;
    if (h > max) { w = Math.floor(w * max / h); vk.style.setProperty('--kbw', w + 'px'); }
  }

  // height kept for the on-screen keyboard: the ZX / XT keyboard as measured at this width (an estimate before it was shown)
  const kbdSeen = {};
  function kbdRoom(cw) {
    const vk = $('vkbd'), t = vkbd && vkbd.tab;
    if (!vk.hidden && t !== 'joy' && vk.offsetHeight) kbdSeen[cw] = Math.max(kbdSeen[cw] || 0, vk.offsetHeight);
    // the tallest of ZX / XT (up to 314 px) and ZX48 (its height follows its width: on a tablet the tallest): the room is
    // there before any keyboard was shown, so the window does not move up when one appears (+2: rounding of the keys)
    return Math.max(kbdSeen[cw] || 0, Math.min(Math.round(cw * 0.49), 314), Math.ceil((cw + 2) * z48r)) + 2;
  }

  // ------------------------------------------------------------------ CPU clock (t-states per frame)
  const baseFrame = () => ulaFrame || MODELS[model].base; // 3.5 MHz = 1x (Options / ULA may set its own)
  const SPEEDS = [0.1, 0.5, 1, 2, 2.5, 3, 5, 10, 15, 20];
  let speedIdx = SPEEDS.indexOf(2);
  function speedLabel(x) { return x + 'x'; }
  // the clock shown over the screen (the CPU clock setting only: the machine's own turbo bit is not emulated)
  function mhzLabel() { hudSet('mhz', $('speedmhz').textContent); }
  // TS-Conf: the program sets the CPU clock (SysConfig: 3.5 / 7 / 14 MHz); the label shows it (the slider stays locked)
  let tsMult = 0;
  // TS-Conf: reset with Symbol Shift held (TS-BIOS opens Setup); the Shift keys of the PC are let go for it (left Shift is
  // Caps Shift: TS-BIOS would start the CS boot instead)
  function tsSetup() {
    releaseAll(); E.web_zxkey(57, 1); E.web_reset(0);
    afterFrames(60, () => E.web_zxkey(57, 0));
  }
  // ZX Evo TS-Conf: it starts in the TS-BIOS Setup; sd/wc.zip goes onto the SD card (unless a card is in) and NVRAM
  // "Reset to" is "BD boot.$c", so Reset (F12) boots Wild Commander of the card (TR-DOS: Setup, Reset to: ROM)
  const wcUrl = () => new URL(lowDir(UPD.WCTS.sd), location.href).href;
  let wcCardP = null; // sd/wc.zip on its way onto the SD card (the start and a disk copied to the card share it)
  function wcCard() {
    if (!wcCardP) wcCardP = (async () => {
      const t = UPD.WCTS;
      try { const b = await fetchBytes(t.sd); nedoNote(b, t); await sdFromBytes(t.sd.replace(/^.*\//, ''), b, true); if (sdName) sdSrc = wcUrl(); } catch (e) {}
    })().finally(() => { wcCardP = null; });
    return wcCardP;
  }
  async function tsWc() {
    if (wcCardP) await wcCardP;
    if (!(sdName && fs.exists(sdName))) await wcCard();
    if (!sdName) { tsNvSet(0xB4, 0); return; } // no card (none on the server): Reset to ROM (TR-DOS)
    sdEnable(true);
  }
  // a TS-BIOS NVRAM cell (#B0..#E5) with its CRC16 (CCITT, from #FFFF over #B1..#E5) at #E6 / #E7
  function tsNvSet(cell, v) {
    if (!E.web_cmos) return;
    const c = new Uint8Array(E.memory.buffer, E.web_cmos(), 256);
    const crc = () => { let r = 0xFFFF; for (let i = 0xB1; i <= 0xE5; i++) { r ^= c[i] << 8; for (let b = 0; b < 8; b++) r = r & 0x8000 ? ((r << 1) ^ 0x1021) & 0xFFFF : (r << 1) & 0xFFFF; } return r; };
    if (crc() !== (c[0xE6] | c[0xE7] << 8)) { // no NVRAM yet: TS-BIOS defaults (nv_def of ts-bios.asm), as its Setup would write them
      const def = [0, 0, 0, 1, 0, 0, 3, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0];
      for (let k = 0; k < 16; k++) { const g = k < 8 ? k * 2 : (k - 8) * 2 + 1, w = g << 10 | g << 5 | g; def.push(w & 0xFF, w >> 8); }
      c.set(def, 0xB0);
    }
    c[cell] = v;
    const r = crc(); c[0xE6] = r & 0xFF; c[0xE7] = r >> 8;
  }
  const tsNvGet = (cell) => (E.web_cmos ? new Uint8Array(E.memory.buffer, E.web_cmos(), 256)[cell] : 0);
  // TS-BIOS boots by its NVRAM "Reset to" (#B4) / "->bank" (#B5): a macro that resets into a ROM bank sets ROM #00 + the bank
  // for its reset and puts the user's choice back right after it (Reset, F12: Wild Commander again)
  function tsResetTo(bank) {
    const b4 = tsNvGet(0xB4), b5 = tsNvGet(0xB5);
    tsNvSet(0xB4, 0); tsNvSet(0xB5, bank);
    return [{ reset: 0 }, { wait: 25 }, { fn: () => { tsNvSet(0xB4, b4); tsNvSet(0xB5, b5); } }];
  }
  // Wild Commander on the screen: the TS-Conf text mode with its key bar ("SetUP") in the screen page
  function wcShown() {
    if (!isTS() || !E.web_ts_info || !E.web_mem_ptr) return false; // TS-Conf, a Custom ROM one too
    const i = new Uint32Array(E.memory.buffer, E.web_ts_info(), 40);
    if ((i[0] & 3) !== 3) return false;
    const m = new Uint8Array(E.memory.buffer, E.web_mem_ptr() + (i[1] & 0xFF) * 16384, 16384), k = [83, 101, 116, 85, 80]; // SetUP
    for (let o = 0; o + 5 <= m.length; o++) if (m[o] === 83 && m[o + 1] === 101 && m[o + 2] === 116 && m[o + 3] === 85 && m[o + 4] === 80) return true;
    return false;
  }
  // Wild Commander's text screen (TS-Conf text mode: 256 bytes a row, characters 0..127, their attributes at +128):
  // rows as text; the key bar row ("SetUP"); the panels: columns 1..44 and 46..89
  function wcText() {
    if (!isTS() || !E.web_ts_info) return '';
    const i = new Uint32Array(E.memory.buffer, E.web_ts_info(), 40), m = new Uint8Array(E.memory.buffer, E.web_mem_ptr() + (i[1] & 0xFF) * 16384, 16384);
    let t = ''; for (let y = 0; y < 64; y++) t += String.fromCharCode(...m.subarray(y * 256, y * 256 + 128)) + '\n';
    return t;
  }
  function wcScreen() {
    const i = new Uint32Array(E.memory.buffer, E.web_ts_info(), 40);
    const m = new Uint8Array(E.memory.buffer, E.web_mem_ptr() + (i[1] & 0xFF) * 16384, 16384);
    const rows = [], attr = [];
    for (let y = 0; y < 64; y++) { rows.push(String.fromCharCode(...m.subarray(y * 256, y * 256 + 128)).replace(/[\x00-\x1F\x7F-\xFF]/g, ' ')); attr.push(m.subarray(y * 256 + 128, y * 256 + 256)); }
    const bar = rows.findIndex((r) => r.includes('SetUP'));
    if (bar < 4) return null;
    const half = [[1, 45], [46, 90]];
    // the active panel: the one with the cursor bar — a background (high nibble) the other file rows do not have
    const cnt = new Map(), at = [];
    for (let y = 2; y < bar - 2; y++) for (let h = 0; h < 2; h++) { const b = attr[y][half[h][0] + 1] >> 4; at.push([y, h, b]); cnt.set(b, (cnt.get(b) || 0) + 1); }
    const cur = at.filter(([, , b]) => cnt.get(b) <= 2).sort((p, q) => cnt.get(p[2]) - cnt.get(q[2]))[0], act = cur ? cur[1] : 0, [c0, c1] = half[act];
    return {
      path: rows[1].slice(c0 - 1, c1).trim(), // "0:\" or "0:\DIR\"
      name: rows[bar - 2].slice(c0, c1).split(/ {2,}/)[0].trim(), // the status line: the long name under the cursor
    };
  }
  // Wild Commander starts a file of the SD card (sdRun, the card's .json): it waits for Wild Commander, goes to the
  // file's folder from the root (Enter on folders, ".." up), moves the cursor until the status line shows the file and
  // presses Enter — as the user would. PC keys mode for the keys (back as it was after)
  function wcAutorun() {
    if (!sdRun || !isTS()) return;
    const parts = sdRun.split('/').filter(Boolean), want = sdRun;
    let depth = 0, dir = 1, last = null, same = 0, flips = 0, steps = 0;
    const press = (code) => [{ xt: [code] }, { wait: 5 }, { fn: nav }];
    const lower = (t) => t.toLowerCase();
    function nav() {
      if (++steps > 4000 || !isTS()) { toast('Wild Commander: ' + want + ' not found', true); return; }
      const sc = wcShown() && wcScreen();
      if (!sc) { macro.steps.unshift({ wait: 10 }, { fn: nav }); return; }
      const here = lower(sc.path.replace(/^\d+:\\?/, '').replace(/\\$/, '')), need = lower(parts.slice(0, depth).join('\\'));
      if (here !== need && !(need.startsWith(here) && (here === '' || need[here.length] === '\\'))) { // above or aside the way: up
        if (sc.name === '..') { macro.steps.unshift(...press('Enter'), { wait: 15 }); last = null; same = flips = 0; dir = 1; return; }
        if (here === '') { toast('Wild Commander: ' + want + ' not found', true); return; }
        macro.steps.unshift(...press(dir > 0 ? 'ArrowUp' : 'ArrowDown')); dir = -1; return; // ".." is the first row
      }
      if (here !== need) { depth = here ? here.split('\\').length : 0; } // deeper on our way: go on from there
      const target = lower(parts[depth]);
      if (lower(sc.name) === target) {
        macro.steps.unshift({ xt: ['Enter'] }, { wait: 15 });
        if (depth < parts.length - 1) { depth++; last = null; same = flips = 0; dir = 1; macro.steps.splice(2, 0, { fn: nav }); }
        else macro.steps.splice(2, 0, { until: () => wcText().includes('RUN File AT'), max: 50, soft: true }, { fn: () => { if (wcText().includes('RUN File AT')) macro.steps.unshift({ xt: ['Enter'] }); } }); // an SPG without its clock: the speed Wild Commander offers
        return;
      }
      if (sc.name === last) { if (++same >= 3) { if (++flips > 2) { toast('Wild Commander: ' + want + ' not found', true); return; } dir = -dir; same = 0; } } // an end of the list: the other way
      else same = 0;
      last = sc.name;
      macro.steps.unshift(...press(dir > 0 ? 'ArrowDown' : 'ArrowUp'));
    }
    const xt = !!E.web_xt_kbd();
    runMacro([{ until: () => !wcShown(), max: 300, soft: true }, // the reset first (a Wild Commander on the screen now is the one before)
      { until: () => wcShown() && !!wcScreen(), max: 3000, fail: 'Wild Commander did not start: ' + want + ' not run' }, { wait: 50 },
      { xtmode: 1 }, { fn: nav }, { xtmode: xt ? 1 : 0 }]);
  }
  // ZX Evo TS-Conf: files for Wild Commander go into the root of the SD card — a disk put into a drive (as .trd: Enter on it
  // in Wild Commander starts its MOUNTER plug-in, vDOS) and a .wmf program (Wild Commander runs it). The card has to be the
  // server's wc.zip without changes (files put there this way do not count); another card, or a changed one, is replaced with
  // wc.zip when the user says so. Wild Commander on the screen re-reads its panels (Ctrl+R, Tab)
  async function wcDiskToSd(d, name, buf) {
    if (M() !== 'TSCONF' || !/\.(trd|scl|fdi|udi|td0)$/i.test(name)) return;
    let img = null;
    if (/\.trd$/i.test(name)) img = new Uint8Array(buf);
    else { // other formats: TRD through the core, from the drive
      setName('__wc.trd'); if (E.web_disk_peek_trd && E.web_disk_peek_trd(d) && fs.exists('__wc.trd')) img = new Uint8Array(fs.read('__wc.trd'));
      try { fs.remove('__wc.trd'); } catch (e) {}
    }
    if (!img || img.length < 0x900 || img[0x8E7] !== 0x10) return; // not a TR-DOS disk
    await wcPut((name.replace(/\.[^.]*$/, '').trim() || 'DISK') + '.trd', img, ' is in drive ' + DRV[d] + ': only');
  }
  // a Wild Commander program (.wmf): only onto the SD card (on another machine TS-Conf starts first)
  async function wcWmf(name, buf) {
    if (!isTS()) { toast(name + ': a Wild Commander program — ZX Evo TS-Conf starts'); await setModel('TSCONF', true); if (!isTS()) return; }
    await wcPut(name, new Uint8Array(buf), ' not loaded');
  }
  async function wcPut(fname, data, failNote) {
    if (wcCardP) await wcCardP;
    const have = !!(sdName && fs.exists(sdName));
    if (!(have && sdSrc === wcUrl() && (!sdDirty || sdWcOwn))) {
      if (have) {
        if (linkLoading) return false; // a link brings its own card: kept, no question
        const q = sdDirty && !sdWcOwn ? 'SD image ' + sdName + ' is to unmount (it has changes).\nDiscard changes and insert wc.zip with ' + fname + '?'
          : 'SD image ' + sdName + ' is to unmount.\nInsert wc.zip with ' + fname + ' instead?';
        if (!await askBox('SD card', q)) return false;
      }
      await wcCard();
      if (!(sdName && fs.exists(sdName) && sdSrc === wcUrl())) { toast(UPD.WCTS.sd + ' not found: ' + fname + failNote, true); return false; }
    }
    const T = window.UnrealFC._test, a = fs.read(sdName), base = T.fatFind(a)[0];
    if (base === undefined) return false;
    const vol = T.fatVol(a, base), dot = fname.lastIndexOf('.'), nm = dot > 0 ? fname.slice(0, dot) : fname, ext = dot > 0 ? fname.slice(dot + 1) : '';
    vol.setPath([]);
    const old = vol.list().find((it) => !it.dir && (it.name + (it.ext ? '.' + it.ext : '')).toLowerCase() === fname.toLowerCase());
    if (old) {
      const od = vol.read(old).data;
      if (od.length === data.length && od.every((v, k) => v === data[k])) { toast('SD card: ' + fname + ' is in the root already'); return true; }
      vol.del(old);
    }
    try { vol.write({ name: nm, ext, data }); } catch (e) { toast('SD card: ' + fname + ' not copied (' + e.message + ')', true); return false; }
    sdDirty = true; sdWcOwn = true; sdUI(); // written: '*' (Save gives the card with it)
    toast('SD card: ' + fname + ' in the root (Wild Commander: Enter on it)');
    if (!macro && wcShown()) { const xt = !!E.web_xt_kbd(), rr = { xt: ['ControlLeft', 'KeyR'] }, tab = { xt: ['Tab'] }; runMacro([{ xtmode: 1 }, rr, tab, rr, tab, { xtmode: xt ? 1 : 0 }]); } // both panels
    return true;
  }
  // TS-BIOS "CS Reset to: BD boot.$c" (its default): Caps Shift held over Reset starts boot.$C of the boot device (SD card)
  function tsBootSd() {
    const wait = 125 - framesRun; // just started: TS-BIOS first goes through its power-up (keys held there open the Setup)
    if (wait > 0) { afterFrames(wait, tsBootSd); return; }
    releaseAll(); E.web_zxkey(0, 1); E.web_reset(0);
    afterFrames(60, () => E.web_zxkey(0, 0));
  }
  // the machine's own clock (TS-Conf: always; others: True clock): the program switches it, the label follows
  function hwClock() {
    if (M() === 'SAM') { tsMult = 0; if (trueClk() && $('speedmhz').textContent !== '6 MHz') { $('speedmhz').textContent = '6 MHz'; mhzLabel(); } return; } // SAM Coupé: 6 MHz (True clock), else the slider
    const m = E && E.web_hw_mult ? E.web_hw_mult() : 0;
    if (m === tsMult) return; tsMult = m;
    if (!m) { if (!trueClk()) setSpeed(speedIdx, false); return; }
    $('speedmhz').textContent = (3.5 * m) + ' MHz'; mhzLabel();
    $('speedticks').querySelectorAll('span').forEach((t) => t.classList.toggle('on', +t.dataset.x === m));
  }
  // True clock (Options / System, off by default): every model runs at its own 3.5 MHz and programs switch its turbo
  // (TS-Conf works so always: its checkbox is on and locked)
  // a link may set it for this visit (trueclock=1 / 0; speed= alone: off), not stored; the checkbox ends that
  let tcLink = null;
  const tcFromLink = (p) => { if (p.trueclock !== undefined) tcLink = !/^(0|no|off|false)$/i.test(p.trueclock); else if (p.speed !== undefined) tcLink = false; };
  const trueClk = () => !!MODELS[model].fixed || (tcLink !== null ? tcLink : load('trueclk') === '1');
  // the speed the ROM runs at for the start macros (their waits in frames): True clock: as the machine (1x; TS-Conf
  // keeps the slider), else the CPU slider
  function mclk() { return !isTS() && trueClk() ? 1 : SPEEDS[speedIdx]; }
  function trueClkApply() {
    const ts = !!MODELS[model].fixed;
    $('trueclk').checked = trueClk(); $('trueclk').disabled = ts;
    $('trueclkrow').title = ts ? 'ZX Evo TS-Conf: always — the program sets the clock (3.5 / 7 / 14 MHz)' : $('trueclkrow').dataset.t || $('trueclkrow').title;
    if (E && E.web_true_clock && !ts) E.web_true_clock(trueClk() && M() !== 'SAM' ? baseFrame() : 0); // SAM: its own clock (web_sam_speed)
    tsMult = -1; setSpeed(speedIdx, false); hwClock();
  }
  // MHz (top centre) and fps (top right) over the screen: drawn on a transparent canvas of its own, at the pixel density of the
  // display — no page text changes every second (ad blockers in Safari rescan the page on each change: 1/3 s stalls)
  let hudLay = ''; // ☰ corner / ● REC shown: the ULAX label moves (hudDraw)
  const hud = { fps: '— fps', mhz: '', net: '', trk: '', trkKind: 0, ulax: '' }; // trk: the track at the disk LED (updLed)
  let hudW = 0, hudH = 0, hudDpr = 0;
  function hudSet(k, v) { if (hud[k] === v) return; hud[k] = v; hudDraw(); }
  // redrawn whenever its size changes (window resize, zoom, fullscreen, another display): the drawing is not stretched
  if (window.ResizeObserver) new ResizeObserver(() => hudDraw()).observe($('hudc'));
  window.addEventListener('resize', () => hudDraw());
  // the site answering? HEAD of the page (no service worker in the way: it handles GET only), 5 s at most; every 20 s,
  // when the network changes and when the page comes back. Options / Offline: "offline" over the screen, on by default
  let netOff = false;
  async function netProbe() {
    if (!/^https?:$/.test(location.protocol)) return;
    const ac = window.AbortController ? new AbortController() : null, t = ac && setTimeout(() => ac.abort(), 5000);
    let ok = false;
    try { const r = await fetch(location.pathname + '?ping=' + Date.now(), { method: 'HEAD', cache: 'no-store', signal: ac && ac.signal }); ok = r.status > 0; } catch (e) { ok = false; }
    clearTimeout(t);
    netOff = !ok || navigator.onLine === false; netLabel();
  }
  function netLabel() { hudSet('net', netOff && load('offlabel') !== '0' ? 'offline' : ''); }
  function bindNet() {
    $('of_label').checked = load('offlabel') !== '0';
    $('of_label').onchange = () => { store('offlabel', $('of_label').checked ? '1' : '0'); netLabel(); };
    // the site is checked at start; checking it again (every 20 s, on a network change, on return to the tab) is an option
    const poll = () => load('offpoll') === '1';
    $('of_poll').checked = poll();
    $('of_poll').onchange = () => { store('offpoll', $('of_poll').checked ? '1' : '0'); if (poll()) netProbe(); };
    window.addEventListener('online', () => { if (poll()) netProbe(); }); window.addEventListener('offline', () => { if (poll()) { netOff = true; netLabel(); } });
    document.addEventListener('visibilitychange', () => { if (!document.hidden && poll()) netProbe(); });
    setInterval(() => { if (!document.hidden && poll()) netProbe(); }, 20000);
    netProbe();
  }
  function hudDraw() {
    const c = $('hudc'); if (!c) return;
    const r = c.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    if (!r.width) return;
    const w = Math.round(r.width * dpr), h = Math.round(Math.min(r.height, 24) * dpr);
    if (w !== hudW || h !== hudH || dpr !== hudDpr) { c.width = hudW = w; c.height = hudH = h; hudDpr = dpr; c.style.height = (h / dpr) + 'px'; }
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    const fs = window.innerWidth <= 520 ? 9 : 11; // as the page text had it (narrow screens: 9px)
    g.font = fs + 'px ui-monospace, Consolas, Menlo, monospace'; g.textBaseline = 'top';
    const put = (t, x, align) => {
      if (!t) return; g.textAlign = align;
      g.fillStyle = '#000'; g.shadowColor = '#000'; g.shadowBlur = 3; g.fillText(t, x + 1, 5); // the shadow of the old page text
      g.shadowBlur = 0; g.fillStyle = 'rgba(225,232,240,.75)'; g.fillText(t, x, 4);
    };
    const calm = document.body.classList.contains('calm'); // Hide Menu Bar (also a phone in landscape), hidden now: MHz and FPS go, "offline" stays
    const noMhz = calm, noFps = calm;
    if (!noMhz) put(hud.mhz, r.width / 2, 'center');
    if (!noFps) put(hud.fps, r.width - 5, 'right');
    { // ● REC: at a quarter of the width, right of the ☰ corner and of the sound visualizer (its room even while it is faded
      // out); no room for it before the MHz: a line lower, under the visualizer
      const rm = $('recmark');
      if (!rm.hidden) {
        const rb = (id, any) => { const e = $(id); if (!e || e.hidden) return null; const b = e.getBoundingClientRect(); return b.width && (any || getComputedStyle(e).visibility !== 'hidden') ? b : null; };
        const bc = rb('barshow'), vz = vzMode !== 'off' ? rb('viz', true) : null, w = rm.offsetWidth;
        const L0 = bc ? bc.right - r.left + 6 : 4, L = Math.max(L0, vz ? vz.right - r.left + 8 : 0);
        const mhzL = noMhz ? r.width - 5 - (noFps ? 0 : g.measureText(hud.fps || '').width + 10) : r.width / 2 - g.measureText(hud.mhz || '').width / 2 - 8;
        let c = Math.max(r.width / 4, L + w / 2), top = 2;
        if (c + w / 2 > mhzL) { c = Math.max(L0, vz ? vz.left - r.left : 4) + w / 2; top = Math.round((vz ? vz.bottom : (bc ? bc.bottom : r.top + 20)) - r.top + 4); }
        rm.style.left = Math.round(c) + 'px'; rm.style.top = top + 'px';
      }
    }

    let netL = r.width - 5;
    if (hud.net) { // "offline": left of the fps (at the right edge when the fps is hidden), red
      const x = r.width - 5 - (noFps ? 0 : g.measureText(hud.fps || '').width + 10); g.textAlign = 'right';
      g.fillStyle = '#000'; g.shadowColor = '#000'; g.shadowBlur = 3; g.fillText(hud.net, x + 1, 5);
      g.shadowBlur = 0; g.fillStyle = 'rgba(255,82,82,.95)'; g.fillText(hud.net, x, 4);
      netL = x - g.measureText(hud.net).width;
    } else if (!noFps) netL = r.width - 5 - g.measureText(hud.fps || '').width;
    // the disk / tape LED: in the middle of the room between MHz and "offline" (or the fps)
    let mhzR = noMhz ? r.width / 2 : r.width / 2 + g.measureText(hud.mhz || '').width / 2;
    { // ZX ULAX (a dux loaded): drawn as the MHz, right of it (a small gap), white on / gray off; its button an invisible
      // place to click over the text; the disk LED in the middle of the room after it. Hide Menu Bar: gone with the MHz
      const b = $('ulaxhud');
      if (b) b.style.visibility = calm || !hud.ulax ? 'hidden' : '';
      if (b && hud.ulax && !calm) {
        const t = 'ULAX', tw = g.measureText(t).width, x = noMhz ? r.width / 2 - tw / 2 : mhzR + Math.round(fs * 1.2);
        g.textAlign = 'left'; g.fillStyle = '#000'; g.shadowColor = '#000'; g.shadowBlur = 3; g.fillText(t, x + 1, 5);
        g.shadowBlur = 0; g.fillStyle = hud.ulax === 'on' ? 'rgba(245,248,252,.95)' : 'rgba(150,156,164,.55)'; g.fillText(t, x, 4);
        b.style.left = Math.round(x - 4) + 'px'; b.style.width = Math.round(tw + 8) + 'px'; b.style.height = Math.round(fs + 10) + 'px';
        mhzR = x + tw;
      }
    }
    const ledX = Math.round((mhzR + netL) / 2);
    $('dled').style.left = ledX + 'px';
    if (hud.trk) { // the track right of the floppy, in its color (read blue, write red, seek dim)
      g.textAlign = 'left'; const x = ledX + 9 + 3;
      g.fillStyle = '#000'; g.shadowColor = '#000'; g.shadowBlur = 3; g.fillText(hud.trk, x + 1, 5);
      g.shadowBlur = 0; g.fillStyle = hud.trkKind === 1 ? '#4f9dff' : hud.trkKind === 4 ? 'rgba(225,232,240,.6)' : '#ff4f43'; g.fillText(hud.trk, x, 4);
    }
  }
  function setSpeed(idx, save) {
    if (MODELS[model].fixed) { idx = SPEEDS.indexOf(MODELS[model].speed); save = false; }
    $('speedrange').closest('.speedbox').classList.toggle('off', !!MODELS[model].fixed || trueClk());
    speedIdx = Math.max(0, Math.min(SPEEDS.length - 1, idx));
    const x = SPEEDS[speedIdx];
    if (E && E.web_sam_speed) E.web_sam_speed(M() === 'SAM' && !trueClk() ? Math.round(x * 1000) : 1000); // SAM: the core keeps the ASIC's time
    if (trueClk()) { tsMult = 0; hwClock(); return; } // the machine's own clock: the core sets the frame
    if (E && M() !== 'SAM') E.web_set_frame(Math.round(baseFrame() * x));
    $('speedrange').value = speedIdx;
    $('speedmhz').textContent = ((M() === 'SAM' ? 6 : 3.5) * x).toFixed(2).replace(/\.?0+$/, '') + ' MHz';
    mhzLabel();
    $('speedticks').querySelectorAll('span').forEach((t, i) => t.classList.toggle('on', i === speedIdx));
  }
  function bindSpeed() {
    const ticks = $('speedticks');
    $('speedrange').max = String(SPEEDS.length - 1);
    SPEEDS.forEach((x, i) => { const t = document.createElement('span'); t.textContent = speedLabel(x); t.dataset.x = String(x); t.onclick = () => setSpeed(i, true); ticks.appendChild(t); });
    $('speedrange').oninput = () => setSpeed(+$('speedrange').value, true);
    $('trueclkrow').dataset.t = $('trueclkrow').title;
    $('trueclk').onchange = () => { tcLink = null; store('trueclk', $('trueclk').checked ? '1' : '0'); trueClkApply(); };
    loadSpeed();
  }
  // ------------------------------------------------------------------ port #EFF7 (Pentagon: Options / System, as the EFF7 page of the Win32 settings)
  const EFF7_BITS = ['16 colors (4 bits per pixel)', 'Pentagon 512×192 monochrome', 'disable memory above 128K', 'RAM 0 at #0000', 'no turbo (always on; True clock: off = 7 MHz)',
    'hardware multicolor (8×1 attributes at #6000)', '384×304 video mode', 'CMOS (#DFF7 / #BFF7)'];
  let eff7Built = false;
  const eff7Key = (m) => 'eff7.' + (m || model);
  function eff7Saved(m) { try { const o = JSON.parse(load(eff7Key(m)) || '{}'); return { m: (o.m | 0) & 0xEF, s: (o.s | 0) & 0xFF }; } catch (e) { return { m: 0, s: 0 }; } }
  const isPent = (m) => m === 'PENTAGON' || (m === 'CUSTOM' && MACHINES[customCfg.mach] && MACHINES[customCfg.mach].himem === 'PENTAGON');
  function eff7Apply() { // model start: the locked bits and their state as set before
    if (!E || !E.web_eff7 || E.web_mem_model() !== 0) return;
    const { m, s } = eff7Saved();
    E.web_eff7_mask(m); E.web_eff7((E.web_eff7(-1) & ~m) | (s & m));
  }
  // shown for the model chosen in the list: the running one live; another one (not started yet): its saved locked bits, used at its start
  const eff7Live = () => $('modelsel').value === model && !!(E && E.web_eff7 && E.web_mem_model() === 0);
  function eff7Get() { if (eff7Live()) return { v: E.web_eff7(-1), m: E.web_eff7_mask(-1) }; const o = eff7Saved($('modelsel').value); return { v: o.s | 0x10, m: o.m }; }
  function eff7Set(v, m) {
    const sel = $('modelsel').value;
    if (eff7Live()) { E.web_eff7_mask(m); E.web_eff7(v); eff7Store(); }
    else store(eff7Key(sel), JSON.stringify({ m: m & 0xEF, s: v & m & 0xEF }));
  }
  function eff7UI() {
    const card = $('eff7card'), on = isPent($('modelsel').value);
    card.hidden = !on; if (!on) return;
    const g = $('eff7grid');
    if (!eff7Built) {
      eff7Built = true;
      EFF7_BITS.forEach((t, i) => {
        const b = document.createElement('span'); b.textContent = 'D' + i;
        const s = document.createElement('input'); s.type = 'checkbox'; s.dataset.st = i;
        const l = document.createElement('input'); l.type = 'checkbox'; l.dataset.lk = i;
        const n = document.createElement('span'); n.textContent = t;
        if (i === 4) { s.disabled = l.disabled = true; n.className = 'dis'; }
        s.onchange = () => { const { v, m } = eff7Get(), b = 1 << i; eff7Set(s.checked ? v | b : v & ~b, eff7Live() || !s.checked ? m : m | b); eff7UI(); }; // not started: on = on + lock
        l.onchange = () => { const { v, m } = eff7Get(), b = 1 << i; eff7Set(v, l.checked ? m | b : m & ~b); eff7UI(); };
        g.append(b, s, l, n);
      });
    }
    const { v, m } = eff7Get();
    $('eff7later').hidden = eff7Live();
    g.querySelectorAll('[data-st]').forEach((x) => { x.checked = !!(v & (1 << x.dataset.st)); });
    g.querySelectorAll('[data-lk]').forEach((x) => { if (x.dataset.lk !== '4') x.checked = !!(m & (1 << x.dataset.lk)); });
    $('eff7val').textContent = '#' + v.toString(16).toUpperCase().padStart(2, '0') + (m & 0xEF ? ' · lock #' + (m & 0xEF).toString(16).toUpperCase().padStart(2, '0') : '');
  }
  function eff7Store() { const m = E.web_eff7_mask(-1) & 0xEF; store(eff7Key(), JSON.stringify({ m, s: E.web_eff7(-1) & m })); }
  setInterval(() => { if (optOpen() && curPane === 'sys') eff7UI(); }, 400); // programs change the port: shown while the page is open

  // ------------------------------------------------------------------ ULA (Options / ULA, as the ULA page of the Win32 settings)
  // The running model's ULA: timings (a preset of unreal.ini or own values) and its options, kept in the browser for each
  // model ('ula.<model>') and set again at its start. The defaults: the model as it starts (its preset, its 3.5 MHz frame).
  // The frame here is the 3.5 MHz one: the CPU clock multiplies it. Not for SAM Coupé (its own ASIC) and the RZX machines.
  let ulaFrame = null, ulaDef = null, ulaHz = 50;
  const ULA_T = [2, 3, 4, 5], ULA_O = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
  const ULA_NUM = { ulapaper: 2, ulaline: 3, ulaint: 4, ulaintlen: 5 };
  const ulaKey = () => 'ula.' + model;
  const ulaMach = () => (model === 'CUSTOM' ? customCfg.mach : M());
  const ulaOk = () => !!(E && E.web_ula) && M() !== 'SAM' && !RZX_MODELS.has(model);
  const ulaTimeOk = () => ulaOk() && !MODELS[model].fixed; // TS-Conf, Sprinter: their own frame
  const ulaFor = (id) => { // the options that are for some machines only
    const m = ulaMach();
    if (id === 13) return m === 'PROFI';
    if (id === 14) return ['ATM450', 'ATM710', 'XBIOS136', 'EVO', 'PROFI'].includes(m);
    if (id === 15) return ['ATM450', 'ATM710', 'XBIOS136', 'EVO'].includes(m);
    return true;
  };
  function ulaSaved() { try { const o = JSON.parse(load(ulaKey()) || 'null'); return o && typeof o === 'object' ? o : null; } catch (e) { return null; } }
  function ulaPreIdx(name) { if (!name) return -1; for (let i = 0, n = E.web_ula_presets(); i < n; i++) if (cstr(E.web_ula_preset_name(i)) === name) return i; return -1; }
  const ulaSet = (id, v) => { if (E.web_ula(id, -1) !== v) E.web_ula(id, v); }; // only a change (a value set makes the preset custom)
  function ulaApply() { // model start: the defaults read, then what was set for it before
    ulaFrame = null; ulaDef = null; ulaHz = 50;
    if (!ulaOk()) return;
    ulaDef = { pre: E.web_ula(0, -1), v: {} };
    for (const id of [...ULA_T, ...ULA_O]) ulaDef.v[id] = E.web_ula(id, -1);
    const s = ulaSaved();
    if (s) {
      if (ulaTimeOk() && s.t) {
        const i = ulaPreIdx(s.t.pre);
        if (i >= 0) E.web_ula(0, i); else { E.web_ula(0, 255); for (const id of ULA_T) if (s.t[id] !== undefined) ulaSet(id, s.t[id] | 0); }
        if (s.t.frame >= 2000) ulaFrame = s.t.frame | 0;
      }
      if (s.o) for (const id of ULA_O) if (s.o[id] !== undefined && ulaFor(id)) ulaSet(id, s.o[id] ? 1 : 0);
    }
    ulaHz = E.web_ula(4, -1) || 50;
    if (optOpen() && curPane === 'ula') ulaUI();
  }
  function ulaStore() { // what differs from the defaults
    if (!ulaDef) return;
    const pre = E.web_ula(0, -1), t = { pre: pre >= 0 ? cstr(E.web_ula_preset_name(pre)) : '' }, o = {};
    for (const id of ULA_T) t[id] = E.web_ula(id, -1);
    if (ulaFrame) t.frame = ulaFrame;
    let tDiff = pre !== ulaDef.pre || !!ulaFrame || (pre < 0 && ULA_T.some((id) => t[id] !== ulaDef.v[id]));
    let oDiff = false;
    for (const id of ULA_O) { o[id] = E.web_ula(id, -1); if (o[id] !== ulaDef.v[id]) oDiff = true; }
    if (!tDiff && !oDiff) { try { localStorage.removeItem('unreal.' + ulaKey()); } catch (e) {} return; }
    store(ulaKey(), JSON.stringify({ t: tDiff ? t : undefined, o: oDiff ? o : undefined }));
  }
  function ulaFrameSet(f) { // the 3.5 MHz frame: as the model's own = no override
    ulaFrame = f && f !== MODELS[model].base ? f : null;
    trueClkApply(); // the frame again: CPU clock × this (True clock: the core's base)
  }
  function ulaTimeDefault() {
    if (!ulaDef) return;
    const keep = {}; for (const id of [6, 7, 8, 9, 10]) keep[id] = E.web_ula(id, -1); // the options of the card below stay as they are
    if (ulaDef.pre >= 0) E.web_ula(0, ulaDef.pre); else { for (const id of ULA_T) ulaSet(id, ulaDef.v[id]); E.web_ula(0, 255); }
    if (ulaDef.pre >= 0 && Object.keys(keep).some((id) => keep[id] !== E.web_ula(+id, -1))) for (const id of Object.keys(keep)) ulaSet(+id, keep[id]);
    ulaHz = E.web_ula(4, -1) || 50;
    ulaFrameSet(null); ulaStore(); ulaUI();
  }
  function ulaOptDefault() {
    if (!ulaDef) return;
    for (const id of ULA_O) ulaSet(id, ulaDef.v[id]);
    // the timings and the bus options as the model's preset again: the preset itself
    if (ulaDef.pre >= 0 && E.web_ula(0, -1) < 0 && !ulaFrame && ULA_T.every((id) => E.web_ula(id, -1) === ulaDef.v[id])) E.web_ula(0, ulaDef.pre);
    ulaStore(); ulaUI();
  }
  let ulaBuilt = false;
  function ulaUI() {
    const ok = ulaOk(), tok = ulaTimeOk();
    $('ulamodel').textContent = MODELS[model] ? MODELS[model].name : '';
    if (!ulaBuilt && E && E.web_ula) {
      ulaBuilt = true;
      const sel = $('ulapre');
      for (let i = 0, n = E.web_ula_presets(); i < n; i++) { const o = document.createElement('option'); o.value = String(i); o.textContent = cstr(E.web_ula_preset_name(i)); sel.appendChild(o); }
      const c = document.createElement('option'); c.value = '-1'; c.textContent = 'Custom'; sel.appendChild(c);
      sel.onchange = () => {
        if (!ulaTimeOk()) return;
        const i = +sel.value; E.web_ula(0, i < 0 ? 255 : i);
        if (i >= 0) { ulaHz = E.web_ula(4, -1) || 50; ulaFrameSet(E.web_ula(1, -1)); }
        ulaStore(); ulaUI();
      };
      $('ulaframe').onchange = () => {
        const v = Math.round(+$('ulaframe').value);
        if (ulaTimeOk() && v >= 2000 && v <= 1000000) { E.web_ula(0, 255); ulaFrameSet(v); ulaStore(); }
        ulaUI();
      };
      for (const [el, id] of Object.entries(ULA_NUM)) $(el).onchange = () => {
        const v = Math.round(+$(el).value);
        if (ulaTimeOk() && isFinite(v) && v >= +$(el).min && v <= +$(el).max) { E.web_ula(id, v); if (id === 4) ulaHz = E.web_ula(4, -1) || 50; ulaStore(); }
        ulaUI();
      };
      for (const el of ['ulaframe', ...Object.keys(ULA_NUM)]) $(el).onkeydown = (e) => { if (e.key === 'Enter') { $(el).onchange(); $(el).blur(); } };
      document.querySelectorAll('#ulaopts [data-ula]').forEach((x) => { x.onchange = () => { if (!ulaOk()) return; E.web_ula(+x.dataset.ula, x.checked ? 1 : 0); ulaStore(); ulaUI(); }; });
      $('ulat_def').onclick = ulaTimeDefault; $('ulao_def').onclick = ulaOptDefault;
    }
    const sam = M() === 'SAM';
    $('ulatnote').hidden = tok; $('ulaonote').hidden = ok;
    $('ulatnote').textContent = !E ? '' : sam ? 'SAM Coupé: the timings of its own ASIC.' : RZX_MODELS.has(model) ? 'RZX playback: the timings of the recording.' : 'This machine sets its frame itself (its CPU clock).';
    $('ulaonote').textContent = sam ? 'SAM Coupé: not a ZX Spectrum ULA.' : RZX_MODELS.has(model) ? 'RZX playback: as the recording.' : '';
    $('ulatgrid').classList.toggle('dis', !tok); $('ulat_def').disabled = !tok; $('ulao_def').disabled = !ok;
    $('ulatgrid').querySelectorAll('input, select').forEach((x) => { x.disabled = !tok; });
    if (!E || !E.web_ula) return;
    const busy = document.activeElement;
    if (busy !== $('ulapre')) $('ulapre').value = String(E.web_ula(0, -1));
    if (busy !== $('ulaframe')) $('ulaframe').value = baseFrame();
    for (const [el, id] of Object.entries(ULA_NUM)) if (busy !== $(el)) $(el).value = E.web_ula(id, -1);
    document.querySelectorAll('#ulaopts [data-ula]').forEach((x) => {
      const id = +x.dataset.ula, on = ok && ulaFor(id);
      x.checked = !!E.web_ula(id, -1); x.disabled = !on; x.closest('.chk').classList.toggle('dis', !on);
    });
  }
  // ------------------------------------------------------------------ ZX ULAX: colors of ZX programs (web/web_ulax.cpp)
  // The board on Pentagon 128 / Spectrum +3 (RZX playback too), only with a .dux (the author's colors of one program):
  // - snapshot / RZX + dux (a ZIP, a link, a .dux loaded after it): the dux is applied to the memory at once, ULAX on;
  // - tape / disk + dux: the dux is loaded, ULAX off (gray) - switched on by hand once the program has loaded;
  // - ULAX at the top of the screen (white on, gray off), Options / ULA / ZX ULAX and Ctrl+Alt+U switch it; the first switch
  //   on applies the dux to the memory then; off: the ZX picture, the board keeps going (on again: its colors at once);
  // - a reset: the dux stays, not applied (gray: on again once the program is back); another snapshot, another machine,
  //   Remove dux: it goes.
  const DUX_VER = 1; // the newest dux format known (a "version N" / "ver N" in the text before the data)
  let dux = null; // { name, buf, applied }
  let ulaxActive = false; // its picture shown
  const ulaxFits = () => ['PENTAGON', 'PLUS3'].includes(himem());
  const ulaxMode = () => (E && E.web_ulax_get ? E.web_ulax_get() : 0); // the board: 0 off, 1 no dux, 2 a dux applied
  const ulaxName = () => (ulaxMode() ? cstr(E.web_ulax_name()) : '');
  function duxVer(buf) {
    const t = String.fromCharCode(...buf.subarray(0, Math.min(buf.length, 2048)));
    const m = /(?:^|[\s;])(?:dux[\s_-]*)?(?:format[\s_-]*)?v(?:er(?:sion)?)?[\s.:=]*(\d+)(?:\.\d+)*/im.exec(t);
    return m ? +m[1] : 0;
  }
  function ulaxRefresh() { ulaxHud(); updateUI(); if (optOpen() && curPane === 'ula') ulaxUI(); }
  function ulaxApply() { dux = null; ulaxActive = false; if (E.web_ulax_set) { E.web_ulax_set(0); E.web_ulax_view(1); } ulaxHud(); } // a machine starts
  // the dux onto the memory now; the picture on
  function duxApplyNow() {
    if (!dux || !E.web_ulax_set) return false;
    if (!ulaxFits()) { toast(dux.name + ': ZX ULAX is on Pentagon 128 and Spectrum +3 only', true); return false; }
    if (!ulaxMode() && !E.web_ulax_set(1)) { toast(dux.name + ': no memory for ZX ULAX', true); return false; }
    const p = E.web_ulax_buf(dux.buf.length); new Uint8Array(E.memory.buffer, p, dux.buf.length).set(dux.buf);
    const n = E.web_ulax_dux(p, dux.buf.length, 0);
    const nm = new Uint8Array(E.memory.buffer, E.web_ulax_name(), 64); nm.fill(0); nm.set(new TextEncoder().encode(dux.name).subarray(0, 63));
    dux.applied = true; ulaxActive = true; E.web_ulax_view(1);
    if (!n) toast('ULAX: ' + dux.name + ' — no data in it', true);
    return n > 0;
  }
  // a dux came: now = applied at once (with a snapshot / RZX, or alone), else loaded for a tape / disk program (gray)
  function duxLoad(name, buf, now) {
    name = name.replace(/^.*[\\/]/, '');
    if (!ulaxFits()) { toast(name + ': ZX ULAX is on Pentagon 128 and Spectrum +3 only', true); return false; }
    dux = { name, buf, applied: false }; ulaxActive = false;
    if (E.web_ulax_set && ulaxMode()) { E.web_ulax_set(0); E.web_ulax_view(1); } // the dux of before goes
    const v = duxVer(buf), newer = v > DUX_VER ? ' (dux format ' + v + ': newer than this emulator knows; colors may be wrong)' : '';
    if (now) { duxApplyNow(); toast('ULAX: ' + name + newer, !!newer); }
    else toast(name + " loaded. Switch ULAX on in the game's menu." + newer, !!newer); // colors a game sets once at its start need it on before
    ulaxRefresh();
    return true;
  }
  function ulaxSet(on, say) {
    if (!dux) { if (say) toast('ZX ULAX: load a .dux first', true); return; }
    if (on) { if (!dux.applied || ulaxMode() !== 2) duxApplyNow(); else { ulaxActive = true; E.web_ulax_view(1); } }
    else { ulaxActive = false; if (E.web_ulax_view) E.web_ulax_view(0); }
    if (say) toast(ulaxActive ? 'ZX ULAX: ' + dux.name : 'ZX picture');
    ulaxRefresh();
  }
  const ulaxToggle = (say) => ulaxSet(!(ulaxActive && dux && dux.applied), say);
  function duxDrop() { dux = null; ulaxActive = false; if (E.web_ulax_set) { E.web_ulax_set(0); E.web_ulax_view(1); } ulaxRefresh(); }
  function duxRemove() { dux = null; ulaxActive = false; if (E.web_ulax_set) { E.web_ulax_set(0); E.web_ulax_view(1); } toast('ULAX: dux removed'); ulaxRefresh(); }
  // the board lost the dux (a reset): loaded, not applied - gray
  function ulaxCheck() {
    if (dux && dux.applied && ulaxMode() !== 2) { dux.applied = false; ulaxActive = false; if (E.web_ulax_set) { E.web_ulax_set(0); E.web_ulax_view(1); } ulaxRefresh(); }
  }
  // the whole ULAX state (VRAM, registers): for a seek of RZX and a snapshot saved with it (.ulx in its ZIP)
  function ulaxSave() { if (ulaxMode() !== 2 || !E.web_ulax_save) return null; const p = E.web_ulax_save(), n = E.web_ulax_save_len(); return p && n ? new Uint8Array(E.memory.buffer, p, n).slice() : null; }
  function ulaxLoad(b) {
    if (!b || !ulaxMode()) return false;
    const p = E.malloc(b.length); new Uint8Array(E.memory.buffer, p, b.length).set(b);
    let r; try { r = E.web_ulax_load(p, b.length); } finally { E.free(p); }
    return !!r;
  }
  // ULAX at the top of the screen: there while a dux is loaded; white on, gray off; a click / tap switches it
  function ulaxHud() {
    const b = $('ulaxhud'); if (!b) return;
    const st = !dux ? '' : ulaxActive && dux.applied ? 'on' : 'off';
    if (hud.ulax !== st) { hud.ulax = st; b.hidden = !st; b.classList.toggle('on', st === 'on'); b.title = st === 'on' ? 'ZX ULAX on (' + dux.name + '): a click shows the ZX picture (Ctrl+Alt+U)' : st ? 'ZX ULAX off: a click switches it on' + (dux.applied ? '' : ' and applies ' + dux.name + ' to the program in memory') + ' (Ctrl+Alt+U)' : ''; hudDraw(); }
  }
  let ulaxBuilt = false;
  function ulaxUI() {
    if (!E || !E.web_ulax_set) return;
    if (!ulaxBuilt) {
      ulaxBuilt = true;
      $('ulaxon').onchange = () => ulaxSet($('ulaxon').checked);
      $('ulaxdux').onclick = () => $('file').click();
      $('ulaxagain').onclick = () => { if (dux) { duxApplyNow(); toast('ULAX: ' + dux.name + ' applied again'); ulaxRefresh(); } }; // the colors set while the program ran go
      $('ulaxrm').onclick = duxRemove;
    }
    const fits = ulaxFits(), on = !!(dux && dux.applied && ulaxActive);
    $('ulaxon').checked = on; $('ulaxon').disabled = !dux;
    $('ulaxdux').disabled = !fits; $('ulaxagain').disabled = $('ulaxrm').disabled = !dux;
    $('ulaxinfo').textContent = !fits ? 'This machine has no ZX ULAX (Pentagon 128, Spectrum +3).' : !dux ? 'No dux loaded.'
      : 'dux: ' + dux.name + (on ? '' : dux.applied ? ' (off: the ZX picture)' : ' (not applied yet: switch on once the program has loaded)');
  }
  function loadSpeed() {
    speedIdx = SPEEDS.indexOf(MODELS[model].speed); // every start: the model's clock (2.5x = 8.75 MHz), not remembered
    trueClkApply();
  }

  // ------------------------------------------------------------------ on-screen keyboard
  let vkbd = null;
  const KJ_BITS = { KJ_RIGHT: 1, KJ_LEFT: 2, KJ_DOWN: 4, KJ_UP: 8, KJ_FIRE: 16 };
  let kjBits = 0;
  // on-screen XT keys inside the debugger: KeyboardEvent.code -> Win32 virtual key + character
  const VK_SPECIAL = {
    Escape: [27, 27], Backspace: [8, 8], Tab: [9, 9], Enter: [13, 13], Space: [32, 32], CapsLock: [20, 0],
    ShiftLeft: [16, 0], ShiftRight: [16, 0], ControlLeft: [17, 0], ControlRight: [17, 0], AltLeft: [18, 0], AltRight: [18, 0],
    ArrowLeft: [37, 0], ArrowUp: [38, 0], ArrowRight: [39, 0], ArrowDown: [40, 0],
    Backquote: [192, '`~'], Minus: [189, '-_'], Equal: [187, '=+'], BracketLeft: [219, '[{'], BracketRight: [221, ']}'],
    Backslash: [220, '\\|'], Semicolon: [186, ';:'], Quote: [222, "'\""], Comma: [188, ',<'], Period: [190, '.>'], Slash: [191, '/?'],
  };
  const vkMods = new Set(), vkInDbg = new Set(), vkHeld = new Set(), vkHot = new Set(); // vkHeld: Shift / Ctrl / Alt of the XT keyboard down; vkHot: F keys the page took
  function vkToDebug(code) {
    const shift = vkMods.has('ShiftLeft') || vkMods.has('ShiftRight');
    let vk = 0, ch = 0, m;
    if ((m = /^Key([A-Z])$/.exec(code))) { vk = m[1].charCodeAt(0); ch = shift ? vk : vk + 32; }
    else if ((m = /^Digit(\d)$/.exec(code))) { vk = 48 + +m[1]; ch = (shift ? ')!@#$%^&*('[+m[1]] : m[1]).charCodeAt(0); }
    else if ((m = /^F(\d+)$/.exec(code))) vk = 111 + +m[1];
    else if (VK_SPECIAL[code]) {
      const [v, c] = VK_SPECIAL[code]; vk = v;
      ch = typeof c === 'string' ? c.charCodeAt(shift && c.length > 1 ? 1 : 0) : c;
    }
    return [vk, ch];
  }

  // Options / Input / Joystick: the FIRE key of each joystick type (Kempston: its port bit) and 3 extra buttons
  // not set yet: the 3 extra buttons on, Enter, Space and 1 (menus: "1 - start", the choice of the controls)
  const JOY_EXTRA = [{ on: true, key: 'Enter' }, { on: true, key: 'Space' }, { on: true, key: 'Digit1' }];
  function joyKeys() { try { const k = JSON.parse(load('vkjoykeys') || '{}'); return { fire: k.fire || {}, extra: Array.isArray(k.extra) ? k.extra : JOY_EXTRA.map((x) => Object.assign({}, x)) }; } catch (e) { return { fire: {}, extra: JOY_EXTRA.map((x) => Object.assign({}, x)) }; } }
  function joyUI() {
    if (!vkbd || !$('joytype')) return;
    const M = UnrealVKbd.JOY_MAPS, K = UnrealVKbd.JOY_KEYS, k = joyKeys(), t = vkbd.joy;
    const fill = (sel, list) => { if (sel.options.length) return; for (const [v, n] of list) { const o = document.createElement('option'); o.value = v; o.textContent = n; sel.appendChild(o); } };
    fill($('joytype'), Object.entries(M).map(([id, m]) => [id, m.name]));
    fill($('joyfire'), [['KJ_FIRE', 'Kempston fire'], ...K]);
    for (let i = 0; i < 3; i++) fill($('joyk' + i), K);
    $('joytype').value = t;
    const kemp = t === 'kempston';
    $('joyfire').disabled = kemp; $('joyfire').value = kemp ? 'KJ_FIRE' : (k.fire[t] || M[t].fire);
    for (let i = 0; i < 3; i++) { const x = k.extra[i] || {}; $('joyx' + i).checked = !!x.on; $('joyk' + i).value = x.key || JOY_EXTRA[i].key; $('joyk' + i).disabled = !x.on; }
  }
  function bindJoyOptions() {
    const save = () => {
      const k = joyKeys(), t = vkbd.joy;
      if (t !== 'kempston') { const v = $('joyfire').value; if (v === UnrealVKbd.JOY_MAPS[t].fire) delete k.fire[t]; else k.fire[t] = v; }
      k.extra = [0, 1, 2].map((i) => ({ on: $('joyx' + i).checked, key: $('joyk' + i).value }));
      store('vkjoykeys', JSON.stringify(k)); vkbd.setJoyKeys(k); joyUI();
    };
    $('joytype').onchange = () => { vkbd.setJoy($('joytype').value); joyUI(); $('joytype').blur(); };
    $('joyfire').onchange = () => { save(); $('joyfire').blur(); };
    for (let i = 0; i < 3; i++) { $('joyx' + i).onchange = save; $('joyk' + i).onchange = () => { save(); $('joyk' + i).blur(); }; }
    joyUI();
  }
  function bindVKbd() {
    const panel = $('vkbd');
    // on-screen XT keys go to File Commander while it is the window in use (opened / last touched)
    const vkFc = new Set(), vkFcMods = new Set(), vkDga = new Set();
    const fcUsing = () => fc && fc.open && fcVk;
    const dgaUsing = () => dga && dga.open && (dgaVk || dga.hasFocus());
    const vkPress = (code) => {
      if (dgaUsing() || vkDga.size) { // deBUGa: into its field or its part in use
        vkDga.add(code);
        if (/^(Shift|Control|Alt)/.test(code)) { vkFcMods.add(code); return; }
        dga.vkey(code, vkFcMods);
        return;
      }
      if (fcUsing() || vkFc.size) {
        vkFc.add(code);
        if (/^(Shift|Control|Alt)/.test(code)) { vkFcMods.add(code); return; }
        fc.vkey(code, vkFcMods);
        return;
      }
      if (dbgOn) { // the debugger gets the key (XT keyboard only)
        const sc = SCAN[code]; if (sc === undefined || !E.web_debug_active()) return;
        vkInDbg.add(code); if (/^(Shift|Control|Alt)/.test(code)) vkMods.add(code);
        E.web_key(sc, 1, 0);
        const [vk, ch] = vkToDebug(code);
        if (vk) { E.web_debug_key(vk, ch); debugResume(); }
        return;
      }
      const vkF = () => { // F keys as on the PC keyboard: the page's (Save, Load, Reset, Pause, OSZ Ext keys …) when the machine does not take them
        const has = (p) => [...vkHeld].some((c) => c.startsWith(p));
        if (hotkey({ code, key: code, repeat: false, shiftKey: has('Shift'), ctrlKey: has('Control'), altKey: has('Alt'), metaKey: false })) { vkHot.add(code); return true; }
        return false;
      };
      if (E && isPaused()) { if (/^(Shift|Control|Alt)/.test(code)) vkHeld.add(code); else if (/^F\d+$/.test(code)) vkF(); return; } // paused: F5 goes on, F2 / F3 work, as on the PC keyboard
      if (!E) return;
      startAudio();
      if (code in KJ_BITS) { kjBits |= KJ_BITS[code]; E.web_kjoy(kjBits); return; }
      if (code.startsWith('ZX:')) { E.web_zxkey(+code.slice(3), 1); return; }
      if (/^(Shift|Control|Alt)/.test(code)) vkHeld.add(code);
      if (/^F\d+$/.test(code) && vkF()) return;
      const sc = SCAN[code]; if (sc !== undefined) E.web_key(sc, 1, 0);
    };
    const vkRelease = (code) => {
      if (vkFc.delete(code) || vkDga.delete(code)) { vkFcMods.delete(code); return; }
      if (!E) return;
      vkMods.delete(code); vkHeld.delete(code);
      if (vkHot.delete(code)) return; // done by the page on press
      if (vkInDbg.delete(code)) { // pressed inside the debugger: never reaches the machine
        const sc = SCAN[code]; if (sc !== undefined && E.web_debug_active()) E.web_key(sc, 0, 0);
        return;
      }
      if (code in KJ_BITS) { kjBits &= ~KJ_BITS[code]; E.web_kjoy(kjBits); return; }
      if (code.startsWith('ZX:')) { E.web_zxkey(+code.slice(3), 0); return; }
      const sc = SCAN[code]; if (sc !== undefined) E.web_key(sc, 0, 0);
    };
    const sticky = ['0', '1', '2'].includes(load('sticky')) ? +load('sticky') : 1;
    $('sticky').value = String(sticky);
    $('sticky').onchange = () => { store('sticky', $('sticky').value); vkbd.setSticky(+$('sticky').value); $('sticky').blur(); };
    vkbd = UnrealVKbd.create(panel, { press: vkPress, release: vkRelease, tab: load('vktab'), joy: load('vkjoy') || 'sinclair2', sticky,
      onTab: (t) => { if (!kbdNoStore) store('vktab', t); $('kbdtype').value = t; }, onJoy: (j) => { store('vkjoy', j); joyUI(); },
      joyKeys: joyKeys(), onJoySettings: () => { showOptions(true); showPane('inp'); const c = $('joycard'); c.scrollIntoView({ block: 'nearest' }); c.classList.add('hl'); setTimeout(() => c.classList.remove('hl'), 900); },
      overlayHost: $('screenwrap'), ovBarHost: $('sbjoy'), onLayout: () => applyScale(),
      joyOpts: (() => { try { return JSON.parse(load('vkjoyopt') || '{}'); } catch (e) { return {}; } })(), onJoyOpts: (o) => store('vkjoyopt', JSON.stringify(o)) });
    $('kbdtype').value = vkbd.tab; vkbd.setLand(land); // a phone in landscape already: the stick over the screen
    $('kbdtype').onchange = () => { vkbd.show($('kbdtype').value); $('kbdtype').blur(); applyScale(); };
    const showKbd = (v) => {
      panel.hidden = !v; $('kbdtype').hidden = !v; $('kbdbtn').classList.toggle('on', v);
      $('kbdbtn').title = v ? 'Hide keyboard' : 'On-screen keyboard';
      vkbd.visible(v);
      if (!kbdNoStore) store('vkbd', v ? '1' : '0');
      applyScale();
    };
    kbdLink = (t) => { // REST API kbd=: shown / hidden for this visit, the saved setting stays
      kbdNoStore = true;
      try { if (/^(zx|zx48|xt|xtf|joy)$/.test(t)) { vkbd.show(t); showKbd(true); } else if (/^(off|0|no|none|false)$/.test(t)) showKbd(false); }
      finally { kbdNoStore = false; }
    };
    $('kbdbtn').onclick = () => showKbd(panel.hidden);
    const saved = load('vkbd');
    showKbd(saved === null ? (matchMedia('(pointer: coarse)').matches) : saved === '1');
  }

  let kbdNoStore = false, kbdLink = () => {};
  function bindUI() {
    bindRzx();
    setBare(load('bare') === '1', false); // ~: menu bar and frame hidden (as last time)
    $('vidbare').onchange = (e) => setBare(e.target.checked, true);
    // Keep Screen On (Screen Wake Lock, off by default): taken while the page is shown, again after it comes back
    let wakeLock = null;
    const wakeApply = async () => {
      const on = load('wake') === '1' && !document.hidden;
      if (on && !wakeLock) { try { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); } catch (e) {} }
      else if (!on && wakeLock) { const w = wakeLock; wakeLock = null; try { await w.release(); } catch (e) {} }
    };
    if (!('wakeLock' in navigator)) { $('vidwake').disabled = true; $('vidwake').parentElement.title = 'This browser cannot keep the screen on (Screen Wake Lock)'; }
    else {
      $('vidwake').checked = load('wake') === '1';
      $('vidwake').onchange = (e) => { store('wake', e.target.checked ? '1' : '0'); wakeApply(); };
      document.addEventListener('visibilitychange', wakeApply); wakeApply();
    }
    $('vidmix').onchange = (e) => { mixOn = e.target.checked && M() === 'GMX'; mixN = 0; }; // Mix Frames: GMX only, on at each GMX start (mixUI)
    $('barshow').onclick = () => { if (peekFresh) return; $('barcorner').classList.remove('peek'); clearTimeout(peekT); setBare(!bare, !bareLink && !land); canvas.focus(); }; // landscape: for the moment (upright again: as before)
    let peekT = 0, peekFresh = false; // fresh: the tap that showed the button does not press it too
    $('screenwrap').addEventListener('pointerdown', (e) => { // Hide Menu Bar: the hidden corner icons and texts for 2 s: a tap in the strip along the top or the bottom (as high as the corner buttons)
      const r = $('screenwrap').getBoundingClientRect();
      peekFresh = bare ? document.body.classList.contains('calm') : !$('barcorner').classList.contains('peek');
      if (!bare) { // with the menu bar: a tap in the top left corner shows (for 3 s) the button that hides it, a second tap presses it
        const c = $('barshow').getBoundingClientRect(), m = 10;
        if (!$('barcorner').classList.contains('peek') && e.clientX < c.right + m && e.clientY < c.bottom + m) { $('barcorner').classList.add('peek'); hudDraw(); clearTimeout(peekT); peekT = setTimeout(() => { $('barcorner').classList.remove('peek'); hudDraw(); }, 3000); }
        return;
      }
      const sz = ($('kbdbtn').offsetHeight || 28) + 8; if (e.clientY - r.top < sz || r.bottom - e.clientY < sz) calmShow();
    }, true);
    if (LAND_MQ) { if (LAND_MQ.addEventListener) LAND_MQ.addEventListener('change', landUpdate); else if (LAND_MQ.addListener) LAND_MQ.addListener(landUpdate); }
    let landRaf = 0; const landSoon = () => { if (!landRaf) landRaf = requestAnimationFrame(() => { landRaf = 0; landUpdate(); }); };
    window.addEventListener('resize', landSoon); window.addEventListener('orientationchange', () => setTimeout(landUpdate, 350)); landUpdate();
    if (window.visualViewport) window.visualViewport.addEventListener('resize', landSoon); // the browser's bars come and go: the height that is there
    { const unscroll = () => { if (land && (window.scrollX || window.scrollY)) window.scrollTo(0, 0); }; // iOS home screen: a scrolled page draws higher than it takes taps
      window.addEventListener('scroll', unscroll, { passive: true }); if (window.visualViewport) window.visualViewport.addEventListener('scroll', unscroll); }
    buildDrives();
    $('file').onchange = async (e) => {
      const f = e.target.files[0]; e.target.value = '';
      if (f) { // Load / Local file: its Autostart; Insert of a drive in Options / Disk: only mounted there
        if (fromLoadWin) { if (ldAuto()) fwinShow('loadwin', false); await withLocal(() => loadFile(f, 0), true); ldStoreUI(); } // Autostart off: Load stays open
        else { const d = pendingDrive; await loadFile(f, d); }
      }
      fromLoadWin = false;
      pendingDrive = -1;
      canvas.focus();
    };
    const btn = (id, fn) => { $(id).onclick = () => { fn(); if (!modalOpen()) canvas.focus(); }; };
    $('load').onclick = () => { if ($('loadwin').hidden) showLoad(); else fwinShow('loadwin', false); };
    btn('pause', () => setUserPaused(!userPaused));
    btn('reset', () => userReset());
    btn('xt', toggleXT);
    btn('turbo', toggleTurbo);
    $('ulaxhud').onclick = (e) => { e.stopPropagation(); ulaxToggle(false); canvas.focus(); }; // ZX ULAX at the top of the screen
    $('ulaxhud').onpointerdown = (e) => e.stopPropagation();
    bindSpeed();
    bindVKbd(); bindJoyOptions();
    bindNedo();
    bindDebugger();
    bindSysInfo();
    bindPerf(); bindNet();
    // About: version and author; the e-mail is a picture (not a mailto / text for address harvesters)
    $('aboutver').innerHTML = `v.${APP_VER} by ae485 (<img class="mailimg" alt="e-mail" src="data:image/png;base64,${MAIL_PNG}">). <a href="#" id="chlink">changes</a>.<br>Based on UnrealSpeccy 0.39.0.`;
    $('chlink').onclick = (e) => { e.preventDefault(); showChanges(true); };
    $('liclink').onclick = (e) => { e.preventDefault(); showChanges(true, 'lic'); };
    bindIosMix();
    bindRest();
    bindSave(); bindHexFields();
    bindSoundOpts();
    bindViz();
    bindMouse();
    $('fxsel').onchange = () => { store('fx', $('fxsel').value); setFx($('fxsel').value); };
    setFx(fxMode);
    if (LINK.fx !== undefined) { // fx=: this visit only, Options keeps its own
      const v = String(LINK.fx).toLowerCase(), f = FX_LINK[v] || v;
      if ([...$('fxsel').options].some((o) => o.value === f)) setFx(f); else toast('Unknown fx ' + LINK.fx, true);
    }
    optFW = floatWin($('options'), 'optpos', () => {
      const r = $('screenwrap').getBoundingClientRect(), w = $('options').offsetWidth, vw = document.documentElement.clientWidth;
      return { x: Math.max(4, Math.min(r.left + (r.width - w) / 2, vw - w - 4)), y: Math.max(8, r.top + 16) };
    });
    $('optbtn').onclick = () => showOptions(!optOpen());
    $('sysbtn').onclick = () => { if (optOpen() && curPane === 'sys') showOptions(false); else { if (!optOpen()) showOptions(true); showPane('sys'); } sysBtnUI(); }; // Options / System (machine, ROM, clock)
    $('options').querySelector('[data-close]').onclick = () => showOptions(false);
    document.querySelectorAll('#options header [data-tab]').forEach((b) => b.onclick = () => showPane(b.dataset.tab));
    mhFW = floatWin($('mainhelp'), 'mainhelppos', () => {
      const r = $('screenwrap').getBoundingClientRect(), w = $('mainhelp').offsetWidth, vw = document.documentElement.clientWidth;
      return { x: Math.max(4, Math.min(r.right - w - 8, vw - w - 4)), y: Math.max(8, r.top + 8) };
    });
    $('mainhelpbtn').onclick = () => showMainHelp($('mainhelp').hidden);
    $('mainhelpclose').onclick = () => { showMainHelp(false); canvas.focus(); };
    showPane('sys');
    bindModels(); bindOffline();
    bindLoad();
    $('snd').onclick = toggleSound;
    $('sndhint').onclick = (e) => { e.stopPropagation(); unlockAudio(); $('sndhint').hidden = true; canvas.focus(); };
    $('scale').onchange = () => { store('scale', $('scale').value); applyScale(); canvas.focus(); };
    const sv = load('scale'); if (sv) $('scale').value = sv;
    // a text field in use on a touch device: the on-screen keyboard narrows the viewport — the emulator keeps its size
    // (File Commander editor, Go #, names…); it is fitted again when the field is left
    const typing = () => { const a = document.activeElement; return !!a && matchMedia('(pointer: coarse)').matches && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && !/^(checkbox|radio|range|button|file|submit)$/i.test(a.type))); };
    let scaleRaf = 0; // the resize events of one change (window, visual viewport, focus) fitted once, before the next picture
    const scaleNow = () => { if (!scaleRaf) scaleRaf = requestAnimationFrame(() => { scaleRaf = 0; if (!typing()) applyScale(); }); };
    document.addEventListener('focusout', () => setTimeout(scaleNow, 350));
    window.addEventListener('resize', scaleNow);
    // iOS (home-screen app, back-forward cache): the final viewport size arrives late, without a resize event
    const rescale = () => { applyScale(); setTimeout(applyScale, 150); setTimeout(applyScale, 600); setTimeout(applyScale, 1500); };
    window.addEventListener('pageshow', rescale); window.addEventListener('orientationchange', rescale);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) rescale(); });
    if (window.visualViewport) window.visualViewport.addEventListener('resize', scaleNow);
    rescale();
    document.addEventListener('fullscreenchange', () => { applyScale(); canvas.focus(); });
    const wrap = $('screenwrap');
    wrap.addEventListener('dragover', (e) => e.preventDefault());
    wrap.addEventListener('drop', (e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) withLocal(() => loadFile(f, 0), true); }); // as Load / Local file (its Autostart)
    canvas.addEventListener('mousedown', () => { startAudio(); canvas.focus(); });
    for (const ev of ['pointerdown', 'touchend', 'mousedown', 'keydown', 'click']) document.addEventListener(ev, unlockAudio, true);
    updateSoundBtn();
    applyScale();
  }
  function store(k, v) { try { localStorage.setItem('unreal.' + k, v); } catch (e) {} }
  function load(k) { try { return localStorage.getItem('unreal.' + k); } catch (e) { return null; } }

  // ------------------------------------------------------------------ link API: index.html?model=pentagon&speed=1&a=trd/game.trd&autorun=1
  // Parameters may also follow '#'. Keys and values are case-insensitive (file paths keep their case, folders are lower case).
  const MODEL_ALIASES = {
    atm710: 'ATM710', atm2: 'ATM710', atm: 'ATM710', 'atm2+': 'ATM710',
    xbiosxt: 'XBIOS136', xbios: 'XBIOS136', xbios136: 'XBIOS136', xt136: 'XBIOS136',
    atm450: 'ATM450', atm1: 'ATM450',
    evo: 'EVO', zxevo: 'EVO', atm3: 'EVO',
    pentagon: 'PENTAGON', p128: 'PENTAGON', pentagon128: 'PENTAGON', zx128: 'ZX128', spectrum128: 'ZX128', '128k': 'ZX128',
    scorpion: 'SCORPION', scorp: 'SCORPION', zs256: 'SCORPION', gmx: 'GMX', scorpgmx: 'GMX', profi: 'PROFI', kay: 'KAY', kay1024: 'KAY',
    plus3: 'PLUS3', '+3': 'PLUS3', p3: 'PLUS3', quorum: 'QUORUM', sam: 'SAM', samcoupe: 'SAM', coupe: 'SAM', specnext: 'NEXT', next: 'NEXT', zxnext: 'NEXT',
    tasis: 'TASIS', tasis540: 'TASIS', chic: 'CHIC', isdos: 'CHIC', isdos501: 'CHIC', nedoos: 'NEDOOS', nedo: 'NEDOOS', wc: 'TSCONF', wildcommander: 'TSCONF',
  };
  function linkParams() {
    const out = {};
    const add = (q) => { for (const [k, v] of new URLSearchParams(q)) linkPut(out, k, v); };
    add(location.search);
    if (location.hash.length > 1 && location.hash.includes('=')) add(location.hash.slice(1));
    return out;
  }
  let LINK = linkParams();
  const LINK_USED = Object.keys(LINK).length > 0; // the sound hint is shown only for pages started from a REST API link
  const yes = (v) => v !== undefined && !/^(0|no|off|false)$/i.test(v);
  if (LINK.mmc === undefined && LINK.sd2 !== undefined) LINK.mmc = LINK.sd2; // the first name of mmc= (1.82)
  if (LINK.divmmc !== undefined) dmLink = yes(LINK.divmmc); else if (LINK.mmc) dmLink = true; // this visit (not kept)
  if (LINK.sdtiming !== undefined) { const t = { ideal: 0, realistic: 1, real: 1, slow: 2 }[String(LINK.sdtiming).toLowerCase()]; tmLink = t !== undefined ? t : Math.max(0, Math.min(2, +LINK.sdtiming || 0)); }
  if (LINK.sdseed !== undefined && isFinite(+LINK.sdseed)) sdSeed = (+LINK.sdseed) >>> 0;
  if (LINK.gotekremount !== undefined && isFinite(+LINK.gotekremount)) gkRmLink = Math.max(0, Math.min(10000, +LINK.gotekremount));
  if (LINK.gotekfw !== undefined) gkFwLink = /^3?\.?44/.test(LINK.gotekfw) ? 344 : 342;
  // before the first start: the model (so only its ROM is downloaded)
  function linkModel() {
    tcFromLink(LINK);
    if (LINK.dux && !LINK.model && !LINK.rom && !['PENTAGON', 'PLUS3'].includes((MODELS[model].ini.MISC || {}).HIMEM)) model = 'PENTAGON'; // dux=: a machine with ZX ULAX
    if (!LINK.model) return;
    const m = MODEL_ALIASES[LINK.model.toLowerCase().replace(/[\s_-]/g, '')] || Object.keys(MODELS).find((k) => k.toLowerCase() === LINK.model.toLowerCase());
    if (m) model = m; else toast('Link: unknown model "' + LINK.model + '" (' + Object.keys(MODEL_ALIASES).join(', ') + ')', true);
  }
  // rom=: a Custom ROM ZIP (Save / Custom ROM: ROM + json with the machine, slots, clock, FDD, HDD interface, ini keys)
  // or a plain ROM image — before the first start, so the machine starts as the ZIP says. Nothing of it is stored.
  let romLinkUrl = '';
  // rom= with disks: the machine does not run until they are in (then a reset): as one switched on with the disks inserted
  // (QC from ROM looks for its overlays at the first start only: a run without the disks, then a reset, is not the same)
  let linkHold = false;
  const linkDisks = () => ['a', 'b', 'hdd', 'hdd1', 'sd', 'mmc', 'gotek'].some((k) => LINK[k]);
  async function linkRom() {
    if (!LINK.rom) return;
    const url = new URL(lowDir(LINK.rom), location.href).href, name = urlName(url);
    try {
      await crAdd(name, new Uint8Array(await (await fetchFile(url)).arrayBuffer()));
      if (!crCur) return;
      const p = customApply();
      if (!p.ini) { toast('Link: ' + name + ': ' + p.why, true); return; }
      model = 'CUSTOM'; romLinkUrl = url;
    } catch (err) { toast('Link: ' + name + ': ' + err.message, true); }
  }
  // after the start: clock, keyboard, sound, files
  async function linkApply() {
    if (LINK.speed && M() === 'SPRINTER' && E.web_sp_noturbo) { const v = parseFloat(LINK.speed); if (isFinite(v)) E.web_sp_noturbo(v < 10 ? 1 : 0); } // 3.5 (MHz): no turbo for this visit; 21: as the program sets
    else if (LINK.speed && !isTS()) { // 2, 2x or 7mhz; snapped to the nearest step of the clock slider, not saved (TS-Conf: TS-BIOS NVRAM, see start)
      const v = parseFloat(LINK.speed), x = /mhz/i.test(LINK.speed) ? v / 3.5 : v;
      if (isFinite(x) && x > 0) { let best = 0; SPEEDS.forEach((s, i) => { if (Math.abs(s - x) < Math.abs(SPEEDS[best] - x)) best = i; }); setSpeed(best, false); }
    }
    if (LINK.mute !== undefined && yes(LINK.mute)) { muted = true; updateSoundBtn(); }
    if (LINK.kbd !== undefined) kbdLink(String(LINK.kbd).toLowerCase()); // kbd=zx|zx48|xt|xtf|joy|off: for this visit only
    if (LINK.hidemenu !== undefined) { bareLink = true; if (land) landPrev = yes(LINK.hidemenu); else setBare(yes(LINK.hidemenu), false); } // hidemenu=1: for this visit only
    if (LINK.swapmouse !== undefined && yes(LINK.swapmouse)) { mswapLink = true; applyMouseSwap(); } // not stored
    if (LINK.xt !== undefined && MODELS[model].xt && !!E.web_xt_kbd() !== yes(LINK.xt)) toggleXT();
    // autorun=1 (or run= with no name): its boot, or its first BASIC program; autorun=boot: as Load / Use boot.b
    const auto = ((LINK.autorun !== undefined && yes(LINK.autorun)) || LINK.run === '') && !LINK.run && !LINK.cpm && !LINK.nedoos ? (/^boot$/i.test(LINK.autorun || '') ? 'boot' : true) : false;
    for (const [key, d] of [['hdd', 0], ['hdd1', 1]]) { // hdd0= (hdd=) / hdd1=: an HDD image (zip with .chs, or .hdd) into HDD 0 / 1
      if (!LINK[key]) continue;
      const url = new URL(lowDir(LINK[key]), location.href).href, name = urlName(url);
      try {
        if (!await hddFromBytes(d, name, new Uint8Array(await (await fetchFile(url)).arrayBuffer()), true)) continue;
        hddSrc[d] = url;
        if (!E.web_hdd_scheme(-1)) { E.web_hdd_scheme(+hddIfPref()); hddMount(0); hddMount(1); }
        if (M() === 'SPRINTER') E.web_reset(0); // its BIOS looks for the disk once, at the start (the image may come later than that)
        hddUI(); toast('HDD ' + d + ': ' + hdds[d]);
      } catch (err) { toast('Link: ' + name + ': ' + err.message, true); }
    }
    if (LINK.sd) { // sd=: an SD card image (.img / .vhd or a zip with it) on the Z-Controller
      const url = new URL(lowDir(LINK.sd), location.href).href, name = urlName(url);
      if (!sdOn()) store('sd.if.' + M(), '1'); // like hdd=: the interface goes on
      try {
        const ok = await sdFromBytes(name, new Uint8Array(await (await fetchFile(url)).arrayBuffer()), true);
        // the card is there from power-on; TS-Conf: a card with its program (.json), or autorun=1: TS-BIOS boots the card (Wild Commander)
        if (ok && sdName) { sdSrc = url; if (M() === 'NEXT') { if (LINK.run || (auto && sdRun)) await nxCardBoot(LINK.run); else E.web_reset(0); } else if (M() === 'EVO') E.web_reset(0); if (isTS() && (sdRun || auto)) { tsBootSd(); if (sdRun && !tsNoAuto) wcAutorun(); } }
        if (ok && sdName && sdCfg && (!sdCfg.model || sdCfg.model === model)) await sdDisks(auto, { 0: !!LINK.a, 1: !!LINK.b, 2: !!LINK.c, 3: !!LINK.d }); // the disks of its .json (a= / b= of the link win)
      }
      catch (err) { toast('Link: ' + name + ': ' + err.message, true); }
    }
    if (LINK.mmc) { // mmc=: the card of the DivMMC (Pentagon); the DivMMC goes on for this visit
      const url = new URL(lowDir(LINK.mmc), location.href).href, name = urlName(url);
      if (!dmHere()) toast('Link: mmc=: the DivMMC is on ' + DM_WHERE + ' only', true);
      else try {
        const bytes = new Uint8Array(await (await fetchFile(url)).arrayBuffer()); // the card first: esxDOS looks for it as it starts
        if (!dmOn()) { dmLink = true; await dmApply(); }
        if (await sd2FromBytes(name, bytes, true) && sd2Name) sd2Src = url; // (the DivMMC from the power on and a reset: there)
      } catch (err) { toast('Link: ' + name + ': ' + err.message, true); }
    }
    if (LINK.gotek) { // gotek=a:stick.img (or b:): the Gotek in that drive with its USB stick, for this visit
      const m = /^([ab]):(.*)$/i.exec(LINK.gotek), path = m ? m[2] : LINK.gotek;
      if (!dmHere()) toast('Link: gotek=: the Gotek is on ' + DM_WHERE + ' only', true);
      else try {
        gkLink = m && m[1].toLowerCase() === 'b' ? 1 : 0;
        const url = new URL(lowDir(path), location.href).href;
        if (await usbFromBytes(urlName(url), new Uint8Array(await (await fetchFile(url)).arrayBuffer()), true)) usbSrc = url;
      } catch (err) { toast('Link: ' + LINK.gotek + ': ' + err.message, true); }
    }
    const jobs = [['b', 1, false], ['a', 0, auto], ['tape', -1, auto && !LINK.a], ['snap', -1, false]];
    for (const [key, drive, run] of jobs) {
      // rom=: the machine has waited for the disks of the link (linkHold): it starts now, before the tape / snapshot
      if (key === 'tape') linkHold = false;
      if (!LINK[key]) continue;
      const url = new URL(lowDir(LINK[key]), location.href).href, name = urlName(url);
      try {
        const buf = new Uint8Array(await (await fetchFile(url)).arrayBuffer());
        autorunNext = run;
        loadingUrl = LINK[key]; linkLoading = true; try { await loadBytes(name, buf, drive); } finally { loadingUrl = null; linkLoading = false; }
      } catch (err) { toast('Link: ' + name + ': ' + err.message, true); }
      autorunNext = false;
    }
    if (LINK.dux) { // ZX ULAX colors: after a snapshot at once; a tape / disk program: Load / Media: Apply once it has loaded
      const url = new URL(lowDir(LINK.dux), location.href).href, name = urlName(url);
      try {
        const buf = new Uint8Array(await (await fetchFile(url)).arrayBuffer());
        duxLoad(name, buf, !!LINK.snap || !(LINK.a || LINK.b || LINK.tape));
      } catch (err) { toast('Link: ' + name + ': ' + err.message, true); }
    }
    if (LINK.run && M() === 'NEXT') { if (!LINK.sd) { if (sdName) await nxCardBoot(LINK.run); else toast('Link: run=' + LINK.run + ': no SD card', true); } } // the Next: a NEX / DOT of its SD card
    else if (LINK.run) { if (runInject(0, LINK.run)) { autorun(); toast('Run: ' + LINK.run); } }
    else if (LINK.cpm) cpmRun(LINK.cpm);
    else if (LINK.nedoos) nedoosRun(LINK.nedoos);
  }

  // iOS / iPadOS: no pinch zoom (Safari ignores user-scalable=no; its gesture events can be cancelled)
  for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) document.addEventListener(ev, (e) => e.preventDefault(), { passive: false });
  document.addEventListener('touchmove', (e) => { if (e.touches.length > 1 && e.scale !== undefined && e.scale !== 1) e.preventDefault(); }, { passive: false });
  // a home-screen app (iOS) keeps its index.html for a long time: look for a newer build on the server; the 'reload' fetch
  // also refreshes the browser's cached copy, so one reload is enough
  async function checkUpdate() {
    if (BUILD === 'dev' || location.protocol === 'file:') return;
    try {
      const r = await fetch(location.pathname, { cache: 'reload' });
      if (!r.ok) return;
      const m = /<meta name="build" content="([^"]+)"/.exec(await r.text());
      if (!m || m[1] === BUILD) { try { sessionStorage.removeItem('unreal.upd'); } catch (e) {} return; } // up to date: the next new build reloads again
      let tries = 0; try { tries = +sessionStorage.getItem('unreal.upd') || 0; sessionStorage.setItem('unreal.upd', String(tries + 1)); } catch (e) {}
      if (tries >= 2) return; // the server / a proxy keeps the old page: do not loop
      toast('A new version — reloading…');
      setTimeout(() => location.reload(), 600);
    } catch (e) {}
  }
  // touch devices: no context menu, and no page drag from the emulator window or the on-screen panels (older iOS ignores
  // overscroll-behavior); text fields and scrolling lists inside the floating windows keep working
  const isField = (t) => t && t.closest && t.closest('input, textarea, select, .usel, [contenteditable]');
  document.addEventListener('contextmenu', (e) => { if (!isField(e.target)) e.preventDefault(); });
  document.addEventListener('touchmove', (e) => {
    const t = e.target;
    if (t && t.closest && t.closest('#mainwin, #vkbd') && !isField(t) && e.cancelable) e.preventDefault();
  }, { passive: false });
  document.addEventListener('selectstart', (e) => { if (!isField(e.target)) e.preventDefault(); });
  window.UnrealDebug = { pasteText: (t) => pasteText(t), get E() { return E; }, get fs() { return fs; }, cstr: (p) => cstr(p), get runRestore() { return runRestore; }, get macro() { return macro; }, get audio() { return audio; }, runMacro: (st) => runMacro(st), sdImage: (n) => sdImage(n), cardImage: (w) => cardImage(w), runLink: (q) => runLink(listRel(q, 'sd/')), ZK, UP, DOWN, get hud() { return hud; }, get model() { return model; }, loadBytes: (n, b, d) => loadBytes(n, b, d), setModel: (m, f) => setModel(m, f) }; // for tests and the console
  // ------------------------------------------------------------------ boot
  const boot = async () => { // the scripts may come after DOMContentLoaded (js/js.zip)
    bindUI();
    try {
      linkModel();
      await linkRom(); // rom= (Custom ROM ZIP) wins over model=
      linkHold = !!romLinkUrl && linkDisks() && !LINK.run && !LINK.cpm && !LINK.nedoos && !LINK.autorun;
      await start();
      modelUI(); mixUI();
      await osBoot(true);
      $('loading').remove();
      hiddenPaused = document.hidden;
      applyRunState();
      canvas.focus();
      requestAnimationFrame(tick);
      loadLocked(linkApply).finally(() => { linkHold = false; }).then(checkUpdate); // a newer build reloads the page only after the link's files are in
      swStart(); // offline copy (sw.js)
    } catch (err) {
      let msg = 'Startup error: ' + err.message;
      if (location.protocol === 'file:') msg += '<br>Open page through a web server.';
      $('loading').innerHTML = msg;
      console.error(err);
    }
  };
  if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', boot); else boot();
})();
