// Shader filters of the screen (Options / Video / Filter): xBR, Scale 3x, CRT, PAL. WebGL 2 on a canvas over the screen; the frame of
// the core is the texture, the machine's own pixels are read (a double-size frame: every other one, texelFetch).
// UnrealGL.create(canvas) -> null (no WebGL 2) or { draw(src, w, h, dbl, mode), size(cssW, cssH) }
(function () {
  'use strict';
  const VS = `#version 300 es
in vec2 p; out vec2 uv;
void main() { uv = vec2(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5); gl_Position = vec4(p, 0.0, 1.0); }`;
  const HEAD = `#version 300 es
precision highp float; precision highp int;
uniform sampler2D tex; uniform ivec2 src; uniform ivec2 stp; uniform vec2 outsz;
in vec2 uv; out vec4 o;
vec3 px(ivec2 q) { q = clamp(q, ivec2(0), src - 1); return texelFetch(tex, q * stp, 0).rgb; } // a pixel of the machine
`;
  // xBR level 2 (Hyllian, 2011-2016, MIT): the edges of pixel art found by weighted colour distances and drawn as lines of
  // 30, 45 and 60 degrees, without blur
  const XBR = HEAD + `
const vec4 Ao = vec4(1.0, -1.0, -1.0, 1.0), Bo = vec4(1.0, 1.0, -1.0, -1.0), Co = vec4(1.5, 0.5, -0.5, 0.5);
const vec4 Ax = vec4(1.0, -1.0, -1.0, 1.0), Bx = vec4(0.5, 2.0, -0.5, -2.0), Cx = vec4(1.0, 1.0, -0.5, 0.0);
const vec4 Ay = vec4(1.0, -1.0, -1.0, 1.0), By = vec4(2.0, 0.5, -2.0, -0.5), Cy = vec4(2.0, 0.0, -1.0, 0.5);
const vec4 Ci = vec4(0.25);
const vec3 Yw = vec3(14.352, 28.176, 5.472);
vec4 df(vec4 a, vec4 b) { return abs(a - b); }
vec4 neq(vec4 a, vec4 b) { return vec4(notEqual(a, b)); }
vec4 eq(vec4 a, vec4 b) { return vec4(lessThan(df(a, b), vec4(15.0))); }
vec4 nt(vec4 a) { return 1.0 - a; }
vec4 orv(vec4 a, vec4 b) { return min(a + b, 1.0); }
vec4 wd(vec4 a, vec4 b, vec4 c, vec4 d, vec4 e, vec4 f, vec4 g, vec4 h) { return df(a, b) + df(a, c) + df(d, e) + df(d, f) + 4.0 * df(g, h); }
float cdf(vec3 a, vec3 b) { vec3 d = abs(a - b); return d.r + d.g + d.b; }
vec4 Lv(vec3 a, vec3 b, vec3 c, vec3 d) { return vec4(dot(a, Yw), dot(b, Yw), dot(c, Yw), dot(d, Yw)); }
void main() {
  vec2 sp = uv * vec2(src); ivec2 q = ivec2(floor(sp)); vec2 fp = fract(sp);
  vec3 A1 = px(q + ivec2(-1, -2)), B1 = px(q + ivec2(0, -2)), C1 = px(q + ivec2(1, -2));
  vec3 A = px(q + ivec2(-1, -1)), B = px(q + ivec2(0, -1)), C = px(q + ivec2(1, -1));
  vec3 D = px(q + ivec2(-1, 0)), E = px(q), F = px(q + ivec2(1, 0));
  vec3 G = px(q + ivec2(-1, 1)), H = px(q + ivec2(0, 1)), I = px(q + ivec2(1, 1));
  vec3 G5 = px(q + ivec2(-1, 2)), H5 = px(q + ivec2(0, 2)), I5 = px(q + ivec2(1, 2));
  vec3 A0 = px(q + ivec2(-2, -1)), D0 = px(q + ivec2(-2, 0)), G0 = px(q + ivec2(-2, 1));
  vec3 C4 = px(q + ivec2(2, -1)), F4 = px(q + ivec2(2, 0)), I4 = px(q + ivec2(2, 1));
  vec4 b = Lv(B, D, H, F), c = Lv(C, A, G, I), e = Lv(E, E, E, E);
  vec4 d = b.yzwx, f = b.wxyz, g = c.zwxy, h = b.zwxy, i = c.wxyz;
  vec4 i4 = Lv(I4, C1, A0, G5), i5 = Lv(I5, C4, A1, G0), h5 = Lv(H5, F4, B1, D0), f4 = h5.yzwx;
  vec4 fx = Ao * fp.y + Bo * fp.x, fxl = Ax * fp.y + Bx * fp.x, fxu = Ay * fp.y + By * fp.x;
  vec4 r0 = neq(e, f) * neq(e, h);
  vec4 r1 = r0 * orv(orv(orv(nt(eq(f, b)) * nt(eq(f, c)), nt(eq(h, d)) * nt(eq(h, g))),
                         eq(e, i) * orv(nt(eq(f, f4)) * nt(eq(f, i4)), nt(eq(h, h5)) * nt(eq(h, i5)))), orv(eq(e, g), eq(e, c)));
  vec4 r2l = neq(e, g) * neq(d, g), r2u = neq(e, c) * neq(b, c);
  float dl = clamp(0.5 * float(src.x) / outsz.x, 0.05, 0.5); // the edges a bit soft, one output pixel wide
  vec4 dt = vec4(dl);
  vec4 f45i = clamp((fx + dt - Co - Ci) / (2.0 * dt), 0.0, 1.0), f45 = clamp((fx + dt - Co) / (2.0 * dt), 0.0, 1.0);
  vec4 f30 = clamp((fxl + dt - Cx) / (2.0 * dt), 0.0, 1.0), f60 = clamp((fxu + dt - Cy) / (2.0 * dt), 0.0, 1.0);
  vec4 w1 = wd(e, c, g, i, h5, f4, h, f), w2 = wd(h, d, i5, f, i4, b, e, i);
  vec4 edri = vec4(lessThanEqual(w1, w2)) * r0, edr = vec4(lessThan(w1, w2)) * r1;
  vec4 edrl = vec4(lessThanEqual(2.0 * df(f, g), df(h, c))) * r2l * edr, edru = vec4(greaterThanEqual(df(f, g), 2.0 * df(h, c))) * r2u * edr;
  f45 *= edr; f30 *= edrl; f60 *= edru; f45i *= edri;
  vec4 pxs = vec4(lessThanEqual(df(e, f), df(e, h)));
  vec4 m = max(max(f30, f60), max(f45, f45i));
  vec3 a1 = mix(E, mix(H, F, pxs.x), m.x); a1 = mix(a1, mix(B, D, pxs.z), m.z);
  vec3 a2 = mix(E, mix(F, B, pxs.y), m.y); a2 = mix(a2, mix(D, H, pxs.w), m.w);
  o = vec4(mix(a1, a2, step(cdf(E, a1), cdf(E, a2))), 1.0);
}`;
  // CRT: a slightly curved tube, the beam as a soft line (wider where it is brighter), the colours across blurred a little,
  // a phosphor mask when the screen is big enough to show it, darker corners
  const CRT = HEAD + `
vec3 lin(vec3 c) { return c * c; }
vec3 row(float y, float x) { // the line y across, blurred (Gaussian over 5 pixels), in linear light
  float xc = floor(x); vec3 s = vec3(0.0); float ws = 0.0;
  for (int k = -2; k <= 2; k++) { float t = xc + float(k) + 0.5 - x; float w = exp(-2.2 * t * t); s += w * lin(px(ivec2(int(xc) + k, int(y)))); ws += w; }
  return s / ws;
}
void main() {
  vec2 c = uv * 2.0 - 1.0; c *= 1.0 + vec2(0.020, 0.032) * (c.yx * c.yx); // curvature
  vec2 u = c * 0.5 + 0.5;
  if (u.x < 0.0 || u.y < 0.0 || u.x > 1.0 || u.y > 1.0) { o = vec4(0.0, 0.0, 0.0, 1.0); return; }
  vec2 sp = u * vec2(src); float y0 = floor(sp.y - 0.5), fy = sp.y - 0.5 - y0;
  vec3 a = row(y0, sp.x), b = row(y0 + 1.0, sp.x);
  float lines = outsz.y / float(src.y); // output pixels a line: scanlines only when there is room
  float sharp = lines >= 2.5 ? 1.0 : lines >= 1.6 ? 0.55 : 0.0;
  vec3 wa = exp(-pow(fy / (0.32 + 0.22 * sqrt(a)), vec3(2.0)) * 1.6), wb = exp(-pow((1.0 - fy) / (0.32 + 0.22 * sqrt(b)), vec3(2.0)) * 1.6);
  vec3 col = mix(mix(a, b, fy), (a * wa + b * wb) * 1.45, sharp);
  if (outsz.x / float(src.x) >= 2.5) { // aperture grille: R G B stripes of the output pixels
    float m = mod(gl_FragCoord.x, 3.0); vec3 mk = vec3(m < 1.0 ? 1.0 : 0.72, m >= 1.0 && m < 2.0 ? 1.0 : 0.72, m >= 2.0 ? 1.0 : 0.72);
    col *= mk * 1.18;
  }
  float v = (1.0 - 0.32 * dot(c * c, vec2(0.6, 0.8))); col *= v;
  o = vec4(sqrt(clamp(col, 0.0, 1.0)), 1.0);
}`;
  // Scale3x (AdvMAME, Andrea Mazzoleni): every pixel of the machine as 3x3, the corners of slopes filled from the neighbours
  // that agree; drawn without blur at any size (each of the 9 parts of a pixel picked by where the output pixel falls)
  const SC3 = HEAD + `
void main() {
  vec2 sp = uv * vec2(src); ivec2 q = ivec2(floor(sp)); ivec2 k = ivec2(min(floor(fract(sp) * 3.0), vec2(2.0)));
  vec3 A = px(q + ivec2(-1, -1)), B = px(q + ivec2(0, -1)), C = px(q + ivec2(1, -1));
  vec3 D = px(q + ivec2(-1, 0)), E = px(q), F = px(q + ivec2(1, 0));
  vec3 G = px(q + ivec2(-1, 1)), H = px(q + ivec2(0, 1)), I = px(q + ivec2(1, 1));
  vec3 r = E;
  if (B != H && D != F) {
    int n = k.y * 3 + k.x;
    if (n == 0) r = D == B ? D : E;
    else if (n == 1) r = (D == B && E != C) || (B == F && E != A) ? B : E;
    else if (n == 2) r = B == F ? F : E;
    else if (n == 3) r = (D == B && E != G) || (D == H && E != A) ? D : E;
    else if (n == 5) r = (B == F && E != I) || (H == F && E != C) ? F : E;
    else if (n == 6) r = D == H ? D : E;
    else if (n == 7) r = (D == H && E != I) || (H == F && E != G) ? H : E;
    else if (n == 8) r = H == F ? F : E;
  }
  o = vec4(r, 1.0);
}`;
  // PAL: a home TV's colour: the brightness about as sharp as the pixels, the colour (U, V) blurred over a few pixels across,
  // so fine patterns of two colours mix as they did on the TV
  const PAL = HEAD + `
const mat3 toY = mat3(0.299, -0.14713, 0.615, 0.587, -0.28886, -0.51499, 0.114, 0.436, -0.10001);
const mat3 toR = mat3(1.0, 1.0, 1.0, 0.0, -0.39465, 2.03211, 1.13983, -0.58060, 0.0);
void main() {
  vec2 sp = uv * vec2(src); float x = sp.x - 0.5; int y = int(sp.y); float xc = floor(x);
  float yy = 0.0, wy = 0.0; vec2 ch = vec2(0.0); float wc = 0.0;
  for (int k = -3; k <= 4; k++) {
    float t = xc + float(k) - x; vec3 s = toY * px(ivec2(int(xc) + k, y));
    float w1 = exp(-3.5 * t * t); yy += w1 * s.x; wy += w1;
    float w2 = exp(-0.35 * t * t); ch += w2 * s.yz; wc += w2;
  }
  o = vec4(clamp(toR * vec3(yy / wy, ch / wc), 0.0, 1.0), 1.0);
}`;

  function create(cv) {
    const gl = cv.getContext('webgl2', { alpha: false, antialias: false });
    if (!gl) return null;
    const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
    const vs = sh(gl.VERTEX_SHADER, VS), progs = {};
    const prog = (name) => {
      if (progs[name]) return progs[name];
      const p = gl.createProgram(); gl.attachShader(p, vs); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, { xbr: XBR, crt: CRT, pal: PAL, scale3x: SC3 }[name]));
      gl.bindAttribLocation(p, 0, 'p'); gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
      return (progs[name] = { p, src: gl.getUniformLocation(p, 'src'), stp: gl.getUniformLocation(p, 'stp'), outsz: gl.getUniformLocation(p, 'outsz'), tex: gl.getUniformLocation(p, 'tex') });
    };
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return {
      size(w, h) { const k = window.devicePixelRatio || 1, W = Math.max(1, Math.round(w * k)), H = Math.max(1, Math.round(h * k)); if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; } },
      draw(src, w, h, dbl, mode) { // src: ImageData of the frame (w × h); dbl: D0 doubled across, D1 doubled down
        const P = prog(mode);
        gl.bindTexture(gl.TEXTURE_2D, tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
        gl.viewport(0, 0, cv.width, cv.height); gl.useProgram(P.p);
        const sx = dbl & 1 ? 2 : 1, sy = dbl & 2 ? 2 : 1;
        gl.uniform2i(P.src, Math.floor(w / sx), Math.floor(h / sy)); gl.uniform2i(P.stp, sx, sy);
        gl.uniform2f(P.outsz, cv.width, cv.height); gl.uniform1i(P.tex, 0);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      },
      // the frame through the filter, k output pixels a pixel of the machine (of half the frame), read back (Screenshot "with the filter"): ImageData
      capture(src, w, h, dbl, mode, k) {
        const W = Math.round(w * k / 2), H = Math.round(h * k / 2); // the frame is 2x its pixels mostly: k of them a pixel, its shape kept
        const ow = cv.width, oh = cv.height; cv.width = W; cv.height = H;
        this.draw(src, w, h, dbl, mode);
        const px = new Uint8Array(W * H * 4); gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, px);
        cv.width = ow; cv.height = oh; this.draw(src, w, h, dbl, mode);
        const out = new ImageData(W, H), row = W * 4; // GL rows go up
        for (let y = 0; y < H; y++) out.data.set(px.subarray((H - 1 - y) * row, (H - y) * row), y * row);
        return out;
      },
    };
  }
  window.UnrealGL = { create };
})();
