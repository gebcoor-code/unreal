                      Quick Commander v3.23
             (C)1998-2026 Andrey Bogdanovich/Spectre
              Inspired by the boot "Max Petrov'96"
     ──────────────────────────────────────────────────────
     Powerful shell for TR-DOS and esxDOS. Main features:

     - Includes  all  necessary  tools for operating with 4
       drives: copying of files, disk compression, renaming
       of files, renaming of disks, pasting files together;
     - Works under esxDOS (DivMMC) with TRD images on an SD
       card,  and  can be its default boot (TRDBOOT.BIN) in
       place of TR-DOS Navigator;
     - 48Kb-1024Kb RAM of all standards support;
     - Support for code files launching;
     - Features  picture, font (768/2048 bytes) and  sprite
       viewers, and a musical player;
     - Text viewer with cp866 and UTF-8 autodetect; support
       colors and CR/CRLF/LF in text;
     - Hrust v2.x and ZX0 unpacking transparent support is
       available;
     - Full kempston mouse support;
     - Support for disks with more than 160 tracks;
     - Maximum  speed  of  disk  operations  due  to direct
       WD-1793 programming;
     - Russian language support for filenames is included;
     - Shadow  RAM  installation, installation  instead  of
       BASIC 128 is also possible;
     - Convenient color highlight of 24 various file types;
     - Color settings customization is available;
     - CMOS clock support;
     ──────────────────────────────────────────────────────
                       Site: www.zxby.org
